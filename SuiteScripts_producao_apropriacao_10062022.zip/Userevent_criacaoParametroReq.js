/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* Userevent aplicado ao suitelet de criação de parametros de modelos de requisição
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        // const ppp = ctx.newRecord.getSublists()
        // Log.error('ppp', ppp)
        // const x = ctx.form.getSublist({
        //     id: 'custpage_itens',
        // })
        // x.addField({
        //     id: "custpage_num_document",
        //     label: "Número Documento",
        //     type: UI.FieldType.TEXT
        // })
    };
    exports.beforeLoad = beforeLoad;
    // Após clicar no botão, os atributos serão armazenados na sublista
    var afterSubmit = function (ctx) {
        if (ctx.type === ctx.UserEventType.CREATE || ctx.type === ctx.UserEventType.EDIT) {
            //cria um array (itens), e dentro dele tem o item com os seguintes atributos para serem atribuidos a um JSON
            var itens = [];
            var item = {
                item: '',
                quantidade: '',
                fornecedor: '',
                unidades: '',
                descricao: '',
                taxaEstimada: 0,
                valorEstimado: 0
            };
            var quantItensLines = ctx.newRecord.getLineCount({
                sublistId: 'custpage_modelos_req'
            });
            for (var i = 0; i < quantItensLines; i++) {
                item.item = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_item',
                    line: i
                }));
                item.quantidade = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_quantidade',
                    line: i
                }));
                item.fornecedor = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_fornecedor',
                    line: i
                }));
                item.unidades = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_unidades',
                    line: i
                }));
                item.descricao = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_descricao',
                    line: i
                }));
                item.taxaEstimada = Number(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_taxa_estimada',
                    line: i
                }));
                item.valorEstimado = Number(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_valor_estimado',
                    line: i
                }));
                itens.push(item);
            }
        }
    };
    exports.afterSubmit = afterSubmit;
});
