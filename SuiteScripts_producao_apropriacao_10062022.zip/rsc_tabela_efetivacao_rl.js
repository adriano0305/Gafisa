/**
 *@NApiVersion 2.1
 *@NScriptType Restlet
 */
define(['N/https', 'N/log', 'N/record', 'N/search'], function(https, log, record, search) {
function formatData(data) {
    var partesData = data.split("/");

    var novaData = new Date(partesData[2], partesData[1] - 1, partesData[0]);

    return novaData;
}

function gerarReparcelamento2(campos) {
   log.audit('gerarReparcelamento2', campos);

    const reparcelamento2 = record.create({type: 'customrecord_rsc_reparcelamento_2', isDynamic: true});
    
    Object.keys(campos).forEach(function(bodyField) {
        if (bodyField != 'resumo') {
            switch(bodyField) {
                case 'custrecord_rsc_vencimento_entrada': 
                    reparcelamento2.setValue({
                        fieldId: bodyField, 
                        value: formatData(campos[bodyField])
                    });
                break;

                default: 
                reparcelamento2.setValue({
                    fieldId: bodyField, 
                    value: campos[bodyField]
                });
            }
        }        
    });

    const reparcelamento2Id = reparcelamento2.save();
    log.audit('reparcelamento2Id', reparcelamento2Id);

    if (reparcelamento2Id) {
        /** Para preenchimento do campo "Fatura Principal" com o id do contrato está sendo acionado o userEvent abaixo:
         * NOME: RSC Reparcelamento 2 Geral UE
         * URL: https://5843489-sb1.app.netsuite.com/app/common/scripting/script.nl?id=1146
         * MOTIVO: erro no preenchimento durante a criação do Reparcelamento 2. */
        log.audit('Aviso!', 'Para preenchimento do campo "Fatura principal" com o id do contrato está sendo acionado o userEvent: '+{
            nome: 'RSC Reparcelamento 2 Geral UE', url: 'https://5843489-sb1.app.netsuite.com/app/common/scripting/script.nl?id=1146'
        });

        campos.resumo.forEach(function (parcela) {
            const loadFinanciamentoInvoice = record.load({
                type: 'customsale_rsc_financiamento',
                id: parcela.parcela_contrato
            });
            log.audit('Parcela Nº: '+loadFinanciamentoInvoice.getValue('tranid'), 'Atualizando reparcelamento destino...');

            loadFinanciamentoInvoice.setValue({
                fieldId: 'custbody_rsc_reparcelamento_destino',
                value: reparcelamento2Id
            });

            loadFinanciamentoInvoice.save({ignoreMandatoryFields: true});
        });

        return reparcelamento2Id;
    } else {
        return null;
    }
}

function sublistaTabelaEfetivacao(filtros) {
    log.audit('sublistaTabelaEfetivacao', filtros);

    const bsc_sublista_tabela_efetivacao = search.create({type: "customrecord_rsc_sublista_tab_efetivacao",
        filters: filtros,
        columns: [
            "custrecord_rsc_resumo_reparcelamento","custrecord_rsc_tipo_parcela","custrecord_rsc_parcela","custrecord_rsc_prestacao"
        ]
    }).run().getRange(0,1000);
    log.audit('bsc_sublista_tabela_efetivacao: ', bsc_sublista_tabela_efetivacao);

    return bsc_sublista_tabela_efetivacao;
}

function _post(context) {
    log.audit('_post', context);

    var filtro = [["internalid","anyof",context.sublistId]];

    var bsc_linhas_parcelas = sublistaTabelaEfetivacao(filtro);    

    if (bsc_linhas_parcelas.length == 0) {
        return {
            status: 'Sublista Tabela Efetivação não localizada!'
        }
    }

    const idReneg = bsc_linhas_parcelas[0].getValue('custrecord_rsc_resumo_reparcelamento');

    const lkpTabelaEfetivacao = search.lookupFields({
        type: 'customrecord_rsc_tab_efetiva_reparcela',
        id: bsc_linhas_parcelas[0].getValue('custrecord_rsc_resumo_reparcelamento'),
        columns: [
            "internalid","custrecord_rsc_status_aprovacao","custrecord_rsc_contrato_fatura_principal","custrecord_rsc_cliente","custrecord_rsc_unidade","custrecord_rsc_total_fatura_principal",
            "custrecord_rsc_reparcelamento_2","custrecord_rsc_valor_financiado","custrecord_rsc_total_prestacoes_marcadas","custrecord_rsc_valor_total","custrecord_rsc_valor_da_entrada",
            "custrecord_rsc_reparcelar_em","custrecord_rsc_vencimento_da_entrada","custrecord_rsc_tipo_renegociacao","custrecord_rsc_novo_valor","custrecord_rsc_novo_vencimento","custrecord_rsc_primeiro_vencimento",
            "custrecord_rsc_juros_de_mora","custrecord_rsc_observacao_memo","custrecord_rsc_status_ter"
        ]
    });
    log.audit('lkpTabelaEfetivacao', lkpTabelaEfetivacao);    

    if (lkpTabelaEfetivacao.custrecord_rsc_status_aprovacao[0].value == '1') {
        return {
            status: lkpTabelaEfetivacao.custrecord_rsc_status_aprovacao[0].text, 
            mensagem: 'Tabela Efetivação '+lkpTabelaEfetivacao.internalid[0].value+' deve estar aprovada.'
        }
    }

    if (lkpTabelaEfetivacao.custrecord_rsc_status_aprovacao[0].value == '3') {
        return {
            status: lkpTabelaEfetivacao.custrecord_rsc_status_aprovacao[0].text
        }
    }
    
    if (lkpTabelaEfetivacao.custrecord_rsc_status_aprovacao[0].value == '4') {
        return {
            status: lkpTabelaEfetivacao.custrecord_rsc_status_aprovacao[0].text, 
            tabelaEfetivacao: lkpTabelaEfetivacao.internalid[0].value
        }
    }
    
    const loadTabelaEfetivacao = record.load({type: 'customrecord_rsc_tab_efetiva_reparcela', id: bsc_linhas_parcelas[0].getValue('custrecord_rsc_resumo_reparcelamento')});

    var parcelas = [];
    var resumo = [];

    for (i=0; i<bsc_linhas_parcelas.length; i++) {
        parcelas.push({
            tipoParcela: bsc_linhas_parcelas[i].getValue('custrecord_rsc_tipo_parcela'),
            parcela: bsc_linhas_parcelas[i].getValue('custrecord_rsc_parcela'),
            prestacao: bsc_linhas_parcelas[i].getValue('custrecord_rsc_prestacao')
        });
    }

    filtro = [
        // ["custrecord_rsc_resumo_reparcelamento","anyof",bsc_linhas_parcelas[0].getValue('custrecord_rsc_resumo_reparcelamento')], "AND", 
        ["custrecord_rsc_resumo_reparcelamento","anyof",idReneg], "AND", 
        ["internalid","noneof",context.sublistId]
    ];
    
    bsc_linhas_parcelas = sublistaTabelaEfetivacao(filtro); 

    if (bsc_linhas_parcelas.length > 0) {
        for (i=0; i<bsc_linhas_parcelas.length; i++) {
            parcelas.push({
                tipoParcela: bsc_linhas_parcelas[i].getValue('custrecord_rsc_tipo_parcela'),
                parcela: bsc_linhas_parcelas[i].getValue('custrecord_rsc_parcela'),
                prestacao: bsc_linhas_parcelas[i].getValue('custrecord_rsc_prestacao')
            });
        }
    }
    
    const bsc_linhasResumo = search.create({type: "customrecord_rsc_sublista_resumo",
        filters: [
            ["custrecord_rsc_resumo","anyof",idReneg]
        ],
        columns: [
            "custrecord_rsc_parcela_contrato"
        ]
    }).run().getRange(0,1000);
    log.audit('bsc_linhasResumo', bsc_linhasResumo);

    if (bsc_linhasResumo.length > 0) {
        for (i=0; i<bsc_linhasResumo.length; i++) {
            resumo.push({
                parcela_contrato: bsc_linhasResumo[i].getValue('custrecord_rsc_parcela_contrato')
            });
        }
    }

    const json = {
        tabelaEfetivacaoId: idReneg,
        contrato_fatura_principal: lkpTabelaEfetivacao.custrecord_rsc_contrato_fatura_principal[0].value,
        custrecord_rsc_tipo_renegociacao: lkpTabelaEfetivacao.custrecord_rsc_tipo_renegociacao[0].value,    
        custrecord_rsc_novo_valor: lkpTabelaEfetivacao.custrecord_rsc_novo_valor,
        custrecord_rsc_novo_vencimento: lkpTabelaEfetivacao.custrecord_rsc_novo_vencimento,
        reparcelamento2Id: gerarReparcelamento2({
            custrecord_rsc_total_financiado: lkpTabelaEfetivacao.custrecord_rsc_valor_financiado || 0,
            custrecord_rsc_total_parcelas_marcadas: lkpTabelaEfetivacao.custrecord_rsc_total_prestacoes_marcadas || 0,
            custrecord_custo_total: lkpTabelaEfetivacao.custrecord_rsc_valor_total || 0,
            custrecord_rsc_valor_entrada: lkpTabelaEfetivacao.custrecord_rsc_valor_da_entrada || 0,
            custrecord_rsc_vencimento_entrada: lkpTabelaEfetivacao.custrecord_rsc_vencimento_da_entrada || parcelas[0].parcela,
            // custrecord_rsc_fatura_principal: lkpTabelaEfetivacao.custrecord_rsc_contrato_fatura_principal[0].value,
            custrecord_rsc_id_fatura_principal: lkpTabelaEfetivacao.custrecord_rsc_contrato_fatura_principal[0].value,
            custrecord_rsc_enviado: true,
            custrecord_rsc_status: 1,
            resumo: resumo
        }),
        parcelas: parcelas,
        resumo: resumo        
    };
    log.audit('json', json);

    // Suitelet: RSC Fatura Novas Parcelas 2 ST
    const response = https.post({
        url: 'https://5843489-sb1.extforms.netsuite.com/app/site/hosting/scriptlet.nl?script=995&deploy=1&compid=5843489_SB1&h=fc3cbe0ae05453aaef22',
        body: JSON.stringify(json)
    });
    log.audit('code: '+response.code, 'body: '+response.body);

    if (response.code == 200) {
        var loadReg = record.load({type: 'customrecord_rsc_tab_efetiva_reparcela', id: idReneg});
        log.audit('loadReg', loadReg);
        loadReg.setValue({fieldId: 'custrecord_rsc_reparcelamento_2', value: json.reparcelamento2Id})
        .save({ignoreMandatoryFields: true});

        return {status: 'Sucesso'}
    }
    
    return {status: 'Erro!', msg: 'Houve um erro no envio da solicitação. Tente novamente.'}
}

function _get(context) {
    log.audit('_get', context);

    const loadReg = record.load({type: 'invoice', id: 52082});
    log.audit('Fatura: '+loadReg.getValue('tranid'), 'Atualizando status de aprovação...');

    loadReg.setValue('approvalstatus', 2).save();
}

function _put(context) {
    
}

function _delete(context) {
    
}

return {
    get: _get,
    post: _post,
    put: _put,
    delete: _delete
}
});
