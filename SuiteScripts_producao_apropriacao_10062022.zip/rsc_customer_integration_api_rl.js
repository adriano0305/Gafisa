/**
 * @NApiVersion 2.x
 * @NScriptType restlet
 */
 define(['N/search', 'N/record', 'N/log', './rsc_integration_api_helper.js', '../../SuiteScripts/custom/Debugging'], function (search, record, log, integration, debugging) {
    function get(context) {
        var action = context['action'];
        return getActions[action](context);
    }
    
    function post(context) {
        if(typeof context === 'string') {context = JSON.parse(context);}
        var action = context['action'];
        return postActions[action](context);
    }
    
    const getActions = {
        search: function (context) {
            var filter = context['search'] ? [
                ["entityid", "haskeywords", context['search']], "OR",
                ["altname", "haskeywords", context['search']], "OR",
                ["custentity_enl_cnpjcpf", "haskeywords", context['search']], "OR",
                ["email", "haskeywords", context['search']]
            ] : []
    
            var customers = [];
            var customerSearchObj = search.create({type: "customer",
                filters: filter,
                columns: [
                    //"isinactive","isperson","altname","mobilephone","phone","custentity_enl_cnpjcpf","custentity_rsc_rg","email","entitystatus",
                    "isinactive","isperson","altname","mobilephone","phone","custentity_enl_cnpjcpf","email","entitystatus",
                    //"subsidiary","datecreated","globalsubscriptionstatus",
                    "subsidiary","datecreated",
                    search.createColumn({name: "lastmodifieddate", sort: search.Sort.DESC, label: "Última alteração"})
                ]
            });
            var searchResultCount = customerSearchObj.runPaged().count;
            log.debug("customerSearchObj result count", searchResultCount);
    
            const MAX_PAGE_SIZE = context.maxpagesize || 30;
            var pagedData = customerSearchObj.runPaged({pageSize: MAX_PAGE_SIZE});
            var countPage = pagedData.pageRanges.length;
            var actualPage = 0
            if (context.page) {
                actualPage = context.page
            }
    
            pagedData.fetch({index: actualPage}).data.forEach(function (result) {
                var customer = {};
                customer['id'] = result['id'];
                customer['isinactive'] = result.getValue('isinactive');
                customer['isperson'] = result.getValue('isperson');
                customer['name'] = result.getValue('altname');
                customer['mobilephone'] = result.getValue('mobilephone');
                customer['phone'] = result.getValue('phone');
                //customer['rg'] = result.getValue('custentity_rsc_rg');
                customer['cpfcnpj'] = result.getValue('custentity_enl_cnpjcpf');
                customer['email'] = result.getValue('email');
                customer['subsidiary'] = result.getValue('subsidiary');
                customer['datecreated'] = result.getValue('datecreated');
                customer['lastmodifieddate'] = result.getValue('lastmodifieddate');
                //customer['emailmarketing'] = result.getValue(' globalsubscriptionstatus') == '1';
                customers.push(customer);
                return true;
            });
    
            var lastPage = countPage - 1
            return JSON.stringify({
                'customers': customers,
                'pagination': {
                    'itemsPerPage': MAX_PAGE_SIZE,
                    'currentPage': actualPage,
                    'nextPage': actualPage == lastPage ? false : (actualPage + 1),
                    'lastPage': lastPage
                }
            })
        },
    
        details: function (context) {
            var customerRec = record.load({type: 'customer', id: context['id'], isDynamic: true});
            var customer = {}
            customer.id = customerRec['id'];
            var valuesToGet = {
                'isperson': "isperson",
                'email': "email",
                'phone': "phone",
                'mobilephone': "mobilephone",
                'altphone': 'altphone',
                'custentity_rsc_bday': "birthday",
                'custentity_enl_cnpjcpf': "cpfcnpj"
            };
    
            customer['subsidiary'] = {'id': customerRec.getValue({fieldId: "subsidiary"}), 'name': customerRec.getText({fieldId: "subsidiary"})};
            customer['emailmarketing'] = customerRec.getValue({fieldId: "globalsubscriptionstatus"}) == '1';
            customer['category'] = {'id': customerRec.getValue({fieldId: "category"}), 'name': customerRec.getText({fieldId: "category"})};
            customer['gender'] = {
                'id': customerRec.getValue({fieldId: "custentity_rsc_gen"}), 
                'name': customerRec.getText({fieldId: "custentity_rsc_gen"})
            };
    
            if (customerRec.getValue('isperson') == 'T') {
                valuesToGet['firstname'] = "firstname"; valuesToGet['lastname'] = "lastname"; valuesToGet['custentity_rsc_rg'] = "rg";
            } else {
                valuesToGet['companyname'] = "companyname";
                valuesToGet['custentity_enl_legalname'] = "legalname";
                valuesToGet['custentity_enl_ienum'] = "ienum";
                valuesToGet['custentity_enl_ccmnum'] = "im";
            }
            log.audit({title: 'valuesToGet', details: valuesToGet});
    
            Object.keys(valuesToGet).forEach(function (field) {customer[valuesToGet[field]] = customerRec.getValue({fieldId: field})});
            customer['creditmemoamount'] = getCreditMemoAmount(customer['id']);
            customer['address'] = []
    
            var addressCount = customerRec.getLineCount({sublistId: "addressbook"})
            if (addressCount > 0) {
                valuesToGet = {
                    'addrtext': "addrtext",
                    'country': "country",
                    'zip': "zipcode",
                    'addr1': "addr",
                    'custrecord_enl_numero': "number",
                    'addr2': "complement",
                    'addr3': "district"
                }
    
                for (var line = 0; line < addressCount; line++) {
                    customerRec.selectLine({sublistId: 'addressbook', line: line});
                    var addressSubrecord = customerRec.getCurrentSublistSubrecord({sublistId: 'addressbook', fieldId: 'addressbookaddress'});
    
                    var address = {};
                    address['addressid'] = customerRec.getSublistValue({sublistId: 'addressbook', fieldId: 'addressid', line: line});
                    address['line'] = line;
                    address['label'] = customerRec.getSublistValue({sublistId: 'addressbook', fieldId: 'label', line: line});
                    address['defaultbilling'] = customerRec.getSublistValue({sublistId: 'addressbook', fieldId: 'defaultbilling', line: line});
                    address['defaultshipping'] = customerRec.getSublistValue({sublistId: 'addressbook', fieldId: 'defaultshipping', line: line});
                    address['town'] = {
                        'id': addressSubrecord.getValue({fieldId: "custrecord_enl_city"}), 
                        'name': addressSubrecord.getText({fieldId: "custrecord_enl_city"})
                    };
                    address['state'] = {
                        'id': addressSubrecord.getValue({fieldId: "custrecord_enl_uf"}),
                        'name': addressSubrecord.getText({fieldId: "custrecord_enl_uf"})
                    };
    
                    Object.keys(valuesToGet).forEach(function (field) {
                        address[valuesToGet[field]] = addressSubrecord.getValue({fieldId: field})
                    });
                    customer['address'].push(address)
                }
            }
            return {'customer': customer}
        },
        townList: function (context) {
            var filter = [["custrecord_enl_citystate", "anyof", context.state]];
            if (context['search']) {
                filter = [
                    ["name", "haskeywords", "São"], "AND",
                    ["custrecord_enl_citystate", "anyof", "25"]
                ];
            }
            var customrecord_enl_citiesSearchObj = search.create({type: "customrecord_enl_cities",
                filters: filter,
                columns: [
                    "custrecord_enl_citystate","name","custrecord_enl_ibgecode"
                ]
            });
            var searchResultCount = customrecord_enl_citiesSearchObj.runPaged().count;
            log.debug("customrecord_enl_citiesSearchObj result count", searchResultCount);
    
            towns = [];
            customrecord_enl_citiesSearchObj.run().each(function (result) {
                towns.push({
                    'id': result.id,
                    'state': {id: result.getValue('custrecord_enl_citystate'), name: result.getText('custrecord_enl_citystate')},
                    'name': result.getValue('name'),
                    'ibge': result.getValue('custrecord_enl_ibgecode')
                });
                return true;
            });
            return {'towns': towns};
        },
        ufList: function (context) {
            var customlist_enl_stateSearchObj = search.create({type: "customlist_enl_state",
                filters: [],
                columns: [
                    "name"
                ]
            });
            var searchResultCount = customlist_enl_stateSearchObj.runPaged().count;
            log.debug("customlist_enl_stateSearchObj result count", searchResultCount);
    
            var states = []
            customlist_enl_stateSearchObj.run().each(function (result) {
                states.push({'id': result.id, 'name': result.getValue('name')});
                return true;
            });
            return {'states': states}
        },
        category: function (context) {
            var customercategorySearchObj = search.create({type: "customercategory",
                filters: [],
                columns: [
                    "name"
                ]
            });
            var searchResultCount = customercategorySearchObj.runPaged().count;
            log.debug("customrecord_sit_cod_pagtoSearchObj result count", searchResultCount);
    
            var categories = [];
            customercategorySearchObj.run().each(function (result) {
                var category = {};
                category['id'] = result['id'];
                category['name'] = result.getValue('name');
                categories.push(category);
                return true;
            });
            return {'categories': categories}
        },
        existCPFCNPJ: function (value) {
            var customerSearchObj = search.create({type: "customer",
                filters: [
                    ["formulatext: {custentity_enl_cnpjcpf}", "is", context['cpfcnpj']]
                ],
                columns: [
                    "entityid"
                ]
            });
            var searchResultCount = customerSearchObj.runPaged().count;
            log.debug("customerSearchObj result count", searchResultCount);
    
            var exist = false;
            customerSearchObj.run().each(function (result) {exist = result['id']; return true;});
            return {'customer': exist};
        }
    };
    
    const postActions = {create: function (context) {return createEdit(context)}, edit: function (context) {return createEdit(context);}};
    
    function toDate(dateStr) {var parts = dateStr.split("-"); return new Date(parts[0], parts[1] - 1, parts[2])}
    
    function createEdit(context) {
        log.audit('context', context);
        
        var customer;
        if (context['id']) {customer = record.load({type: 'customer', id: context['id'], isDynamic: true});} 
        else {            
            var cpfCpnj = false;
            var e_mail = false;
            
            search.create({type: 'customer',
                filters: [
                    search.createFilter({name: 'custentity_enl_cnpjcpf', operator: search.Operator.IS, values: context['cpfcnpj']}),
                    search.createFilter({name: 'email', operator: search.Operator.IS, values: context['email']})
                ]
            }).run().each(function(resultEmailCPF) {
                cpfCpnj = true;
                e_mail = true;
                context['id'] = resultEmailCPF['id'];
            });
    
            if (cpfCpnj && e_mail){
                return {
                    "status": "Warning", 
                    "internal Id": context['id'],
                    "message": "Customer already exists ( CPF/CNPJ: " + context.cpfcnpj + " ) , ( E-mail: " + context.email + " )"
                };
            }
    
            if (!customer) {customer = record.create({type: 'customer', isDynamic: true})}
        }
    
        const valuesToSet = {
            // 'isperson': context['isperson'],
            'email': context['email'],
            'phone': context['phone'].replace(/\s/g, ''),
            'mobilephone': context['mobilephone'].replace(/\s/g, ''),
            'altphone': context['altphone'],
            'subsidiary': context['subsidiary'],
            'category': context['category'],
            'custentity_enl_cnpjcpf': context['cpfcnpj'],
            'globalsubscriptionstatus': context['emailmarketing'] ? 1 : 2
        };
    
        // if (context['phone'] || context['mobilephone']) {
        //     valuesToSet['phone'] = context['phone'].replace(/\s/g, '');
        //     valuesToSet['mobilephone'] = context['mobilephone'].replace(/\s/g, '');
        // }
    
        if (context['isperson'] == 'T' && context['cpfcnpj']['length'] == 11) {
            valuesToSet['isperson'] = context['isperson'];
            valuesToSet['firstname'] = context['firstname'];
            valuesToSet['lastname'] = context['lastname'];
            valuesToSet['legalname'] = context['legalname'];
        } else {
            valuesToSet['isperson'] = 'F';
            log.audit('isperson?', valuesToSet['isperson']);
            if (context['companyname']) {
                valuesToSet['companyname'] = context['companyname'];
                valuesToSet['custentity_enl_legalname'] = context['legalname'];
                valuesToSet['custentity_enl_ienum'] = context['ienum'];
            } else {
                valuesToSet['companyname'] = context['legalname'] = context['firstname']+' '+context['lastname'];
                // context['legalname'] = context['firstname']+' '+context['lastname'];
                valuesToSet['custentity_enl_legalname'] = context['legalname'];
                valuesToSet['custentity_enl_ienum'] = context['ienum'];
            }
            // valuesToSet['companyname'] = context['companyname'];
            // valuesToSet['custentity_enl_legalname'] = context['legalname'];
            // valuesToSet['custentity_enl_ienum'] = context['ienum'];
            // Tendo IE, marca o cliente como "Contribuinte de ICMS".
            if (valuesToSet['custentity_enl_ienum']) {customer.setValue('custentity_enl_statetaxpayer', true);}
            valuesToSet['custentity_enl_ccmnum'] = context['im'];
        }
    
        integration.getCustomFields({recordtype: integration['recordtype']['customer']}).forEach(function (customField) {
            valuesToSet[customField['fieldns']] = integration.convertValue(
                context[customField['fieldjson']], customField['type'], customField['script'], customField['method']
            );
        });
        
        Object.keys(valuesToSet).forEach(function (field) {customer.setValue(field, valuesToSet[field])});
    
        context['address'].forEach(function (address) {
            if (address['addr']['length'] < 3) log.audit('address["addr"]: '+address['addr'], 'Adding "Rua" to the address...');
            if (!address['country']) address['country'] = "BR";
            const valuesToSet = {
                'country': address['country'],
                'zip': address['zipcode'],
                'addr1': address['addr']['length'] < 3 ? 'Rua '+address['addr'] : address['addr'],
                'custrecord_enl_numero': String(address['number']),
                'addr2': address['complement'],
                'addr3': address['district'],
                'custrecord_enl_city': address['town'],
                'custrecord_enl_uf': address['state'],
                'defaultbilling': address['defaultbilling'] || false,
                'defaultshipping': address['defaultshipping'] || false
            }
            log.audit('valuesToSet', valuesToSet);
    
            integration.getCustomFields({recordtype: integration['recordtype']['customer'], sublist: "address"})
            .forEach(function (customField) {valuesToSet[customField['fieldns']] = 
                integration.convertValue(address[customField['fieldjson']], customField['type'], customField['script'], customField['method']);
            });
    
            /**Para efeitos de array: informar no json o índice do endereço no campo line 
             * Sublista json: "address" */         
            if (address['line'] || address['line'] == 0) {customer.selectLine({sublistId: 'addressbook', line: address['line']});} 
            else {customer.selectNewLine('addressbook')}
    
            var addressSubrecord = customer.getCurrentSublistSubrecord('addressbook', 'addressbookaddress');
    
            customer.setCurrentSublistValue('addressbook', 'label', address['label'])
            .setCurrentSublistValue('addressbook', 'defaultbilling', address['defaultbilling'] || false)
            .setCurrentSublistValue('addressbook', 'defaultshipping', address['defaultshipping'] || false);
            
            Object.keys(valuesToSet).forEach(function (field) {addressSubrecord.setValue(field, valuesToSet[field])});
            customer.commitLine('addressbook')
        })
    
        var id = customer.save({enableSourcing: true, ignoreMandatoryFields: true});
        log.audit('customerId', id);
        // Load the client and send in the object json the "from-to" with the id of the NS addresses and admin
        customer = record.load({type: 'customer', id: id});
    
        var allAddress = customer.getLineCount('addressbook');
        var customersData = {'idCustomer': id, 'address': []}
    
        for (i=0; i < allAddress; i++){
            customersData.address.push({
                'idnetsuite': customer.getSublistValue('addressbook', 'internalid', i),
                'address_id': context['address'][i] && context['address'][i]['address_id'],
                'line': i
            });
        }
    
        if(context['id']) {return {'status': 'Changed', 'customer': customersData}}
        else {return {'status': 'Sucess', 'customer': customersData}}    
    }
    
    function getCreditMemoAmount(customer) {
        var creditmemoSearchObj = search.create({type: "creditmemo",
            filters: [
                ["type","anyof","CustCred"], "AND",
                ["mainline","is","T"], "AND",
                ["status","anyof","CustCred:A"], "AND",
                ["customer.internalidnumber", "equalto", customer]
            ],
            columns: [
                "amountremaining"
            ]
        });
        var searchResultCount = creditmemoSearchObj.runPaged().count;
        var amount = 0;
        creditmemoSearchObj.run().each(function (result) {amount += Number(result.getValue('amountremaining')); return true;});
        return amount;
    }
    
    return {'get': get, 'post': post}
    });