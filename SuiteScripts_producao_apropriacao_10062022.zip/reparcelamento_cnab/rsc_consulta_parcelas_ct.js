/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*/

const custPage = 'custpage_rsc_';

define(['./renegociacao/rsc_tabela_renegociacao.js', 'N/currentRecord', 'N/ui/dialog', 'N/url', 'N/search'], function(reneg, currentRecord, dialog, url, search) {
function novaConsulta() {
    dialog.alert({
        title: 'Aviso!',
        message: 'Em construção...'
    });
}

function validarDataVencimento(dataInicio) {
    // console.log('validarDataVencimento: '+dataInicio);

    var partesData = dataInicio.split("/");

    var dataVencParcela = new Date(partesData[2], partesData[1] - 1, partesData[0]);

    return dataVencParcela > new Date() ? true : false;
}

function gravarSimulacao() {
    const registroAtual = currentRecord.get();

    const clienteTarefa = {
        id: registroAtual.getValue(custPage+'cliente_tarefa'),
        nome: registroAtual.getText(custPage+'cliente_tarefa')
    }

    const fatura = registroAtual.getValue(custPage+'memo_contrato');

    const listaParcelas = custPage+'sublista_lista_parcelas';

    const quantidadeParcelas = registroAtual.getValue(custPage+'quantidade_parcelas');

    const primeiroVencimento = {
        value: registroAtual.getValue(custPage+'primeiro_vencimento'),
        text: registroAtual.getText(custPage+'primeiro_vencimento')
    }

    const periodicidade = {
        id: registroAtual.getValue(custPage+'periodicidade'),
        nome: registroAtual.getText(custPage+'periodicidade')
    };
    
    const observacao = registroAtual.getValue(custPage+'observacao');

    if (!quantidadeParcelas) {
        dialog.alert({
            title: 'Aviso',
            message: 'Quantidade de Parcelas não informado.'
        });

        return false;
    } else if (!primeiroVencimento) {
        dialog.alert({
            title: 'Aviso',
            message: 'Primeiro Vencimento não informado.'
        });

        return false;
    } else if (!periodicidade) {
        dialog.alert({
            title: 'Aviso',
            message: 'Periodicidade não informado.'
        });

        return false;
    } else {
        for (i=0; i<registroAtual.getLineCount(listaParcelas); i++) {
            var cliente_tarefa_linha = registroAtual.getSublistText(listaParcelas, custPage+'cliente_tarefa_linha', i);

            if (cliente_tarefa_linha != clienteTarefa.nome) {
                dialog.alert({
                    title: 'Aviso',
                    message: 'As parcelas não pertencem ao cliente selecionado.'
                });

                return false;
            }
        }
    }
    
    if (primeiroVencimento.text != '' && validarDataVencimento(primeiroVencimento.text) == false) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Primeiro vencimento deve ser maior que a data de hoje.'
        });

        return false;
    }

    var json = {
        dadosGerais: {
            clienteTarefa: clienteTarefa,
            fatura: fatura
        },
        simulacao: {
            quantidadeParcelas: quantidadeParcelas,
            primeiroVencimento: primeiroVencimento,
            periodicidade: periodicidade,
            observacao: observacao
        }
    }

    var totalParcelas = 0;

    var arrayParcelas = [];

    for (i=0; i<registroAtual.getLineCount(listaParcelas); i++) {
        var reparcelar = registroAtual.getSublistValue(listaParcelas, custPage+'reparcelar', i);
        
        if (reparcelar == true) {
            arrayParcelas.push({
                linha: registroAtual.getSublistValue(listaParcelas, custPage+'linha', i),
                id_financiamento_invoice: parseInt(registroAtual.getSublistValue(listaParcelas, custPage+'id_financiamento_invoice', i)),
                vencimento: registroAtual.getSublistValue(listaParcelas, custPage+'vencimento', i),
                valor: registroAtual.getSublistValue(listaParcelas, custPage+'valor_original', i)
            });

            totalParcelas += Number(registroAtual.getSublistValue(listaParcelas, custPage+'valor_original', i));
        }
    }

    if (arrayParcelas.length == 0) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Selecione ao menos uma parcela.'
        });

        return false;
    } 

    json.simulacao.totalParcelas = totalParcelas;
    json.simulacao.novasParcelas = totalParcelas / quantidadeParcelas
    json.arrayParcelas = arrayParcelas;
    console.log('json: '+JSON.stringify(json));

    var gerarRenegociacao = reneg.reneg(json);
    console.log('gerarRenegociacao: '+JSON.stringify(gerarRenegociacao));
    
    var campo_tabela_renegociacao, campo_erro;

    if (gerarRenegociacao.status == 'Sucesso') {
        var link = "https://5843489-sb1.app.netsuite.com";

        registroAtual.setValue(custPage+'tabela_renegociacao', link + gerarRenegociacao.url);

        window.open(link + gerarRenegociacao.url, '_blank');
    } else {
        dialog.alert({
            title: 'Erro!',
            message: 'Verifique o campo "Erro".'
        });

        registroAtual.setValue(custPage+'erro', gerarRenegociacao.msg);
    }
}

function voltar() {
    dialog.alert({
        title: 'Aviso!',
        message: 'Em andamento... \. '+
        'Redirect para o Suitelet.'
    })
}

function pageInit(context) {
    const registroAtual = context.currentRecord;

    var campoFatura = registroAtual.getField({
        fieldId: custPage+'fatura'
    });

    campoFatura.isDisabled = true;
}

function saveRecord(context) {
    
}

function validateField(context) {
    
}

function fieldChanged(context) {
    const registroAtual = context.currentRecord;

    const listaParcelas = custPage+'sublista_lista_parcelas';

    var campo = context.fieldId;

    if (campo == custPage+'cliente_tarefa') {
        var clienteTarefa = registroAtual.getValue(campo);

        if (clienteTarefa != '') {
            var bscFatura = search.create({type: "invoice",
                filters: [
                   ["shipping","is","F"], "AND", 
                   ["taxline","is","F"], "AND", 
                   ["mainline","is","T"], "AND", 
                   ["type","anyof","CustInvc"], "AND", 
                   ["customermain.internalid","anyof",clienteTarefa]
                ],
                columns: [
                   "internalid","tranid"
                ]
            }).run().getRange(0,1000);
            
            if (bscFatura.length > 0) {
                for (i=0; i<bscFatura.length; i++) {
                    var campoFatura = registroAtual.getField({
                        fieldId: custPage+'fatura'
                    });

                    campoFatura.isDisabled = false;

                    campoFatura.insertSelectOption({
                        value: bscFatura[i].id,
                        // text: 'Fatura Nº '+bscFatura[i].getValue('tranid')
                        text: bscFatura[i].getValue('tranid')
                    });
                }
            } else {
                dialog.alert({
                    title: 'Aviso!',
                    message: 'Não existem faturas para o cliente selecionado.'
                });

                registroAtual.setValue(custPage+'fatura', '');

                if (registroAtual.getLineCount(listaParcelas) > 0) {
                    for (i=0; i<registroAtual.getLineCount(listaParcelas); i++) {
                        console.log('Remover linha: '+i);

                        registroAtual.removeLine({
                            sublistId: listaParcelas,
                            line: i
                        });
                    }
                }
            }
        } else {
            if (registroAtual.getLineCount(listaParcelas) > 0) {
                for (i=0; i<registroAtual.getLineCount(listaParcelas); i++) {
                    console.log('Remover linha: '+i);

                    registroAtual.removeLine({
                        sublistId: listaParcelas,
                        line: i
                    });
                }
            }
        }
    }
}

function postSourcing(context) {
    
}

function lineInit(context) {
    
}

function validateDelete(context) {
    
}

function validateInsert(context) {
    
}

function validateLine(context) {
    
}

function sublistChanged(context) {
    
}

return {
    novaConsulta: novaConsulta,
    gravarSimulacao: gravarSimulacao,
    voltar: voltar,
    pageInit: pageInit,
    // saveRecord: saveRecord,
    // validateField: validateField,
    fieldChanged: fieldChanged,
    // postSourcing: postSourcing,
    // lineInit: lineInit,
    // validateDelete: validateDelete,
    // validateInsert: validateInsert,
    // validateLine: validateLine,
    // sublistChanged: sublistChanged
}
});
