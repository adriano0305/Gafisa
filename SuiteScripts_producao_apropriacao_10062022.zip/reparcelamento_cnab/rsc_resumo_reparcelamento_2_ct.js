/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*/

const custPage = 'custpage_rsc_';

define(['N/currentRecord', 'N/https', 'N/log', 'N/search', 'N/ui/dialog', 'N/url'], function(currentRecord, https, log, search, dialog, url) {
function checarStatus() {
    const registroAtual = currentRecord.get();

    const idReparcelamento2 = registroAtual.getValue({fieldId: custPage+'id_reparcelamento_2'});

    const idTabelaEfetivacao = registroAtual.getValue({fieldId: custPage+'id_tabela_efetivacao_reparcelamento'});

    if (idReparcelamento2) {
        var status = search.lookupFields({type: 'customrecord_rsc_reparcelamento_2',
            id: idReparcelamento2,
            columns: ['custrecord_rsc_status']
        }).custrecord_rsc_status[0].text;

        dialog.alert({
            title: 'Status',
            message: status
        });
    }

    if (idTabelaEfetivacao) {
        var status = search.lookupFields({type: 'customrecord_rsc_tab_efetiva_reparcela',
            id: idTabelaEfetivacao,
            columns: ['custrecord_rsc_status_ter']
        }).custrecord_rsc_status_ter[0].text;

        dialog.alert({
            title: 'Status',
            message: status
        });
    }
}

function gerarReparcelamento() {
    const registroAtual = currentRecord.get();
    
    const resumoReparcelamento = custPage+'sublista_resumo_reparcelamento';

    const efetivarApos1Pagamento = registroAtual.getValue({fieldId: custPage+'efetivar_apos_1_pagamento'});

    var arrayResumoReparcelamento = [];
    
    var enviado = registroAtual.getValue({fieldId: custPage+'enviado'});

    if (enviado == true) {
        dialog.alert({
            title: 'Aviso!',
            message: 'A solicitação já foi enviada.'
        });
    } else {        
        for (i=0; i<registroAtual.getLineCount({sublistId: resumoReparcelamento}); i++) {
            registroAtual.selectLine({
                sublistId: resumoReparcelamento,
                line: i
            });

            var ano = registroAtual.getSublistValue({
                sublistId: resumoReparcelamento,
                fieldId: custPage+'ano',
                line: i
            });

            var parcela = registroAtual.getSublistValue({
                sublistId: resumoReparcelamento,
                fieldId: custPage+'parcela',
                line: i
            });

            var prestacao = registroAtual.getSublistValue({
                sublistId: resumoReparcelamento,
                fieldId: custPage+'prestacao',
                line: i
            });

            var juros = registroAtual.getSublistValue({
                sublistId: resumoReparcelamento,
                fieldId: custPage+'juros',
                line: i
            });

            arrayResumoReparcelamento.push({
                ano: ano,
                parcela: parcela,
                prestacao: prestacao
                // ,
                // juros: juros
            });
        }

        const json = {
            efetivarApos1Pagamento: efetivarApos1Pagamento,
            reparcelamento: registroAtual.getValue({fieldId: custPage+'json_reparcelamento'}),
            novasParcelas: JSON.stringify(arrayResumoReparcelamento)
        }

        // Suitelet: RSC Fatura Novas Parcelas 2 ST
        const response = https.post({
            url: 'https://5843489-sb1.extforms.netsuite.com/app/site/hosting/scriptlet.nl?script=995&deploy=1&compid=5843489_SB1&h=fc3cbe0ae05453aaef22',
            body: json
        });

        if (response.code == 200) {
            registroAtual.setValue({
                fieldId: custPage+'enviado',
                value: true
            });

            registroAtual.setValue({
                fieldId: custPage+'tarefa',
                value: response.body
            });
        } else {
            dialog.alert({
                title: 'Erro',
                message: 'Houve um erro no envio da solicitação. Tente novamente.'
            });
        }
    }
}

function voltar() {
    const registroAtual = currentRecord.get();

    const idReparcelamento2 = registroAtual.getValue({fieldId: custPage+'id_reparcelamento_2'});

    const idTabelaEfetivacao = registroAtual.getValue({fieldId: custPage+'id_tabela_efetivacao_reparcelamento'});

    const linkReparcelamento2 = registroAtual.getValue({fieldId: custPage+'link_reparcelamento_2'});

    const linkTabelaEfetivacao = registroAtual.getValue({fieldId: custPage+'link_tabela_efetivacao_reparcelamento'});  
    
    var status;
    
    if (idReparcelamento2 || linkReparcelamento2) {
        status = search.lookupFields({type: 'customrecord_rsc_reparcelamento_2',
            id: idReparcelamento2,
            columns: ['custrecord_rsc_status']
        }).custrecord_rsc_status[0].text;

        if (status == 'Em andamento') {
            dialog.alert({
                title: 'Aviso!',
                message: 'Operação em andamento. Aguarde...'
            });

            return false;
        } else {
            history.go(-4); // Fatura Principal
        }       
    } else if (idTabelaEfetivacao || linkTabelaEfetivacao) {
        status = search.lookupFields({type: 'customrecord_rsc_tab_efetiva_reparcela',
            id: idTabelaEfetivacao,
            columns: ['custrecord_rsc_status_ter']
        }).custrecord_rsc_status_ter[0].text;

        if (status == 'Em andamento') {
            dialog.alert({
                title: 'Aviso!',
                message: 'Operação em andamento. Aguarde...'
            });

            return false;
        } else {
            history.go(-4); // Fatura Principal
        }
    } else {
        history.back();
    }
}

function pageInit(context) {
    log.audit('pageInit', context);
}

function saveRecord(context) {
    log.audit('saveRecord', context);
}

function validateField(context) {
    log.audit('validateField', context);
}

function fieldChanged(context) {
    log.audit('fieldChanged', context);
}

function postSourcing(context) {
    log.audit('postSourcing', context);
}

function lineInit(context) {
    log.audit('lineInit', context);
}

function validateDelete(context) {
    log.audit('validateDelete', context);
}

function validateInsert(context) {
    log.audit('validateInsert', context);
}

function validateLine(context) {
    log.audit('validateLine', context);
}

function sublistChanged(context) {
    log.audit('sublistChanged', context);
}

return {
    checarStatus: checarStatus,
    gerarReparcelamento: gerarReparcelamento,
    voltar: voltar,
    pageInit: pageInit,
    // saveRecord: saveRecord,
    // validateField: validateField,
    // fieldChanged: fieldChanged,
    // postSourcing: postSourcing,
    // lineInit: lineInit,
    // validateDelete: validateDelete,
    // validateInsert: validateInsert,
    // validateLine: validateLine,
    // sublistChanged: sublistChanged
}
});
