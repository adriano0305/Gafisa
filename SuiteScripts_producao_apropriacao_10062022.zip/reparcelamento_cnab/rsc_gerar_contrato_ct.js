/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*/

const custPage = 'custpage_rsc_';

define(['N/currentRecord', 'N/ui/dialog', 'N/url', 'N/search'], function(currentRecord, dialog, url, search) {
function checarStatus() {
    const registroAtual = currentRecord.get();

    const idContrato = registroAtual.getValue(custPage+'id_contrato');

    if (idContrato) {
        bscFinanciamentoInvoice = search.create({type: "transaction",
            filters: [
               ["shipping","is","F"], "AND", 
               ["taxline","is","F"], "AND", 
               ["mainline","is","T"], "AND", 
               ["type","anyof","CuTrSale123"], "AND", 
               ["custbody_lrc_fatura_principal.internalid","anyof",idContrato]
            ],
            columns: [
               search.createColumn({name: "datecreated", summary: "GROUP", sort: search.Sort.DESC, label: "Data da criação"}),
               search.createColumn({name: "tranid", summary: "GROUP", label: "Número do documento"}),
               search.createColumn({name: "entity", summary: "GROUP", label: "Nome"}),
               search.createColumn({name: "total", summary: "MAX", label: "Valor (Total da transação)"}),
            ]
        }).run().getRange(0,1000);


        if (bscFinanciamentoInvoice.length > 0) {
            dialog.alert({
                title: 'Aviso!',
                message: 'Parcelas geradas: '+bscFinanciamentoInvoice.length+'.'
            });
            return false
        } else {
            dialog.alert({
                title: 'Aviso!',
                message: 'Nenhuma parcela gerada (até o momento)...'
            });

            return false;
        }
    }
}

function voltar() {
    const registroAtual = currentRecord.get();

    const idContrato = registroAtual.getValue(custPage+'id_contrato');

    const quantidadeParcelas = Number(registroAtual.getValue(custPage+'quantidade_parcelas'));

    if (idContrato) {
        bscFinanciamentoInvoice = search.create({type: "transaction",
            filters: [
               ["shipping","is","F"], "AND", 
               ["taxline","is","F"], "AND", 
               ["mainline","is","T"], "AND", 
               ["type","anyof","CuTrSale123"], "AND", 
               ["custbody_lrc_fatura_principal.internalid","anyof",idContrato]
            ],
            columns: [
               search.createColumn({name: "datecreated", summary: "GROUP", sort: search.Sort.DESC, label: "Data da criação"}),
               search.createColumn({name: "tranid", summary: "GROUP", label: "Número do documento"}),
               search.createColumn({name: "entity", summary: "GROUP", label: "Nome"}),
               search.createColumn({name: "total", summary: "MAX", label: "Valor (Total da transação)"}),
            ]
        }).run().getRange(0,1000);

        
        if (bscFinanciamentoInvoice.length < quantidadeParcelas) {
            dialog.alert({
                title: 'Aviso!',
                message: 'Operação em andamento. Aguarde...'
            });

            return false;
        } else {
            history.back();
        }
    }    
}

function compararDatas(dt1, dt2) {
    // console.log('compararDatas: '+{dt1: dt1, dt2: dt2});

    var partesDt1 = dt1.split("/");
    var partesDt2 = dt2.split("/");

    var vencDt1 = new Date(partesDt1[2], partesDt1[1] - 1, partesDt1[0]);
    var vencDt2 = new Date(partesDt2[2], partesDt2[1] - 1, partesDt2[0]);

    return vencDt1 > vencDt2 ? true : false;
} 

function gerarContrato() {
    const registroAtual = currentRecord.get();

    // Informações Principais
    const clienteTarefa = registroAtual.getText(custPage+'cliente_tarefa');
    const dataInicio = registroAtual.getValue(custPage+'data_inicio');
    const dataTermino = registroAtual.getValue(custPage+'data_termino');
    const entregarAte = registroAtual.getValue(custPage+'entregar_ate');
    const memo = registroAtual.getValue(custPage+'memo');

    // Classificação
    const subsidiaria = registroAtual.getText(custPage+'subsidiaria');
    const localidade = registroAtual.getText(custPage+'localidade');
    const nomeProjeto = registroAtual.getText(custPage+'nome_projeto');

    // Dados do Contrato
    const numeroProposta = registroAtual.getValue(custPage+'numero_proposta');
    const statusContrato = registroAtual.getText(custPage+'status_contrato');
    const unidade = registroAtual.getText(custPage+'unidade');

    // Faturamento
    const valorFinanciamento = registroAtual.getValue(custPage+'valor_financiamento');
    const quantidadeParcelas = registroAtual.getValue(custPage+'quantidade_parcelas');
    const valoresParcelas = registroAtual.getValue(custPage+'valores_parcelas');

    if (!clienteTarefa) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Cliente : Tarefa não-informado.'
        });

        return false;
    } else if (!dataInicio) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Data Início não-informado.'
        });

        return false;
    } else if (!dataTermino) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Data Término não-informado.'
        });

        return false;
    } else if (!entregarAte) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Entregar Até não-informado.'
        });

        return false;
    } else if (!subsidiaria) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Subsidiária não-informada.'
        });

        return false;
    } else if (!localidade) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Localidade não-informado.'
        });

        return false;
    } else if (!nomeProjeto) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Nome do Projeto não-informado.'
        });

        return false;
    } else if (!numeroProposta) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Número da Proposta não-informado.'
        });

        return  false;
    } else if (!statusContrato) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Status do Contrato não-informado.'
        });

        return false;
    } else if (!unidade) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Unidade não-informado.'
        });

        return false;
    } else if (!valorFinanciamento) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Valor do Financiamento não-informado.'
        });

        return false;
    } else if (!quantidadeParcelas) {
        dialog.alert({
            title: 'Aviso!',
            message: 'Quantidade de Parcelas não-informada.'
        });

        return false;
    } else {
        // dialog.alert({
        //     title: 'Aviso!',
        //     message: 'Todos os campos foram preenchidos.'
        // });

        // return false;

        // var json = JSON.stringify({
        //     clienteTarefa: clienteTarefa,
        //     dataInicio: dataInicio,
        //     dataTermino: dataTermino,
        //     entregarAte: entregarAte,
        //     memo: memo,
        //     subsidiaria: subsidiaria,
        //     localidade: localidade,
        //     nomeProjeto: nomeProjeto,
        //     numeroProposta: numeroProposta,
        //     statusContrato: statusContrato,
        //     unidade: unidade,
        //     valorFinanciamento: valorFinanciamento,
        //     quantidadeParcelas: quantidadeParcelas,
        //     valoresParcelas: valoresParcelas
        // });
        // console.log('json: '+json);

        urlGerarContratoSuitelet2 = url.resolveScript({
            scriptId: 'customscript_rsc_gerar_contrato_st',
            deploymentId: 'customdeploy_rsc_gerar_contrato_st_2',
            params: {
                json: JSON.stringify({
                    clienteTarefa: clienteTarefa,
                    dataInicio: dataInicio,
                    dataTermino: dataTermino,
                    entregarAte: entregarAte,
                    memo: memo,
                    subsidiaria: subsidiaria,
                    localidade: localidade,
                    nomeProjeto: nomeProjeto,
                    numeroProposta: numeroProposta,
                    statusContrato: statusContrato,
                    unidade: unidade,
                    valorFinanciamento: valorFinanciamento,
                    quantidadeParcelas: quantidadeParcelas,
                    valoresParcelas: valoresParcelas
                })
            }
        }); 

        console.log('urlGerarContratoSuitelet2', urlGerarContratoSuitelet2);

        document.location = urlGerarContratoSuitelet2;  
    }  
}

function pageInit(context) {
    
}

function saveRecord(context) {
    
}

function validateField(context) {
    
}

function fieldChanged(context) {
    // console.log('fieldChanged: '+JSON.stringify(context));

    const registroAtual = context.currentRecord;

    var campo = context.fieldId;

    if (campo == custPage+'valor_financiamento') {
        var valorFinanciamento = registroAtual.getValue(custPage+'valor_financiamento');
    
        var quantidadeParcelas = Number(registroAtual.getValue(custPage+'quantidade_parcelas'));

        registroAtual.setValue(
            custPage+'valores_parcelas', 
            quantidadeParcelas ? (valorFinanciamento / quantidadeParcelas).toFixed(2) : valorFinanciamento
        );              
    }

    if (campo == custPage+'quantidade_parcelas') {    
        var quantidadeParcelas = Number(registroAtual.getValue(custPage+'quantidade_parcelas'));

        var valorFinanciamento = registroAtual.getValue(custPage+'valor_financiamento');

        registroAtual.setValue(
            custPage+'valores_parcelas', 
            valorFinanciamento ? (valorFinanciamento / quantidadeParcelas).toFixed(2) : 0
        );        
    }
    
    if (campo == custPage+'data_inicio') {    
        var dataInicio = registroAtual.getText(custPage+'data_inicio');

        var dataTermino = registroAtual.getText(custPage+'data_termino');

        if (dataTermino) {
            if (compararDatas(dataTermino, dataInicio) == false) {
                dialog.alert({
                    title: 'Aviso!',
                    message: 'Data Término não pode ser menor que Data Início.'
                });

                return false;
            }
        }  
    } 

    if (campo == custPage+'data_termino') {    
        var dataTermino = registroAtual.getText(custPage+'data_termino');

        var dataInicio = registroAtual.getText(custPage+'data_inicio');   
        
        if (dataInicio) {
            if (compararDatas(dataTermino, dataInicio) == false) {
                dialog.alert({
                    title: 'Aviso!',
                    message: 'Data Término não pode ser menor que Data Início.'
                });

                return false;
            }
        } 
    }

    if (campo == custPage+'entregar_ate') { 
        var entregarAte = registroAtual.getText(custPage+'entregar_ate');

        var dataTermino = registroAtual.getText(custPage+'data_termino');

        var dataInicio = registroAtual.getText(custPage+'data_inicio');   
        
        if (dataInicio) {
            if (compararDatas(entregarAte, dataInicio) == false) {
                dialog.alert({
                    title: 'Aviso!',
                    message: 'Entregar Até não pode ser menor que Data Início.'
                });

                return false;
            }
        } 

        if (dataTermino) {
            if (compararDatas(entregarAte, dataTermino) == false) {
                dialog.alert({
                    title: 'Aviso!',
                    message: 'Entregar Até não pode ser menor que Data Término.'
                });

                return false;
            }
        } 
    }
}

function postSourcing(context) {
    
}

function lineInit(context) {
    
}

function validateDelete(context) {
    
}

function validateInsert(context) {
    
}

function validateLine(context) {
    
}

function sublistChanged(context) {
    
}

return {
    checarStatus: checarStatus,
    voltar: voltar,
    gerarContrato: gerarContrato,
    // pageInit: pageInit,
    // saveRecord: saveRecord,
    // validateField: validateField,
    fieldChanged: fieldChanged,
    // postSourcing: postSourcing,
    // lineInit: lineInit,
    // validateDelete: validateDelete,
    // validateInsert: validateInsert,
    // validateLine: validateLine,
    // sublistChanged: sublistChanged
}
});
