/**
 *@NApiVersion 2.1
 *@NScriptType ClientScript
 */
define(['N/currentRecord', 'N/log', 'N/search', 'N/ui/dialog'], function(currentRecord, log, search, dialog) {
function pageInit(context) {
    log.audit('pageInit', context);

    const registroAtual = context.currentRecord;
}

function saveRecord(context) {
    log.audit('saveRecord', context);

    const registroAtual = context.currentRecord;

    const subsidiaria = registroAtual.getValue('custrecord_rsc_subsidiaria');

    const localidade = registroAtual.getValue('custrecord_rsc_localidade');

    var bsc_parametros_renegociacao = search.create({type: "customrecord_rcs_parametros_renegociacao",
        filters: [
           ["custrecord_rsc_subsidiaria","anyof",subsidiaria], "AND", 
           ["custrecord_rsc_localidade","anyof",localidade]
        ],
        columns: [
            "created","custrecord_rsc_subsidiaria","custrecord_rsc_localidade"
        ]
    });

    var resultados = bsc_parametros_renegociacao.runPaged().count;

    if (resultados > 0) {
        log.audit('resultados', resultados);

        if (!registroAtual.id) {
            dialog.alert({
                title: 'Aviso!',
                message: 'Já existe um parâmetro de renegociação.'
            });
        }        
    } else {
        dialog.alert({
            title: 'Aviso!',
            message: 'Este parâmentro é novo! Pode salvar...'
        });
        
        return false;
    }

    return true;
}

function validateField(context) {
    
}

function fieldChanged(context) {
    
}

function postSourcing(context) {
    
}

function lineInit(context) {
    
}

function validateDelete(context) {
    
}

function validateInsert(context) {
    
}

function validateLine(context) {
    
}

function sublistChanged(context) {
    
}

return {
    pageInit: pageInit,
    saveRecord: saveRecord,
    // validateField: validateField,
    // fieldChanged: fieldChanged,
    // postSourcing: postSourcing,
    // lineInit: lineInit,
    // validateDelete: validateDelete,
    // validateInsert: validateInsert,
    // validateLine: validateLine,
    // sublistChanged: sublistChanged
}
});
