/**
 *@NApiVersion 2.1
 *@NScriptType MapReduceScript
 */
 define(['N/record','N/search'], function(record,search) {

    function getSearchEtapa1(){
            //etapa 1
        
        var accountSearchObj = search.create({
            type: "account",
            filters:
            [
               ["type","anyof","AcctRec","Bank","OthCurrAsset","FixedAsset","AcctPay","OthCurrLiab","CredCard","OthAsset","UnbilledRec","DeferExpense","NonPosting","OthExpense","OthIncome","Expense","DeferRevenue","COGS","Income","Equity","LongTermLiab","Stat"], 
               "AND", 
               ["balance","between","0.00","0.00"], 
               "AND", 
               ["description","startswith","A"]
            ],
            columns:
            [
               search.createColumn({
                  name: "name",
                  sort: search.Sort.ASC,
                  label: "Nome"
               }),
               search.createColumn({name: "displayname", label: "Nome de exibição (traduzido)"}),
               search.createColumn({name: "type", label: "Tipo da conta"}),
               search.createColumn({name: "description", label: "Descrição"}),
               search.createColumn({name: "balance", label: "Saldo"})
            ]
         });
         var searchResultCount = accountSearchObj.runPaged().count;
         log.debug("accountSearchObj result count",searchResultCount);
         return accountSearchObj;
         

    }

    function getSearchEtapa2(){
        //etapa 2
        var accountSearchObj = search.create({
            type: "account",
            filters:
            [
               ["type","anyof","Bank","AcctRec","OthCurrAsset","FixedAsset","OthAsset","AcctPay","CredCard","OthCurrLiab","LongTermLiab","Equity","Income","COGS","OthIncome","Expense","OthExpense","DeferRevenue","NonPosting","DeferExpense","UnbilledRec","Stat"], 
               "AND", 
               ["balance","between","0.00","0.00"], 
               "AND", 
               ["description","isnotempty",""]
            ],
            columns:
            [
               search.createColumn({name: "number", label: "Número"}),
               search.createColumn({
                  name: "name",
                  sort: search.Sort.ASC,
                  label: "Nome"
               }),
               search.createColumn({name: "type", label: "Tipo da conta"}),
               search.createColumn({name: "balance", label: "Saldo"}),
               search.createColumn({name: "description", label: "Descrição"})
            ]
         });
         var searchResultCount = accountSearchObj.runPaged().count;
         log.debug("accountSearchObj result count","qtde de registros para exclusão: "+searchResultCount);
         return accountSearchObj;
         
        
    }

    function getSearchEtapa3(){
        var accountSearchObj = search.create({
            type: "account",
            filters:
            [
               ["type","anyof","Bank","AcctRec","OthCurrAsset","FixedAsset","OthAsset","CredCard","AcctPay","OthCurrLiab","Income","Equity","LongTermLiab","COGS","Expense","OthIncome","Stat","DeferExpense","DeferRevenue","OthExpense","NonPosting","UnbilledRec"], 
               "AND", 
               ["number","contains","_old"]
            ],
            columns:
            [
               search.createColumn({
                  name: "name",
                  sort: search.Sort.ASC,
                  label: "Nome"
               }),
               search.createColumn({name: "displayname", label: "Nome de exibição (traduzido)"}),
               search.createColumn({name: "type", label: "Tipo da conta"}),
               search.createColumn({name: "description", label: "Descrição"}),
               search.createColumn({name: "balance", label: "Saldo"}),
               search.createColumn({name: "custrecord_fam_account_showinfixedasset", label: "Show in Fixed Assets Management"}),
               search.createColumn({name: "custrecord_avlr_acct_taxcompliance", label: "Integrado ao TaxCompliance"}),
               search.createColumn({name: "custrecord_acctbudgetdefn_cc", label: "Budget Definition Level"}),
               search.createColumn({name: "custrecord_excludebudcheck_cc", label: "Exclude From Budget Check"})
            ]
         });
         var searchResultCount = accountSearchObj.runPaged().count;
         log.debug("accountSearchObj result count","qtde de registros para exclusão: "+searchResultCount);
         return accountSearchObj;
            
    }




    function getInputData() {
            /*
        var _search = search.load({id:"customsearch1150"});
        var searchResult = _search.runSearch();
        return searchResult;
            */

        return getSearchEtapa3();
        
         
         
    }

    function map(context) {
            
        const srcResult = JSON.parse(context.value);
        log.debug('map', "recordtype : "+srcResult.recordType+"  "+srcResult.id);
        
        var rec = record.load({type: srcResult.recordType, id: srcResult.id});
        
        /*
        let text = search.lookupFields({
            type: srcResult.recordType,
            id: srcResult.id,
            columns: ['acctnumber']
        });
        */

        let text = rec.getValue({fieldId: 'acctnumber'});
        log.debug("----old value----",text);
        text = text.replace('_old','');
        log.debug("----new value----",text);
        
        rec.setValue({fieldId: 'acctnumber', value: text});
        rec.save();
        
        //log.debug('srcResult', "recordtype : "+srcResult.recordType+"  "+srcResult.id);
        /*
        let acct = record.delete(
            {
                type: srcResult.recordType,
                id: srcResult.id
            });
        */

        log.audit('registro deletado ', 'accountid: '+acct);

        //const tipo = srcResult.recordType;
        
    }

    function reduce(context) {
        
    }

    function summarize(summary) {

        var type = summary.toString();
        log.audit(type,
            '"Uso Consumido:" ' + summary.usage +
            ', "Número de Filas:" ' + summary.concurrency +
            ', "Quantidade de Saídas:" ' + summary.yields
        );
        var contents = '';
        summary.output.iterator().each(function (key, value) {
            contents += (key + ' ' + value + '\n');
            return true;
        });
        
    }

    return {
        getInputData: getInputData,
        map: map,
        reduce: reduce,
        summarize: summarize
    }
});
