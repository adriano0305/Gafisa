/**
 *@NApiVersion 2.x
 *@NScriptType MapReduceScript
 *
 * @author Wilson
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/query", "N/log", "N/record", "N/search"], function (require, exports, query_1, log_1, record_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.reduce = exports.getInputData = void 0;
    query_1 = __importDefault(query_1);
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    exports.getInputData = function () {
        // const sql = 'SELECT custentity_rsc_pende_atua_subsdiarias, id, entityid FROM vendor WHERE custentity_rsc_pende_atua_subsdiarias IS 0'
        // const query_result = query.runSuiteQL({
        //    query: sql
        // }).asMappedResults();
        // log.debug('REsult', query_result)
        return search_1.default.create({
            type: 'vendor',
            filters: ['custentity_rsc_pende_atua_subsdiarias', 'IS', 'F']
        });
    };
    exports.reduce = function (ctx) {
        var result = ctx.values;
        var json_result = JSON.parse(result[0]);
        var id = json_result["id"];
        // const result = JSON.parse(ctx["values"])
        // const id = result["id"]
        var sql = "SELECT id, iselimination FROM subsidiary WHERE id != 12 AND iselimination = 'F'";
        var query_result = query_1.default.runSuiteQL({
            query: sql
        }).asMappedResults();
        var len = query_result.length;
        log_1.default.debug('Len', len);
        // log.debug('Result', vendor_record)
        for (var i = 0; i < len; i++) {
            var sub_array = Array();
            log_1.default.debug('Lsita', sub_array);
            var vendor_record = record_1.default.load({
                type: 'vendor',
                id: id
            });

            var lines = vendor_record.getLineCount({ sublistId: 'submachine' });
            for (var x = 0; x < lines; x++) {
                var d = vendor_record.getSublistValue({
                    sublistId: 'submachine',
                    fieldId: 'subsidiary',
                    line: x
                });
                sub_array.push(Number(d));
            }
            var dados = query_result[i];
            var index = sub_array.indexOf(dados["id"]);
            log_1.default.debug('Daods', dados);
            try {
                // var sublista = vendor_record.selectNewLine({sublistId: 'submachine'})
                if (index == -1) {
                    vendor_record.setSublistValue({
                        fieldId: 'subsidiary',
                        sublistId: 'submachine',
                        line: i,
                        value: dados["id"]
                    });
                    // vendor_record.commitLine({
                    //    sublistId:'submachine'
                    // })
                    vendor_record.setValue({
                        fieldId: 'custentity_rsc_pende_atua_subsdiarias',
                        value: true
                    });
                    var id_vendo = vendor_record.save({
                        ignoreMandatoryFields: true
                    });
                    log_1.default.audit('ID do forcedor', id_vendo);
                }
            }
            catch (e) {
                log_1.default.error('Erro', e);
            }
        }
    };
});
