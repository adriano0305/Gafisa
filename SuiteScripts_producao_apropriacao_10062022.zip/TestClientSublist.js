/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * TestClientSublist.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log"], function (require, exports, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateLine = exports.validateInsert = exports.validateDelete = exports.fieldChanged = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    exports.fieldChanged = function (ctx) {
        var currRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        log_1.default.error("fieldId", fieldId);
        if (fieldId == "custrecord1409") {
            currRecord.setValue({
                fieldId: "custpage_lrc_check_validate",
                value: false
            });
            var rec = void 0;
            if (currRecord.getValue(fieldId)) {
                rec = record_1.default.load({
                    type: "customrecord_lrc_teste2",
                    id: currRecord.getValue(fieldId)
                });
            }
            var n = 0;
            if (rec) {
                n = rec.getValue("custrecord1410") || 0;
            }
            var sublistSize = currRecord.getLineCount("custpage_lrc_test");
            log_1.default.error("sublistSize", sublistSize);
            for (var i = sublistSize - 1; i >= 0; i--) {
                currRecord.removeLine({
                    sublistId: "custpage_lrc_test",
                    line: i
                });
            }
            for (var i = 0; i < n; i++) {
                currRecord.selectNewLine({
                    sublistId: "custpage_lrc_test"
                });
                currRecord.setCurrentSublistValue({
                    sublistId: "custpage_lrc_test",
                    fieldId: "custpage_lrc_criterio",
                    value: currRecord.getValue("custrecord1409"),
                    ignoreFieldChange: true
                });
                currRecord.setCurrentSublistValue({
                    sublistId: "custpage_lrc_test",
                    fieldId: "custpage_lrc_criterio_description",
                    value: "Descrição",
                    ignoreFieldChange: true
                });
                currRecord.setCurrentSublistValue({
                    sublistId: "custpage_lrc_test",
                    fieldId: "custpage_lrc_criterio_peso",
                    value: parseInt(n),
                    ignoreFieldChange: true
                });
                currRecord.commitLine({
                    sublistId: "custpage_lrc_test"
                });
            }
            currRecord.setValue({
                fieldId: "custpage_lrc_check_validate",
                value: true
            });
        }
    };
    exports.validateDelete = function (ctx) {
        log_1.default.error("validateInsert", { ctx: ctx, validate: ctx.currentRecord.getValue("custpage_lrc_check_validate") });
        if (ctx.sublistId == "custpage_lrc_test") {
            if (ctx.currentRecord.getValue("custpage_lrc_check_validate")) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos a partir do modelo");
                return false;
            }
            return true;
        }
    };
    exports.validateInsert = function (ctx) {
        log_1.default.error("validateInsert", { ctx: ctx, validate: ctx.currentRecord.getValue("custpage_lrc_check_validate") });
        if (ctx.sublistId == "custpage_lrc_test") {
            if (ctx.currentRecord.getValue("custpage_lrc_check_validate")) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos a partir do modelo");
                return false;
            }
            return true;
        }
    };
    exports.validateLine = function (ctx) {
        log_1.default.error("validateLine", { ctx: ctx, validate: ctx.currentRecord.getValue("custpage_lrc_check_validate") });
        var sublistIndex = ctx.currentRecord.getCurrentSublistIndex({ sublistId: "custpage_lrc_test" });
        log_1.default.error("sublistIndex", sublistIndex);
        var sublistCount = ctx.currentRecord.getLineCount({ sublistId: "custpage_lrc_test" });
        log_1.default.error("sublistCount", sublistCount);
        if (ctx.sublistId == "custpage_lrc_test") {
            var avaliacao = ctx.currentRecord.getValue();
            var clause = ();
            if (ctx.currentRecord.getValue("custpage_lrc_check_validate") && sublistIndex == sublistCount) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos a partir do modelo");
                return false;
            }
            return true;
        }
    };
});
