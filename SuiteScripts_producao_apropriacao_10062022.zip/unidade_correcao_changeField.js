"use strict";
/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
*changeField_unidade_correcao.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const _fieldChanged = exports.pageInit = void 0;
export { _fieldChanged as fieldChanged };
var log_1 = __importDefault(require("N/log"));
import { FieldDisplayType } from "@hitc/netsuite-types/N/ui/serverWidget";
var pageInit = function (ctx) {
    var currentRecord = ctx.currentRecord;
    var campoCorrecao = currentRecord.getValue('custrecord_lrc_tipo_correcao');
    log_1.default.error('Campo correção', campoCorrecao);
    if (campoCorrecao == 2) {
        log_1.default.error('entrou', 'if');
        currentRecord.getField('custrecord_lrc_valor_fixo').updateDisplayType({
            displayType: FieldDisplayType.NORMAL
        });
        currentRecord.getField('custrecord_lrc_fator_add_sub_uc').updateDisplayType({
            displayType: FieldDisplayType.DISABLED
        });
    }
    else {
        currentRecord.getField('custrecord_lrc_valor_fixo').updateDisplayType({
            displayType: FieldDisplayType.DISABLED
        });
        currentRecord.getField('custrecord_lrc_fator_add_sub_uc').updateDisplayType({
            displayType: FieldDisplayType.NORMAL
        });
    }
};
const _pageInit = pageInit;
export { _pageInit as pageInit };
var fieldChanged = function (ctx) {
    var currentRecord = ctx.currentRecord;
    var campoCorrecao = currentRecord.getValue('custrecord_lrc_tipo_correcao');
    log_1.default.error('Campo correção', campoCorrecao);
    if (campoCorrecao == 2) {
        log_1.default.error('entrou', 'if');
        currentRecord.getField('custrecord_lrc_valor_fixo').updateDisplayType({
            displayType: FieldDisplayType.NORMAL
        });
        currentRecord.getField('custrecord_lrc_fator_add_sub_uc').updateDisplayType({
            displayType: FieldDisplayType.DISABLED
        });
    }
    else {
        currentRecord.getField('custrecord_lrc_valor_fixo').updateDisplayType({
            displayType: FieldDisplayType.DISABLED
        });
        currentRecord.getField('custrecord_lrc_fator_add_sub_uc').updateDisplayType({
            displayType: FieldDisplayType.NORMAL
        });
    }
};
const _fieldChanged = fieldChanged;
export { _fieldChanged as fieldChanged };
