/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*/

define(['N/currentRecord', 'N/ui/dialog', 'N/url', 'N/search'], function(currentRecord, dialog, url, search) {
function pageInit(context) {}

function saveRecord(context) {}

function validateField(context) {}

function fieldChanged(context) {
    log.audit('context', context);
    console.log('context', JSON.stringify(context));
    const registroAtual = context.currentRecord;

    const campo = context.fieldId;

    const line = context.line;

    if (campo == 'memo') {
        var memo = registroAtual.getValue(campo);

        if (memo == 'PV') {
            for (i=0; i<registroAtual.getLineCount('item'); i++) {
                var item = registroAtual.getSublistValue('item', 'item', i);

                if (item == 19420) {
                    log.audit(i, {removerItem: item});
                    console.log(i, {removerItem: item});
                    registroAtual.removeLine('item', i);
                }
            }
        }
    }
}

function postSourcing(context) {}

function lineInit(context) {}

function validateDelete(context) {}

function validateInsert(context) {}

function validateLine(context) {}

function sublistChanged(context) {}

return {
    pageInit: pageInit,
    // saveRecord: saveRecord,
    // validateField: validateField,
    fieldChanged: fieldChanged,
    // postSourcing: postSourcing,
    // lineInit: lineInit,
    // validateDelete: validateDelete,
    // validateInsert: validateInsert,
    // validateLine: validateLine,
    // sublistChanged: sublistChanged
}
});
