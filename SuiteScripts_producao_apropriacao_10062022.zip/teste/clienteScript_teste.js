/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScprit_simulacao_reparcelamento
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/search", "N/url", "N/log"], function (require, exports, currentRecord_1, search_1, url_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.envio = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    search_1 = __importDefault(search_1);
    url_1 = __importDefault(url_1);
    log_1 = __importDefault(log_1);
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var envio = function () {
        var record = currentRecord_1.default.get();
        console.log('teste');
        var array = [];
        console.log('array', array);
        search_1.default.create({
            type: 'customrecord_lrc_unidade_correcao',
        }).run().each(function (result) {
            array.push(result.id);
            return true;
        });
        var enviar = url_1.default.resolveScript({
            scriptId: 'customscript_lrc_teste_recebe',
            deploymentId: 'customdeploy_lrc_teste_recebe',
            params: {
                array: JSON.stringify(array)
            },
        });
        log_1.default.error("Enviar", enviar);
        window.location.replace(enviar);
    };
    exports.envio = envio;
});
