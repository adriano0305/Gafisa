/**
 *@NApiVersion 2.1
*@NScriptType MapReduceScript
*/
define(['N/log', 'N/query', 'N/record', 'N/search', 'N/transaction'], (log, query, record, search, transaction) => {
const getInputData =  (context) => {
    log.audit('getInputData', context);

    return search.create({type: "invoice",
        filters: [
           ["shipping","is","F"], "AND", 
           ["taxline","is","F"], "AND", 
           ["mainline","is","T"], "AND", 
           ["type","anyof","CustInvc"]
        //    , "AND", 
        //    ["custbody_rsc_cnab_inst_locationba_ls","anyof","449"]
        ],
        columns: [
            "datecreated","internalid","tranid","custbody_rsc_cnab_inst_locationba_ls"
        ]
    });
}

const map = (context) => {
    log.audit('map', context);

    const src = JSON.parse(context.value);
    log.audit('src', src);

    const agenciaBancaria = 449; // Agência 000 - Cobrança
    const disponivel = 1; // Disponível

    const loadReg = record.load({type: 'invoice', id: src.id});

    try {
        loadReg.setValue('custbody_rsc_cnab_inst_locationba_ls', agenciaBancaria)
        // .setValue('custbody_rsc_cnab_inst_status_ls', disponivel)
        .save({ignoreMandatoryFields: true});
        log.audit('Sucesso!', {tranid: src.values.tranid});
    } catch(e) {
        log.audit('Erro!', {tranid: src.values.tranid, msg: e});
    }    
}

const reduce = (context) => {
    log.audit('reduce', context);
}

const summarize = (summary) => {
    var type = summary.toString();
    log.audit(type, 
        '"Uso Consumido:" '+summary.usage+
        ', "Número de Filas:" '+summary.concurrency+
        ', "Quantidade de Saídas:" '+summary.yields
    );
    var contents = '';
    summary.output.iterator().each(function (key, value) {
        contents += (key + ' ' + value + '\n');
        return true;
    });
}

return {
    getInputData: getInputData,
    map: map,
    reduce: reduce,
    summarize: summarize
}
});
