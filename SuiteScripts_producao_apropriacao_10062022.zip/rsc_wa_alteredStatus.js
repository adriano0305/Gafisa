/**
 *@NApiVersion 2.x
 *@NScriptType WorkflowActionScript
 */
define(["N/record", "N/runtime"], function(record, runtime) {

    function onAction(ctx) {
        var newRec = ctx.newRecord;
        // log.debug('newRecord', newRec);

        var idPurchaseOR = newRec.getValue({fieldId: 'transaction'})
        // log.debug('idPurchaseOR', idPurchaseOR);  

        var scriptObj = runtime.getCurrentScript().getParameter({name: 'custscript1'});
        // log.debug('Script parameter of custscript1: ', scriptObj); //type string

        var scriptObj2 = runtime.getCurrentScript().getParameter({name: 'custscript2'});
        log.debug('Script parameter of custscript2: ', scriptObj2); //type string

        var typeRec = record.load({
            type: 'customrecord1204',
            id: parseInt(scriptObj2)
        }).getText({fieldId: 'custrecord1419'});
        log.debug('typeRec', typeRec);      

        var toRec = record.load({
            type: typeRec,
            id: idPurchaseOR
        }); 
        // log.debug('toRec', toRec);  

        var approveField = toRec.getValue({fieldId: 'approvalstatus'});
        // log.debug('approveField', approveField); 
        
        if(approveField != parseInt(scriptObj)){
            toRec.setValue({
                fieldId: 'approvalstatus',
                value: parseInt(scriptObj),
                // ignoreFieldChange: true
            });
    
            toRec.save({
                ignoreMandatoryFields: true
            });
        }           
    }

    return {
        onAction: onAction
    }
});
