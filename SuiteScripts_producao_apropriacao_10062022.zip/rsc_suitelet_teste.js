/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/ui/serverWidget', 'N/search', 'N/config'],
    /**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{runtime} runtime
 * @param{serverWidget} serverWidget
 * @param{search} search
     * @param{config} config
 */
    (currentRecord, record, runtime, serverWidget, search, config) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            var Form = serverWidget.createForm({
                title: 'Form Teste'
            });

            Form.addField({
                id: 'custpage_fieldteste',
                type: serverWidget.FieldType.TEXT,
                label: 'Campo Teste'
            });

            var mySearch = record.load({
                id: '114',
                type: 'CUSTOM_RECORD'
            })

            /*var x = config.load({
                type: config.Type.COMPANY_PREFERENCES
            })*/

            log.debug('MinhaBusca', mySearch)


            scriptContext.response.writePage(Form)
        }

        return {onRequest}

    });
