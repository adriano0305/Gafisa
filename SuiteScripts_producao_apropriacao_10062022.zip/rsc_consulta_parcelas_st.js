/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */

const custPage = 'custpage_rsc_';

define(['N/log', 'N/query', 'N/record', 'N/search', 'N/ui/serverWidget', 'N/url'], function(log, query, record, search, serverWidget, url) {
function onRequest(context) {
     /* ******************* FIELD TYPES ****************** *
    * ■ CHECKBOX ■ CURRENCY ■ DATE ■ DATETIMETZ ■ EMAIL   *
    * ■ FILE ■ FLOAT ■ HELP ■ INLINEHTML ■ INTEGER        *
    * ■ IMAGE ■ LABEL ■ LONGTEXT ■ MULTISELECT ■ PASSPORT *
    * ■ PERCENT ■ PHONE ■ SELECT ■ RADIO ■ RICHTEXT       *
    * ■ TEXT ■ TEXTAREA ■ TIMEOFDAY ■ URL                 *
    * *************************************************** */ 

    /* ****************** SUBLIST TYPES ***************** *
    * ■ INLINEEDITOR ■ EDITOR ■ LIST ■ STATICLIST         *
    * *************************************************** */ 

    const request = context.request;
    const response = context.response;

    const form = construtor();

    form.clientScriptModulePath = "./reparcelamento_cnab/rsc_consulta_parcelas_ct.js";

    var clienteTarefa, fatura, quantidadeParcelas, primeiroVencimento, periodicidade, observacao, tabelaRenegociacao, erro, sublistaReparcelamento, marcarTudo, desmarcarTudo, linha, id_financiamento_invoice, 
    vencimento, valorOriginal, multa, valorAtualizado, status, reparcelar;

    if (request.method == 'GET') {
        log.audit('context GET', context);
    } else {
        log.audit('context POST', context);

        const parameters = request.parameters;
        log.audit('parameters', parameters);

        var prestacoes = localizarParcelas(parameters.custpage_rsc_fatura); 
        log.audit('prestacoes', prestacoes);

        var lkpFatura = search.lookupFields({
            type: 'invoice',
            id: parameters.custpage_rsc_fatura,
            columns: ['tranid']
        });

        if (prestacoes.length > 0) {
            clienteTarefa = form.getField({
                id: custPage+'cliente_tarefa'
            });

            clienteTarefa.defaultValue = parameters.custpage_rsc_cliente_tarefa;

            fatura = form.getField({
                id: custPage+'fatura'
            });

            fatura.defaultValue = parameters.custpage_rsc_fatura;

            memoContrato = form.addField({
                id: custPage+'memo_contrato',
                type: serverWidget.FieldType.TEXT,
                label: 'Memo do Contrato',
                container: custPage+'dados_gerais'
            });

            memoContrato.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            memoContrato.defaultValue = JSON.stringify({
                id: parameters.custpage_rsc_fatura,
                nome: 'Fatura Nº '+lkpFatura.tranid
            });

            // Lista de Parcelas
            sublistaReparcelamento = form.addSublist({
                id : custPage+'sublista_lista_parcelas',
                type : serverWidget.SublistType.LIST,
                label : 'Lista de Parcelas'
            });
    
            // sublistaReparcelamento.addMarkAllButtons();

            linha = sublistaReparcelamento.addField({
                id: custPage+'linha',
                type: serverWidget.FieldType.TEXT,
                label: 'Linha'
            });

            cliente_tarefa_linha = sublistaReparcelamento.addField({
                id: custPage+'cliente_tarefa_linha',
                type: serverWidget.FieldType.TEXT,
                label: 'Cliente : Tarefa'
            });
            
            id_financiamento_invoice = sublistaReparcelamento.addField({
                id: custPage+'id_financiamento_invoice',
                type: serverWidget.FieldType.TEXT,
                label: 'ID Financiamento Invoice'
            });

            id_financiamento_invoice.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.HIDDEN
            });
    
            vencimento = sublistaReparcelamento.addField({
                id: custPage+'vencimento',
                type: serverWidget.FieldType.DATE,
                label: 'Vencimento'
            });
    
            valorOriginal = sublistaReparcelamento.addField({
                id: custPage+'valor_original',
                type: serverWidget.FieldType.CURRENCY,
                label: 'Valor'
            });
    
            multa = sublistaReparcelamento.addField({
                id: custPage+'multa',
                type: serverWidget.FieldType.CURRENCY,
                label: 'Multa'
            });

            multa.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.ENTRY
            });
    
            valorAtualizado = sublistaReparcelamento.addField({
                id: custPage+'valor_atualizado',
                type: serverWidget.FieldType.CURRENCY,
                label: 'Valor Atualizado'
            });
            
            valorAtualizado.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.ENTRY
            });
            
            status = sublistaReparcelamento.addField({
                id: custPage+'status',
                type: serverWidget.FieldType.TEXT,
                label: 'Status' // Aberto | Pago | Reparcelado | Atraso | Parcial
            });
    
            reparcelar = sublistaReparcelamento.addField({
                id: custPage+'reparcelar',
                type: serverWidget.FieldType.CHECKBOX,
                label: 'Reparcelar'
            });

            for (i=0; i<prestacoes.length; i++) {
                var totalParcela = prestacoes[i].foreigntotal;
                var totalPagamento = prestacoes[i].foreignamountpaid;
                var parcela = prestacoes[i].duedate;

                if (totalPagamento == 0 || (totalPagamento > 0 && totalPagamento < totalParcela)) {
                    sublistaReparcelamento.setSublistValue({
                        id: linha.id,
                        line: i,
                        value: String(parseInt(i+1))
                    }); 

                    sublistaReparcelamento.setSublistValue({
                        id: cliente_tarefa_linha.id,
                        line: i,
                        value: prestacoes[i].entitytitle
                    });
                    
                    sublistaReparcelamento.setSublistValue({
                        id: id_financiamento_invoice.id,
                        line: i,
                        value: prestacoes[i].id
                    }); 

                    sublistaReparcelamento.setSublistValue({
                        id: vencimento.id,
                        line: i,
                        value: parcela
                    }); 
                    
                    sublistaReparcelamento.setSublistValue({
                        id: valorOriginal.id,
                        line: i,
                        value: totalParcela
                    });
                    
                    sublistaReparcelamento.setSublistValue({
                        id: multa.id,
                        line: i,
                        value: Number('0').toFixed(2)
                    }); 

                    sublistaReparcelamento.setSublistValue({
                        id: valorAtualizado.id,
                        line: i,
                        value: Number('0').toFixed(2)
                    }); 

                    sublistaReparcelamento.setSublistValue({
                        id: status.id,
                        line: i,
                        value: totalPagamento == 0 ? 'Aberto' : 'Parcial'
                    });
                }
            };

            // Simulação
            quantidadeParcelas = form.addField({
                id: custPage+'quantidade_parcelas',
                type: serverWidget.FieldType.INTEGER,
                label: 'Quantidade de parcelas',
                container: custPage+'simulacao'
            });

            primeiroVencimento = form.addField({
                id: custPage+'primeiro_vencimento',
                label: '1º Vencimento',
                type: serverWidget.FieldType.DATE,
                container: custPage+'simulacao'
            });

            periodicidade = form.addField({
                id: custPage+'periodicidade',
                label: 'Periodicidade',
                type: serverWidget.FieldType.SELECT,
                container: custPage+'simulacao',
                source: 'customlist_rsc_periodicidade'
            });

            observacao = form.addField({
                id: custPage+'observacao',
                label: 'Observação',
                type: serverWidget.FieldType.TEXT,
                container: custPage+'simulacao'
            });
            
            tabelaRenegociacao = form.addField({
                id: custPage+'tabela_renegociacao',
                label: 'Tabela de Renegociação',
                type: serverWidget.FieldType.URL,
                container: custPage+'simulacao'
            }); 
            
            tabelaRenegociacao.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            erro = form.addField({
                id: custPage+'erro',
                label: 'Erro',
                type: serverWidget.FieldType.TEXTAREA,
                container: custPage+'simulacao'
            });

            erro.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });
            
            form.addButton({
                id: custPage+'gravar_simulacao',
                label: 'Gravar Simulação',
                functionName: 'gravarSimulacao'
            });

            // form.addButton({
            //     id: custPage+'checar_status',
            //     label: 'Checar Status',
            //     functionName: 'checarStatus'
            // });

            form.addButton({
                id: custPage+'nova_consulta',
                label: 'Nova Consulta',
                functionName: 'novaConsulta'
            });
        } 
    }

    response.writePage({
        pageObject: form
    });
}

function localizarParcelas(idContrato) {
    log.audit('localizarParcelas', idContrato);

    const sql = "SELECT	transaction.id, Customer.entitytitle, transaction.tranid, transaction.duedate, transaction.foreigntotal, transaction.foreignamountpaid "+
	"FROM transaction "+
    "INNER JOIN Customer ON (Customer.id = transaction.entity) "+
    "WHERE transaction.custbody_lrc_fatura_principal = ? "+
    'ORDER BY transaction.duedate asc';

    var consulta = query.runSuiteQL({
        query: sql,
        params: [idContrato]
    });

    var sqlResults = consulta.asMappedResults();
    log.audit('sqlResults', sqlResults);
    
    return sqlResults;
}

function construtor() {
    var atencao, clienteTarefa, fatura;
    
    var form = serverWidget.createForm({
        title: 'Consulta de Parcelas'
    });

    const dadosGerais = form.addFieldGroup({
        id: custPage+'dados_gerais',
        label: 'Dados Gerais'
    });    
        
    const simulacao = form.addFieldGroup({
        id: custPage+'simulacao',
        label: 'Simulação'
    });

    atencao = form.addField({
        id: custPage+'atencao',
        type: serverWidget.FieldType.INLINEHTML,
        label: ' ',
    });

    atencao.defaultValue = '<B>Selecione o cliente e a fatura e clique em "Buscar Parcelas".</B> <br><br>';

    atencao.updateLayoutType({
        layoutType: serverWidget.FieldLayoutType.OUTSIDEABOVE
    });

    // Dados Gerais
    clienteTarefa = form.addField({
        id: custPage+'cliente_tarefa',
        type: serverWidget.FieldType.SELECT,
        label: 'Cliente : Tarefa',
        container: custPage+'dados_gerais',
        source: 'customer'
    });

    clienteTarefa.isMandatory = true;

    fatura = form.addField({
        id: custPage+'fatura',
        type: serverWidget.FieldType.SELECT,
        label: 'Fatura',
        container: custPage+'dados_gerais'
    });

    fatura.isMandatory = true;

    fatura.addSelectOption({
        value: '',
        text: ''
    });

    form.addSubmitButton({
        label: 'Buscar Parcelas'
    });

    // form.addSubmitButton({
    //     label: 'Buscar Faturas'
    // });
    
    return form;
}

return {
    onRequest: onRequest
}
});
