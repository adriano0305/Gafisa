/**
 *@NApiVersion 2.1
*@NScriptType Restlet
*/
define(['N/log', 'N/search', 'N/record'], function(log, search, record) {
function _get(context) {
    log.audit('_get', context);
}

function _post(context) {
    log.audit('context', context);

    var Record = record.create({
        type: 'customrecord_rsc_tab_efetiva_reparcela',
        isDynamic: true
    });

    // Dados Gerais
    Record.setValue({
        fieldId: 'custrecord_rsc_contrato_fatura_principal',
        value: context.contrato_fatura_principal
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_cliente',
        value: context.cliente
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_unidade',
        value: context.unidade
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_total_fatura_principal',
        value: context.total_fatura_principal
    });

    // Dados para Efetivação (Reparcelamento)
    Record.setValue({
        fieldId: 'custrecord_rsc_valor_financiado',
        value: context.valor_financiado
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_total_prestacoes_marcadas',
        value: context.total_prestacoes_marcadas
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_valor_total',
        value: context.valor_total
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_valor_da_entrada',
        value: context.valor_entrada
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_reparcelar_em',
        value: context.reparcelar_em
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_vencimento_da_entrada',
        value: context.vencimento_entrada
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_primeiro_vencimento',
        value: context.primeiro_vencimento
    });

    Record.setValue({
        fieldId: 'custrecord_rsc_juros_de_mora',
        value: context.juros_mora
    });

    // Sublista Parcelas
    for (i=0; i<context.resumo_reparcelamento; i++) {
        Record.selectLine({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento',
            line: i
        });

        Record.setCurrentMatrixSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento',
            fieldId: 'custrecord_rsc_ano',
            value: context.resumo_reparcelamento[i].ano
        });

        Record.setCurrentMatrixSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento',
            fieldId: 'custrecord_rsc_parcela',
            value: context.resumo_reparcelamento[i].parcela
        });

        Record.setCurrentMatrixSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento',
            fieldId: 'custrecord_rsc_prestacao',
            value: context.resumo_reparcelamento[i].prestacao
        });

        Record.commitLine({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento',
        });
    }

    var idTabelaEfetivacao, erro, status;
    try {
        idTabelaEfetivacao = Record.save({ignoreMandatoryFields: true});
        log.audit('idTabelaEfetivacao', idTabelaEfetivacao);
    } catch (e) {
        log.error('Erro', e);
        erro = e;
    }

    if (idTabelaEfetivacao) {
        status = JSON.stringify({
            status: 'Sucesso',
            idTabelaEfetivacao: idTabelaEfetivacao
        });
        log.audit('status', status);
    } else {
        status = JSON.stringify({
            status: 'Erro',
            msg: erro
        });
    }

    return status;
}

function _put(context) {
    
}

function _delete(context) {
    
}

return {
    get: _get,
    post: _post,
    put: _put,
    delete: _delete
}
});