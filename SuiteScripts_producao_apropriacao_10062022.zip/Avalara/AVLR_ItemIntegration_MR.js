/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/encode', 'N/https', 'N/record', 'N/query', 'N/search','N/config'],
  (encode, https, record, query, search, config) => {
    //------------------------------------------------------------
    //----------------------------- GID
    //------------------------------------------------------------
    /**
     * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
     *
     * @param {Object} inputContext
     */
    const getInputData = (inputContext) => {
      const itemsQuery = `
        SELECT 
            item.displayname,
            agast.name,
            item.itemid,
            item.itemtype,
            item.custitem_enl_taxorigin,
            item.custitem_enl_producttype,
            item.unitstype,
            subsidiary.custrecord_enl_urlswfiscal,
            subsidiary.custrecord_enl_avataxuser,
            subsidiary.custrecord_enl_pwdavatax,
            subsidiary.custrecord_enl_companyid,
            item.id,
            item.custitem_avlr_integratedwithavatax,
            subsidiary.id,
            subsidiary.name
        FROM item
            LEFT JOIN customrecord_enl_taxgroup AS agast                                    ON item.custitem_enl_it_taxgroup = agast.id 
            LEFT JOIN subsidiary                                                            ON 0=0
            LEFT JOIN MAP_item_custitem_avlr_integratedwithavatax  AS integratedwithavatax  ON integratedwithavatax.maptwo = subsidiary.id AND item.id = integratedwithavatax.mapone
        WHERE item.itemtype                             in ('InvtPart', 'Group', 'Kit', 'NonInvtPart', 'Service')
          AND item.custitem_enl_it_taxgroup             IS NOT NULL
          AND item.custitem_avlr_has_integration_error  <> 'T'
        --AND item.id NOT IN (  SELECT mapone 
        --                FROM MAP_item_custitem_avlr_integratedwithavatax 
        --                WHERE MAP_item_custitem_avlr_integratedwithavatax.maptwo = subsidiary.id  )
          AND subsidiary.isinactive                 <> 'T'
          AND subsidiary.iselimination              = 'F'
          AND subsidiary.custrecord_enl_urlswfiscal IS NOT NULL
          AND integratedwithavatax.maptwo           IS NULL
          AND rownum                                <= 20000
        ORDER BY item.id
      `
        const pagedData      = query.runSuiteQLPaged({ query: itemsQuery, pageSize: 1000 })
        const resultIterator = pagedData.iterator()
        const results        = []

        resultIterator.each(page => {
            const pageIterator = page.value.data.iterator()
            pageIterator.each(row => {
                results.push(row.value.values)
                return true
            })
            return true
        })
        if (results.length > 0) {
            log.emergency("último item ANTES", results[ results.length - 1] )

            let ultItem = results[ results.length - 1][2]
            if (results.length == 20000) {
                while ( results.length > 0 && ultItem == results[ results.length - 1 ][2]) {
                    let itemDelete = results.pop();
                    log.emergency("excluído", itemDelete[2] )
                }
            }

            log.emergency("último item DEPOIS", results[ results.length - 1] )
        }

        log.emergency("getInputData", "TOTAL de registros: " + results.length )
        return results
    }
    //------------------------------------------------------------
    //----------------------------- MAP
    //------------------------------------------------------------
    /**
     * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
     * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
     * context.
     *
     * @param {Object} mapContext
     */
    const map = (mapContext) => {
        const companyPrefs        = config.load({ type: config.Type.COMPANY_PREFERENCES });
        const companyItemID       = String(companyPrefs.getValue({ fieldId: 'custscript_enl_itemidfield'      })).trim() || 'itemid';
        const companyDisplayName  = String(companyPrefs.getValue({ fieldId: 'custscript_enl_descriptionfield' })).trim() || 'displayname';

        let error
        let errorCode
        let errorMessage
        let errorDate

        const resultValues = JSON.parse(mapContext.value)

        const payload = {
            code:        String(companyItemID      == 'itemid'      ? resultValues[2] : resultValues[0]),
            agast:       resultValues[1],
            description: String(companyDisplayName == 'displayname' ? resultValues[0] : resultValues[2]).slice(0, 61) || undefined,
            cityTaxConf: []
        }

        const type = resultValues[3]

        if (type === 'Service') {
            payload.source      = _getProductSource(resultValues[4])
            payload.productType = _getProductType(resultValues[5])

            const unitsType = resultValues[6]

            if (unitsType) {
                payload.salesUnit     = unitsType
                payload.purchaseUnit  = unitsType
            }

            payload.firstUse = false
            payload.sealCode = null
        }

        let baseUrl = resultValues[7]

        if (!baseUrl) {
            error = 'Campo "FISCAL SW URL" não esta definido.'
        } else {
            baseUrl = baseUrl.substr(0, 8).concat(baseUrl.substr(8).replace('//', '/'))

            const user = resultValues[8]
            const pass = resultValues[9]
            const companyCode = resultValues[10]

            const authorization = 'Basic ' + encode.convert({
                string: `${user}:${pass}`,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            })

            const avalaraProductType = type === 'Service' ? 'service' : 'goods'

            const headers = {
                'Avalara-Product-Type': avalaraProductType,
                Authorization: authorization,
                'Content-Type': 'application/json',
                'Avalara-Company-Code': companyCode || undefined
            }

            let url

            if (type === 'Service') {
                url = `${baseUrl}/v2/companies/items?service`
                payload.agast = payload.agast || 'BRLC'
            } else {
                url = `${baseUrl}/v2/companies/items?goods`
                payload.agast = payload.agast || 'BRNCM'
            }

            //- POST
            let response = https.post({ url, headers, body: JSON.stringify(payload) })

            if (response.body != "") {
                errorCode    = JSON.parse(response.body)?.error?.code
                errorMessage = JSON.parse(response.body)?.error?.message
            }
            errorDate    = new Date();

            if (response.code === 400 && (errorCode === '000' || errorCode === '11000') )  {  //ALEX-11000
                url = `${baseUrl}/v2/companies/items/${encodeURIComponent(payload.code)}?${avalaraProductType}`
            
                //- PUT
                let responsePut = https.put({ url, headers, body: JSON.stringify(payload) })
        
                if (responsePut.code !== 204) {
                    errorCode    = JSON.parse(responsePut.body)?.error?.code
                    errorMessage = JSON.parse(responsePut.body)?.error?.message

                    log.debug({ title: 'https.put',     details: { url, headers, body: JSON.stringify(payload) } })
                    log.debug({ title: 'put response',  details: { code: responsePut.code, body: responsePut.body } })
                
                    if (errorCode = "000") errorMessage = (type === 'Service'?'ItemService':'ItemGoods') + '/Agast  não encontrado na Subsidiaria.'
            
                    if (responsePut.code !== 400 || (errorCode !== '000' && errorCode !== '11000') )  {  //ALEX-11000
                        let payloadLOG = { ...payload, log: responsePut.code + '-' + errorCode + ' ' + errorMessage  }
                        log.error({ title: 'PUT Subsidiária: ' + resultValues[14], details: JSON.stringify(payloadLOG) })
                    }
                    error = true
                }
            } else if (response.code !== 201) {
                log.debug({ title: 'https.post',    details: { url, headers, body: JSON.stringify(payload) } })
                log.debug({ title: 'post response', details: { code: response.code, body: response.body } })

                let payloadLOG = { ...payload, log: response.code + '-' + errorCode + ' ' + errorMessage  }
                log.error({ title: 'POST Subsidiária: ' + resultValues[14], details: JSON.stringify(payloadLOG) })
                error = true
            }
        }

        mapContext.write({
            key: {
                type,
                id: resultValues[11],
                integratedSubsidiariesIds: resultValues[12] ? resultValues[12].split(', ') : ''
            },
            value: {
                subsidiaryId:   resultValues[13],
                subsidiaryName: resultValues[14],
                companyCode:    resultValues[10],
                error:          error,
                errorCode:      errorCode     ? errorCode     : "",
                errorMessage:   errorMessage  ? errorMessage  : "",
                errorDate:      errorDate  
            }
        })
    }
    //------------------------------------------------------------
    //----------------------------- REDUCE
    //------------------------------------------------------------
    /**
     * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
     * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
     *
     * @param {Object} reduceContext
     */
    const reduce = (reduceContext) => {
        try {
            const itemValues = JSON.parse(reduceContext.key)
            const integratedSubsidiariesIds = itemValues.integratedSubsidiariesIds || []
            const newIntegratedSubsidiariesIds = []
            const errors = []

            reduceContext.values.forEach(value => {
                value = JSON.parse(value)

                const error = value.error

                if (!error) {
                    newIntegratedSubsidiariesIds.push(value.subsidiaryId)
                } else {
                    errors.push( value )
                }
            })

            const inactiveSubsidiaries = _getInactiveSubsidiaries()

            const allIntegratedSubsidiariesIds = integratedSubsidiariesIds
                .concat(newIntegratedSubsidiariesIds)
                .filter(subsidiaryId => !inactiveSubsidiaries.some(id => id === subsidiaryId))

            record.submitFields({
                type: _getItemRecordType(itemValues.type),
                id: itemValues.id,
                values: {
                    custitem_avlr_integratedwithavatax: allIntegratedSubsidiariesIds,
                    custitem_avlr_has_integration_error: errors.length > 0,
                    custitem_avlr_integration_error: errors.length ? JSON.stringify(errors) : ''
                },
                options: {
                    ignoreMandatoryFields: true
                }
            })

            log.debug("REDUCE", {
                type: _getItemRecordType(itemValues.type),
                id: itemValues.id, erro: (errors.length > 0),
                qtdErros: errors.length
            })
        } catch (mapError) {
            log.error("REDUCECatchError", mapError )
            log.error("REDUCECatchError", { contentKey: reduceContext.key, contentValue: reduceContext.value })
        }
    }
    //------------------------------------------------------------
    //----------------------------- SUMMARIZE
    //------------------------------------------------------------
    /**
     * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
     * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
     *
     * @param {Object} summaryContext
     */
    const summarize = (summaryContext) => {
        const inputSummaryError = summaryContext.inputSummary.error

        if (inputSummaryError) log.error({ title: 'Input Error', details: inputSummaryError })

        summaryContext.mapSummary.errors.iterator().each((key, error) => {
            log.error({ title: 'Map Error for key: ' + key, details: error })
            log.error({ title: 'summaryContext', details: summaryContext })
            return true
        })

        summaryContext.reduceSummary.errors.iterator().each((key, error) => {
            log.error({ title: 'Reduce Error for key: ' + key, details: error })
            return true
        })
        log.audit("summarize", "##### Fim #####")
        log.error("summarize", "##### Fim #####")
        log.emergency("summarize", "##### Fim #####")
    }
    //------------------------------------------------------------
    //------------------------------------------------------------
    /**
     * Get product source.
     *
     * @param source
     * @returns {string}
     * @private
     */
    const _getProductSource = (source) => {
        switch (source) {
            case '1': return '0'// Comprado
            case '2': return '1'// Importado
            case '3': return '2'// Importado Mercado Interno
            case '4': return '3'// Nacional - Importação superior 40% e Inferior a 70%
            case '5': return '4'// Nacional - Produzido conforme decreto
            case '6': return '5'// Nacional - Importação inferior 40%
            case '7': return '6'// Importado direto Camex
            case '8': return '7'// Importado Mercado Interno Camex
            case '9': return '8'// Nacional - mercadoria ou bem com conteúdo superior a 70%
            default: return '0'
        }
    }
    /**
     * Get product type.
     *
     * @param productTypeId
     * @returns {string}
     * @private
     */
    const _getProductType = (productTypeId) => {
        if (!productTypeId) return 'NO RESTRICTION'

        switch (productTypeId) {
            case '1':  return 'FOR PRODUCT'
            case '2':  return 'FOR MERCHANDISE'
            case '3':  return 'NO RESTRICTION'
            case '4':  return 'SERVICE'
            case '5':  return 'FEEDSTOCK'
            case '6':  return 'FIXED ASSETS'
            case '7':  return 'PACKAGING'
            case '8':  return 'PRODUCT IN PROCESS'
            case '9':  return 'SUBPRODUCT'
            case '10': return 'INTERMEDIATE PRODUCT'
            case '11': return 'MATERIAL FOR USAGE AND CONSUMPTION'
            case '12': return 'OTHER INPUTS'
            default:   return 'FOR MERCHANDISE'
        }
    }
    /**
     * Get item record type.
     *
     * @param type
     * @returns {string}
     * @private
     */
    const _getItemRecordType = (type) => {
        switch (type) {
            case 'Service':     return 'serviceitem'
            case 'InvtPart':    return 'inventoryitem'
            case 'NonInvtPart': return 'noninventoryitem'
            case 'Kit':         return 'kititem'
            case 'OthCharge':   return 'otherchargeitem'
            case 'Payment':     return 'paymentitem'
            case 'Subtotal':    return 'subtotalitem'
            case 'Assembly':    return 'assemblyitem'
            case 'Discount':    return 'discountitem'
            case 'Description': return 'descriptionitem'
            case 'Markup':      return 'markupitem'
            default:            return ''
        }
    }
    /**
     * Get inactive subsidiaries.
     *
     * @returns {number[]}
     * @private
     */
    const _getInactiveSubsidiaries = () => {
        return search.create({
            type: search.Type.SUBSIDIARY,
            filters: [{ name: 'isinactive', operator: search.Operator.IS, values: true }]
        })
        .run()
        .getRange({ start: 0, end: 1000 })
        .map(result => result.id)
    }
    return { getInputData, map, reduce, summarize }
})