/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */

const custPage = 'custpage_rsc_';

define(['N/file', 'N/https', 'N/log', 'N/query', 'N/record', 'N/runtime', 'N/url', 'N/search', 'N/task'], (file, https, log, query, record, runtime, url, search, task) => {
function afterSubmit(context) {
    log.audit('afterSubmit', context);
}

function beforeLoad(context) {
    // log.audit('beforeLoad', context);

    const registroAtual = context.newRecord;

    const form = context.form;

    var usuarioAtual = runtime.getCurrentUser().id;

    const orderStatus = registroAtual.getValue('orderstatus');
    
    if (registroAtual.id == 52080) {
        if (orderStatus == 'G') {// Faturado
            var bscFaturas = search.create({type: "invoice",
                filters: [
                   ["shipping","is","F"], "AND", 
                   ["taxline","is","F"], "AND", 
                   ["mainline","is","T"], "AND", 
                   ["type","anyof","CustInvc"], "AND", 
                   ["createdfrom.internalid","anyof",registroAtual.id]
                ],
                columns: [
                    "internalid","tranid"
                ]
            }).run().getRange(0,100);

            if (bscFaturas.length > 0) {
                gerarSublista(form, bscFaturas[0].id);
            }
        }        
    }
}

function gerarSublista(form, idFatura) {
    // log.audit('gerarSublista',{form: form, idFatura: idFatura});

    // Guia Parcelamento do Contrato
    const guia_parcelamento_contrato = form.addTab({
        id: custPage+'guia_parcelas',
        label: 'Fluxo de pagamentos'
    });

    // Sublista Parcelas
    const sublistaParcelas = form.addSublist({
        id: custPage+'parcelas',
        type: 'list',
        label: 'Parcelas',
        // tab: 'custtab_116_5843489_622'
        tab: custPage+'guia_parcelas'
    });

    // var link = sublistaParcelas.addField({
    //     id: custPage+'link',
    //     type: 'url',
    //     label: 'Link'
    // });

    // link.linkText = 'Visualizar';   

    // var ano = sublistaParcelas.addField({
    //     id: custPage+'ano',
    //     type: 'text',
    //     label: 'Ano'
    // });

    var numeroParcela = sublistaParcelas.addField({
        id: custPage+'numero_parcela',
        type: 'integer',
        label: '#'
    });

    var ver = sublistaParcelas.addField({
        id: custPage+'ver',
        type: 'text',
        label: 'Ver'
    });

    var vencimento = sublistaParcelas.addField({
        id: custPage+'vencimento',
        type: 'date',
        label: 'Vencimento'
    });

    var tipoParcela = sublistaParcelas.addField({
        id: custPage+'tipo_parcela',
        type: 'text',
        label: 'Tipo Parcela',
    });

    var indice = sublistaParcelas.addField({
        id: custPage+'indice',
        type: 'text',
        label: 'Índice',
    });
    
    var valorOriginal = sublistaParcelas.addField({
        id: custPage+'valor_original',
        type: 'currency',
        label: 'Valor'
    });

    var multa = sublistaParcelas.addField({
        id: custPage+'multa',
        type: 'currency',
        label: 'Multa'
    });

    var juros = sublistaParcelas.addField({
        id: custPage+'juros',
        type: 'currency',
        label: 'Juros'
    });

    var valorAtualizado = sublistaParcelas.addField({
        id: custPage+'valor_atualizado',
        type: 'currency',
        label: 'Valor Atualizado'
    });

    var dataPagamento = sublistaParcelas.addField({
        id: custPage+'data_pagamento',
        type: 'date',
        label: 'Data Pagamento',
    });

    var valorPago = sublistaParcelas.addField({
        id: custPage+'valor_pago',
        type: 'currency',
        label: 'Valor Pago',
    });
    
    var status = sublistaParcelas.addField({
        id: custPage+'status',
        type: 'text',
        label: 'Status' // Aberto | Pago | Reparcelado | Atraso | Parcial
    });

    var prestacoes = localizarParcelas(idFatura);

    if (prestacoes.arrayParcelas.length > 0) {
        for (i=0; i<prestacoes.arrayParcelas.length; i++) {            
            // var urlFaturaParcela = url.resolveRecord({
            //     recordType: 'customsale_rsc_financiamento',
            //     recordId: prestacoes.arrayParcelas[i].ver 
            // });

            // sublistaParcelas.setSublistValue({
            //     id: link.id,
            //     line: i,
            //     value: urlFaturaParcela
            // });

            sublistaParcelas.setSublistValue({
                id: ver.id,
                line: i,
                value: 'Parcela Nº '+prestacoes.arrayParcelas[i].documento
            });

            sublistaParcelas.setSublistValue({
                id: numeroParcela.id, 
                line: i,
                value: i+1
            });

            sublistaParcelas.setSublistValue({
                id: vencimento.id, // Vencimento
                line: i,
                value: prestacoes.arrayParcelas[i].parcela
            });
            
            var lkpTipoParcela;
            
            if (prestacoes.arrayParcelas[i].tipoParcela) {
                lkpTipoParcela = search.lookupFields({
                    type: 'customlist_rsc_tipo_parcela',
                    id: prestacoes.arrayParcelas[i].tipoParcela,
                    columns: 'name'
                });

                sublistaParcelas.setSublistValue({
                    id: tipoParcela.id,
                    line: i,
                    value: lkpTipoParcela.name
                });
            } 

            sublistaParcelas.setSublistValue({
                id: valorOriginal.id,
                line: i,
                value: prestacoes.arrayParcelas[i].valorOriginal
            });

            sublistaParcelas.setSublistValue({
                id: multa.id,
                line: i,
                value: prestacoes.arrayParcelas[i].multa
            });

            sublistaParcelas.setSublistValue({
                id: juros.id,
                line: i,
                value: prestacoes.arrayParcelas[i].juros
            });            

            sublistaParcelas.setSublistValue({
                id: valorAtualizado.id,
                line: i,
                value: (prestacoes.arrayParcelas[i].status == 'Aberto' || prestacoes.arrayParcelas[i].status == 'Liquidado' || prestacoes.arrayParcelas[i].reparcelamentoDestino) ? Number(prestacoes.arrayParcelas[i].valorAtualizado).toFixed(2) : 0
            });

            sublistaParcelas.setSublistValue({
                id: dataPagamento.id,
                line: i,
                value: prestacoes.arrayParcelas[i].dataPagamento
            });

            sublistaParcelas.setSublistValue({
                id: valorPago.id,
                line: i,
                value: prestacoes.arrayParcelas[i].valorPago
            });

            sublistaParcelas.setSublistValue({
                id: status.id,
                line: i,
                value: prestacoes.arrayParcelas[i].status
            });
        }
    }
}

function localizarParcelas(idFatura) {
    // log.audit('localizarParcelas', idFatura);

    var arrayParcelas = [];

    const acrescimos = 19422;
    const incc = 19423;
    const multa = Number('0.01');   // 1% ao mês
    const jurosMora = multa;
    const mes = Number ('30');

    // var sql = 'select t.id, t.duedate, t.tranid, t.custbodyrsc_tpparc, t.custbody_rsc_tran_unidade, t.foreigntotal, '+
    // 'tl.item, tl.quantity, tl.rate '+
    // 'from transaction as t '+
    // 'inner join transactionline as tl on (tl.transaction = t.id) '+
    // 'where t.custbody_lrc_fatura_principal = ? order by t.duedate asc';

    var sql = 'select t.id, t.duedate, t.tranid, t.custbodyrsc_tpparc, t.custbody_rsc_tran_unidade, t.custbody_rsc_reparcelamento_origem, '+
    't.custbody_rsc_reparcelamento_destino, t.foreigntotal, t.shipdate, t.foreignamountpaid, t.foreignamountunpaid, '+
    'tl.item, tl.quantity, tl.rate '+
    'from transaction as t '+
    'inner join transactionline as tl on (tl.transaction = t.id) '+
    'where t.custbody_lrc_fatura_principal = ? '+
    // 'and t.type = CuTrSale '+    
    'order by t.duedate asc';

    var consulta = query.runSuiteQL({
        query: sql,
        params: [idFatura]
    });

    var sqlResults = consulta.asMappedResults();    
    log.audit('sqlResults', sqlResults);

    if (sqlResults.length > 0) {
        var correcoes = 0;
        var juros = 0;

        for (var prop in sqlResults) {            
            if (sqlResults[prop].item != null && sqlResults[prop].item == 19420) {
                var parcelaVencida = !sqlResults[prop].shipdate ? validarVencimento(sqlResults[prop].duedate) : validarVencimento2(sqlResults[prop].shipdate, sqlResults[prop].duedate);

                juros = parcelaVencida.status == true ? sqlResults[prop].foreigntotal * (jurosMora / mes) * parcelaVencida.diasMora : 0;      
            
                var status;

                if (sqlResults[prop].foreignamountpaid == sqlResults[prop].foreigntotal) {
                    status = 'Liquidado';
                } else if ((sqlResults[prop].foreignamountpaid < sqlResults[prop].foreigntotal) || sqlResults[prop].foreignamountpaid == 0) {
                    if (sqlResults[prop].custbody_rsc_reparcelamento_destino) {
                        status = 'Reparcelado';
                    } else {
                        status = 'Aberto';
                    }
                } 
            
                correcoes = Math.abs(sqlResults[prop].rate * sqlResults[prop].quantity).toFixed(2);            
                    
                arrayParcelas.push({
                    ver: sqlResults[prop].id,
                    reparcelamentoOrigem: sqlResults[prop].custbody_rsc_reparcelamento_origem,
                    reparcelamentoDestino: sqlResults[prop].custbody_rsc_reparcelamento_destino,
                    parcela: sqlResults[prop].duedate,
                    prestacao: sqlResults[prop].foreigntotal,
                    tipoParcela: sqlResults[prop].custbodyrsc_tpparc,
                    valorOriginal: sqlResults[prop].foreignamountunpaid,
                    // valorOriginal: sqlResults[prop].foreigntotal,
                    multa: sqlResults[prop].foreignamountpaid > 0 ? 0 : (parcelaVencida.status == true ? sqlResults[prop].foreigntotal * multa : 0),
                    // multa: parcelaVencida.status == true ? sqlResults[prop].foreigntotal * multa : 0,
                    juros: sqlResults[prop].foreignamountpaid > 0 ? 0 : juros,                    
                    valorAtualizado: parcelaVencida.status == true ? (sqlResults[prop].foreigntotal + (sqlResults[prop].foreigntotal * multa) + juros) : sqlResults[prop].foreigntotal,
                    dataPagamento: sqlResults[prop].foreignamountpaid > 0 ? sqlResults[prop].shipdate : null,
                    valorPago: sqlResults[prop].foreignamountpaid,
                    documento: sqlResults[prop].tranid,
                    status: sqlResults[prop].foreignamountpaid == sqlResults[prop].foreigntotal ? 'Liquidado' : 'Aberto'
                }); 
                                
            }
        }
        // log.audit('correcoes: '+correcoes, 'juros: '+juros);
    }

    arrayParcelas = arrayParcelas.filter(function (dados) {
        return !this[JSON.stringify(dados)] && (this[JSON.stringify(dados)] = true);
    }, Object.create(null));
    // log.audit('filter', arrayParcelas);

    arrayParcelas = [...new Set(arrayParcelas)];
    // log.audit('new Set', arrayParcelas);

    // arrayParcelas = arrayParcelas.slice(0).reverse();
    var totalFinanciado = 0;

    arrayParcelas.forEach(function (dados) {
        totalFinanciado += Number(dados.prestacao);
    });
    // log.audit('totalFinanciado: '+totalFinanciado.toFixed(2), 'arrayParcelas: '+JSON.stringify(arrayParcelas));

    var fileObj = file.create({
        name: 'arrayParcelas.txt',
        fileType: file.Type.PLAINTEXT,
        folder: 704,    // SuiteScripts > teste > Arquivos
        contents: JSON.stringify(arrayParcelas)
    });

    var fileObjId = fileObj.save();

    return {arrayParcelas: arrayParcelas, totalFinanciado: totalFinanciado.toFixed(2)};
}

function validarVencimento(duedate) {
    // log.audit('validarVencimento', duedate);

    const hoje = new Date();

    var diaHoje = hoje.getDate();
    var mesHoje = hoje.getMonth()+1;
    var anoHoje = hoje.getFullYear();

    var partesData = duedate.split("/");

    var vencimento = new Date(partesData[2], partesData[1] - 1, partesData[0]);

    var diaVencimento = vencimento.getDate();
    var mesVencimento = vencimento.getMonth()+1;
    var anoVencimento = vencimento.getFullYear();

    if (hoje > vencimento) {
        var tempo = Math.abs(hoje.getTime() - vencimento.getTime());

        var diasMora = Math.ceil(tempo / (1000 * 3600 * 24));
        // log.audit('status: true', {tempo: tempo, diasMora: diasMora});

        if ((diasMora-1) > 1) {
            return {
                status: true, 
                diasMora: diasMora-1
            }
        }   
        
        return {
            status: false
        }
    } else {
        return {
            status: false
        }
    }
}

function validarVencimento2(shipdate, duedate) {
    // log.audit('validarVencimento', duedate);

    const partesShipdate = shipdate.split("/");

    var vencimentoShipdate = new Date(partesShipdate[2], partesShipdate[1] - 1, partesShipdate[0]);

    var diaShipdate = vencimentoShipdate.getDate();
    var mesShipdate = vencimentoShipdate.getMonth()+1;
    var anoShipdate = vencimentoShipdate.getFullYear();

    const partesDuedate = duedate.split("/");

    var vencimentoDuedate = new Date(partesDuedate[2], partesDuedate[1] - 1, partesDuedate[0]);

    var diaDuedate = vencimentoDuedate.getDate();
    var mesDuedate = vencimentoDuedate.getMonth()+1;
    var anoDuedate = vencimentoDuedate.getFullYear();

    if (vencimentoShipdate > vencimentoDuedate) {
        var tempo = Math.abs(vencimentoShipdate.getTime() - vencimentoDuedate.getTime());

        var diasMora = Math.ceil(tempo / (1000 * 3600 * 24));
        // log.audit('status: true', {vencimentoShipdate: vencimentoShipdate, vencimentoDuedate: vencimentoDuedate, tempo: tempo, diasMora: diasMora});

        if ((diasMora-1) > 1) {
            return {
                status: true, 
                diasMora: diasMora-1
            }
        }   
        
        return {
            status: false
        }
    } else {
        return {
            status: false
        }
    }
}

return {
    afterSubmit: afterSubmit,
    beforeLoad: beforeLoad
};

});