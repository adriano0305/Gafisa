/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
define([ "N/record", "N/runtime", "N/search"],
    
    (record, runtime, search) => {
        /**
         * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
         * @param {Object} inputContext
         * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Object} inputContext.ObjectRef - Object that references the input data
         * @typedef {Object} ObjectRef
         * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
         * @property {string} ObjectRef.type - Type of the record instance that contains the input data
         * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
         * @since 2015.2
         */

        const getInputData = (inputContext) => {
                return search_1.default.create({
                        type: 'customrecord_rsc_junix_feed_proposta',
                        filters: [
                                ['custrecord_rsc_processado', 'IS', 'F'],
                            ["and"],
                                ['custrecord_rsc_custrecord_rsc_erro_flag', 'IS', 'F']
                        ]

                })
        }

        /**
         * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
         * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
         * context.
         * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
         *     is provided automatically based on the results of the getInputData stage.
         * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
         *     function on the current key-value pair
         * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
         *     pair
         * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} mapContext.key - Key to be processed during the map stage
         * @param {string} mapContext.value - Value to be processed during the map stage
         * @since 2015.2
         */

        const map = (mapContext) => {
                var proposta = JSON.parse(mapContext.value);
                var idClientePrincipal = 0;

                var registroProcesso = record.load({type: 'customrecord_rsc_junix_feed_proposta', id:proposta.id })

                var body = {
                        tipoFiltro: "NÃO PROCESSADOS",
                        Codigo: proposta.getValue('custrecord_rsc_numero_proposta')
                }
                var retorno = JSON.parse(api.sendRequest(body, 'proposta/PesquisarVenda'));


                /* Recuperar Subsidiaria */
                var speNetsuite = 177;

                if (retorno.NumeroProposta > 0){
                        /* Create or validate Client */
                        var compradores = retorno.ListaCompradores;
                        if (compradores) {
                               compradores.foreach(function (comprador){
                                       var principal = comprador.Principal;
                                       var cliente = comprador.Cliente;
                                       log.error({title:'json', details: cliente});
                                       log.error({title: 'clienteId', details: cliente['Id']});
                                       var searchCustomer = search.create({
                                               type: 'customer',
                                               filters: [
                                                       ['custentity_enl_cnpjcpf', 'IS', cliente['CPF_CNPJ']]
                                               ]
                                       }).run().getRange({
                                               start: 0,
                                               end: 1
                                       });
                                       /* Localizou o cliente */
                                       var customerRecord = null;
                                       if (searchCustomer[0]) {
                                               /* validar se o cliente está naquela SPE */
                                               customerRecord = record.load({
                                                       type: 'customer',
                                                       id: searchCustomer[0].id
                                               });
                                       } else {
                                               customerRecord = record.create({
                                                       type: record_1.default.Type.CUSTOMER,
                                                       isDynamic: true
                                               });
                                               var cpf = cliente['CPF'];
                                               if (cpf == '') {
                                                       customerRecord.setValue({
                                                               fieldId: 'isperson',
                                                               value: 'F'
                                                       });
                                                       customerRecord.setValue({
                                                               fieldId: 'companyname',
                                                               value: cliente['Nome']
                                                       });
                                                       customerRecord.setValue({
                                                               fieldId: 'custentity_enl_cnpjcpf',
                                                               value: cliente['CNPJ']
                                                       });
                                               }
                                               else {
                                                       var _a = getSeparetedName(cliente['Nome']), firstName = _a.firstName, lastName = _a.lastName;
                                                       customerRecord.setValue({
                                                               fieldId: 'isperson',
                                                               value: 'T'
                                                       });
                                                       customerRecord.setValue({
                                                               fieldId: 'firstname',
                                                               value: firstName
                                                       });
                                                       customerRecord.setValue({
                                                               fieldId: 'lastname',
                                                               value: lastName
                                                       });
                                                       customerRecord.setValue({
                                                               fieldId: 'custentity_enl_cnpjcpf',
                                                               value: cliente['CPF']
                                                       });
                                               }
                                               var customerRecord = record_1.default.load({
                                                       type: 'customer',
                                                       id: searchCustomer[0].id
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'email',
                                                       value: cliente['Email']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'mobilephone',
                                                       value: cliente['Celular']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'phone',
                                                       value: cliente['celularComercial']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'homephone',
                                                       value: cliente['telefoneResidencial']
                                               });
                                               var sexo = cliente['Sexo'].toLowerCase();
                                               if (sexo == 'masculino') {
                                                       sexo = 1;
                                               }
                                               else {
                                                       sexo = 2;
                                               }
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_rsc_sexo',
                                                       value: sexo
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_codigo_externo',
                                                       value: cliente['CodigoClienteExterno']
                                               });
                                               var nascimento = cliente['DataNascimento'].split('T');
                                               var dataNasc = nascimento[0].split('-');
                                               var nascData = dataNasc[2] + '/' + dataNasc[1] + '/' + dataNasc[0];
                                               nascData = nascData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                                               nascData = new Date(nascData);
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_data_nascimento',
                                                       value: nascData
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_nacionalidade',
                                                       value: cliente['Nacionalidade']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_naturalidade',
                                                       value: cliente['Naturalidade']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_estado_civil',
                                                       value: cliente['EstadoCivil']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_rg',
                                                       value: cliente['RG']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentityprof',
                                                       value: cliente['Profissao']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_orgao_expedidor',
                                                       value: cliente['OrgaoExpedidor']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_telefone_comercial',
                                                       value: cliente['TelefoneComercial']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_tipo_pessoa',
                                                       value: cliente['TipoPessoa']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_nome_pai',
                                                       value: cliente['NomePai']
                                               });
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_nome_mae',
                                                       value: cliente['NomeMae']
                                               });
                                               var emissao = cliente['DataEmissao'].split('T');
                                               // Log.error('nascimento', nascimento)
                                               var dataEmissao = emissao[0].split('-');
                                               var emissaoData = dataEmissao[2] + '/' + dataEmissao[1] + '/' + dataEmissao[0];
                                               emissaoData = emissaoData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                                               emissaoData = new Date(emissaoData);
                                               customerRecord.setValue({
                                                       fieldId: 'custentity_lrc_data_emissao',
                                                       value: emissaoData
                                               });
                                               customerRecord.save({
                                                       ignoreMandatoryFields: true
                                               });

                                               if (principal == true) {
                                                       idClientePrincipal = clienteId;
                                               }
                                       }
                               });

                                var objFaturaprincipal = {};

                                var dataCadastro = retorno.DataCadastro.split('T');
                                var dateCadastro = dataCadastro[0].split('-');
                                var cadastroData = dateCadastro[2] + '/' + dateCadastro[1] + '/' + dateCadastro[0];
                                cadastroData = cadastroData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                                cadastroData = new Date(cadastroData);

                                var dataVenda = retorno.DataVenda.split('T');
                                var dateVenda = dataVenda[0].split('-');
                                var vendaData = dateVenda[2] + '/' + dateVenda[1] + '/' + dateVenda[0];
                                vendaData = vendaData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                                vendaData = new Date(vendaData);
                                var arrayerros = [];
                                var string = '';
                                var stringFinal = '';

                                var fieldsCustomer = {
                                        "custbody_rsc_nr_proposta": retorno.NumeroProposta,
                                        "duedate": cadastroData,
                                        "custbody_lrc_distribuicao_premio": retorno.PossuiDistribuicaoPremio,
                                        "custbody_lrc_critica_fluxo": retorno.CriticaFluxo,
                                        "custbody_rsc_projeto_obra_gasto_compra": retorno.CodigoEmpreendimento,
                                        "custbody_rsc_ebu": retorno.CodigoBloco,
                                        "custbody_lrc_codigo_unidade": retorno.CodigoUnidade,
                                        "custbody_lrc_numero_contrato": retorno.NumeroContrato,
                                        "custbody_rsc_data_venda": vendaData,
                                        "custbody_lrc_tipo_contrato": retorno.TipoContrato,
                                        "custbody_rsc_ativo": retorno.Ativo,
                                        "custbody_lrc_itbi_gratis": retorno.ITBIGratis,
                                        "custbody_lrc_registro_gratis": retorno.RegistroGratis,
                                        "custbody_lrc_vlr_venda_att": retorno.ValorVendaAtualizada,
                                        "custbody_lrc_vlr_devedor": retorno.ValorSaldoDevedor,
                                        "custrecord_enl_bankid": retorno.Banco,
                                        "custbody_rsc_tipo_op": retorno.TipoOperacao,
                                        "custbody_rsc_mod_financ": retorno.ModalidadeFinanciamento,
                                        "custbody_rsc_sist_amort": retorno.SistemaAmortizacao,
                                        "custbody_lrc_valor_fgts": retorno.ValorFGTS,
                                        "custbody_lrc_vlr_subsidio": retorno.ValorSubsidio,
                                        "custbody_lrc_vlr_interveniencia": retorno.ValorInterveniencia,
                                        "custbody_lrc_recursos_proprios": retorno.ValorRecursosProprios,
                                        "custrecord_gst_instal_interestrate": retorno.TaxaJurosv,
                                        "custbody_lrc_assessoria": retorno.Assessoria,
                                        "custbody_lrc_vlr_total_comissao": retorno.ValorTotalComissao,
                                };
                                var invoiceRecord = record.create({
                                        type: 'invoice',
                                });
                                Object.keys(fieldsCustomer).forEach(function (key) {
                                        invoiceRecord.setValue({
                                                fieldId: key,
                                                value: fieldsCustomer[key]
                                        });

                                });
                                invoiceRecord.setValue({
                                        fieldId: 'entity',
                                        value: idClientePrincipal
                                });
                                var localidade = 114;
                                var item = 195 ;
                                invoiceRecord.setValue({
                                        fieldId: 'location',
                                        value: localidade
                                });
                                invoiceRecord.setSublistValue({
                                        fieldId: 'item',
                                        sublistId: 'item',
                                        line: 0,
                                        value: item
                                });
                                invoiceRecord.setSublistValue({
                                        fieldId: 'amount',
                                        sublistId: 'item',
                                        line: 0,
                                        value: ctx.ValorVenda
                                });
                                invoiceRecord.setSublistValue({
                                        fieldId: 'quantity',
                                        sublistId: 'item',
                                        line: 0,
                                        value: 1
                                });
                                var faturaPrincipalId = invoiceRecord.save({
                                        ignoreMandatoryFields: true
                                });
                                /*var faturas = ctx.ListaSerie;
                                if (faturas) {
                                        objRetorno['ListaSerie'] = 'Status: Ok';
                                        faturas.forEach(function (fatura) {
                                                var qntd = fatura.Quantidade;
                                                var dataParcela = fatura.Data.split('T');
                                                var date = dataParcela[0].split('-');
                                                var parcelaData = date[2] + '/' + date[1] + '/' + date[0];
                                                parcelaData = parcelaData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                                                var meses = fatura.QuantidadeMesesEntreParcela;
                                                var dataCorrecao = fatura.DataInicioCorrecao.split('T');
                                                var data = dataCorrecao[0].split('-');
                                                var correcaoData = data[2] + '/' + data[1] + '/' + data[0];
                                                correcaoData = correcaoData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                                                correcaoData = new Date(correcaoData);
                                                parcelaData = new Date(parcelaData);
                                                var dataParcelaCalcula = fatura.Data;
                                                var fieldsCustomer = {
                                                        "custbody_lrc_cod_parcela": fatura.Cod,
                                                        "custbodyrsc_tpparc": fatura.TipoParcela,
                                                        "total": fatura.ValorTotal,
                                                        "custbody_lrc_possui_correcao": fatura.PossuiCorrecao,
                                                        "custbody_lrc_vlr_presente": fatura.ValorPresente,
                                                        "custbody_lrc_percentual": fatura.Percentual,
                                                        "custbody_lrc_crit_analise_credito": fatura.CriticaAnaliseCredito,
                                                        "custbody_lrc_data_inicio_correcao": correcaoData,
                                                        "custbody_lrc_tipo_amortizacao": fatura.TipoAmortizacao,
                                                        "custbody_lrc_taxa_amortizacao": fatura.TaxaAmortizacao,
                                                        "custbody_lrc_tipo_receita": fatura.TipoReceita,
                                                        "custbody_lrc_fatura_principal": faturaPrincipalId,
                                                        "location": localidade,
                                                        "entity": idClientePrincipal,
                                                        // "approvalstatus": 2
                                                };
                                                var _loop_1 = function (i) {
                                                        var parcelaRecord = record_1.default.create({
                                                                type: 'invoice'
                                                        });
                                                        Object.keys(fieldsCustomer).forEach(function (key) {
                                                                parcelaRecord.setValue({
                                                                        fieldId: key,
                                                                        value: fieldsCustomer[key]
                                                                });
                                                                // Log.error('fieldsCustomer',fieldsCustomer[key]);
                                                        });
                                                        parcelaRecord.setValue({
                                                                fieldId: 'duedate',
                                                                value: parcelaData
                                                        });
                                                        if (i != 0) {
                                                                Log.error('dataParcelaCalcula', dataParcelaCalcula);
                                                                dataParcelaCalcula = JSON.stringify(dataParcelaCalcula).split('T');
                                                                Log.error('dataParcelaCalcula', dataParcelaCalcula);
                                                                var dateCalcula = dataParcelaCalcula[0].split('-');
                                                                dateCalcula[1] = Number(dateCalcula[1]) + Number(meses);
                                                                var anoSplited = dateCalcula[0].split('"');
                                                                Log.error('anoSplited', anoSplited);
                                                                if (dateCalcula[1] > 12) {
                                                                        Log.error('dateCalcula[1]', dateCalcula[1]);
                                                                        var anos = Math.floor(dateCalcula[1] / 12);
                                                                        Log.error('anos', anos);
                                                                        dateCalcula[1] = dateCalcula[1] - 12;
                                                                        Log.error('dateCalcula[1]', dateCalcula[1]);
                                                                        Log.error('dateCalcula[0]', dateCalcula[0]);
                                                                        anoSplited[1] = Number(anos) + Number(anoSplited[1]);
                                                                }
                                                                var parcelaCalcula = dateCalcula[1] + '/' + dateCalcula[2] + '/' + anoSplited[1];
                                                                Log.error('parcelaCalcula', parcelaCalcula);
                                                                // parcelaCalcula = parcelaCalcula.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                                                                parcelaCalcula = new Date(parcelaCalcula);
                                                                dataParcelaCalcula = parcelaCalcula;
                                                                Log.error('parcelaCalcula', parcelaCalcula);
                                                                parcelaRecord.setValue({
                                                                        fieldId: "duedate",
                                                                        value: parcelaCalcula
                                                                });
                                                        }
                                                        parcelaRecord.setSublistValue({
                                                                sublistId: 'item',
                                                                fieldId: 'item',
                                                                line: 0,
                                                                value: item
                                                        });
                                                        parcelaRecord.setSublistValue({
                                                                sublistId: 'item',
                                                                fieldId: 'amount',
                                                                line: 0,
                                                                value: fatura.ValorParcela
                                                        });
                                                        parcelaRecord.save({
                                                                ignoreMandatoryFields: true
                                                        });
                                                };
                                                for (var i = 0; i < qntd; i++) {
                                                        _loop_1(i);
                                                }
                                        });
                                }
                                else {
                                        objRetorno['ListaSerie'] = 'Status: Não há lista de parcelas no json';
                                }*/

                                registroProcesso.setValue(
                                    {
                                            fieldId: 'custrecord_rsc_invoice_netsuite',
                                            value: faturaPrincipalId
                                    });

                                registroProcesso.setValue(
                                    {
                                            fieldId: 'custrecord_rsc_processado',
                                            value: 'T'
                                    });

                        } else {
                                registroProcesso.setValue(
                                    {
                                            fieldId: 'custrecord_rsc_log_error',
                                            value: 'Status: Não há lista de compradores no json'
                                    });
                                registroProcesso.setValue(
                                    {
                                            fieldId: 'custrecord_rsc_erro_flag',
                                            value: 'T'
                                    });
                        }

                } else {
                        registroProcesso.setValue(
                            {
                                    fieldId: 'custrecord_rsc_log_error',
                                    value: 'Status: Não há lista de compradores no json'
                            });
                        registroProcesso.setValue(
                            {
                                    fieldId: 'custrecord_rsc_erro_flag',
                                    value: 'T'
                            });
                }

                registroProcesso.save();

        }

        /**
         * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
         * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
         * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
         *     provided automatically based on the results of the map stage.
         * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
         *     reduce function on the current group
         * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
         * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} reduceContext.key - Key to be processed during the reduce stage
         * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
         *     for processing
         * @since 2015.2
         */
        const reduce = (reduceContext) => {

        }


        /**
         * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
         * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
         * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
         * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
         *     script
         * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
         * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
         * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
         * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
         *     script
         * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
         * @param {Object} summaryContext.inputSummary - Statistics about the input stage
         * @param {Object} summaryContext.mapSummary - Statistics about the map stage
         * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
         * @since 2015.2
         */
        const summarize = (summaryContext) => {

        }

        return {getInputData, map, reduce, summarize}

    });
