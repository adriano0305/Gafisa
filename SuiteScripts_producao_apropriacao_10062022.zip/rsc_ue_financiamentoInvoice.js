/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/record', 'N/task'],
/**
 * @param{record} record
 * @param{task} task
 */
    (record, task) => {
        const afterSubmit = (scriptContext) => {
            var Rec = scriptContext.newRecord;
            var cond_pagamento = Rec.getValue({fieldId: 'custbody_rsc_terms'});
            var checkParcelas = Rec.getValue({fieldId: 'custbody_rsc_checkparcelas'})

            const othersObj = {
                total: Rec.getValue({fieldId: 'total'}),
                id: Rec.id
            };

            const objList = {
                entity: Rec.getValue({fieldId: 'entity'}),
                subsidiary: Rec.getValue({fieldId: 'subsidiary'}),
                location: Rec.getValue({fieldId: 'location'}),
                custbody_rsc_projeto_obra_gasto_compra: Rec.getValue({fieldId: 'custbody_rsc_projeto_obra_gasto_compra'}),
                startdate: Rec.getValue({fieldId: 'startdate'}),
                enddate: Rec.getValue({fieldId: 'enddate'}),
                duedate: Rec.getValue({fieldId: 'duedate'}),
                memo: Rec.getValue({fieldId: 'memo'}),
                custbody_lrc_fatura_principal: Rec.getValue({fieldId: 'custbody_lrc_fatura_principal'}),
                custbody_rsc_reparcelamento_origem: Rec.getValue({fieldId: 'custbody_rsc_reparcelamento_origem'}),
                custbody_enl_operationtypeid: Rec.getValue({fieldId: 'custbody_enl_operationtypeid'})
            };

            const objSublist = {
                item: 287,
                quantity: 1
            };

            if(checkParcelas == false && cond_pagamento){
                    task.create({
                        taskType: task.TaskType.SCHEDULED_SCRIPT,
                        scriptId: 'customscript_rsc_scheduled_createinvoice',
                        deploymentId: 'customdeploy_rsc_scheduled_createinvoice',
                        params: {
                            custscript_rsc_qtdfaturas: cond_pagamento,
                            custscript_rsc_get_objlist: objList,
                            custscript_rsc_get_objsublist: objSublist,
                            custscript_rsc_get_recfatura: othersObj
                        }
                    }).submit();
                }
            }

        return { afterSubmit}

    });
