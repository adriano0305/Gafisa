/**
 *@NApiVersion 2.1
 *@NScriptType Suitelet
 */
define(['N/log', 'N/record', 'N/search'], function(log, record, search) {
function onRequest(context) {
    log.audit('onRequest', context);

    const request = context.request;
    const response = context.response;

    if (request.method == 'GET') {
        var page = record.load({
            type: 'subsidiary',
            id: 1
        });
        log.audit('page', page);
    }
}

return {
    onRequest: onRequest
}
});
