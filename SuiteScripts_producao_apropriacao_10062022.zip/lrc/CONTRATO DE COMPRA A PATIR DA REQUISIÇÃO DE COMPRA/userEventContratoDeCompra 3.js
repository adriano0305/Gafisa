/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * User_botoesTelaItem.ts
 * 
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        var form = ctx.form;
        form.clientScriptModulePath = "./clientScriptContratoDeCompra.js";
        form.addButton({
            id: 'custpage_button',
            label: 'Transformar em um contrato de compra',
            functionName: 'criarContratoDeCompra',
        });
    };
    exports.beforeLoad = beforeLoad;
});
