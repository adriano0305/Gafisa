/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_botao_impressaopdf.js
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        var form = ctx.form;
        form.clientScriptModulePath = './ClientScript_pdfbtn_function.js';
        log_1.default.error("Form->", form);
        if (ctx.type == ctx.UserEventType.EDIT) {
            form.addButton({
                id: 'custpage_btn_imprimir_pdf_do_Registro',
                label: 'Imprimir PDF do Registro',
                // functionName: 'Impressao_do_pdf( ' + form  + ')'
                functionName: 'Impressao_do_pdf'
            });
        }
    };
    exports.beforeLoad = beforeLoad;
});
