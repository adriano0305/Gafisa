/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * ClientScript_Segmentos.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/log", "N/url"], function (require, exports, currentRecord_1, log_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Visualizar_Segmento = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    log_1 = __importDefault(log_1);
    url_1 = __importDefault(url_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var Visualizar_Segmento = function () {
        var record = currentRecord_1.default.get();
        log_1.default.error("ClientScript", "Done");
        log_1.default.error("currentRecord", record);
        var test = record.getValue('custrecord_lrc_segmento_seg');
        log_1.default.error("segmento", test);
        //  window.location.href = URL.resolveScript({
        //      scriptId: "customscript_lrc_st_preview_segment",
        //      deploymentId: "customdeploy_lrc_st_preview_segment",
        //      params: {
        //         "segment":  record.getText('custrecord_lrc_segmento_seg'),
        //         "layout":   record.getValue('custrecord_lrc_layout_pdf_seg'),
        //         "recordId": record.getValue('custrecord_lrc_id_registro_gerador_pdf')
        //      }
        //  });
        window.location.href = url_1.default.resolveScript({
            scriptId: "customscript_lrc_st_preview_segment",
            deploymentId: "customdeploy_lrc_st_preview_segment",
            params: {
                "segment": record.getText('custrecord_lrc_segmento_seg'),
                "layout": record.getValue('custrecord_lrc_layout_pdf_seg'),
                "recordId": record.getValue('custrecord_lrc_id_registro_gerador_pdf')
            }
        });
    };
    exports.Visualizar_Segmento = Visualizar_Segmento;
});
