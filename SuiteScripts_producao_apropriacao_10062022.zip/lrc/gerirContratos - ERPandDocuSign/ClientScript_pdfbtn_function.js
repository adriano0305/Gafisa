/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * ClientScript_pdfbtn.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url", "N/log"], function (require, exports, currentRecord_1, url_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Impressao_do_pdf = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    log_1 = __importDefault(log_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var Impressao_do_pdf = function () {
        var currentRecord = currentRecord_1.default.get();
        log_1.default.error("ClientScriptPDF", "Chegou");
        log_1.default.error("recordId", currentRecord.id);
        log_1.default.error("Form", currentRecord.getValue({
            fieldId: 'customform'
        }));
        log_1.default.error("recordType", currentRecord.type);
        window.location.href = url_1.default.resolveScript({
            scriptId: 'customscript_lrc_imprimir_pdf',
            deploymentId: 'customdeploy_lrc_imprimir_pdf',
            params: {
                recordId: currentRecord.id,
                form: currentRecord.getValue({
                    fieldId: 'customform'
                }),
                tranid: currentRecord.getValue({
                    fieldId: 'tranid'
                }),
                recordtype: currentRecord.type,
            }
        });
    };
    exports.Impressao_do_pdf = Impressao_do_pdf;
});
