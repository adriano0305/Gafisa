/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_Segmentos.ts
 *
 * Retornar valor de crédito do memorando de crédito.
 *
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        var newFormulario = ctx.newRecord;
        var formulario = ctx.form;
        formulario.clientScriptModulePath = './ClientScript_Segmentos.js';
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT) {
            formulario.addButton({
                label: 'Pré Visualizar Segmento',
                id: 'custpage_btn_visualizar_segmento',
                functionName: 'Visualizar_Segmento'
            });
        }
    };
    exports.beforeLoad = beforeLoad;
});
