/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_regrasRegistro_Simbolos.js
 *
 * UserEvent aplicado nos registros de simbolo'
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/search"], function (require, exports, log_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    function checkDups(recordType, layout, symbol, currentInternalId) {
        return (checkDupFormSymbol(recordType, layout, symbol, currentInternalId)
            || checkDupFieldSymbol(recordType, layout, symbol, currentInternalId)
            || checkDupSublistSymbol(recordType, layout, symbol, currentInternalId)
            || checkDupSuiteScriptSymbol(recordType, layout, symbol, currentInternalId));
    }
    function checkDupFormSymbol(recordType, layout, symbol, currentInternalId) {
        var filters = [
            ["custrecord_lrc_simbolo_form", "IS", symbol],
            "AND",
            ["custrecord_lrc_simbolo_form_layout", "IS", layout]
        ];
        if (recordType == "customrecord_lrc_simbolo_formulario" && currentInternalId) {
            filters.push("AND");
            filters.push(["internalid", "NONEOF", currentInternalId.toString()]);
        }
        log_1.default.error("filters", filters);
        return (search_1.default.create({
            type: "customrecord_lrc_simbolo_formulario",
            filters: filters
        }).runPaged().count > 0);
    }
    function checkDupFieldSymbol(recordType, layout, symbol, currentInternalId) {
        var filters = [
            ["custrecord_lrc_simbolo_campo", "IS", symbol],
            "AND",
            ["custrecord_lrc_simbolo_campo_layout", "IS", layout]
        ];
        if (recordType == "customrecord_lrc_simbolo_campo" && currentInternalId) {
            filters.push("AND");
            filters.push(["internalid", "NONEOF", currentInternalId.toString()]);
        }
        log_1.default.error("filters", filters);
        return (search_1.default.create({
            type: "customrecord_lrc_simbolo_campo",
            filters: filters
        }).runPaged().count > 0);
    }
    function checkDupSublistSymbol(recordType, layout, symbol, currentInternalId) {
        var filters = [
            ["custrecord_lrc_simbolo", "IS", symbol],
            "AND",
            ["custrecord_lrc_layout", "IS", layout]
        ];
        if (recordType == "customrecord_lrc_simbolo_sublista" && currentInternalId) {
            filters.push("AND");
            filters.push(["internalid", "NONEOF", currentInternalId.toString()]);
        }
        log_1.default.error("filters", filters);
        return (search_1.default.create({
            type: "customrecord_lrc_simbolo_sublista",
            filters: filters
        }).runPaged().count > 0);
    }
    function checkDupSuiteScriptSymbol(recordType, layout, symbol, currentInternalId) {
        var filters = [
            ["custrecord_lrc_script_simbolo", "IS", symbol],
            "AND",
            ["custrecord_lrc_simbolo_script_layout", "IS", layout]
        ];
        if (recordType == "customrecord_lrc_simbolo_suitescript" && currentInternalId) {
            filters.push("AND");
            filters.push(["internalid", "NONEOF", currentInternalId.toString()]);
        }
        log_1.default.error("filters", filters);
        return (search_1.default.create({
            type: "customrecord_lrc_simbolo_suitescript",
            filters: filters
        }).runPaged().count > 0);
    }
    exports.beforeSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var newRecord = ctx.newRecord;
            var objSymbolFields = {
                // recordType: ID do campo "Simbolo" no recordType
                customrecord_lrc_simbolo_formulario: "custrecord_lrc_simbolo_form",
                customrecord_lrc_simbolo_campo: "custrecord_lrc_simbolo_campo",
                customrecord_lrc_simbolo_sublista: "custrecord_lrc_simbolo",
                customrecord_lrc_simbolo_suitescript: "custrecord_lrc_script_simbolo",
            };
            var objLayoutFields = {
                // recordType: ID do campo "Layout PDF de Registro" no recordType
                customrecord_lrc_simbolo_formulario: "custrecord_lrc_simbolo_form_layout",
                customrecord_lrc_simbolo_campo: "custrecord_lrc_simbolo_campo_layout",
                customrecord_lrc_simbolo_sublista: "custrecord_lrc_layout",
                customrecord_lrc_simbolo_suitescript: "custrecord_lrc_simbolo_script_layout",
            };
            var recordType = newRecord.type.toString();
            var symbolFieldId = objSymbolFields[recordType];
            log_1.default.error("symbolFieldId", symbolFieldId);
            var layoutFieldId = objLayoutFields[recordType];
            log_1.default.error("layoutFieldId", layoutFieldId);
            var symbol = String(newRecord.getValue(symbolFieldId));
            log_1.default.error("symbol", symbol);
            var layout = String(newRecord.getValue(layoutFieldId));
            log_1.default.error("layout", layout);
            if (checkDups(recordType, layout, symbol, newRecord.id)) {
                throw Error("O símbolo " + symbol + " foi encontrado em outro registro no NetSuite para o mesmo 'Layout de PDF de Registro'." + " A submissão será cancelada!");
            }
        }
        return true;
    };
});
