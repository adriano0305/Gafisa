/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_regrasRegistro.js
 *
 * UserEvent aplicado no registro 'LRC @ Campo'
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    exports.beforeSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var record = ctx.newRecord;
            var getPDFRecordId = record.getValue("custrecord_lrc_regcampo_idinterno_regist");
            var firstHopId = record.getValue("custrecord_lrc_regcampo_idregistro_inici");
            if (!getPDFRecordId && !firstHopId) {
                throw Error('Não há comportamento bem definido quando o campo "Capturar ID interno do registro gerador de PDF" é falso'
                    + ' e o campo "ID interno do registro inicial" não está preenchido. A submissão será cancelada!');
            }
            else if (getPDFRecordId && firstHopId) {
                throw Error('Não há comportamento bem definido quando o campo "Capturar ID interno do registro gerador de PDF" é verdadeiro'
                    + ' e o campo "ID interno do registro inicial" está preenchido. A submissão será cancelada!');
            }
            return true;
        }
    };
});
