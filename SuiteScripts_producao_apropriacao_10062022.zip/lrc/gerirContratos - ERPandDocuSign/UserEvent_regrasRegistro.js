/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_regrasRegistro.js
 *
 * UserEvent aplicado no registro 'LRC @ Layout PDF de Registro'
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log"], function (require, exports, search_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    function checkDup(recordType, entryForm, transactionForm, currentInternalId) {
        var searchResultCount = 0;
        if (entryForm) {
            // Checar se há alguma tupla (entryForm, recordType) em outro registro de "Layout de PDF de registro"
            var filters = [
                ["custrecord_lrc_layout_id_tipo_registro", "IS", recordType],
                "AND",
                ["custrecord_lrc_layout_entryform", "IS", entryForm]
            ];
            if (currentInternalId) { // Deve ser verificado se não estamos buscando o registro atual (ocorre no modo de edição, mas não na criação)
                filters.push("AND");
                filters.push(["internalid", "NONEOF", currentInternalId.toString()]);
            }
            log_1.default.error("filters", filters);
            searchResultCount = search_1.default.create({
                type: "customrecord_lrc_reg_layout_pdf",
                filters: filters
            }).runPaged().count;
        }
        else {
            // Checar se há alguma tupla (transactionForm, recordType) em outro registro de "Layout de PDF de registro"
            var filters = [
                ["custrecord_lrc_layout_id_tipo_registro", "IS", recordType],
                "AND",
                ["custrecord_lrc_layout_form", "IS", transactionForm]
            ];
            if (currentInternalId) { // Deve ser verificado se não estamos buscando o registro atual (ocorre no modo de edição, mas não na criação)
                filters.push("AND");
                filters.push(["internalid", "NONEOF", currentInternalId.toString()]);
            }
            log_1.default.error("filters", filters);
            searchResultCount = search_1.default.create({
                type: "customrecord_lrc_reg_layout_pdf",
                filters: filters
            }).runPaged().count;
        }
        log_1.default.error("searchResultCount", searchResultCount);
        return (searchResultCount > 0);
    }
    exports.beforeSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT) {
            var newRecord = ctx.newRecord;
            var transactionForm = newRecord.getValue("custrecord_lrc_layout_form"); // Formularios de transacao
            var entryForm = newRecord.getValue("custrecord_lrc_layout_entryform"); // Formularios personalizados 
            var recordType = newRecord.getValue("custrecord_lrc_layout_id_tipo_registro"); // texto que representa o ID do tipo de registro
            if (!recordType) {
                throw Error('É necessário preencher o campo "ID DO TIPO DO REGISTRO"');
            }
            else if (!transactionForm && !entryForm) {
                throw Error("É necessário preencher pelo menos algum formulário!");
            }
            else if (transactionForm && entryForm) {
                throw Error("Apenas um dos campos de formulário deve ser preenchido!");
            }
            if (checkDup(recordType, entryForm, transactionForm, newRecord.id)) { // Caso ja exista um registro com uma mesma tupla (entryForm, recordType) ou (transactionForm, recordType), deve ocorrer um erro
                if (entryForm)
                    throw Error('Já existe outro registro com a mesma tupla  "(Formulário de Entrada, ID do Tipo do Registro)"');
                else
                    throw Error('Já existe outro registro com a mesma tupla  "(Formulário de Transação, ID do Tipo do Registro)"');
            }
            return true;
        }
    };
});
