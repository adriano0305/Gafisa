/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* EFD – INTEGRAÇÃO JUNIX BAIXA AO PAGAMENTO
* MapReduce
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record", "N/log"], function (require, exports, search_1, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    //cria uma busca no registro json de cobrança do baixa pagamento junix
    var getInputData = function () {
        return search_1.default.create({
            type: 'customdeploy_lrc_criacao_cobranca_junix',
            filters: [
                ['custbody8', 'IS', 'T'], 'AND', ['custbody_lrc_enviado_junix_', 'IS', 'F']
            ],
            columns: ['IdDespesa', 'trandate', 'usertotal'] // falta colocar o campo "ComprovantePagamento" que é o arquivo de comprovante da cobrança
            //le as informações da cobrança 
            /*IdDespesa = IdDespesa
            * DataPagamento = trandate
            * ValorPago = usertotal
            * ComprovantePagamento = ainda deve ser feito
            */
        });
    };
    exports.getInputData = getInputData;
    //cria um variavel mapReduce que fará uma busca no netsuite a cada 15 minutos para pegar todos os registros não processados
    var map = function (ctx) {
        try {
            var requisicao = JSON.parse(ctx.value);
            var input = JSON.parse(requisicao.values['']); //customdeploy_lrc_criacao_cobranca_bjunix
            var record = record_1.default.load({
                type: 'vendorbill',
                isDynamic: true,
                id: requisicao.id
            });
            //id da despesa
            var idDespesa = record.getValue({
                fieldId: 'IdDespesa'
            });
            //DataPagamento
            var dataPagamento = record.getValue({
                fieldId: 'trandate'
            });
            //ValorPago
            var valorPago = record.getValue({
                fieldId: 'usertotal'
            });
            //ComprovantePagamento
            // const comprovantePagamento = record.getValue({
            //     fieldId: '',
            // });
            var cobranca = {};
            cobranca['idDespesa'] = idDespesa;
            cobranca['trandate'] = dataPagamento;
            cobranca['usertotal'] = valorPago;
            //ainda deve ser feito o pedaço para enviar para junix
        }
        catch (error) {
            log_1.default.error('Error', error);
            alert("Error: " + error);
        }
    };
    exports.map = map;
});
