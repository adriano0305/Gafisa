/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEventScript_BloqueioFornecedor_sublistas.ts
 * 
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/search"], function (require, exports, log_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    var beforeSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var newRecordType = ctx.newRecord.type;        
        log.debug('newRecordType: ', newRecordType);        
        // log.error('contextNewRecord', ctx.newRecord)

        log.debug('ctx.type: ', ctx.type);
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT) {
            var sublistId = "";
            var fieldId = "";
            if (newRecordType == "purchaserequisition") {
                sublistId = "item";
                fieldId = "povendor";
            }
            else if (newRecordType == "customtransaction_rsc_cotacao_compras") {
                sublistId = 'recmachcustrecord_rsc_cot_forn_cotid';
                fieldId = 'custrecord_rsc_cot_fornid';
            }
            else {
                return;
            }
            var nlinhas = newRecord.getLineCount({
                sublistId: sublistId
            });
            log_1.default.error("Num linhas", nlinhas);
            for (var i = 0; i < nlinhas; i++) {
                //obter fornecedores na sublista
                var idFornecedor = newRecord.getSublistValue({
                    sublistId: sublistId,
                    fieldId: fieldId,
                    line: i
                });
                log_1.default.error('idfornecedor', idFornecedor);
                if (idFornecedor) {
                    //buscar status de suspensão do fornecedor
                    var searchFornecedor = search_1.default.create({
                        type: "vendor",
                        filters: ['internalid', 'IS', idFornecedor],
                        columns: ['custentity_lrc_status_suspensao']
                    }).run().getRange({
                        start: 0,
                        end: 1
                    });
                    log_1.default.error('search', searchFornecedor);
                    //Verificar se o fornecedor está suspenso
                    var statusSuspensao = Number(searchFornecedor[0].getValue('custentity_lrc_status_suspensao'));
                    if (statusSuspensao != 1) {
                        if (statusSuspensao == 2 || statusSuspensao == 3 || statusSuspensao == 4 || statusSuspensao == 5 || statusSuspensao == 6) {
                            if (newRecordType == 'purchaserequisition' || newRecordType == 'customtransaction_rsc_cotacao_compras') {
                                throw Error('Fornecedor Suspenso');
                            }
                        }
                    }
                }
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
// Contrato de compra = "purchasecontract"
// Pagamento = "vendorpayment"
// Requisição = "purchaserequisition"
// Pedido de compra = "purchaseorder"
// Cotação de compras = "customtransaction_rsc_cotacao_compras"
// Cotação de compra = "customtransaction_rsc_cotacao_compras"     
