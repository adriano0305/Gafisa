/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClienteScript_BloqueioFornecedor.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/search"], function (require, exports, log_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = exports.pageInit = void 0;
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var currentRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        //Log.error('type', currentRecordType )
        //Log.error('ctx', ctx);
        //Log.error('fieldId', fieldId);
        //Log.error('sublistId', ctx.sublistId);
        if (fieldId == 'entity' && !ctx.sublistId) {
            var objField = currentRecord.getField({
                fieldId: fieldId
            });
            var vendorId = currentRecord.getValue({
                fieldId: fieldId
            });
            if (!vendorId) {
                return;
            }
            var vendorFields = search_1.default.lookupFields({
                type: 'vendor',
                id: vendorId,
                columns: ['custentity_lrc_status_suspensao']
            });
            log_1.default.error("Campo", objField);
            log_1.default.error("CampoValue", vendorId);
            log_1.default.error("lookupFields", vendorFields);
            if (vendorFields && vendorFields.custentity_lrc_status_suspensao && vendorFields.custentity_lrc_status_suspensao[0]) {
                log_1.default.error("status", vendorFields.custentity_lrc_status_suspensao[0]);
                var statusSuspensao = vendorFields.custentity_lrc_status_suspensao[0].value;
                if (statusSuspensao == 3 || statusSuspensao == 4 || statusSuspensao == 5 || statusSuspensao == 6) {
                    alert("Fornecedor Suspenso");
                    if (currentRecord.getField({ fieldId: 'custpage_vendorid' })) {
                        log_1.default.error("Teste1", "Entrou");
                        var value = currentRecord.getValue({
                            fieldId: 'custpage_vendorid'
                        });
                        currentRecord.setValue({
                            fieldId: 'entity',
                            value: Number(value)
                        });
                    }
                    else {
                        log_1.default.error("Teste2", "Entrou");
                        currentRecord.setValue({
                            fieldId: 'entity',
                            value: ''
                        });
                    }
                }
            }
        }
    };
    exports.fieldChanged = fieldChanged;
});
