/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * ClientScript_BloqueioFornecedor_sublistas.ts
 * 
 * Rteste.
 * 
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/search"], function (require, exports, log_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateField = exports.pageInit = void 0;
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var validateField = function (ctx) {
        var currentRecord = ctx.currentRecord;
        var currentRecordType = ctx.currentRecord.type;
        var sublistId = "";
        var fieldId = "";
        if (currentRecordType == "purchaserequisition") {
            sublistId = "item";
            fieldId = "povendor";
        }
        else if (currentRecordType == "customtransaction_rsc_cotacao_compras") {
            sublistId = 'recmachcustrecord_rsc_cot_forn_cotid';
            fieldId = 'custrecord_rsc_cot_fornid';
        }
        else {
            return;
        }
        if (ctx.sublistId == sublistId && ctx.fieldId == fieldId) {
            //pegar id do fornecedor
            var idFornecedor = currentRecord.getCurrentSublistValue({
                sublistId: sublistId,
                fieldId: fieldId
            });
            log_1.default.error('pegar id', idFornecedor);
            //acessar fornedor em questão
            var fieldLookUp = search_1.default.lookupFields({
                type: 'vendor',
                id: idFornecedor,
                columns: ['custentity_lrc_status_suspensao']
            });
            log_1.default.error('fieldLookUp2', fieldLookUp);
            //buscar status de suspensão do fornecedor
            if (fieldLookUp.custentity_lrc_status_suspensao[0]) {
                var statusSuspensao = fieldLookUp.custentity_lrc_status_suspensao[0].value;
                log_1.default.error('status', statusSuspensao);
                if (statusSuspensao != 1) {
                    log_1.default.error("Entrou", "Aqui");
                    if (statusSuspensao == 2 || statusSuspensao == 3 || statusSuspensao == 4 || statusSuspensao == 5 || statusSuspensao == 6) {
                        // let linhaSelecionada = currentRecord.selectLine({
                        //    sublistId: 'recmachcustrecord_rsc_cot_forn_cotid',
                        //    line: i
                        // });
                        // Log.error('linha selecionada', linhaSelecionada)
                        //    currentRecord.setCurrentSublistValue({
                        //       sublistId: 'recmachcustrecord_rsc_cot_forn_cotid',
                        //       fieldId: 'custrecord_rsc_cot_fornid',
                        //       value: '',
                        //       ignoreFieldChange: true
                        // });
                        // Log.error('setValue', currentRecord.setCurrentSublistValue)
                        // currentRecord.commitLine({
                        //    sublistId: 'item'
                        // });
                        alert('Fornecedor Suspenso');
                        return false;
                    }
                }
            }
        }
        return true;
    };
    exports.validateField = validateField;
});
