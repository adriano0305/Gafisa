/**
* @NAPIVersion 2.0
* @NScriptType Restlet
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/record", "N/runtime", "N/search"], function (require, exports, Log, record_1, runtime_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.post = exports.delete = void 0;
    Log = __importStar(Log);
    record_1 = __importDefault(record_1);
    runtime_1 = __importDefault(runtime_1);
    search_1 = __importDefault(search_1);
    var del = function (ctx) {
        var type = ctx.type;
        var id = ctx.id;
        return {
            success: true
        };
    };
    exports.delete = del;
    var post = function (ctx) {
        Log.error('passou', 'aqui');
        var objRetorno = {};
        var compradores = ctx.ListaCompradores;
        var idClientePrincipal = 0;
        if (compradores) {
            objRetorno['ListaCompradores'] = 'Status: Ok';
            compradores.forEach(function (comprador) {
                var principal = comprador.Principal;
                var cliente = comprador.Cliente;
                Log.error('json', cliente);
                Log.error('clienteId', cliente['Id']);
                var searchCustomer = search_1.default.create({
                    type: 'customer',
                    filters: [
                        ['entityid', 'IS', cliente['Id']]
                    ]
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                Log.error('searchCustomer[0]', searchCustomer[0]);
                if (searchCustomer[0]) {
                    if (principal == true) {
                        idClientePrincipal = Number(searchCustomer[0].id);
                    }
                    var customerRecord = record_1.default.load({
                        type: 'customer',
                        id: searchCustomer[0].id
                    });
                    customerRecord.setValue({
                        fieldId: 'email',
                        value: cliente['Email']
                    });
                    customerRecord.setValue({
                        fieldId: 'mobilephone',
                        value: cliente['Celular']
                    });
                    customerRecord.setValue({
                        fieldId: 'phone',
                        value: cliente['celularComercial']
                    });
                    customerRecord.setValue({
                        fieldId: 'homephone',
                        value: cliente['telefoneResidencial']
                    });
                    var sexo = cliente['Sexo'].toLowerCase();
                    if (sexo == 'masculino') {
                        sexo = 1;
                    }
                    else {
                        sexo = 2;
                    }
                    customerRecord.setValue({
                        fieldId: 'custentity_rsc_sexo',
                        value: sexo
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_codigo_externo',
                        value: cliente['CodigoClienteExterno']
                    });
                    var nascimento = cliente['DataNascimento'].split('T');
                    var dataNasc = nascimento[0].split('-');
                    var nascData = dataNasc[2] + '/' + dataNasc[1] + '/' + dataNasc[0];
                    nascData = nascData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                    nascData = new Date(nascData);
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_data_nascimento',
                        value: nascData
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_nacionalidade',
                        value: cliente['Nacionalidade']
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_naturalidade',
                        value: cliente['Naturalidade']
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_estado_civil',
                        value: cliente['EstadoCivil']
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_rg',
                        value: cliente['RG']
                    });
                    customerRecord.setValue({
                        fieldId: 'custentityprof',
                        value: cliente['Profissao']
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_orgao_expedidor',
                        value: cliente['OrgaoExpedidor']
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_telefone_comercial',
                        value: cliente['TelefoneComercial']
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_tipo_pessoa',
                        value: cliente['TipoPessoa']
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_nome_pai',
                        value: cliente['NomePai']
                    });
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_nome_mae',
                        value: cliente['NomeMae']
                    });
                    var emissao = cliente['DataEmissao'].split('T');
                    // Log.error('nascimento', nascimento)
                    var dataEmissao = emissao[0].split('-');
                    var emissaoData = dataEmissao[2] + '/' + dataEmissao[1] + '/' + dataEmissao[0];
                    emissaoData = emissaoData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                    emissaoData = new Date(emissaoData);
                    customerRecord.setValue({
                        fieldId: 'custentity_lrc_data_emissao',
                        value: emissaoData
                    });
                    customerRecord.save({
                        ignoreMandatoryFields: true
                    });
                    Log.error('Editando Cliente', customerRecord.save);
                }
                else {
                    var novoCliente_1 = record_1.default.create({
                        type: record_1.default.Type.CUSTOMER,
                        isDynamic: true
                    });
                    var cpf = cliente['CPF'];
                    if (cpf == '') {
                        novoCliente_1.setValue({
                            fieldId: 'isperson',
                            value: 'F'
                        });
                        novoCliente_1.setValue({
                            fieldId: 'companyname',
                            value: cliente['Nome']
                        });
                        novoCliente_1.setValue({
                            fieldId: 'custentity_enl_cnpjcpf',
                            value: cliente['CNPJ']
                        });
                    }
                    else {
                        var _a = getSeparetedName(cliente['Nome']), firstName = _a.firstName, lastName = _a.lastName;
                        novoCliente_1.setValue({
                            fieldId: 'isperson',
                            value: 'T'
                        });
                        novoCliente_1.setValue({
                            fieldId: 'firstname',
                            value: firstName
                        });
                        novoCliente_1.setValue({
                            fieldId: 'lastname',
                            value: lastName
                        });
                        novoCliente_1.setValue({
                            fieldId: 'custentity_enl_cnpjcpf',
                            value: cliente['CPF']
                        });
                    }
                    novoCliente_1.setValue({
                        fieldId: 'email',
                        value: cliente['Email']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'mobilephone',
                        value: cliente['TelefoneComercial']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'phone',
                        value: cliente['Celular']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'homephone',
                        value: cliente['TelefoneComercial']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'subsidiary',
                        value: 1
                    });
                    var sexo = cliente['Sexo'].toLowerCase();
                    if (sexo == 'masculino') {
                        sexo = 1;
                    }
                    else {
                        sexo = 2;
                    }
                    novoCliente_1.setValue({
                        fieldId: 'custentity_rsc_sexo',
                        value: sexo
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_codigo_externo',
                        value: cliente['CodigoClienteExterno']
                    });
                    Log.error('dataAntes', cliente['DataNascimento']);
                    var nascimento = cliente['DataNascimento'].split('T');
                    Log.error('nascimento', nascimento);
                    var dataNasc = nascimento[0].split('-');
                    var nascData = dataNasc[2] + '/' + dataNasc[1] + '/' + dataNasc[0];
                    nascData = nascData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                    nascData = new Date(nascData);
                    Log.error('dataNasc', dataNasc);
                    Log.error('nascData', nascData);
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_data_nascimento',
                        value: nascData
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_nacionalidade',
                        value: cliente['Nacionalidade']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_naturalidade',
                        value: cliente['Naturalidade']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_estado_civil',
                        value: cliente['EstadoCivil']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_rg',
                        value: cliente['RG']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentityprof',
                        value: cliente['Profissao']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_orgao_expedidor',
                        value: cliente['OrgaoExpedidor']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_telefone_comercial',
                        value: cliente['TelefoneComercial']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_tipo_pessoa',
                        value: cliente['TipoPessoa']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_nome_pai',
                        value: cliente['NomePai']
                    });
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_nome_mae',
                        value: cliente['NomeMae']
                    });
                    var emissao = cliente['DataEmissao'].split('T');
                    // Log.error('nascimento', nascimento)
                    var dataEmissao = emissao[0].split('-');
                    var emissaoData = dataEmissao[2] + '/' + dataEmissao[1] + '/' + dataEmissao[0];
                    emissaoData = emissaoData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                    emissaoData = new Date(emissaoData);
                    // Log.error('dataNasc', dataNasc)
                    // Log.error('nascData', nascData)
                    novoCliente_1.setValue({
                        fieldId: 'custentity_lrc_data_emissao',
                        value: emissaoData
                    });
                    comprador.Cliente.Enderecos.forEach(function (endereco) {
                        var AddressSubrecord = novoCliente_1.getCurrentSublistSubrecord({
                            sublistId: 'addressbook',
                            fieldId: 'addressbookaddress',
                        });
                        Log.error('AddressSubrecord', AddressSubrecord);
                        var numero = endereco['EnderecoNumero'];
                        AddressSubrecord.setValue({
                            fieldId: 'zip',
                            value: endereco['CEP']
                        });
                        AddressSubrecord.setValue({
                            fieldId: 'addr1',
                            value: endereco['Endereco'] + ', ' + numero
                        });
                        AddressSubrecord.setValue({
                            fieldId: 'addr2',
                            value: endereco['Bairro']
                        });
                        AddressSubrecord.setValue({
                            fieldId: 'custrecord_o2g_address_l_mun',
                            value: endereco['Cidade']
                        });
                        AddressSubrecord.setValue({
                            fieldId: 'state',
                            value: endereco['UF']
                        });
                        novoCliente_1.commitLine({
                            sublistId: 'addressbook'
                        });
                    });
                    var clienteId = novoCliente_1.save({
                        ignoreMandatoryFields: true
                    });
                    if (principal == true) {
                        idClientePrincipal = clienteId;
                    }
                    Log.error('idClientePrincipal', idClientePrincipal);
                }
            });
        }
        else {
            objRetorno['ListaCompradores'] = 'Status: Não há lista de compradores no json';
        }
        var objFaturaprincipal = {};
        Log.error('passou', 'aqui 2');
        var dataCadastro = ctx.DataCadastro.split('T');
        var dateCadastro = dataCadastro[0].split('-');
        var cadastroData = dateCadastro[2] + '/' + dateCadastro[1] + '/' + dateCadastro[0];
        cadastroData = cadastroData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
        cadastroData = new Date(cadastroData);
        var dataVenda = ctx.DataVenda.split('T');
        var dateVenda = dataVenda[0].split('-');
        var vendaData = dateVenda[2] + '/' + dateVenda[1] + '/' + dateVenda[0];
        vendaData = vendaData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
        vendaData = new Date(vendaData);
        var fieldsTratativa = {
            "NumeroProposta": ctx.NumeroProposta,
            "DataCadastro": cadastroData,
            "PossuiDistribuicaoPremio": ctx.PossuiDistribuicaoPremio,
            "CriticaFluxo": ctx.CriticaFluxo,
            "CodigoEmpreendimento,": ctx.CodigoEmpreendimento,
            "CodigoBloco": ctx.CodigoBloco,
            "CodigoUnidade": ctx.CodigoUnidade,
            "NumeroContrato": ctx.NumeroContrato,
            "DataVenda": vendaData,
            "TipoContrato": ctx.TipoContrato,
            "Ativo": ctx.Ativo,
            "ITBIGratis": ctx.ITBIGratis,
            "RegistroGratis": ctx.RegistroGratis,
            "ValorVendaAtualizada": ctx.ValorVendaAtualizada,
            "ValorSaldoDevedor": ctx.ValorSaldoDevedor,
            "Banco": ctx.Banco,
            "TipoOperacao": ctx.TipoOperacao,
            "ModalidadeFinanciamento": ctx.ModalidadeFinanciamento,
            "SistemaAmortizacao": ctx.SistemaAmortizacao,
            "ValorFGTS": ctx.ValorFGTS,
            "ValorSubsidio": ctx.ValorSubsidio,
            "ValorInterveniencia": ctx.ValorInterveniencia,
            "ValorRecursosProprios": ctx.ValorRecursosProprios,
            "TaxaJurosv": ctx.TaxaJurosv,
            "Assessoria": ctx.Assessoria,
            "ValorTotalComissao": ctx.ValorTotalComissao,
        };
        var arrayerros = [];
        var string = '';
        var stringFinal = '';
        Object.keys(fieldsTratativa).forEach(function (key) {
            if (fieldsTratativa[key] || fieldsTratativa[key] == false || fieldsTratativa[key] == 0) {
            }
            else {
                arrayerros.push(key);
            }
            // Log.error('fieldsCustomer',fieldsCustomer[key]);
        });
        for (var i = 0; i < arrayerros.length; i++) {
            string = string + "," + arrayerros[i];
        }
        stringFinal = 'Status: Faltam os seguintes argumentos: ' + string;
        Log.error('arrayerros.length', arrayerros.length);
        if (arrayerros.length != 0) {
            objRetorno['FaturaPrincipal'] = stringFinal;
        }
        else {
            objRetorno['FaturaPrincipal'] = 'Status: ok';
        }
        var fieldsCustomer = {
            "custbody_rsc_nr_proposta": ctx.NumeroProposta,
            "duedate": cadastroData,
            "custbody_lrc_distribuicao_premio": ctx.PossuiDistribuicaoPremio,
            "custbody_lrc_critica_fluxo": ctx.CriticaFluxo,
            "custbody_rsc_projeto_obra_gasto_compra": ctx.CodigoEmpreendimento,
            "custbody_rsc_ebu": ctx.CodigoBloco,
            "custbody_lrc_codigo_unidade": ctx.CodigoUnidade,
            "custbody_lrc_numero_contrato": ctx.NumeroContrato,
            "custbody_rsc_data_venda": vendaData,
            "custbody_lrc_tipo_contrato": ctx.TipoContrato,
            "custbody_rsc_ativo": ctx.Ativo,
            "custbody_lrc_itbi_gratis": ctx.ITBIGratis,
            "custbody_lrc_registro_gratis": ctx.RegistroGratis,
            "custbody_lrc_vlr_venda_att": ctx.ValorVendaAtualizada,
            "custbody_lrc_vlr_devedor": ctx.ValorSaldoDevedor,
            "custrecord_enl_bankid": ctx.Banco,
            "custbody_rsc_tipo_op": ctx.TipoOperacao,
            "custbody_rsc_mod_financ": ctx.ModalidadeFinanciamento,
            "custbody_rsc_sist_amort": ctx.SistemaAmortizacao,
            "custbody_lrc_valor_fgts": ctx.ValorFGTS,
            "custbody_lrc_vlr_subsidio": ctx.ValorSubsidio,
            "custbody_lrc_vlr_interveniencia": ctx.ValorInterveniencia,
            "custbody_lrc_recursos_proprios": ctx.ValorRecursosProprios,
            "custrecord_gst_instal_interestrate": ctx.TaxaJurosv,
            "custbody_lrc_assessoria": ctx.Assessoria,
            "custbody_lrc_vlr_total_comissao": ctx.ValorTotalComissao,
        };
        var invoiceRecord = record_1.default.create({
            type: 'invoice',
        });
        Object.keys(fieldsCustomer).forEach(function (key) {
            invoiceRecord.setValue({
                fieldId: key,
                value: fieldsCustomer[key]
            });
            // Log.error('fieldsCustomer',fieldsCustomer[key]);
        });
        // const array = []
        // const listaCompradores = ctx.ListaCompradores;
        // listaCompradores.forEach(comprador => {
        //   const idClienteFatura = comprador.CodigoCliente
        //   array.push(idClienteFatura)
        // })
        // Log.error("array", array)
        // const searchCliente = Search.create({
        //   type:'customer',
        //   filters:['internalid', 'IS', array[0]]
        // }).run().getRange({
        //   start: 0,
        //   end: 1
        // })
        invoiceRecord.setValue({
            fieldId: 'entity',
            value: idClientePrincipal
        });
        var localidade = runtime_1.default.getCurrentScript().getParameter({ name: "custscript_lrc_localidade_junix" });
        var item = runtime_1.default.getCurrentScript().getParameter({ name: "custscript_lrc_item_integra_junix" });
        invoiceRecord.setValue({
            fieldId: 'location',
            value: localidade
        });
        invoiceRecord.setSublistValue({
            fieldId: 'item',
            sublistId: 'item',
            line: 0,
            value: item
        });
        invoiceRecord.setSublistValue({
            fieldId: 'amount',
            sublistId: 'item',
            line: 0,
            value: ctx.ValorVenda
        });
        invoiceRecord.setSublistValue({
            fieldId: 'quantity',
            sublistId: 'item',
            line: 0,
            value: 1
        });
        var faturaPrincipalId = invoiceRecord.save({
            ignoreMandatoryFields: true
        });
        var faturas = ctx.ListaSerie;
        if (faturas) {
            objRetorno['ListaSerie'] = 'Status: Ok';
            faturas.forEach(function (fatura) {
                var qntd = fatura.Quantidade;
                var dataParcela = fatura.Data.split('T');
                var date = dataParcela[0].split('-');
                var parcelaData = date[2] + '/' + date[1] + '/' + date[0];
                parcelaData = parcelaData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                var meses = fatura.QuantidadeMesesEntreParcela;
                var dataCorrecao = fatura.DataInicioCorrecao.split('T');
                var data = dataCorrecao[0].split('-');
                var correcaoData = data[2] + '/' + data[1] + '/' + data[0];
                correcaoData = correcaoData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                correcaoData = new Date(correcaoData);
                parcelaData = new Date(parcelaData);
                var dataParcelaCalcula = fatura.Data;
                var fieldsCustomer = {
                    "custbody_lrc_cod_parcela": fatura.Cod,
                    "custbodyrsc_tpparc": fatura.TipoParcela,
                    "total": fatura.ValorTotal,
                    "custbody_lrc_possui_correcao": fatura.PossuiCorrecao,
                    "custbody_lrc_vlr_presente": fatura.ValorPresente,
                    "custbody_lrc_percentual": fatura.Percentual,
                    "custbody_lrc_crit_analise_credito": fatura.CriticaAnaliseCredito,
                    "custbody_lrc_data_inicio_correcao": correcaoData,
                    "custbody_lrc_tipo_amortizacao": fatura.TipoAmortizacao,
                    "custbody_lrc_taxa_amortizacao": fatura.TaxaAmortizacao,
                    "custbody_lrc_tipo_receita": fatura.TipoReceita,
                    "custbody_lrc_fatura_principal": faturaPrincipalId,
                    "location": localidade,
                    "entity": idClientePrincipal,
                    // "approvalstatus": 2
                };
                var _loop_1 = function (i) {
                    var parcelaRecord = record_1.default.create({
                        type: 'invoice'
                    });
                    Object.keys(fieldsCustomer).forEach(function (key) {
                        parcelaRecord.setValue({
                            fieldId: key,
                            value: fieldsCustomer[key]
                        });
                        // Log.error('fieldsCustomer',fieldsCustomer[key]);
                    });
                    parcelaRecord.setValue({
                        fieldId: 'duedate',
                        value: parcelaData
                    });
                    if (i != 0) {
                        Log.error('dataParcelaCalcula', dataParcelaCalcula);
                        dataParcelaCalcula = JSON.stringify(dataParcelaCalcula).split('T');
                        Log.error('dataParcelaCalcula', dataParcelaCalcula);
                        var dateCalcula = dataParcelaCalcula[0].split('-');
                        dateCalcula[1] = Number(dateCalcula[1]) + Number(meses);
                        var anoSplited = dateCalcula[0].split('"');
                        Log.error('anoSplited', anoSplited);
                        if (dateCalcula[1] > 12) {
                            Log.error('dateCalcula[1]', dateCalcula[1]);
                            var anos = Math.floor(dateCalcula[1] / 12);
                            Log.error('anos', anos);
                            dateCalcula[1] = dateCalcula[1] - 12;
                            Log.error('dateCalcula[1]', dateCalcula[1]);
                            Log.error('dateCalcula[0]', dateCalcula[0]);
                            anoSplited[1] = Number(anos) + Number(anoSplited[1]);
                        }
                        var parcelaCalcula = dateCalcula[1] + '/' + dateCalcula[2] + '/' + anoSplited[1];
                        Log.error('parcelaCalcula', parcelaCalcula);
                        // parcelaCalcula = parcelaCalcula.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                        parcelaCalcula = new Date(parcelaCalcula);
                        dataParcelaCalcula = parcelaCalcula;
                        Log.error('parcelaCalcula', parcelaCalcula);
                        parcelaRecord.setValue({
                            fieldId: "duedate",
                            value: parcelaCalcula
                        });
                    }
                    parcelaRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'item',
                        line: 0,
                        value: item
                    });
                    parcelaRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'amount',
                        line: 0,
                        value: fatura.ValorParcela
                    });
                    parcelaRecord.save({
                        ignoreMandatoryFields: true
                    });
                };
                for (var i = 0; i < qntd; i++) {
                    _loop_1(i);
                }
            });
        }
        else {
            objRetorno['ListaSerie'] = 'Status: Não há lista de parcelas no json';
        }
        return objRetorno;
    };
    exports.post = post;
    function getSeparetedName(name) {
        var separetedName = name.split(' ');
        var firstName = '';
        var lastName = '';
        separetedName.forEach(function (word, index) {
            if (index === 0) {
                firstName = word;
            }
            else {
                lastName += ' ' + word;
            }
        });
        Log.error(firstName, lastName);
        return { firstName: firstName, lastName: lastName };
    }
});
