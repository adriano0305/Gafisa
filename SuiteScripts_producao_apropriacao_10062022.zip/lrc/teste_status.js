/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * teste_status.ts
 *
 * Retornar valor de crédito do memorando de crédito.
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record"], function (require, exports, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = void 0;
    record_1 = __importDefault(record_1);
    //
    exports.afterSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT) {
            var newRecord = record_1.default.load({
                type: record_1.default.Type.PURCHASE_ORDER,
                id: ctx.newRecord.id
            });
            newRecord.setValue({
                fieldId: "subtotal",
                value: Number(newRecord.getValue("subtotal")) + 2
            });
            // log.error('registro', ctx.newRecord)
            // var registro = record_1.default.load({
            //     type: 'purchaserequisition',
            //     id: 2626,
            // })
            // var faseProjeto = registro.getValue('custbody_rsc_tarefa_proj_empreendiment')
            // newRecord.setValue({
            //     fieldId: "custbody_rsc_tarefa_proj_empreendiment",
            //     value: faseProjeto
            // });
            newRecord.save();
        }
    };
});
