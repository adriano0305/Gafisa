/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEventReturnAuth.ts
 *
 *
 *
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log", "N/ui/serverWidget", "N/search"], function (require, exports, record_1, log_1, UI, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = exports.beforeSubmit = exports.beforeLoad = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    UI = __importStar(UI);
    search_1 = __importDefault(search_1);
    function checkCriterioSublist(modeloId, newRecord) {
        var pesos = {};
        search_1.default.create({
            type: "customrecord_lrc_criterio",
            filters: [
                ["custrecord_lrc_modelo_valaiacao_pai", "IS", modeloId]
            ],
            columns: [
                "custrecord_lrc_peso_criterio"
            ]
        }).run().each(function (result) {
            pesos[result.id.toString()] = Number(result.getValue("custrecord_lrc_peso_criterio"));
            return true;
        });
        log_1.default.error("pesos", pesos);
        var linhasAv = Number(newRecord.getLineCount({
            sublistId: 'custpage_lrc_criterio_avaliacao'
        }));
        log_1.default.error("linhasAv", linhasAv);
        var objKeys = Object.keys(pesos);
        log_1.default.error("objKeys", objKeys);
        if (linhasAv != objKeys.length) {
            throw Error("O tamanho da sublista de critérios é incompatível com o número de critérios do modelo!. A submissão será cancelada!");
        }
        var somaPontos = 0;
        for (var line = 0; line < linhasAv; line++) {
            var lineAvaliacao = Number(newRecord.getSublistValue({
                sublistId: 'custpage_lrc_criterio_avaliacao',
                fieldId: 'custpage_lrc_avaliacao',
                line: line
            }));
            log_1.default.error("lineAvaliacao", lineAvaliacao);
            if (lineAvaliacao < 0 || lineAvaliacao > 100) {
                throw Error("A linha " + line + " tem uma avaliação fora do intervalo [0,100]. A submissão será cancelada!");
            }
            var lineCriterio = newRecord.getSublistValue({
                sublistId: "custpage_lrc_criterio_avaliacao",
                fieldId: "custpage_lrc_criterio",
                line: line
            });
            log_1.default.error("lineCriterio", lineCriterio);
            var linePesoCriterio = Number(newRecord.getSublistValue({
                sublistId: 'custpage_lrc_criterio_avaliacao',
                fieldId: 'custpage_lrc_peso_criterio',
                line: line
            }));
            log_1.default.error("linePesoCriterio", linePesoCriterio);
            var linePontos = Number(newRecord.getSublistValue({
                sublistId: 'custpage_lrc_criterio_avaliacao',
                fieldId: 'custpage_lrc_peso_criterio',
                line: line
            }));
            log_1.default.error("custpage_lrc_pontos", linePontos);
            if (objKeys.indexOf(lineCriterio.toString()) < 0) { // Nao tem o criterio da sublista no modelo
                throw Error("O critério da sublista, de ID interno igual a " + lineCriterio.toString() + ", não está presente no modelo. A submissão será cancelada!");
            }
            if (pesos[lineCriterio.toString()] != linePesoCriterio) { // O peso da sublista nao corresponde ao criterio  
                throw Error("O critério de ID interno " + lineCriterio.toString() + " não corresponde ao peso da sublista!. A submissão será cancelada!");
            }
            somaPontos += linePontos;
        }
        if (somaPontos < 0 || somaPontos > 100) {
            throw Error('O "Total dos Pontos" da Avaliação está fora do intervalo [0,100]. A submissão será cancelada!');
        }
    }
    exports.beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT) {
            var avaliacaoForm = ctx.form;
            log_1.default.error("getTabs", avaliacaoForm.getTabs());
            avaliacaoForm.addTab({
                id: 'custpage_lrc_tabela',
                label: 'Tabela'
            });
            var validarAlteracao = avaliacaoForm.addField({
                id: 'custpage_lrc_validar_alteracao',
                type: UI.FieldType.CHECKBOX,
                label: 'Validar Alteração'
            }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN });
            var sublist = avaliacaoForm.addSublist({
                id: 'custpage_lrc_criterio_avaliacao',
                type: UI.SublistType.INLINEEDITOR,
                label: 'Critérios e Avaliação',
                tab: 'custpage_lrc_tabela'
            });
            sublist.addField({
                id: 'custpage_lrc_criterio',
                type: UI.FieldType.SELECT,
                label: 'Critério',
                source: 'customrecord_lrc_criterio'
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist.addField({
                id: 'custpage_lrc_detalhe_criterio',
                label: 'Detalhe do Critério',
                type: UI.FieldType.TEXTAREA
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist.addField({
                id: 'custpage_lrc_peso_criterio',
                label: 'Peso do Critério',
                type: UI.FieldType.INTEGER
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist.addField({
                id: 'custpage_lrc_avaliacao',
                label: 'Avaliação',
                type: UI.FieldType.INTEGER
            });
            sublist.addField({
                id: 'custpage_lrc_pontos',
                label: 'Pontos',
                type: UI.FieldType.FLOAT
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        }
        if (ctx.type == ctx.UserEventType.VIEW) {
            // Criando a sublista no formulário de visualização
            var avaliacaoForm = ctx.form;
            avaliacaoForm.addTab({
                id: 'custpage_lrc_tabela',
                label: 'Tabela'
            });
            var sublist_1 = avaliacaoForm.addSublist({
                id: 'custpage_lrc_criterio_avaliacao',
                type: UI.SublistType.LIST,
                label: 'Criterios e Avaliacao',
                tab: 'custpage_lrc_tabela'
            });
            sublist_1.addField({
                id: 'custpage_lrc_criterio',
                type: UI.FieldType.SELECT,
                label: 'Critério',
                source: 'customrecord_lrc_criterio'
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist_1.addField({
                id: 'custpage_lrc_detalhe_criterio',
                label: 'Detalhe do Critério',
                type: UI.FieldType.TEXTAREA
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist_1.addField({
                id: 'custpage_lrc_peso_criterio',
                label: 'Peso do Critério',
                type: UI.FieldType.INTEGER
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist_1.addField({
                id: 'custpage_lrc_avaliacao',
                label: 'Avaliação',
                type: UI.FieldType.INTEGER
            });
            sublist_1.addField({
                id: 'custpage_lrc_pontos',
                label: 'Pontos',
                type: UI.FieldType.FLOAT
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            // Populando a sublista
            var i_1 = 0;
            var avaliacaoId = ctx.newRecord.id;
            search_1.default.create({
                type: 'customrecord_lrc_fornecedor_linha',
                filters: [
                    ['custrecord_lrc_avaliacao_forncedor', 'IS', avaliacaoId]
                ],
                columns: [
                    'custrecord_lrc_criterio.custrecord_lrc_detalhe_criterio',
                    'custrecord_lrc_criterio.custrecord_lrc_peso_criterio',
                    'custrecord_lrc_criterio',
                    'custrecord_lrc_avaliacao'
                ]
            }).run().each(function (result) {
                log_1.default.error('result', result);
                sublist_1.setSublistValue({
                    id: 'custpage_lrc_criterio',
                    value: result.getValue('custrecord_lrc_criterio').toString(),
                    line: i_1
                });
                log_1.default.error('criterio', result.getValue('custrecord_lrc_criterio'));
                sublist_1.setSublistValue({
                    id: 'custpage_lrc_detalhe_criterio',
                    value: result.getValue({ join: "custrecord_lrc_criterio", name: "custrecord_lrc_detalhe_criterio" }) || " ",
                    line: i_1
                });
                log_1.default.error('Detalhe', result.getValue({ join: "custrecord_lrc_criterio", name: "custrecord_lrc_detalhe_criterio" }));
                var peso = parseFloat(result.getValue({ join: "custrecord_lrc_criterio", name: "custrecord_lrc_peso_criterio" })).toString();
                log_1.default.error("peso", peso);
                sublist_1.setSublistValue({
                    id: 'custpage_lrc_peso_criterio',
                    value: parseInt(peso).toString(),
                    line: i_1
                });
                var avaliacao = parseFloat(result.getValue('custrecord_lrc_avaliacao')).toString();
                log_1.default.error("avaliacao", avaliacao);
                sublist_1.setSublistValue({
                    id: 'custpage_lrc_avaliacao',
                    value: parseInt(avaliacao).toString(),
                    line: i_1
                });
                log_1.default.error('Avaliacao', Number(result.getValue('custrecord_lrc_avaliacao')));
                var pontos = (avaliacao * peso) / 100;
                log_1.default.error("pontos", pontos);
                sublist_1.setSublistValue({
                    id: 'custpage_lrc_pontos',
                    value: pontos.toFixed(2),
                    line: i_1
                });
                i_1++;
                return true;
            });
        }
    };
    exports.beforeSubmit = function (ctx) {
        var _a, _b;
        if (ctx.type == ctx.UserEventType.CREATE) {
            var newRecord = ctx.newRecord;
            var name_1 = newRecord.getValue('name');
            var modeloId = (_a = newRecord.getValue("custrecord_lrc_camp_avaliacao_fornecedor")) === null || _a === void 0 ? void 0 : _a.toString();
            // Checar unicidade do campo "name"
            var searchResult = search_1.default.create({
                type: 'customrecord_lrc_avaliacao_fornecedores',
                filters: [
                    ['name', 'IS', name_1]
                ],
                columns: ['name']
            }).run().getRange({
                start: 0,
                end: 1
            });
            if (searchResult[0]) {
                var recordName = searchResult[0].getValue('name');
                if (recordName == name_1) {
                    throw Error("Nome do registro já utilizado!");
                }
            }
            // Os valores dos campos "Pontos" deverão ser alterados para "Peso do Critério"/100 * "Avaliação"
            var lineCount = newRecord.getLineCount({
                sublistId: "custpage_lrc_criterio_avaliacao"
            });
            log_1.default.error("lineCount", lineCount);
            for (var line = 0; line < lineCount; line++) {
                var pesoCriterio = Number(newRecord.getSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_peso_criterio',
                    line: line
                }));
                log_1.default.error("pesoCriterio", pesoCriterio);
                var avaliacao = Number(newRecord.getSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_avaliacao',
                    line: line
                }));
                log_1.default.error("pesoCriterio", pesoCriterio);
                var pontos = (pesoCriterio * avaliacao) / 100;
                log_1.default.error('pontos', pontos);
                newRecord.setSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_pontos',
                    line: line,
                    value: pontos.toFixed(2)
                });
            }
            // Checar se a sublista respeita as regras
            checkCriterioSublist(modeloId, newRecord);
        }
        else if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var newRecord = ctx.newRecord;
            var oldRecord = ctx.oldRecord;
            var modeloId = (_b = newRecord.getValue("custrecord_lrc_camp_avaliacao_fornecedor")) === null || _b === void 0 ? void 0 : _b.toString();
            log_1.default.error("modeloId", modeloId);
            // Unicidade do campo "name"
            if (newRecord.getValue('name') != oldRecord.getValue('name')) {
                var searchResult = search_1.default.create({
                    type: 'customrecord_lrc_avaliacao_fornecedor',
                    filters: [
                        ['name', 'IS', newRecord.getValue('name')]
                    ],
                    columns: ['name']
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                if (searchResult[0]) {
                    var recordName = searchResult[0].getValue('name');
                    if (recordName == newRecord.getValue('name')) {
                        throw Error("Nome do registro já utilizado!");
                    }
                }
            }
            // Os valores dos campos "Pontos" deverão ser alterados para "Peso do Critério"/100 * "Avaliação"
            var lineCount = newRecord.getLineCount({
                sublistId: "custpage_lrc_criterio_avaliacao"
            });
            log_1.default.error("lineCount", lineCount);
            for (var line = 0; line < lineCount; line++) {
                var pesoCriterio = Number(newRecord.getSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_peso_criterio',
                    line: line
                }));
                log_1.default.error("pesoCriterio", pesoCriterio);
                var avaliacao = Number(newRecord.getSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_avaliacao',
                    line: line
                }));
                log_1.default.error("pesoCriterio", pesoCriterio);
                var pontos = (pesoCriterio * avaliacao) / 100;
                log_1.default.error('pontos', pontos);
                newRecord.setSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_pontos',
                    line: line,
                    value: pontos.toFixed(2)
                });
            }
            // Checar se a sublista respeita as regras
            checkCriterioSublist(modeloId, newRecord);
        }
    };
    exports.afterSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE) {
            var newRecord = ctx.newRecord;
            var pontos = 0;
            var sublistCount = newRecord.getLineCount({
                sublistId: "custpage_lrc_criterio_avaliacao"
            });
            for (var line = 0; line < sublistCount; line++) {
                var fornecedorLinha = record_1.default.create({
                    type: 'customrecord_lrc_fornecedor_linha'
                });
                var pontoLinha = newRecord.getSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_pontos',
                    line: line
                });
                pontos += Number(pontoLinha);
                fornecedorLinha.setValue({
                    fieldId: 'custrecord_lrc_avaliacao_forncedor',
                    value: newRecord.id
                });
                fornecedorLinha.setValue({
                    fieldId: 'custrecord_lrc_modelo_forncedor_linha',
                    value: newRecord.getValue('custrecord_lrc_camp_avaliacao_fornecedor')
                });
                fornecedorLinha.setValue({
                    fieldId: 'custrecord_lrc_criterio',
                    value: newRecord.getSublistValue({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        fieldId: 'custpage_lrc_criterio',
                        line: line
                    })
                });
                fornecedorLinha.setValue({
                    fieldId: 'custrecord_lrc_avaliacao',
                    value: newRecord.getSublistValue({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        fieldId: 'custpage_lrc_avaliacao',
                        line: line
                    })
                });
                fornecedorLinha.save({
                    ignoreMandatoryFields: true
                });
            }
            log_1.default.error('Pontos finais', pontos);
            var avaliacaoFornecedor = record_1.default.load({
                type: 'customrecord_lrc_avaliacao_fornecedores',
                id: newRecord.id
            });
            avaliacaoFornecedor.setValue({
                fieldId: 'custrecord_lrc_campo_data_de_criacao_',
                value: new Date()
            });
            avaliacaoFornecedor.setValue({
                fieldId: 'custrecord_lrc_campo_total_avaliacao',
                value: pontos
            });
            avaliacaoFornecedor.save({
                ignoreMandatoryFields: true
            });
        }
        else if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var newRecord_1 = ctx.newRecord;
            var modeloAvaliacaoNew = newRecord_1.getValue('custrecord_lrc_camp_avaliacao_fornecedor');
            var oldRecord = ctx.oldRecord;
            var modeloAvaliacaoOld = oldRecord.getValue('custrecord_lrc_camp_avaliacao_fornecedor');
            var pontos_1 = 0;
            var sublistCount = newRecord_1.getLineCount({
                sublistId: "custpage_lrc_criterio_avaliacao"
            });
            if (modeloAvaliacaoNew != modeloAvaliacaoOld) {
                search_1.default.create({
                    type: 'customrecord_lrc_fornecedor_linha',
                    filters: [
                        ['custrecord_lrc_avaliacao_forncedor', 'IS', oldRecord.id]
                    ]
                }).run().each(function (result) {
                    if (result) {
                        record_1.default.delete({
                            type: 'customrecord_lrc_fornecedor_linha',
                            id: result.id
                        });
                    }
                    return true;
                });
                for (var line = 0; line < sublistCount; line++) {
                    var fornecedorLinha = record_1.default.create({
                        type: 'customrecord_lrc_fornecedor_linha'
                    });
                    var pontoLinha = newRecord_1.getSublistValue({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        fieldId: 'custpage_lrc_pontos',
                        line: line
                    });
                    pontos_1 += Number(pontoLinha);
                    fornecedorLinha.setValue({
                        fieldId: 'custrecord_lrc_avaliacao_forncedor',
                        value: newRecord_1.id
                    });
                    fornecedorLinha.setValue({
                        fieldId: 'custrecord_lrc_modelo_forncedor_linha',
                        value: newRecord_1.getValue('custrecord_lrc_camp_avaliacao_fornecedor')
                    });
                    fornecedorLinha.setValue({
                        fieldId: 'custrecord_lrc_criterio',
                        value: newRecord_1.getSublistValue({
                            sublistId: 'custpage_lrc_criterio_avaliacao',
                            fieldId: 'custpage_lrc_criterio',
                            line: line
                        })
                    });
                    fornecedorLinha.setValue({
                        fieldId: 'custrecord_lrc_avaliacao',
                        value: newRecord_1.getSublistValue({
                            sublistId: 'custpage_lrc_criterio_avaliacao',
                            fieldId: 'custpage_lrc_avaliacao',
                            line: line
                        })
                    });
                    fornecedorLinha.save({
                        ignoreMandatoryFields: true
                    });
                }
                log_1.default.error('Pontos finais', pontos_1);
                var avaliacaoFornecedor = record_1.default.load({
                    type: 'customrecord_lrc_avaliacao_fornecedores',
                    id: newRecord_1.id
                });
                avaliacaoFornecedor.setValue({
                    fieldId: 'custrecord_lrc_campo_total_avaliacao',
                    value: pontos_1
                });
                avaliacaoFornecedor.save({
                    ignoreMandatoryFields: true
                });
            }
            else {
                var line_1 = 0;
                search_1.default.create({
                    type: 'customrecord_lrc_fornecedor_linha',
                    filters: ['custrecord_lrc_avaliacao_forncedor', 'IS', newRecord_1.id]
                }).run().each(function (result) {
                    var fornecedorLinha = record_1.default.load({
                        type: 'customrecord_lrc_fornecedor_linha',
                        id: result.id
                    });
                    var pontoLinha = newRecord_1.getSublistValue({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        fieldId: 'custpage_lrc_pontos',
                        line: line_1
                    });
                    pontos_1 += Number(pontoLinha);
                    fornecedorLinha.setValue({
                        fieldId: 'custrecord_lrc_avaliacao_forncedor',
                        value: newRecord_1.id
                    });
                    fornecedorLinha.setValue({
                        fieldId: 'custrecord_lrc_modelo_forncedor_linha',
                        value: newRecord_1.getValue('custrecord_lrc_camp_avaliacao_fornecedor')
                    });
                    fornecedorLinha.setValue({
                        fieldId: 'custrecord_lrc_criterio',
                        value: newRecord_1.getSublistValue({
                            sublistId: 'custpage_lrc_criterio_avaliacao',
                            fieldId: 'custpage_lrc_criterio',
                            line: line_1
                        })
                    });
                    fornecedorLinha.setValue({
                        fieldId: 'custrecord_lrc_avaliacao',
                        value: newRecord_1.getSublistValue({
                            sublistId: 'custpage_lrc_criterio_avaliacao',
                            fieldId: 'custpage_lrc_avaliacao',
                            line: line_1
                        })
                    });
                    fornecedorLinha.save({
                        ignoreMandatoryFields: true
                    });
                    line_1++;
                    return true;
                });
                log_1.default.error('Pontos finais', pontos_1);
                var avaliacaoFornecedor = record_1.default.load({
                    type: 'customrecord_lrc_avaliacao_fornecedores',
                    id: newRecord_1.id
                });
                avaliacaoFornecedor.setValue({
                    fieldId: 'custrecord_lrc_campo_total_avaliacao',
                    value: pontos_1
                });
                avaliacaoFornecedor.save({
                    ignoreMandatoryFields: true
                });
            }
        }
        else if (ctx.type == ctx.UserEventType.DELETE) {
            var oldRecord = ctx.oldRecord;
            var searchResult = search_1.default.create({
                type: 'customrecord_lrc_fornecedor_linha',
                filters: [
                    ['custrecord_lrc_avaliacao_forncedor', 'IS', oldRecord.id]
                ],
            }).run().each(function (result) {
                if (result) {
                    record_1.default.delete({
                        type: 'customrecord_lrc_fornecedor_linha',
                        id: result.id
                    });
                }
                return true;
            });
        }
    };
});
