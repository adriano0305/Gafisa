/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEventReturnAuth.ts
 *
 *
 *
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search"], function (require, exports, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    search_1 = __importDefault(search_1);
    var beforeSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE) {
            var newRecord = ctx.newRecord;
            var name_1 = newRecord.getValue('name');
            var date = new Date();
            newRecord.setValue({
                fieldId: 'custrecord_lrc_campo_data_de_criacao',
                value: date
            });
            var searchResult = search_1.default.create({
                type: 'customrecord_lrc_avaliacao_fornecedor',
                filters: [
                    ['name', 'IS', name_1]
                ],
                columns: ['name']
            }).run().getRange({
                start: 0,
                end: 1
            });
            if (searchResult[0]) {
                var recordName = searchResult[0].getValue('name');
                if (recordName == name_1) {
                    throw Error("Nome do registro já utilizado!");
                }
            }
        }
        if (ctx.type == ctx.UserEventType.EDIT) {
            var newRecord = ctx.newRecord;
            var oldRecord = ctx.oldRecord;
            if (newRecord.getValue('name') != oldRecord.getValue('name')) {
                var searchResult = search_1.default.create({
                    type: 'customrecord_lrc_avaliacao_fornecedor',
                    filters: [
                        ['name', 'IS', newRecord.getValue('name')]
                    ],
                    columns: ['name']
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                if (searchResult[0]) {
                    var recordName = searchResult[0].getValue('name');
                    if (recordName == newRecord.getValue('name')) {
                        throw Error("Nome do registro já utilizado!");
                    }
                }
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
