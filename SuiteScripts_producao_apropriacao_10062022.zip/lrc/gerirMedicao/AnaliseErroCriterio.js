/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEventReturnAuth.ts
 *
 *
 *
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log", "N/search"], function (require, exports, record_1, log_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = exports.beforeSubmit = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    exports.beforeSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE) {
            var newRecord = ctx.newRecord;
            var modeloId = newRecord.getValue("custrecord_lrc_modelo_valaiacao_pai");
            log_1.default.error("modeloId", modeloId);
            if (modeloId) {
                var pesoCriterio = newRecord.getValue("custrecord_lrc_peso_criterio");
                log_1.default.error("pesoCriterio", pesoCriterio);
                var modeloLookup = search_1.default.lookupFields({
                    type: "customrecord_lrc_avaliacao_fornecedor",
                    id: modeloId,
                    columns: ["custrecord_lrc_campo_total_peso_criterio", "name"]
                });
                // Lookup fields ele pode retornar varios tipos de campo
                // Campo simples -> ele vai retornar o valor direto
                // Campo Select -> ele vai retornar um objeto do tipo {value: ID do registro, text: Nome do registro}
                // Campo Multi-Select -> ele vai retornar um array de objetos do tipo {value: ID do registro, text: Nome do registro} 
                var total_criterio_modelo = modeloLookup["custrecord_lrc_campo_total_peso_criterio"];
                log_1.default.error("total_criterio_modelo", total_criterio_modelo);
                var modeloName = modeloLookup["name"];
                log_1.default.error("modeloName", modeloName);
                var somaValorCriterio = Number(total_criterio_modelo) + Number(pesoCriterio);
                log_1.default.error("somaValorCriterio", somaValorCriterio);
                if (somaValorCriterio > 100) {
                    throw Error("A soma dos valores Peso do critério ultrapassou o valor de 100 no modelo de avaliação '" + modeloName + "'. " + "A submissão do critério será cancelada!");
                }
            }
        }
        else if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            // O modelo pai pode ser alterado
            // O peso do critério também pode ser alterado
            var oldRecord = ctx.oldRecord;
            var newRecord = ctx.newRecord;
            var oldModeloId = oldRecord.getValue("custrecord_lrc_modelo_valaiacao_pai");
            log_1.default.error("oldModeloId", oldModeloId);
            var newModeloId = newRecord.getValue("custrecord_lrc_modelo_valaiacao_pai");
            log_1.default.error("newModeloId", oldModeloId);
            if (oldModeloId != newModeloId && newModeloId) { // Modelo alterado para um valor não-nulo
                var newPesoCriterio = newRecord.getValue("custrecord_lrc_peso_criterio");
                log_1.default.error("newPesoCriterio", newPesoCriterio);
                var modeloLookup = search_1.default.lookupFields({
                    type: "customrecord_lrc_avaliacao_fornecedor",
                    id: newModeloId,
                    columns: ["custrecord_lrc_campo_total_peso_criterio", "name"]
                });
                log_1.default.error("modeloLookup", modeloLookup);
                var total_criterio_modelo = modeloLookup["custrecord_lrc_campo_total_peso_criterio"];
                log_1.default.error("total_criterio_modelo", total_criterio_modelo);
                var modeloName = modeloLookup["name"];
                log_1.default.error("modeloName", modeloName);
                var somaValorCriterio = Number(total_criterio_modelo) + Number(newPesoCriterio);
                log_1.default.error("somaValorCriterio", somaValorCriterio);
                if (somaValorCriterio > 100) {
                    throw Error("A soma dos valores Peso do critério ultrapassou o valor de 100 no modelo de avaliação '" + modeloName + "'. " + "A submissão do critério será cancelada!");
                }
            }
            else if (newModeloId) { // modelos permanecem os mesmos
                var pesoDiff = Number(newRecord.getValue("custrecord_lrc_peso_criterio")) - Number(oldRecord.getValue("custrecord_lrc_peso_criterio")); // diferença entre pesos 
                log_1.default.error("diff", pesoDiff);
                var modeloLookup = search_1.default.lookupFields({
                    type: "customrecord_lrc_avaliacao_fornecedor",
                    id: newModeloId,
                    columns: ["custrecord_lrc_campo_total_peso_criterio", "name"]
                });
                log_1.default.error("modeloLookup", modeloLookup);
                var total_criterio_modelo = modeloLookup["custrecord_lrc_campo_total_peso_criterio"];
                log_1.default.error("total_criterio_modelo", total_criterio_modelo);
                var modeloName = modeloLookup["name"];
                log_1.default.error("modeloName", modeloName);
                var somaValorCriterio = Number(total_criterio_modelo) + Number(pesoDiff);
                log_1.default.error("somaValorCriterio", somaValorCriterio);
                if (somaValorCriterio > 100) {
                    throw Error("A soma dos valores Peso do critério ultrapassou o valor de 100 no modelo de avaliação '" + modeloName + "'. " + "A submissão do critério será cancelada!");
                }
            }
        }
    };
    exports.afterSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE) {
            var record = ctx.newRecord;
            var modeloId_1 = record.getValue("custrecord_lrc_modelo_valaiacao_pai");
            log_1.default.error("modeloId", modeloId_1);
            if (modeloId_1) {
                var pesoCriterio = record.getValue("custrecord_lrc_peso_criterio");
                log_1.default.error("pesoCriterio", pesoCriterio);
                var modeloLookup = search_1.default.lookupFields({
                    type: "customrecord_lrc_avaliacao_fornecedor",
                    id: modeloId_1,
                    columns: ["custrecord_lrc_campo_total_peso_criterio", "name"]
                });
                var total_criterio_modelo = modeloLookup["custrecord_lrc_campo_total_peso_criterio"];
                log_1.default.error("total_criterio_modelo", total_criterio_modelo);
                var modeloName = modeloLookup["name"];
                log_1.default.error("modeloName", modeloName);
                var somaValorCriterio = Number(total_criterio_modelo) + Number(pesoCriterio);
                log_1.default.error("somaValorCriterio", somaValorCriterio);
                var recordModelo = record_1.default.load({
                    type: 'customrecord_lrc_avaliacao_fornecedor',
                    id: modeloId_1
                });
                recordModelo.setValue({
                    fieldId: 'custrecord_lrc_campo_total_peso_criterio',
                    value: somaValorCriterio
                });
                recordModelo.save({
                    ignoreMandatoryFields: true
                });
                // Criando o criterio no "Modelo de Avaliação Linhas"
                search_1.default.create({
                    type: "customrecord_lrc_avaliacao_fornecedores",
                    filters: ["custrecord_lrc_camp_avaliacao_fornecedor", "IS", modeloId_1]
                }).run().each(function (result) {
                    var fornecedorLinha = record_1.default.create({
                        type: "customrecord_lrc_fornecedor_linha",
                    });
                    fornecedorLinha.setValue({
                        fieldId: "custrecord_lrc_avaliacao_forncedor",
                        value: result.id
                    });
                    fornecedorLinha.setValue({
                        fieldId: "custrecord_lrc_criterio",
                        value: ctx.newRecord.id
                    });
                    fornecedorLinha.setValue({
                        fieldId: "custrecord_lrc_modelo_forncedor_linha",
                        value: modeloId_1
                    });
                    fornecedorLinha.setValue({
                        fieldId: "custrecord_lrc_avaliacao",
                        value: 0
                    });
                    fornecedorLinha.save({
                        ignoreMandatoryFields: true
                    });
                    return true;
                });
            }
        }
        else if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var newRecord_1 = ctx.newRecord;
            var oldRecord = ctx.oldRecord;
            var oldModeloId = oldRecord.getValue("custrecord_lrc_modelo_valaiacao_pai");
            var newModeloId_1 = newRecord_1.getValue("custrecord_lrc_modelo_valaiacao_pai");
            var newPeso = Number(newRecord_1.getValue('custrecord_lrc_peso_criterio'));
            log_1.default.error("newPeso", newPeso);
            var oldPeso_1 = Number(oldRecord.getValue('custrecord_lrc_peso_criterio'));
            log_1.default.error("oldPeso", oldPeso_1);
            if (oldModeloId != newModeloId_1) {
                if (oldModeloId) {
                    var oldModeloLookup = search_1.default.lookupFields({
                        type: "customrecord_lrc_avaliacao_fornecedor",
                        id: oldModeloId.toString(),
                        columns: [
                            "custrecord_lrc_campo_total_peso_criterio"
                        ]
                    });
                    log_1.default.error("oldModeloLookup", oldModeloLookup);
                    // Retirar o peso do criterio do total do criterio do modelo
                    record_1.default.submitFields({
                        type: "customrecord_lrc_avaliacao_fornecedor",
                        id: oldModeloId.toString(),
                        values: {
                            "custrecord_lrc_campo_total_peso_criterio": Number(oldModeloLookup['custrecord_lrc_campo_total_peso_criterio']) - oldPeso_1
                        },
                        options: {
                            ignoreMandatoryFields: true,
                            enableSourcing: false
                        }
                    });
                    // Excluir eventuais registros de "Avaliacao Fornecedor Linhas" com esse criterio e remover o "Total Avaliacao" do registro de "Avaliacao de Fornecedor"
                    search_1.default.create({
                        type: "customrecord_lrc_avaliacao_fornecedores",
                        filters: [
                            ["custrecord_lrc_camp_avaliacao_fornecedor", "IS", oldModeloId]
                        ],
                        columns: [
                            "custrecord_lrc_campo_total_avaliacao"
                        ]
                    }).run().each(function (result) {
                        var pontos = Number(result.getValue("custrecord_lrc_campo_total_avaliacao"));
                        log_1.default.error("pontos antes de deletar linha", pontos);
                        // Eu tenho que pegar o registro de "Avaliacao de Fornecedor Linhas" relacionada a esse criterio e pegar a avaliacao
                        var linhaSearchResult = search_1.default.create({
                            type: "customrecord_lrc_fornecedor_linha",
                            filters: [
                                ["custrecord_lrc_avaliacao_forncedor", "IS", result.id],
                                "AND",
                                ["custrecord_lrc_criterio", "IS", newRecord_1.id]
                            ],
                            columns: [
                                "custrecord_lrc_avaliacao",
                            ]
                        }).run().getRange({ start: 0, end: 1 });
                        if (linhaSearchResult[0]) {
                            log_1.default.error("id da linha", linhaSearchResult[0].id);
                            // Primeiro, remova os pontos da "avaliação de fornecedor" com base no peso do critério e na "Avaliação" da linha
                            var avaliacaoLinha = Number(linhaSearchResult[0].getValue("custrecord_lrc_avaliacao"));
                            log_1.default.error("avaliacao", avaliacaoLinha);
                            pontos -= (oldPeso_1 * avaliacaoLinha) / 100;
                            log_1.default.error("pontos apos deletar linha " + linhaSearchResult[0].id, pontos);
                            // Deletar a linha
                            record_1.default.delete({
                                type: "customrecord_lrc_fornecedor_linha",
                                id: linhaSearchResult[0].id
                            });
                            // Alterar pontos do registro de "Avaliação de Fornecedor"
                            record_1.default.submitFields({
                                type: "customrecord_lrc_avaliacao_fornecedores",
                                id: result.id,
                                values: {
                                    "custrecord_lrc_campo_total_avaliacao": pontos
                                },
                                options: {
                                    ignoreMandatoryFields: true,
                                    enableSourcing: false
                                }
                            });
                            return true;
                        }
                    });
                }
                if (newModeloId_1) {
                    var newModeloLookup = search_1.default.lookupFields({
                        type: "customrecord_lrc_avaliacao_fornecedor",
                        id: newModeloId_1.toString(),
                        columns: [
                            "custrecord_lrc_campo_total_peso_criterio"
                        ]
                    });
                    log_1.default.error("oldModeloLookup", newModeloLookup);
                    // Retirar o peso do criterio do total do criterio do modelo
                    record_1.default.submitFields({
                        type: "customrecord_lrc_avaliacao_fornecedor",
                        id: newModeloId_1.toString(),
                        values: {
                            "custrecord_lrc_campo_total_peso_criterio": Number(newModeloLookup['custrecord_lrc_campo_total_peso_criterio']) + newPeso
                        },
                        options: {
                            ignoreMandatoryFields: true,
                            enableSourcing: false
                        }
                    });
                    // Criar eventuais registros de "Avaliacao Fornecedor Linhas" com esse criterio
                    search_1.default.create({
                        type: "customrecord_lrc_avaliacao_fornecedores",
                        filters: [
                            ["custrecord_lrc_camp_avaliacao_fornecedor", "IS", newModeloId_1]
                        ]
                    }).run().each(function (result) {
                        var fornecedorLinha = record_1.default.create({
                            type: "customrecord_lrc_fornecedor_linha",
                        });
                        fornecedorLinha.setValue({
                            fieldId: "custrecord_lrc_avaliacao_forncedor",
                            value: result.id
                        });
                        fornecedorLinha.setValue({
                            fieldId: "custrecord_lrc_criterio",
                            value: ctx.newRecord.id
                        });
                        fornecedorLinha.setValue({
                            fieldId: "custrecord_lrc_modelo_forncedor_linha",
                            value: newModeloId_1
                        });
                        fornecedorLinha.setValue({
                            fieldId: "custrecord_lrc_avaliacao",
                            value: 0
                        });
                        fornecedorLinha.save({
                            ignoreMandatoryFields: true
                        });
                        return true;
                    });
                }
            }
            else if (newPeso != oldPeso_1) { // newModelo == oldModelo 
                if (newModeloId_1) {
                    // Alterar o total do criterio no modelo
                    var pesoDiff_1 = (newPeso - oldPeso_1);
                    log_1.default.error("pesoDiff", pesoDiff_1);
                    var modeloLookup = search_1.default.lookupFields({
                        type: "customrecord_lrc_avaliacao_fornecedor",
                        id: newModeloId_1.toString(),
                        columns: [
                            "custrecord_lrc_campo_total_peso_criterio"
                        ]
                    });
                    log_1.default.error("modeloLookup", modeloLookup);
                    record_1.default.submitFields({
                        type: "customrecord_lrc_avaliacao_fornecedor",
                        id: newModeloId_1.toString(),
                        values: {
                            "custrecord_lrc_campo_total_peso_criterio": Number(modeloLookup["custrecord_lrc_campo_total_peso_criterio"]) + pesoDiff_1
                        },
                        options: {
                            enableSourcing: false,
                            ignoreMandatoryFields: true
                        }
                    });
                    // Alterar o valor "Total dos Pontos" nos registros de avaliacao que utilizam o modelo 
                    search_1.default.create({
                        type: "customrecord_lrc_avaliacao_fornecedores",
                        filters: [
                            ["custrecord_lrc_camp_avaliacao_fornecedor", "IS", newModeloId_1]
                        ],
                        columns: [
                            "custrecord_lrc_campo_total_avaliacao"
                        ]
                    }).run().each(function (result) {
                        var linhaSearchResult = search_1.default.create({
                            type: "customrecord_lrc_fornecedor_linha",
                            filters: [
                                ["custrecord_lrc_avaliacao_forncedor", "IS", result.id],
                                "AND",
                                ["custrecord_lrc_criterio", "IS", newRecord_1.id]
                            ],
                            columns: [
                                "custrecord_lrc_avaliacao"
                            ]
                        }).run().getRange({ start: 0, end: 1 });
                        if (linhaSearchResult[0]) {
                            log_1.default.error("id da linha", linhaSearchResult[0].id);
                            var avaliacaoLinha = Number(linhaSearchResult[0].getValue("custrecord_lrc_avaliacao"));
                            log_1.default.error("avaliacao", avaliacaoLinha);
                            var pontosDiff = (pesoDiff_1 * avaliacaoLinha) / 100;
                            log_1.default.error("pontosDiff", pontosDiff);
                            record_1.default.submitFields({
                                type: "customrecord_lrc_avaliacao_fornecedores",
                                id: result.id.toString(),
                                values: {
                                    "custrecord_lrc_campo_total_avaliacao": Number(result.getValue("custrecord_lrc_campo_total_avaliacao")) + pontosDiff
                                },
                                options: {
                                    ignoreMandatoryFields: true,
                                    enableSourcing: false
                                }
                            });
                        }
                        return true;
                    });
                }
            }
        }
        else if (ctx.type == ctx.UserEventType.DELETE) {
            var oldRecord_1 = ctx.oldRecord;
            var modeloId = oldRecord_1.getValue("custrecord_lrc_modelo_valaiacao_pai");
            log_1.default.error("modeloId", modeloId);
            var peso_1 = Number(oldRecord_1.getValue("custrecord_lrc_peso_criterio"));
            log_1.default.error("peso", peso_1);
            if (modeloId) {
                // Alterar o campo "total peso do criterio" do modelo
                var modeloLookup = search_1.default.lookupFields({
                    type: "customrecord_lrc_avaliacao_fornecedor",
                    id: modeloId.toString(),
                    columns: [
                        "custrecord_lrc_campo_total_peso_criterio"
                    ]
                });
                log_1.default.error("modeloLookup", modeloLookup);
                record_1.default.submitFields({
                    type: "customrecord_lrc_avaliacao_fornecedor",
                    id: modeloId.toString(),
                    values: {
                        "custrecord_lrc_campo_total_peso_criterio": Number(modeloLookup["custrecord_lrc_campo_total_peso_criterio"]) - peso_1
                    },
                    options: {
                        enableSourcing: false,
                        ignoreMandatoryFields: true
                    }
                });
                // Encontrar registros de "Avaliação de Fornecedor" que utilizam esse modelo
                search_1.default.create({
                    type: "customrecord_lrc_avaliacao_fornecedores",
                    filters: [
                        ["custrecord_lrc_camp_avaliacao_fornecedor", "IS", modeloId]
                    ],
                    columns: [
                        "custrecord_lrc_campo_total_avaliacao"
                    ]
                }).run().each(function (result) {
                    var pontos = Number(result.getValue("custrecord_lrc_campo_total_avaliacao"));
                    log_1.default.error("pontos antes de deletar linha", pontos);
                    // Eu tenho que pegar o registro de "Avaliacao de Fornecedor Linhas" relacionada a esse criterio e pegar a avaliacao
                    var linhaSearchResult = search_1.default.create({
                        type: "customrecord_lrc_fornecedor_linha",
                        filters: [
                            ["custrecord_lrc_avaliacao_forncedor", "IS", result.id],
                            "AND",
                            ["custrecord_lrc_criterio", "IS", oldRecord_1.id]
                        ],
                        columns: [
                            "custrecord_lrc_avaliacao",
                        ]
                    }).run().getRange({ start: 0, end: 1 });
                    if (linhaSearchResult[0]) {
                        log_1.default.error("id da linha", linhaSearchResult[0].id);
                        // Primeiro, remova os pontos da "avaliação de fornecedor" com base no peso do critério e na "Avaliação" da linha
                        var avaliacaoLinha = Number(linhaSearchResult[0].getValue("custrecord_lrc_avaliacao"));
                        log_1.default.error("avaliacao", avaliacaoLinha);
                        pontos -= (peso_1 * avaliacaoLinha) / 100;
                        log_1.default.error("pontos apos deletar linha", pontos);
                        // Deletar a linha
                        record_1.default.delete({
                            type: "customrecord_lrc_fornecedor_linha",
                            id: linhaSearchResult[0].id
                        });
                        // Alterar pontos do registro de "Avaliação de Fornecedor"
                        record_1.default.submitFields({
                            type: "customrecord_lrc_avaliacao_fornecedores",
                            id: result.id,
                            values: {
                                "custrecord_lrc_campo_total_avaliacao": pontos
                            },
                            options: {
                                ignoreMandatoryFields: true,
                                enableSourcing: false
                            }
                        });
                        return true;
                    }
                });
            }
        }
    };
});
