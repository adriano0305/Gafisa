/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * TestClientSublist.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log"], function (require, exports, search_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.saveRecord = exports.sublistChanged = exports.validateInsert = exports.validateDelete = exports.validateLine = exports.fieldChanged = exports.pageInit = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    exports.pageInit = function (ctx) {
        if (ctx.mode == "create") {
            var currRecord_1 = ctx.currentRecord;
            var i_1 = 0;
            var modeloId = currRecord_1.getValue('custrecord_lrc_camp_avaliacao_fornecedor');
            if (modeloId) {
                currRecord_1.setValue({
                    fieldId: 'custpage_lrc_validar_alteracao',
                    value: false
                });
                search_1.default.create({
                    type: 'customrecord_lrc_criterio',
                    filters: [
                        ['custrecord_lrc_modelo_valaiacao_pai', 'IS', modeloId]
                    ],
                    columns: [
                        'custrecord_lrc_detalhe_criterio',
                        'custrecord_lrc_peso_criterio'
                    ]
                }).run().each(function (result) {
                    currRecord_1.selectLine({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        line: i_1
                    });
                    currRecord_1.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        fieldId: 'custpage_lrc_criterio',
                        value: result.id,
                    });
                    currRecord_1.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        fieldId: 'custpage_lrc_detalhe_criterio',
                        value: result.getValue('custrecord_lrc_detalhe_criterio'),
                    });
                    currRecord_1.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        fieldId: 'custpage_lrc_peso_criterio',
                        value: Number(result.getValue('custrecord_lrc_peso_criterio')),
                    });
                    currRecord_1.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        fieldId: 'custpage_lrc_avaliacao',
                        value: 0
                    });
                    currRecord_1.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_criterio_avaliacao',
                        fieldId: 'custpage_lrc_pontos',
                        value: 0
                    });
                    i_1++;
                    currRecord_1.commitLine({
                        sublistId: 'custpage_lrc_criterio_avaliacao'
                    });
                    return true;
                });
                currRecord_1.setValue({
                    fieldId: 'custpage_lrc_validar_alteracao',
                    value: true
                });
            }
        }
        if (ctx.mode == "edit") {
            var currRecord_2 = ctx.currentRecord;
            var i_2 = 0;
            var avaliacaoId = currRecord_2.id;
            currRecord_2.setValue({
                fieldId: 'custpage_lrc_validar_alteracao',
                value: false
            });
            search_1.default.create({
                type: 'customrecord_lrc_fornecedor_linha',
                filters: [
                    ['custrecord_lrc_avaliacao_forncedor', 'IS', avaliacaoId]
                ],
                columns: [
                    'custrecord_lrc_criterio.custrecord_lrc_detalhe_criterio',
                    'custrecord_lrc_criterio.custrecord_lrc_peso_criterio',
                    'custrecord_lrc_criterio',
                    'custrecord_lrc_avaliacao'
                ]
            }).run().each(function (result) {
                log_1.default.error('result', result);
                currRecord_2.selectLine({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    line: i_2
                });
                currRecord_2.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_criterio',
                    value: result.getValue('custrecord_lrc_criterio').toString(),
                });
                log_1.default.error('criterio', result.getValue('custrecord_lrc_criterio'));
                currRecord_2.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_detalhe_criterio',
                    value: result.getValue({ join: "custrecord_lrc_criterio", name: "custrecord_lrc_detalhe_criterio" }) || " ",
                });
                log_1.default.error('Detalhe', result.getValue({ join: "custrecord_lrc_criterio", name: "custrecord_lrc_detalhe_criterio" }));
                currRecord_2.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_peso_criterio',
                    value: Number(result.getValue({ join: "custrecord_lrc_criterio", name: "custrecord_lrc_peso_criterio" })),
                });
                log_1.default.error('peso', result.getValue({ join: "custrecord_lrc_criterio", name: "custrecord_lrc_peso_criterio" }));
                currRecord_2.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_avaliacao',
                    value: Number(result.getValue('custrecord_lrc_avaliacao'))
                });
                log_1.default.error('Avaliacao', Number(result.getValue('custrecord_lrc_avaliacao')));
                var pontos = Number(Number(result.getValue({ join: "custrecord_lrc_criterio", name: "custrecord_lrc_peso_criterio" })) / 100 * Number(result.getValue('custrecord_lrc_avaliacao')));
                currRecord_2.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_pontos',
                    value: pontos.toFixed(2)
                });
                currRecord_2.commitLine({
                    sublistId: 'custpage_lrc_criterio_avaliacao'
                });
                i_2++;
                return true;
            });
            currRecord_2.setValue({
                fieldId: 'custpage_lrc_validar_alteracao',
                value: true
            });
        }
    };
    exports.fieldChanged = function (ctx) {
        var currRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        var i = 0;
        var modeloId = currRecord.getValue('custrecord_lrc_camp_avaliacao_fornecedor');
        if (fieldId == 'custrecord_lrc_camp_avaliacao_fornecedor') {
            currRecord.setValue({
                fieldId: 'custpage_lrc_validar_alteracao',
                value: false
            });
            var linhasAv = currRecord.getLineCount({
                sublistId: 'custpage_lrc_criterio_avaliacao'
            });
            for (var i_3 = linhasAv - 1; i_3 >= 0; i_3--) {
                currRecord.removeLine({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    line: i_3
                });
            }
            search_1.default.create({
                type: 'customrecord_lrc_criterio',
                filters: [
                    ['custrecord_lrc_modelo_valaiacao_pai', 'IS', modeloId]
                ],
                columns: [
                    'custrecord_lrc_detalhe_criterio',
                    'custrecord_lrc_peso_criterio'
                ]
            }).run().each(function (result) {
                log_1.default.error("detalheCriterio", result.getValue('custrecord_lrc_detalhe_criterio') || " ");
                currRecord.selectLine({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    line: i
                });
                currRecord.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_criterio',
                    value: result.id,
                });
                log_1.default.error('Criterio', result.id);
                currRecord.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_detalhe_criterio',
                    value: result.getValue('custrecord_lrc_detalhe_criterio') || " ",
                });
                currRecord.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_peso_criterio',
                    value: Number(result.getValue('custrecord_lrc_peso_criterio')),
                });
                currRecord.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_avaliacao',
                    value: 0
                });
                currRecord.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_criterio_avaliacao',
                    fieldId: 'custpage_lrc_pontos',
                    value: 0
                });
                i++;
                currRecord.commitLine({
                    sublistId: 'custpage_lrc_criterio_avaliacao'
                });
                return true;
            });
            currRecord.setValue({
                fieldId: 'custpage_lrc_validar_alteracao',
                value: true
            });
        }
    };
    exports.validateLine = function (ctx) {
        var sublistIndex = ctx.currentRecord.getCurrentSublistIndex({ sublistId: "custpage_lrc_criterio_avaliacao" });
        log_1.default.error('sublistIndex', sublistIndex);
        var sublistCount = ctx.currentRecord.getLineCount({ sublistId: "custpage_lrc_criterio_avaliacao" });
        log_1.default.error('sublistCount', sublistCount);
        var qtLinhas = 0;
        //if(ctx.currentRecord.id){
        //  Search.create({
        // type: 'customrecord_lrc_fornecedor_linha',
        // filters:[
        //    ['custrecord_lrc_avaliacao_forncedor', 'IS', ctx.currentRecord.id]
        // ]
        //}).run().each(() =>{
        //qtLinhas++
        //return true
        //})
        //}else{
        //qtLinhas = ctx.currentRecord.getLineCount({sublistId: "custpage_lrc_criterio_avaliacao"});
        // }
        log_1.default.error('qtLinhas', qtLinhas);
        if (ctx.sublistId = 'custpage_lrc_criterio_avaliacao') {
            if (ctx.currentRecord.getValue('custpage_lrc_validar_alteracao') == true && sublistIndex == sublistCount) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos a partir do modelo");
                return false;
            }
            else {
                var avaliacao = Number(ctx.currentRecord.getCurrentSublistValue({
                    sublistId: ctx.sublistId,
                    fieldId: "custpage_lrc_avaliacao"
                }));
                if ((avaliacao < 0 || avaliacao > 100)) {
                    alert("Avaliação deve ser entre 0 e 100");
                    return false;
                }
                else {
                    var pontos = 0;
                    var pesoCriterio = Number(ctx.currentRecord.getCurrentSublistValue({
                        sublistId: ctx.sublistId,
                        fieldId: "custpage_lrc_peso_criterio"
                    }));
                    pontos = pesoCriterio / 100 * avaliacao;
                    if (pontos > 100) {
                        alert("A soma dos pontos ultrapassou o valor de 100");
                        return false;
                    }
                    else {
                        ctx.currentRecord.setCurrentSublistValue({
                            sublistId: ctx.sublistId,
                            fieldId: "custpage_lrc_pontos",
                            value: pontos.toFixed(2),
                        });
                    }
                }
            }
        }
        return true;
    };
    exports.validateDelete = function (ctx) {
        if (ctx.sublistId == "custpage_lrc_criterio_avaliacao") {
            if (ctx.currentRecord.getValue("custpage_lrc_validar_alteracao") == true) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos a partir do modelo");
                return false;
            }
            return true;
        }
        return true;
    };
    exports.validateInsert = function (ctx) {
        if (ctx.sublistId == "custpage_lrc_criterio_avaliacao") {
            if (ctx.currentRecord.getValue("custpage_lrc_validar_alteracao") == true) {
                alert("Você não pode inserir linhas. Os critérios são definidos a partir do modelo");
                return false;
            }
            return true;
        }
        return true;
    };
    exports.sublistChanged = function (ctx) {
        var sublistCount = ctx.currentRecord.getLineCount({
            sublistId: "custpage_lrc_criterio_avaliacao"
        });
        var pontos = 0;
        for (var line = 0; line < sublistCount; line++) {
            pontos += Number(ctx.currentRecord.getSublistValue({
                sublistId: "custpage_lrc_criterio_avaliacao",
                fieldId: "custpage_lrc_pontos",
                line: line
            }));
        }
        ctx.currentRecord.setValue({
            fieldId: "custrecord_lrc_campo_total_avaliacao",
            value: pontos
        });
    };
    exports.saveRecord = function (ctx) {
        if (Number(ctx.currentRecord.getValue('custrecord_lrc_campo_total_avaliacao')) > 100) {
            alert("O total de pontos de avaliação ultrapassou o valor de 100. Altere os valores de avaliação para que seja permitida a submissão");
            return false;
        }
        return true;
    };
});
