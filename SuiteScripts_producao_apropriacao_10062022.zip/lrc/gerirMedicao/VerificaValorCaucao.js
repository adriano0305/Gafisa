/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * beforeSubmit.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/log"], function (require, exports, serverWidget_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = exports.beforeSubmit = void 0;
    serverWidget_1 = __importDefault(serverWidget_1);
    log_1 = __importDefault(log_1);
    var beforeSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var record = ctx.newRecord;
            var valorCaucao = record.getValue("custbody_lrc_valor_caucao");
            if (valorCaucao >= 0 && valorCaucao <= 100) {
                return true;
            }
            else {
                throw Error("valor do campo VALOR DE CAUÇÃO nao está entre 0 e 100");
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var record = ctx.newRecord;
            var form = ctx.form;
            var valorCaucaoField = form.getField({
                id: 'custbody_lrc_valor_caucao'
            });
            var retencaoCaucao = record.getValue("custbody_lrc_retencao_caucao");
            log_1.default.error("retencaoCaucao", retencaoCaucao);
            valorCaucaoField.updateDisplayType({ displayType: retencaoCaucao ? serverWidget_1.default.FieldDisplayType.NORMAL : serverWidget_1.default.FieldDisplayType.DISABLED });
        }
    };
    exports.beforeLoad = beforeLoad;
});
