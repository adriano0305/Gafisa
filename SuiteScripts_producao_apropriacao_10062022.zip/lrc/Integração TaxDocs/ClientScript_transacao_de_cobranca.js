/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 *
 * ClientScript_transacao_de_cobranca.js
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/record", "N/url"], function (require, exports, currentRecord_1, record_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.selecionaNfe = exports.fieldChanged = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    record_1 = __importDefault(record_1);
    url_1 = __importDefault(url_1);
    var pageInit = function (ctx) {
        var nfes;
        var idCobranca;
        var currentTrRecord = currentRecord_1.default.get();
        if (String(currentTrRecord.getValue('custpage_campo_array_nfes')) != "undefined") {
            nfes = JSON.parse(String(currentTrRecord.getValue('custpage_campo_array_nfes')));
        }
        console.log(currentTrRecord.getValue('custrecord_lrc_idcobranca'));
        if (String(currentTrRecord.getValue('custrecord_lrc_idcobranca')) != "undefined") {
            idCobranca = currentTrRecord.getValue('custrecord_lrc_idcobranca');
        }
        setListValues(nfes, idCobranca);
    };
    exports.pageInit = pageInit;
    function fieldChanged(ctx) {
        var currRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        var sublistId = ctx.sublistId;
        if (sublistId == "custpage_lrc_nf" && fieldId == "custpage_lrc_check_nfe") {
            var num_lines = currRecord.getLineCount({ sublistId: "custpage_lrc_nf" });
            for (var line = 0; line < num_lines; line++) {
                console.log('ctx.line', ctx.line);
                console.log('line', line);
                if (ctx.line == line) {
                    console.log('T');
                    currRecord.selectLine({
                        line: line,
                        sublistId: "custpage_lrc_nf"
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: "custpage_lrc_check_nfe",
                        sublistId: "custpage_lrc_nf",
                        value: true,
                        ignoreFieldChange: true
                    });
                    if (line != num_lines - 1) {
                        currRecord.commitLine({
                            sublistId: "custpage_lrc_nf"
                        });
                    }
                }
                else {
                    console.log('F');
                    currRecord.selectLine({
                        line: line,
                        sublistId: "custpage_lrc_nf"
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: "custpage_lrc_check_nfe",
                        sublistId: "custpage_lrc_nf",
                        value: false,
                        ignoreFieldChange: true
                    });
                    if (line != num_lines - 1) {
                        currRecord.commitLine({
                            sublistId: "custpage_lrc_nf",
                        });
                    }
                }
            }
        }
    }
    exports.fieldChanged = fieldChanged;
    var setListValues = function (list, idCobranca) {
        var current = currentRecord_1.default.get();
        list.forEach(function (item) {
            current.selectNewLine({
                sublistId: 'custpage_lrc_nf',
            });
            current.setCurrentSublistValue({
                sublistId: 'custpage_lrc_nf',
                fieldId: 'custpage_lrc_nfe',
                value: String(item.id) || ""
            });
            current.setCurrentSublistValue({
                sublistId: 'custpage_lrc_nf',
                fieldId: 'custpage_lrc_xped',
                value: item.values.custrecord_lrc_xped || ""
            });
            current.setCurrentSublistValue({
                sublistId: 'custpage_lrc_nf',
                fieldId: 'custpage_lrc_chave_acesso',
                value: item.values.custrecord_lrc_chave_acesso || ""
            });
            console.log(idCobranca);
            current.setCurrentSublistValue({
                sublistId: 'custpage_lrc_nf',
                fieldId: 'custrecord_lrc_idcobranca',
                value: idCobranca || ""
            });
            current.setCurrentSublistValue({
                sublistId: 'custpage_lrc_nf',
                fieldId: 'custpage_lrc_check_nfe',
                value: false
            });
            current.commitLine({
                sublistId: 'custpage_lrc_nf'
            });
        });
    };
    var selecionaNfe = function () {
        var currRecord = currentRecord_1.default.get();
        var num_lines = currRecord.getLineCount({ sublistId: "custpage_lrc_nf" });
        console.log("Num_line: ", num_lines);
        for (var i = 0; i < num_lines; i++) {
            var idCobranca = currRecord.getValue('custrecord_lrc_idcobranca');
            console.log(idCobranca);
            console.log(idCobranca);
            var currCheckBoxValue = currRecord.getSublistValue({
                fieldId: 'custpage_lrc_check_nfe',
                sublistId: 'custpage_lrc_nf',
                line: i
            });
            var record = record_1.default.load({
                id: idCobranca,
                type: 'vendorbill'
            });
            console.log("currCheckBoxValue 01", currCheckBoxValue);
            if (currCheckBoxValue) {
                var chaveDeacesso = currRecord.getSublistValue({
                    sublistId: 'custpage_lrc_nf',
                    line: i,
                    fieldId: 'custpage_lrc_chave_acesso'
                });
                console.log("currCheckBoxValue 02", currCheckBoxValue);
                console.log("chaveDeAcesso: ", chaveDeacesso);
                record.setValue({
                    fieldId: 'custbody_enl_accesskey',
                    value: String(chaveDeacesso)
                });
                record.save();
                console.log(record);
                var url = url_1.default.resolveRecord({
                    recordId: record.id,
                    isEditMode: false,
                    recordType: 'vendorbill',
                    params: {
                        'chaveDeacesso': chaveDeacesso
                    }
                });
                window.location.replace(url);
            }
        }
    };
    exports.selecionaNfe = selecionaNfe;
});
