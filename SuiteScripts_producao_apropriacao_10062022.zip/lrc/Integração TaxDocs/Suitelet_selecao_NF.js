/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 *
 * Suitelet_selecao_cobranca.ts
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget"], function (require, exports, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    var onRequest = function (ctx) {
        var parameters = ctx.request.parameters;
        var list_nfe = [], idCobranca;
        if (parameters.hasOwnProperty('list_nfe'))
            list_nfe = JSON.parse(parameters.list_nfe);
        if (parameters.hasOwnProperty('id_cobranca'))
            idCobranca = parameters.id_cobranca;
        var form = UI.createForm({
            title: 'Seleciona a NF-e'
        });
        // Field para armazenar dados do parâmetro da requisição
        form.addField({
            id: 'custpage_campo_array_nfes',
            label: 'list',
            type: UI.FieldType.LONGTEXT
        }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = JSON.stringify(list_nfe);
        form.addField({
            id: 'custrecord_lrc_idcobranca',
            label: 'id',
            type: UI.FieldType.TEXT
        }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = idCobranca;
        var sublist = form.addSublist({
            id: 'custpage_lrc_nf',
            type: UI.SublistType.INLINEEDITOR,
            label: 'Seleciona a NF-e'
        });
        sublist.addField({
            id: 'custpage_lrc_nfe',
            type: UI.FieldType.TEXT,
            label: "NF-e"
        });
        sublist.addField({
            id: 'custpage_lrc_xped',
            type: UI.FieldType.TEXT,
            label: "XPED"
        });
        sublist.addField({
            id: 'custpage_lrc_chave_acesso',
            type: UI.FieldType.TEXT,
            label: "Chave de Acesso"
        });
        sublist.addField({
            id: 'custpage_lrc_check_nfe',
            type: UI.FieldType.CHECKBOX,
            label: "Selecionar"
        });
        form.addButton({
            id: 'button_lrc_selecionar',
            label: "Selecionar",
            functionName: "selecionaNfe"
        });
        form.clientScriptModulePath = "./ClientScript_transacao_de_cobranca.js";
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
});
