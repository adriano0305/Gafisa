/**
 *@NApiVersion 2.x
 *@NScriptType MapReduceScript
 *
 * mapReduce_sendClients.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record", "N/log"], function (require, exports, search_1, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    var getInputData = function () {
        return search_1.default.create({
            type: 'customrecord_lrc_log_lancamento',
            filters: [
                ['custrecord_lrc_processado', 'IS', 'F']
            ],
            columns: [
                'custrecord_lrc_json',
                'custrecord_lrc_processado',
                'custrecord_lrc_log_lancamento'
            ]
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var req = JSON.parse(ctx.value);
        var inputData = JSON.parse(req.values['custrecord_lrc_json']);
        log_1.default.error('req', req);
        var lancamentoRecord = record_1.default.load({
            type: "customrecord_lrc_log_lancamento",
            id: req.id
        });
        try {
            var record_2 = record_1.default.create({
                type: "journalentry",
            });
            record_2.setValue({
                fieldId: "subsidiary",
                value: inputData["subsidiary"]
            });
            record_2.setValue({
                fieldId: "class",
                value: inputData["class"]
            });
            record_2.setValue({
                fieldId: "currency",
                value: inputData["currency"]
            });
            record_2.setValue({
                fieldId: "exchangerate",
                value: inputData["exchangerate"]
            });
            record_2.setValue({
                fieldId: "memo",
                value: inputData["memo"]
            });
            record_2.setValue({
                fieldId: "postingperiod",
                value: inputData["postingperiod"]
            });
            var reversalDate = inputData["reversaldate"].replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            reversalDate = new Date(reversalDate);
            record_2.setValue({
                fieldId: "reversaldate",
                value: reversalDate
            });
            record_2.setValue({
                fieldId: "reversaldefer",
                value: inputData["reversaldefer"]
            });
            var trandate = inputData["trandate"].replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            trandate = new Date(trandate);
            record_2.setValue({
                fieldId: "trandate",
                value: trandate
            });
            // record.setValue({
            //   fieldId:"reversaldate",
            //   value:inputData["reversaldate"]
            // });
            var i_1 = 0;
            inputData.lines.forEach(function (line) {
                log_1.default.error('entrou line', i_1);
                // record.selectNewLine({
                //   sublistId: 'line'
                // })
                record_2.setSublistValue({
                    sublistId: 'line',
                    fieldId: 'account',
                    value: line['account'],
                    line: i_1
                });
                log_1.default.error('conta', line['account']);
                record_2.setSublistValue({
                    sublistId: 'line',
                    fieldId: 'entity',
                    value: line['entity'],
                    line: i_1
                });
                record_2.setSublistValue({
                    sublistId: 'line',
                    fieldId: 'department',
                    value: line['department'],
                    line: i_1
                });
                record_2.setSublistValue({
                    sublistId: 'line',
                    fieldId: 'debit',
                    value: line['debit'],
                    line: i_1
                });
                record_2.setSublistValue({
                    sublistId: 'line',
                    fieldId: 'credit',
                    value: line['credit'],
                    line: i_1
                });
                // record.commitLine({
                //   sublistId: 'line'
                // })
                i_1++;
            });
            log_1.default.error('antes do save', 'done');
            var idNovo = record_2.save({
                ignoreMandatoryFields: true
            });
            log_1.default.error('antes do save', idNovo);
            lancamentoRecord.setValue({
                fieldId: "custrecord_lrc_processado",
                value: true
            });
            lancamentoRecord.setValue({
                fieldId: "custrecord_lrc_log_lancamento",
                value: idNovo
            });
            lancamentoRecord.setValue({
                fieldId: "custrecord_lrc_erro_integracao",
                value: false
            });
            lancamentoRecord.setValue({
                fieldId: "custrecord_lrc_erros",
                value: ''
            });
            lancamentoRecord.save({
                ignoreMandatoryFields: true
            });
        }
        catch (e) {
            lancamentoRecord.setValue({
                fieldId: "custrecord_lrc_processado",
                value: false
            });
            lancamentoRecord.setValue({
                fieldId: "custrecord_lrc_erro_integracao",
                value: true
            });
            log_1.default.error('e', e.toString());
            lancamentoRecord.setValue({
                fieldId: "custrecord_lrc_erros",
                value: 'Ocorreu um erro na criação do registro "Lançamento": ' + e.message
            });
            log_1.default.error('antes safe erro', 'done');
            lancamentoRecord.save({
                ignoreMandatoryFields: true
            });
        }
    };
    exports.map = map;
});
