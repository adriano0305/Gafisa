/**
* @NAPIVersion 2.0
* @NScriptType Restlet
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record"], function (require, exports, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.post = exports.delete = void 0;
    record_1 = __importDefault(record_1);
    var del = function (ctx) {
        var type = ctx.type;
        var id = ctx.id;
        return {
            success: true
        };
    };
    exports.delete = del;
    var post = function (ctx) {
        var requestBody = ctx.launchs;
        var objRetorno = {};
        if (requestBody) {
            requestBody.forEach(function (lancamento) {
                if (lancamento.class) {
                    objRetorno['class'] = 'Status: Ok';
                }
                else {
                    objRetorno['class'] = 'Status: Falta argumento "class".';
                }
                if (lancamento.currency) {
                    objRetorno['currency'] = 'Status: Ok';
                }
                else {
                    objRetorno['currency'] = 'Status: Falta argumento "currency".';
                }
                if (lancamento.exchangerate) {
                    objRetorno['exchangerate'] = 'Status: Ok';
                }
                else {
                    objRetorno['exchangerate'] = 'Status: Falta argumento "exchangerate".';
                }
                if (lancamento.memo) {
                    objRetorno['memo'] = 'Status: Ok';
                }
                else {
                    objRetorno['memo'] = 'Status: Falta argumento "memo".';
                }
                if (lancamento.postingperiod) {
                    objRetorno['postingperiod'] = 'Status: Ok';
                }
                else {
                    objRetorno['postingperiod'] = 'Status: Falta argumento "currency".';
                }
                if (lancamento.reversaldate) {
                    objRetorno['reversaldate'] = 'Status: Ok';
                }
                else {
                    objRetorno['reversaldate'] = 'Status: Falta argumento "reversaldate".';
                }
                if (lancamento.reversaldefer == false || lancamento.reversaldefer == true) {
                    objRetorno['reversaldefer'] = 'Status: Ok';
                }
                else {
                    objRetorno['reversaldefer'] = 'Status: Falta argumento "reversaldefer".';
                }
                if (lancamento.subsidiary) {
                    objRetorno['subsidiary'] = 'Status: Ok';
                }
                else {
                    objRetorno['subsidiary'] = 'Status: Falta argumento "subsidiary".';
                }
                if (lancamento.trandate) {
                    objRetorno['trandate'] = 'Status: Ok';
                }
                else {
                    objRetorno['trandate'] = 'Status: Falta argumento "currency".';
                }
                if (lancamento.lines) {
                    objRetorno['lines'] = 'Status: Ok';
                }
                else {
                    objRetorno['lines'] = 'Status: Falta argumento "lines".';
                }
                var i = 1;
                lancamento.lines.forEach(function (line) {
                    if (line.account) {
                        objRetorno['line ' + i + ': account'] = 'Status: Ok';
                    }
                    else {
                        objRetorno['line ' + i + ': account'] = 'Status: Falta argumento "account".';
                    }
                    if (line.entity) {
                        objRetorno['line ' + i + ': entity'] = 'Status: Ok';
                    }
                    else {
                        objRetorno['line ' + i + ': entity'] = 'Status: Falta argumento "entity".';
                    }
                    if (line.department) {
                        objRetorno['line ' + i + ': department'] = 'Status: Ok';
                    }
                    else {
                        objRetorno['line ' + i + ': department'] = 'Status: Falta argumento "department".';
                    }
                    if (line.debit || line.debit == "") {
                        objRetorno['line ' + i + ': debit'] = 'Status: Ok';
                    }
                    else {
                        objRetorno['line ' + i + ': debit'] = 'Status: Falta argumento "debit".';
                    }
                    if (line.credit || line.credit == "") {
                        objRetorno['line ' + i + ': credit'] = 'Status: Ok';
                    }
                    else {
                        objRetorno['line ' + i + ': credit'] = 'Status: Falta argumento "credit".';
                    }
                    i++;
                });
            });
            requestBody.forEach(function (launch) {
                try {
                    var record = record_1.default.create({
                        type: 'customrecord_lrc_log_lancamento'
                    });
                    record.setValue({
                        fieldId: 'custrecord_lrc_processado',
                        value: false
                    });
                    record.setValue({
                        fieldId: 'custrecord_lrc_json',
                        value: JSON.stringify(launch)
                    });
                    record.save({ ignoreMandatoryFields: true });
                }
                catch (e) {
                    throw Error("Erro ao criar o registro Log de Lançamento: " + e);
                }
            });
            return objRetorno;
        }
        else {
            return "Não há nenhum lançamento (launch) no json.";
        }
    };
    exports.post = post;
});
