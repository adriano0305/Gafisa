/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_pedido_compra
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/record"], function (require, exports, log_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    var beforeSubmit = function (ctx) {
        var record = ctx.newRecord;
        var soma = 0;
        var contrato = record.getValue({
            fieldId: 'purchasecontract'
        });
        log_1.default.error('contrato', contrato);
        if (contrato) {
            var recordContrato = record_1.default.load({
                id: contrato,
                type: 'purchasecontract'
            });
            var quantidadeItensSublist_contrato = recordContrato.getLineCount({
                sublistId: 'item'
            });
            for (var i = 0; i < quantidadeItensSublist_contrato; i++) {
                var retencaoCaucao = recordContrato.getSublistValue({
                    fieldId: 'custcol_rsc_retencao_caucao',
                    line: i,
                    sublistId: 'item'
                });
                if (retencaoCaucao) {
                    var itemDisplay_contrato = recordContrato.getSublistValue({
                        fieldId: 'item_display',
                        line: i,
                        sublistId: 'item'
                    });
                    var quantidadeItensSublist_pedido = record.getLineCount({
                        sublistId: 'item'
                    });
                    for (var i_1 = 0; i_1 < quantidadeItensSublist_pedido; i_1++) {
                        var itemDisplay_Pedido = record.getSublistValue({
                            fieldId: 'item_display',
                            line: i_1,
                            sublistId: 'item'
                        });
                        if (itemDisplay_Pedido == itemDisplay_contrato) {
                            var valorPedido = record.getSublistValue({
                                fieldId: 'amount',
                                line: i_1,
                                sublistId: 'item'
                            });
                            log_1.default.error('valor', valorPedido);
                            record.setSublistValue({
                                fieldId: 'custcol_rsc_retencao_caucao',
                                line: i_1,
                                sublistId: 'item',
                                value: true
                            });
                            soma = soma + Number(valorPedido);
                            log_1.default.error('soma', soma);
                        }
                        ;
                    }
                    ;
                }
                ;
            }
            ;
            var campoPorcentagem = record.getValue({
                fieldId: 'custbody_lrc_valor_caucao'
            });
            if (campoPorcentagem) {
                var porcentagem = Number(campoPorcentagem) / 100;
                soma = soma * porcentagem;
                record.setValue({
                    fieldId: 'custbody_rsc_retido_caucao',
                    value: soma
                });
            }
            ;
        }
        ;
    };
    exports.beforeSubmit = beforeSubmit;
});
