/**
 *@NApiVersion 2.x
*@NScriptType UserEventScript
*
* UserEvent_pedido_compra
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/record", "N/search"], function (require, exports, log_1, record_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = exports.beforeSubmit = exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    var beforeLoad = function (ctx) {
        var record = ctx.newRecord;
        var pedidoCompra = record.getSublistValue({
            sublistId: 'purchaseorders',
            fieldId: 'id',
            line: 0
        });
        log_1.default.error('PedidoCompraid', pedidoCompra);
        if (pedidoCompra) {
            var LookupPedido = search_1.default.lookupFields({
                type: 'purchaseorder',
                id: pedidoCompra,
                columns: [
                    'custbody_lrc_retencao_caucao',
                    'custbody_lrc_valor_caucao'
                ]
            });
            record.setValue({
                fieldId: 'custbody_lrc_retencao_caucao',
                value: Boolean(LookupPedido.custbody_lrc_retencao_caucao)
            });
            record.setValue({
                fieldId: 'custbody_lrc_valor_caucao',
                value: String(LookupPedido.custbody_lrc_valor_caucao)
            });
            // record.save({
            //     ignoreMandatoryFields: true
            // })
        }
    };
    exports.beforeLoad = beforeLoad;
    var beforeSubmit = function (ctx) {
        var record = ctx.newRecord;
        var contrato = record.getValue({
            fieldId: 'custbody_lrc_contrato_de_empreitada'
        });
        log_1.default.error('contrato', contrato);
        if (contrato) {
            var soma = 0;
            var recordContrato = record_1.default.load({
                id: contrato,
                type: 'purchasecontract'
            });
            var quantidadeItensSublist_contrato = recordContrato.getLineCount({
                sublistId: 'item'
            });
            for (var i = 0; i < quantidadeItensSublist_contrato; i++) {
                var retencaoCaucao = recordContrato.getSublistValue({
                    fieldId: 'custcol_rsc_retencao_caucao',
                    line: i,
                    sublistId: 'item'
                });
                if (retencaoCaucao) {
                    var itemDisplay_contrato = recordContrato.getSublistValue({
                        fieldId: 'item_display',
                        line: i,
                        sublistId: 'item'
                    });
                    var quantidadeItensSublist_pedido = record.getLineCount({
                        sublistId: 'item'
                    });
                    for (var i_1 = 0; i_1 < quantidadeItensSublist_pedido; i_1++) {
                        var itemDisplay_Pedido = record.getSublistValue({
                            fieldId: 'item_display',
                            line: i_1,
                            sublistId: 'item'
                        });
                        if (itemDisplay_Pedido == itemDisplay_contrato) {
                            var valorPedido = record.getSublistValue({
                                fieldId: 'amount',
                                line: i_1,
                                sublistId: 'item'
                            });
                            log_1.default.error('valor', valorPedido);
                            record.setSublistValue({
                                fieldId: 'custcol_rsc_retencao_caucao',
                                line: i_1,
                                sublistId: 'item',
                                value: true
                            });
                            soma = soma + Number(valorPedido);
                            log_1.default.error('soma', soma);
                        }
                        ;
                    }
                    ;
                }
                ;
            }
            ;
            var campoPorcentagem = record.getValue({
                fieldId: 'custbody_lrc_valor_caucao'
            });
            if (campoPorcentagem) {
                var porcentagem = Number(campoPorcentagem) / 100;
                soma = soma * porcentagem;
                record.setValue({
                    fieldId: 'custbody_rsc_retido_caucao',
                    value: soma
                });
            }
            ;
        }
        else {
            var soma = 0;
            var quantidadeItensSublist_contrato = record.getLineCount({
                sublistId: 'item'
            });
            for (var i = 0; i < quantidadeItensSublist_contrato; i++) {
                var retencaoCaucao = record.getSublistValue({
                    fieldId: 'custcol_rsc_retencao_caucao',
                    line: i,
                    sublistId: 'item'
                });
                if (retencaoCaucao) {
                    var valorPedido = record.getSublistValue({
                        fieldId: 'amount',
                        line: i,
                        sublistId: 'item'
                    });
                    log_1.default.error('valor', valorPedido);
                    soma = soma + Number(valorPedido);
                }
            }
            var campoPorcentagem = record.getValue({
                fieldId: 'custbody_lrc_valor_caucao'
            });
            if (campoPorcentagem) {
                var porcentagem = Number(campoPorcentagem) / 100;
                soma = soma * porcentagem;
                record.setValue({
                    fieldId: 'custbody_rsc_retido_caucao',
                    value: soma
                });
            }
            ;
        }
    };
    exports.beforeSubmit = beforeSubmit;
    var afterSubmit = function (ctx) {
        var record = ctx.newRecord;
        var pedidoCompra = record.getSublistValue({
            sublistId: 'purchaseorders',
            fieldId: 'id',
            line: 0
        });
        if (pedidoCompra) {
            var LookupPedido = search_1.default.lookupFields({
                type: 'purchaseorder',
                id: pedidoCompra,
                columns: [
                    'custbody_lrc_retencao_caucao',
                    'custbody_lrc_valor_caucao'
                ]
            });
            record.setValue({
                fieldId: 'custbody_lrc_retencao_caucao',
                value: Boolean(LookupPedido.custbody_lrc_retencao_caucao)
            });
            record.setValue({
                fieldId: 'custbody_lrc_valor_caucao',
                value: String(LookupPedido.custbody_lrc_valor_caucao)
            });
            var recordPedido = record_1.default.load({
                type: 'purchaseorder',
                id: pedidoCompra
            });
            var qtLinhasPedido = recordPedido.getLineCount({
                sublistId: 'item'
            });
            var qtLinhasContrato = record.getLineCount({
                sublistId: 'item'
            });
            for (var i = 0; i < qtLinhasPedido; i++) {
                var itemPedido = recordPedido.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'item_display',
                    line: i
                });
                for (var j = 0; j < qtLinhasContrato; j++) {
                    var itemContrato = recordPedido.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'item_display',
                        line: i
                    });
                    if (itemPedido == itemContrato) {
                        var retencaoSublistaPedido = recordPedido.getSublistValue({
                            sublistId: 'item',
                            fieldId: 'custcol_rsc_retencao_caucao',
                            line: i
                        });
                        record.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'custcol_rsc_retencao_caucao',
                            value: retencaoSublistaPedido,
                            line: j
                        });
                    }
                }
            }
        }
    };
    exports.afterSubmit = afterSubmit;
});
