/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/search"], function (require, exports, record_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.pageInit = void 0;
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    var pageInit = function (ctx) {
        var record = ctx.currentRecord;
        var pedidoCompra = record.getSublistValue({
            sublistId: 'purchaseorders',
            fieldId: 'id',
            line: 0
        });
        console.log('PedidoCompraid', pedidoCompra);
        if (pedidoCompra) {
            var LookupPedido = search_1.default.lookupFields({
                type: 'purchaseorder',
                id: pedidoCompra,
                columns: [
                    'custbody_lrc_retencao_caucao',
                    'custbody_lrc_valor_caucao'
                ]
            });
            console.log('Lookup', LookupPedido);
            record.setValue({
                fieldId: 'custbody_lrc_retencao_caucao',
                value: Boolean(LookupPedido.custbody_lrc_retencao_caucao)
            });
            record.setValue({
                fieldId: 'custbody_lrc_valor_caucao',
                value: String(LookupPedido.custbody_lrc_valor_caucao)
            });
            var recordPedido = record_1.default.load({
                type: 'purchaseorder',
                id: pedidoCompra
            });
            var qtLinhasPedido = recordPedido.getLineCount({
                sublistId: 'item'
            });
            var qtLinhasContrato = record.getLineCount({
                sublistId: 'item'
            });
            for (var i = 0; i < qtLinhasPedido; i++) {
                var itemPedido = recordPedido.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'item_display',
                    line: i
                });
                for (var j = 0; j < qtLinhasContrato; j++) {
                    var itemContrato = recordPedido.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'item_display',
                        line: i
                    });
                    if (itemPedido == itemContrato) {
                        var retencaoSublistaPedido = recordPedido.getSublistValue({
                            sublistId: 'item',
                            fieldId: 'custcol_rsc_retencao_caucao',
                            line: i
                        });
                        record.selectLine({
                            sublistId: 'item',
                            line: j
                        });
                        record.setCurrentSublistValue({
                            sublistId: 'item',
                            fieldId: 'custcol_rsc_retencao_caucao',
                            value: retencaoSublistaPedido
                        });
                        record.commitLine({
                            sublistId: 'item'
                        });
                    }
                }
            }
        }
    };
    exports.pageInit = pageInit;
});
