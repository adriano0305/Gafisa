/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_unidadeCorrecao.ts
 * 
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        if (ctx.request.method == 'GET') {
            log_1.default.error('request', ctx.request.parameters);
            var parameters = ctx.request.parameters;
            var itemId = parameters.itemId;
            ctx.newRecord.setValue({
                fieldId: 'custrecord_lrc_itens',
                value: itemId
            });
        }
    };
    exports.beforeLoad = beforeLoad;
});
