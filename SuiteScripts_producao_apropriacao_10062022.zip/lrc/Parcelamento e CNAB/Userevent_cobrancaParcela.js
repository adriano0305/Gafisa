/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* UserEventScript_telaConfigParcelamento.ts
* 
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/ui/serverWidget", "N/search"], function (require, exports, log_1, UI, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = exports.beforeSubmit = void 0;
    log_1 = __importDefault(log_1);
    UI = __importStar(UI);
    search_1 = __importDefault(search_1);
    var beforeSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var oldRecord = ctx.oldRecord;
        var searchParcela = search_1.default.create({
            type: 'customrecord_lrc_configuracao_de_parcela',
        }).run().getRange({
            start: 0,
            end: 1
        });
        var parcelaLock = search_1.default.lookupFields({
            type: 'customrecord_lrc_configuracao_de_parcela',
            id: searchParcela[0].id,
            columns: ['custrecord_lrc_campo_tipo_documento_fisc']
        });
        newRecord.setValue({
            fieldId: 'custbody_enl_order_documenttype',
            value: parcelaLock.custrecord_lrc_campo_tipo_documento_fisc[0].value
        });
        if (ctx.type == ctx.UserEventType.DELETE) {
            log_1.default.error('Cobraca principal', oldRecord.getValue('custbody_lrc_cobranca_principal'));
            if (oldRecord.getValue('custbody_lrc_cobranca_principal')) {
                throw Error('Não permitido a exclusão, pois existe uma fatura principal que depende dessa.');
            }
            else {
                var verificaParcela = search_1.default.create({
                    type: 'vendorbill',
                    filters: ['custbody_lrc_cobranca_principal', 'IS', newRecord.id]
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                if (verificaParcela[0]) {
                    throw Error('Existem parcelas referentes a essa fatura.');
                }
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
    var beforeLoad = function (ctx) {
        var newRecord = ctx.newRecord;
        var form = ctx.form;
        var faturaP = newRecord.getValue('custbody_lrc_cobranca_principal');
        if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.VIEW) {
            if (!faturaP) {
                form.getField({
                    id: 'custbody_lrc_cobranca_principal'
                }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
                form.getField({
                    id: 'custbody_lrc_cobranca_cancelada'
                }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN });
            }
        }
    };
    exports.beforeLoad = beforeLoad;
});
