/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* UserEventScript_telaConfigParcelamento.ts
* 
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log", "N/ui/serverWidget", "N/search", "N/runtime"], function (require, exports, record_1, log_1, UI, search_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = exports.afterSubmit = exports.beforeSubmit = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    UI = __importStar(UI);
    search_1 = __importDefault(search_1);
    runtime_1 = __importDefault(runtime_1);
    var beforeSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var oldRecord = ctx.oldRecord; //sd
        log_1.default.error('Tipo fatura', newRecord.getValue('custbody_lrc_tipo_fatura'));
        if (ctx.type == ctx.UserEventType.CREATE) {
            log_1.default.error('modo de criação', 'done');
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == '3') {
                log_1.default.error('entrei no if', 'done');
                var qtLinhas = newRecord.getLineCount({
                    sublistId: 'item'
                });
                var item = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_correcaofatura' });
                for (var i = 0; i < qtLinhas; i++) {
                    log_1.default.error('i', i);
                    log_1.default.error('qtlinhas', qtLinhas);
                    if (i == qtLinhas - 1) {
                        var j = i + 1;
                        newRecord.setSublistValue({
                            fieldId: 'item',
                            sublistId: 'item',
                            value: item,
                            line: j
                        });
                        newRecord.setSublistValue({
                            fieldId: 'amount',
                            sublistId: 'item',
                            value: 0,
                            line: j
                        });
                    }
                }
                log_1.default.error('item', item);
            }
        }
        else if (ctx.type == ctx.UserEventType.EDIT) {
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == 2) {
                if (newRecord.getValue('custbody_lrc_fatura_principal') != oldRecord.getValue('custbody_lrc_fatura_principal')) {
                    throw new Error('Não é permitida a alteração da fatura principal.');
                }
            }
        }
        else if (ctx.type == ctx.UserEventType.DELETE) {
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == 2) {
                if (newRecord.getValue('custbody_lrc_fatura_principal')) {
                    throw new Error('Não é permitido excluir a fatura, pois há uma fatura principal preenchida.');
                }
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
    var afterSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var oldRecord = ctx.oldRecord;
        var item = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_correcaofatura' });
        var faturaprincipal = newRecord.getValue('custbody_lrc_fatura_principal');
        if (ctx.type == ctx.UserEventType.CREATE) {
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == 2) {
                if (newRecord.getValue('custbody_lrc_parcela_cancelada') == false) {
                    var somaparcelas_1 = 0;
                    var searchParcelas = search_1.default.create({
                        type: 'invoice',
                        filters: [
                            ['custbody_lrc_fatura_principal', 'IS', faturaprincipal],
                            'AND',
                            ['mainline', 'IS', 'T']
                        ],
                        columns: ['total']
                    }).run().each(function (result) {
                        log_1.default.error('result', result);
                        var totalLookup = search_1.default.lookupFields({
                            type: 'invoice',
                            id: result.id,
                            columns: ['total']
                        });
                        log_1.default.error('soma', totalLookup['total']);
                        somaparcelas_1 += Number(totalLookup['total']);
                        return true;
                    });
                    log_1.default.error('somaparcelas', somaparcelas_1);
                    var buscaPrincipal = search_1.default.create({
                        type: 'invoice',
                        filters: ['internalid', 'IS', faturaprincipal],
                        columns: ['total']
                    }).run().getRange({
                        start: 0,
                        end: 1
                    });
                    var recordFaturaPrincipal = record_1.default.load({
                        type: 'invoice',
                        id: buscaPrincipal[0].id
                    });
                    log_1.default.error('buscaPrincipalID', buscaPrincipal[0].id);
                    var qtLinhas = recordFaturaPrincipal.getLineCount({
                        sublistId: 'item'
                    });
                    var total = recordFaturaPrincipal.getValue('total');
                    log_1.default.error('total', total);
                    for (var i = 0; i < qtLinhas; i++) {
                        var itemComparacao = recordFaturaPrincipal.getSublistValue({
                            fieldId: 'item',
                            sublistId: 'item',
                            line: i
                        });
                        log_1.default.error('item', item);
                        log_1.default.error('itemComparacao', itemComparacao);
                        if (itemComparacao == item) {
                            recordFaturaPrincipal.setSublistValue({
                                fieldId: 'amount',
                                sublistId: 'item',
                                line: i,
                                value: Number(somaparcelas_1) - Number(total)
                            });
                        }
                    }
                    recordFaturaPrincipal.save({
                        ignoreMandatoryFields: true
                    });
                }
            }
        }
        else if (ctx.type == ctx.UserEventType.EDIT) {
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == 2) {
                if (newRecord.getValue('total') != oldRecord.getValue('total')) {
                    if (newRecord.getValue('custbody_lrc_parcela_cancelada') == false) {
                        var searchPrincipal = search_1.default.create({
                            type: 'invoice',
                            filters: ['internalid', 'IS', faturaprincipal],
                            columns: ['total']
                        }).run().getRange({
                            start: 0,
                            end: 1
                        });
                        var recordFaturaPrincipal = record_1.default.load({
                            type: 'invoice',
                            id: searchPrincipal[0].id
                        });
                        var qtLinhas = recordFaturaPrincipal.getLineCount({
                            sublistId: 'item'
                        });
                        for (var i = 0; i < qtLinhas; i++) {
                            var itemparametrizado = recordFaturaPrincipal.getSublistValue({
                                fieldId: 'item',
                                sublistId: 'item',
                                line: i
                            });
                            var valoritemparametrizado = recordFaturaPrincipal.getSublistValue({
                                fieldId: 'amount',
                                sublistId: 'item',
                                line: i
                            });
                            if (itemparametrizado == item) {
                                var diferençaTotal = Number(newRecord.getValue('total')) - Number(oldRecord.getValue('total'));
                                recordFaturaPrincipal.setSublistValue({
                                    fieldId: 'amount',
                                    sublistId: 'item',
                                    line: i,
                                    value: Number(valoritemparametrizado) + Number(diferençaTotal)
                                });
                            }
                        }
                        recordFaturaPrincipal.save({
                            ignoreMandatoryFields: true
                        });
                    }
                    else if (newRecord.getValue('custbody_lrc_parcela_cancelada') != oldRecord.getValue('custbody_lrc_parcela_cancelada') && newRecord.getValue('custbody_lrc_parcela_cancelada') == true) {
                        var searchPrincipal = search_1.default.create({
                            type: 'invoice',
                            filters: ['internalid', 'IS', faturaprincipal],
                            columns: ['total']
                        }).run().getRange({
                            start: 0,
                            end: 1
                        });
                        var recordFaturaPrincipal = record_1.default.load({
                            type: 'invoice',
                            id: searchPrincipal[0].id
                        });
                        var totalPrincipal = Number(recordFaturaPrincipal.getValue('total'));
                        recordFaturaPrincipal.setValue({
                            fieldId: 'total',
                            value: totalPrincipal - Number(newRecord.getValue('total'))
                        });
                        recordFaturaPrincipal.save({
                            ignoreMandatoryFields: true
                        });
                    }
                }
            }
        }
    };
    exports.afterSubmit = afterSubmit;
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.EDIT) {
            var form = ctx.form;
            form.getField({
                id: 'custbody_lrc_tipo_fatura'
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        }
    };
    exports.beforeLoad = beforeLoad;
});
