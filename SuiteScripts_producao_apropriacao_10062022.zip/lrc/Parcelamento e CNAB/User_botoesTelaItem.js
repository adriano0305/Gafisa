/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * User_botoesTelaItem.ts
 * 
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log"], function (require, exports, search_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        var newRecordType = ctx.newRecord.getValue("type");
        log_1.default.error("newRecordType", newRecordType);
        if (newRecordType == 'item' || newRecordType == 'inventoryitem') {
            var form = ctx.form;
            var newRecord = ctx.newRecord;
            //pegar valor do "item"
            var itemId = newRecord.id;
            if (ctx.type == ctx.UserEventType.EDIT) {
                //verificar se o item ja esta na correcao
                var searchCorrecao = search_1.default.create({
                    type: "customrecord_lrc_unidade_item",
                    filters: ['custrecord_lrc_itens', 'IS', itemId],
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                log_1.default.error('search', searchCorrecao[0]);
                if (!searchCorrecao[0]) {
                    form.addButton({
                        id: "custpage_button",
                        label: "Adicionar Unidade de Correção",
                        functionName: "adicionar"
                    });
                }
                else {
                    form.addButton({
                        id: "custpage_button",
                        label: "Editar Unidade de Correção",
                        functionName: "editar"
                    });
                }
            }
            form.clientScriptModulePath = "./Client_botoesTelaItem.js";
        }
    };
    exports.beforeLoad = beforeLoad;
});
