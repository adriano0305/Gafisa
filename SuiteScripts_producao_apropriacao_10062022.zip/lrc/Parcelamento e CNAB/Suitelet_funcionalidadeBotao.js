/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_mudaCliente.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/search", "N/log", "N/redirect"], function (require, exports, record_1, search_1, log_1, redirect_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    redirect_1 = __importDefault(redirect_1);
    var onRequest = function (ctx) {
        if (ctx.request.method == 'GET') {
            var parameters = ctx.request.parameters;
            var tipoDoc = parameters.tipoDoc;
            var arredondamento = parameters.arredondamento;
            var itens = JSON.parse(parameters.itens);
            log_1.default.error('tipoDoc', tipoDoc);
            log_1.default.error('arredondamento', arredondamento);
            log_1.default.error('itens', itens);
            var searchResult = search_1.default.create({
                type: 'customrecord_lrc_configuracao_de_parcela',
                filters: ['custrecord_lrc_campo_tipo_documento_fisc', 'IS', tipoDoc]
            }).run().getRange({
                start: 0,
                end: 1
            });
            if (arredondamento == 1) {
                arredondamento = true;
            }
            else {
                arredondamento = false;
            }
            if (searchResult[0]) {
                var configRecord = record_1.default.load({
                    type: 'customrecord_lrc_configuracao_de_parcela',
                    id: searchResult[0].id
                });
                log_1.default.error('configRecord', configRecord);
                configRecord.setValue({
                    fieldId: 'custrecord_lrc_arredondamento_parcela',
                    value: arredondamento
                });
                configRecord.setValue({
                    fieldId: 'custrecord_lrc_campo_itens',
                    value: itens
                });
                configRecord.save({
                    ignoreMandatoryFields: true
                });
            }
            else {
                var configRecord = record_1.default.create({
                    type: 'customrecord_lrc_configuracao_de_parcela'
                });
                configRecord.setValue({
                    fieldId: 'custrecord_lrc_arredondamento_parcela',
                    value: arredondamento
                });
                configRecord.setValue({
                    fieldId: 'custrecord_lrc_campo_itens',
                    value: itens
                });
                configRecord.setValue({
                    fieldId: 'custrecord_lrc_campo_tipo_documento_fisc',
                    value: tipoDoc
                });
                configRecord.save({
                    ignoreMandatoryFields: true
                });
            }
            redirect_1.default.toSuitelet({
                scriptId: 'customscript_lrc_suitelet_tela',
                deploymentId: 'customdeploy_lrc_suitelet_tela',
            });
        }
    };
    exports.onRequest = onRequest;
});
