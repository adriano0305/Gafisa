/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_pedidoCompra.js
 *
 * UserEvents aplicados no pedido de compra
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record", "N/log"], function (require, exports, search_1, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = exports.beforeSubmit = exports.beforeLoad = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
      var pedidoRecord = ctx.newRecord;
      log.audit({title: 'Log erro', details: ctx});
      if (ctx.request != null){
        var params = ctx.request.parameters;
        // Verifica se é um pedido de compra de empreitada
        if (params.hasOwnProperty('endeavor_contract')) {
            pedidoRecord.setValue({
                fieldId: 'custbody_lrc_contrato_de_empreitada',
                value: params.endeavor_contract
            });
        }
        else {
            pedidoRecord.setValue({
                fieldId: 'entity',
                value: params.entity
            });
            pedidoRecord.setValue({
                fieldId: 'subsidiary',
                value: params.subsidiary
            });
        }
      }
        
    };
    exports.beforeLoad = beforeLoad;
    var beforeSubmit = function (ctx) {
        log_1.default.error("beforeSubmit type", ctx.type);
        var record = ctx.newRecord;
        var x = 0;
        var contrato = record.getValue('purchasecontract');
        var ContratoEmpreitada = record.getValue('custbody_lrc_contrato_de_empreitada');
        if (contrato) {
            var ContratoLookup = search_1.default.lookupFields({
                type: 'purchasecontract',
                id: contrato,
                columns: ["custbody_rsc_contrato_lpu"]
            });
            var contratoLPU = ContratoLookup.custbody_rsc_contrato_lpu;
            if (contratoLPU) {
                x = 1;
            }
        }
        else if (ContratoEmpreitada) {
            var ContratoLookup = search_1.default.lookupFields({
                type: 'purchasecontract',
                id: ContratoEmpreitada,
                columns: ["custbody_rsc_contrato_lpu"]
            });
            var contratoLPU = ContratoLookup.custbody_rsc_contrato_lpu;
            log_1.default.error('teste', contratoLPU);
            if (contratoLPU) {
                x = 1;
            }
        }
        log_1.default.error('x', x);
        if (x == 0) {
            log_1.default.error('aquui', 'done');
            if (ctx.type == ctx.UserEventType.CREATE) {
                var newRecord = ctx.newRecord;
                var contractId = newRecord.getValue('purchasecontract') || newRecord.getValue("custbody_lrc_contrato_de_empreitada");
                log_1.default.error("contractId", contractId);
                if (contractId) {
                    // O pedido de compra que está sendo criado não pode deixar o saldo do contrato negativo 
                    var valorNovoPedido = Number(newRecord.getValue({
                        fieldId: 'total'
                    }));
                    log_1.default.error("valorNovoPedido", valorNovoPedido);
                    var contractLookUp = search_1.default.lookupFields({
                        type: search_1.default.Type.PURCHASE_CONTRACT,
                        id: contractId,
                        columns: [
                            "custbody_lrc_saldo_contrato",
                            "tranid"
                        ]
                    });
                    log_1.default.error("contractLookUp", contractLookUp);
                    var saldoContrato = Number(contractLookUp["custbody_lrc_saldo_contrato"]);
                    var newSaldoContrato = saldoContrato - valorNovoPedido;
                    log_1.default.error("newSaldoContrato", newSaldoContrato);
                    if (newSaldoContrato < 0) {
                        throw new Error('O saldo do contrato ' + contractLookUp["tranid"] + ' será negativo!' + " A submissão do pedido de compra foi cancelada.");
                    }
                }
            }
            else if (ctx.type == ctx.UserEventType.EDIT) {
                var oldRecord = ctx.oldRecord;
                var newRecord = ctx.newRecord;
                var oldContractId = oldRecord.getValue('purchasecontract') || oldRecord.getValue("custbody_lrc_contrato_de_empreitada");
                log_1.default.error("oldContractId", oldContractId);
                var newContractId = newRecord.getValue('purchasecontract') || newRecord.getValue("custbody_lrc_contrato_de_empreitada");
                log_1.default.error("newContractId", newContractId);
                if (oldContractId != newContractId && newContractId) { // contrato alterado
                    var newValorPedido = Number(newRecord.getValue("total"));
                    log_1.default.error("newValorPedido", newValorPedido);
                    var newContractLookUp = search_1.default.lookupFields({
                        type: search_1.default.Type.PURCHASE_CONTRACT,
                        id: newContractId,
                        columns: [
                            "custbody_lrc_saldo_contrato",
                            "tranid"
                        ]
                    });
                    log_1.default.error("newContractLookUp", newContractLookUp);
                    var saldoNewContrato = Number(newContractLookUp["custbody_lrc_saldo_contrato"]);
                    saldoNewContrato -= newValorPedido;
                    log_1.default.error("saldoNewContract", saldoNewContrato);
                    if (saldoNewContrato < 0) {
                        throw new Error('O saldo do contrato ' + newContractLookUp["tranid"] + ' será negativo!' + " A submissão do pedido de compra foi cancelada.");
                    }
                }
                else if (newContractId) { // contrato permaneceu o mesmo
                    var diff = Number(newRecord.getValue("total")) - Number(oldRecord.getValue("total"));
                    log_1.default.error("diff", diff);
                    var newContractLookUp = search_1.default.lookupFields({
                        type: search_1.default.Type.PURCHASE_CONTRACT,
                        id: newContractId,
                        columns: [
                            "custbody_lrc_saldo_contrato",
                            "tranid"
                        ]
                    });
                    log_1.default.error("newContractLookUp", newContractLookUp);
                    var saldoNewContrato = Number(newContractLookUp["custbody_lrc_saldo_contrato"]);
                    saldoNewContrato -= diff;
                    log_1.default.error("saldoNewContract", saldoNewContrato);
                    if (saldoNewContrato < 0) {
                        throw new Error('O saldo do contrato ' + newContractLookUp["tranid"] + ' será negativo!' + " A submissão do pedido de compra foi cancelada.");
                    }
                }
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
    var afterSubmit = function (ctx) {
        log_1.default.error("afterSubmit eventType", ctx.type);
        var record = ctx.newRecord;
        var x = 0;
        var contrato = record.getValue('purchasecontract');
        var ContratoEmpreitada = record.getValue('custbody_lrc_contrato_de_empreitada');
        if (contrato) {
            var ContratoLookup = search_1.default.lookupFields({
                type: 'purchasecontract',
                id: contrato,
                columns: ["custbody_rsc_contrato_lpu"]
            });
            var contratoLPU = ContratoLookup.custbody_rsc_contrato_lpu;
            if (contratoLPU) {
                x = 1;
            }
        }
        else if (ContratoEmpreitada) {
            var ContratoLookup = search_1.default.lookupFields({
                type: 'purchasecontract',
                id: ContratoEmpreitada,
                columns: ["custbody_rsc_contrato_lpu"]
            });
            var contratoLPU = ContratoLookup.custbody_rsc_contrato_lpu;
            if (contratoLPU) {
                x = 1;
            }
        }
        if (x == 0) {
            if (ctx.type == ctx.UserEventType.CREATE) {
                var isEmpreitada = false;
                var newRecord = ctx.newRecord;
                var contratoId = newRecord.getValue('purchasecontract'); // contrato de compra padrao
                if (!contratoId) {
                    contratoId = newRecord.getValue("custbody_lrc_contrato_de_empreitada"); // contrato de compra de empreitada
                    if (!contratoId)
                        return true;
                    isEmpreitada = true;
                }
                log_1.default.error("contratoId", contratoId);
                log_1.default.error("isEmpreitada", isEmpreitada);
                var valorPedido = Number(newRecord.getValue('total'));
                log_1.default.error("valorPedido", valorPedido);
                var recordContract = record_1.default.load({
                    type: 'purchasecontract',
                    id: contratoId
                });
                if (isEmpreitada) { // Caso o pedido de compra seja de empreitada -> atualizar o valor "Valor Empreitada"
                    var valorEmpreitada = Number(recordContract.getValue("custbody_lrc_valor_empreitada"));
                    log_1.default.error("valorEmpreitada antes", valorEmpreitada);
                    valorEmpreitada += valorPedido;
                    log_1.default.error("valorEmpreitada apos", valorEmpreitada);
                    recordContract.setValue({
                        fieldId: 'custbody_lrc_valor_empreitada',
                        value: valorEmpreitada
                    });
                }
                else {
                    var valorTotalPedidos = Number(recordContract.getValue('custbody_lrc_valor_pedidos')); // Caso o pedido de compra seja padrao -> atualizar o valor "Valor Total Pedidos"
                    log_1.default.error("valorTotalPedidos antes", valorTotalPedidos);
                    valorTotalPedidos = valorTotalPedidos + valorPedido;
                    log_1.default.error("valorTotalPedidos apos", valorTotalPedidos);
                    recordContract.setValue({
                        fieldId: 'custbody_lrc_valor_pedidos',
                        value: valorTotalPedidos
                    });
                }
                var saldoContrato = Number(recordContract.getValue("custbody_lrc_saldo_contrato"));
                log_1.default.error("saldoContrato antes", saldoContrato);
                saldoContrato -= valorPedido;
                log_1.default.error("saldoContrato apos", saldoContrato);
                recordContract.setValue({
                    fieldId: 'custbody_lrc_saldo_contrato',
                    value: saldoContrato
                });
                if (saldoContrato == 0) {
                    recordContract.setValue({
                        fieldId: "custbody_lrc_status",
                        value: 4 // CONTRATO VENCIDO
                    });
                }
                recordContract.save({ ignoreMandatoryFields: true });
            }
            else if (ctx.type == ctx.UserEventType.EDIT) {
                var oldIsEmpreitada = false;
                var newIsEmpreitada = false;
                var newRecord = ctx.newRecord;
                var oldRecord = ctx.oldRecord;
                var oldContractId = oldRecord.getValue("purchasecontract");
                if (!oldContractId) {
                    oldContractId = oldRecord.getValue("custbody_lrc_contrato_de_empreitada"); // pedido de compra de empreitada
                    oldIsEmpreitada = true;
                }
                log_1.default.error("oldContractId", oldContractId);
                log_1.default.error("oldIsEmpreitada", oldIsEmpreitada);
                var newContractId = newRecord.getValue("purchasecontract");
                if (!newContractId) {
                    newContractId = newRecord.getValue("custbody_lrc_contrato_de_empreitada"); // pedido de compra de empreitada
                    newIsEmpreitada = true;
                }
                log_1.default.error("newContractId", newContractId);
                log_1.default.error("newIsEmpreitada", newIsEmpreitada);
                var oldContract = void 0;
                var newContract = 0;
                if (oldContractId) {
                    oldContract = record_1.default.load({
                        type: "purchasecontract",
                        id: oldContractId
                    });
                    var oldValorPedido = Number(oldRecord.getValue('total'));
                    log_1.default.error("oldValorPedido", oldValorPedido);
                    if (oldIsEmpreitada) { // pedido de compra de empreitada
                        var oldValorEmpreitada = Number(oldContract.getValue("custbody_lrc_valor_empreitada"));
                        log_1.default.error("oldValorEmpreitada antes", oldValorEmpreitada);
                        log_1.default.error("oldValorTotalPedidos apos", oldValorEmpreitada - oldValorPedido);
                        oldContract.setValue({
                            fieldId: "custbody_lrc_valor_empreitada",
                            value: oldValorEmpreitada - oldValorPedido
                        });
                    }
                    else { // pedido de compra padrao
                        var oldValorTotalPedidos = Number(oldContract.getValue("custbody_lrc_valor_pedidos"));
                        log_1.default.error("oldValorTotalPedidos antes", oldValorTotalPedidos);
                        log_1.default.error("oldValorTotalPedidos apos", oldValorTotalPedidos - oldValorPedido);
                        oldContract.setValue({
                            fieldId: "custbody_lrc_valor_pedidos",
                            value: oldValorTotalPedidos - oldValorPedido
                        });
                    }
                    var oldSaldoContrato = Number(oldContract.getValue("custbody_lrc_saldo_contrato"));
                    log_1.default.error("oldSaldoContrato antes", oldSaldoContrato);
                    oldSaldoContrato += oldValorPedido;
                    log_1.default.error("oldSaldoContrato apos", oldSaldoContrato);
                    oldContract.setValue({
                        fieldId: 'custbody_lrc_saldo_contrato',
                        value: oldSaldoContrato
                    });
                    if (oldContractId != newContractId) {
                        oldContract.save({
                            ignoreMandatoryFields: true
                        });
                    }
                }
                if (newContractId) {
                    if (oldContractId == newContractId) {
                        newContract = oldContract;
                    }
                    else {
                        newContract = record_1.default.load({
                            type: "purchasecontract",
                            id: newContractId
                        });
                    }
                    var newValorPedido = Number(newRecord.getValue('total'));
                    log_1.default.error("newValorPedido", newValorPedido);
                    if (newIsEmpreitada) { // pedido de compra de empreitada
                        var newValorEmpreitada = Number(newContract.getValue("custbody_lrc_valor_empreitada"));
                        log_1.default.error("newValorEmpreitada antes", newValorEmpreitada);
                        log_1.default.error("newValorTotalPedidos apos", newValorEmpreitada + newValorPedido);
                        newContract.setValue({
                            fieldId: "custbody_lrc_valor_empreitada",
                            value: newValorEmpreitada + newValorPedido
                        });
                    }
                    else { // pedido de compra padrao
                        var newValorTotalPedidos = Number(newContract.getValue("custbody_lrc_valor_pedidos"));
                        log_1.default.error("newValorTotalPedidos antes", newValorTotalPedidos);
                        log_1.default.error("newValorTotalPedidos apos", newValorTotalPedidos + newValorPedido);
                        newContract.setValue({
                            fieldId: "custbody_lrc_valor_pedidos",
                            value: newValorTotalPedidos + newValorPedido
                        });
                    }
                    var newSaldoContrato = Number(newContract.getValue("custbody_lrc_saldo_contrato"));
                    log_1.default.error("newSaldoContrato antes", newSaldoContrato);
                    newSaldoContrato -= newValorPedido;
                    log_1.default.error("newSaldoContrato apos", newSaldoContrato);
                    newContract.setValue({
                        fieldId: 'custbody_lrc_saldo_contrato',
                        value: newSaldoContrato
                    });
                    if (newSaldoContrato == 0) {
                        newContract.setValue({
                            fieldId: "custbody_lrc_status",
                            value: 4 // CONTRATO VENCIDO
                        });
                    }
                    newContract.save({
                        ignoreMandatoryFields: true
                    });
                }
            }
            else if (ctx.type == ctx.UserEventType.DELETE) {
                var isEmpreitada = false;
                var oldRecord = ctx.oldRecord;
                var contratoId = oldRecord.getValue('purchasecontract'); // contrato de compra padrao
                if (!contratoId) {
                    contratoId = oldRecord.getValue("custbody_lrc_contrato_de_empreitada"); // contrato de compra de empreitada
                    if (!contratoId)
                        return true;
                    isEmpreitada = true;
                }
                log_1.default.error("contratoId", contratoId);
                log_1.default.error("isEmpreitada", isEmpreitada);
                var valorPedido = Number(oldRecord.getValue('total'));
                log_1.default.error("valorPedido", valorPedido);
                var recordContract = record_1.default.load({
                    type: 'purchasecontract',
                    id: contratoId
                });
                if (isEmpreitada) { // Caso o pedido de compra seja de empreitada -> atualizar o valor "Valor Empreitada"
                    var valorEmpreitada = Number(recordContract.getValue("custbody_lrc_valor_empreitada"));
                    log_1.default.error("valorEmpreitada antes", valorEmpreitada);
                    valorEmpreitada -= valorPedido;
                    log_1.default.error("valorEmpreitada apos", valorEmpreitada);
                    recordContract.setValue({
                        fieldId: 'custbody_lrc_valor_empreitada',
                        value: valorEmpreitada
                    });
                }
                else {
                    var valorTotalPedidos = Number(recordContract.getValue('custbody_lrc_valor_pedidos')); // Caso o pedido de compra seja padrao -> atualizar o valor "Valor Total Pedidos"
                    log_1.default.error("valorTotalPedidos antes", valorTotalPedidos);
                    valorTotalPedidos -= valorPedido;
                    log_1.default.error("valorTotalPedidos apos", valorTotalPedidos);
                    recordContract.setValue({
                        fieldId: 'custbody_lrc_valor_pedidos',
                        value: valorTotalPedidos
                    });
                }
                var saldoContrato = Number(recordContract.getValue("custbody_lrc_saldo_contrato"));
                log_1.default.error("saldoContrato antes", saldoContrato);
                saldoContrato += valorPedido;
                log_1.default.error("saldoContrato apos", saldoContrato);
                recordContract.setValue({
                    fieldId: 'custbody_lrc_saldo_contrato',
                    value: saldoContrato
                });
                recordContract.save({ ignoreMandatoryFields: true });
            }
        }
    };
    exports.afterSubmit = afterSubmit;
});
