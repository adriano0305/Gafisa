/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * gerirContrato.ts
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/runtime", "N/log", "./ClientScript_gerirContrato"], function (require, exports, ServerWidget, runtime_1, log_1, ClientScript_gerirContrato_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = exports.beforeLoad = void 0;
    ServerWidget = __importStar(ServerWidget);
    runtime_1 = __importDefault(runtime_1);
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        var contratoForm = ctx.form;
        contratoForm.clientScriptModulePath = './ClientScript_gerirContrato.js';
        var contratoRecord = ctx.newRecord;
        if (ctx.type === ctx.UserEventType.CREATE || ctx.type === ctx.UserEventType.EDIT) {
            var contratoJuridicoId = contratoRecord.getValue('custbody_lrc_contrato_juridico');
            var statusContratoJuridico = contratoForm.getField({
                id: 'custbody_lrc_status'
            });
            var statusParametrizado = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_status_aprovado' });
            var statusEnvelope = ClientScript_gerirContrato_1.getStatusEnvelope(String(contratoJuridicoId));
            if (!contratoJuridicoId || statusEnvelope !== statusParametrizado) {
                if (ctx.type === ctx.UserEventType.CREATE) {
                    // Setando o valor "Pendente de aprovação" no campo "status" de Contrato Jurídico
                    statusContratoJuridico.defaultValue = '1';
                }
                statusContratoJuridico.updateDisplayType({
                    displayType: ServerWidget.FieldDisplayType.DISABLED
                });
            }
            if (ctx.type === ctx.UserEventType.EDIT) {
                contratoForm.addButton({
                    id: 'custpage_btn_open_endeavor_sales_order',
                    label: 'Criar Pedido de Compra de Empreitada',
                    functionName: 'openEndeavorSalesOrder'
                });
                contratoForm.addButton({
                    id: 'custpage_btn_open_sales_order',
                    label: 'Criar Pedido de Compra',
                    functionName: 'openSalesOrder'
                });
            }
        }
    };
    exports.beforeLoad = beforeLoad;
    var beforeSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var bSalvar = ctx.newRecord;
            var totalPedidos = Number(bSalvar.getValue('custbody_lrc_valor_pedidos'));
            log_1.default.error("totalPedidos", totalPedidos);
            var totalEmpreitada = Number(bSalvar.getValue('custbody_lrc_valor_empreitada'));
            log_1.default.error("totalEmpreitada", totalEmpreitada);
            var qtItem = bSalvar.getLineCount({
                sublistId: 'item'
            });
            var aux = 0;
            var somaItem = 0;
            for (var i = 0; i < qtItem; i++) {
                somaItem = Number(bSalvar.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: i
                }));
                somaItem = aux + somaItem;
                aux = somaItem;
            }
            bSalvar.setValue({
                fieldId: 'custbody_lrc_valor_contrato',
                value: somaItem
            });
            var saldoContrato = (somaItem - totalPedidos - totalEmpreitada);
            log_1.default.error("saldoContrato", saldoContrato);
            bSalvar.setValue({
                fieldId: 'custbody_lrc_saldo_contrato',
                value: saldoContrato
            });
            if (saldoContrato < 0) {
                throw new Error("O saldo do contrato " + bSalvar.getValue("tranid") + " será negativo!" + " A submissão do contrato de compra será cancelada.");
            }
            else if (saldoContrato == 0) {
                bSalvar.setValue({
                    fieldId: "custbody_lrc_status",
                    value: 4 // CONTRATO VENCIDO
                });
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
