/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * AddButtonComms.js
 *
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    exports.beforeLoad = function (ctx) {
        var form = ctx.form;
        if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.VIEW) {
            form.clientScriptModulePath = "./ClientScriptReq.js";
            form.getSublist({ id: "activities" }).addButton({
                label: "Email",
                id: "custpage_lrc_email",
                functionName: "openEnviarEmail"
            });
        }
    };
});
