/**
 *@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteletEnviarEmail.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/email"], function (require, exports, email_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    email_1 = __importDefault(email_1);
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "POST") {
            var body = JSON.parse(ctx.request.body);
            email_1.default.sendBulk({
                author: -5,
                body: body.content,
                subject: body.subject,
                recipients: body.to,
                bcc: body.ccc
            });
        }
    };
});
