/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* suitelet_gerir_compras.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/url", "N/search", "N/log", "N/record"], function (require, exports, UI, url_1, search_1, log_1, record_1, serverWidget) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    url_1 = __importDefault(url_1);
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    var onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var ITEM_TYPE_1 = {
                'Assembly': 'assemblyitem',
                'Description': 'descriptionitem',
                'Discount': 'discountitem',
                'GiftCert': 'giftcertificateitem',
                'InvtPart': 'inventoryitem',
                'Group': 'itemgroup',
                'Kit': 'kititem',
                'Markup': 'markupitem',
                'NonInvtPart': 'noninventoryitem',
                'OthCharge': 'otherchargeitem',
                'Payment': 'paymentitem',
                'Service': 'serviceitem',
                'Subtotal': 'subtotalitem'
            };
            var parameters = ctx.request.parameters;
            var items = JSON.parse(parameters.items);
            log_1.default.error("parameters no page", parameters);
            var form = UI.createForm({
                title: "Histórico de Preços"
            });
            form.clientScriptModulePath = "./ClientScripts.js";
            var sublist_1 = form.addSublist({
                id: 'custpage_lrc_historico_de_precos',
                label: 'Histórico de Preços',
                type: UI.SublistType.LIST,
            });
            sublist_1.addField({
                id: 'custpage_lrc_item',
                type: UI.FieldType.TEXT,
                label: 'Item',
            });
            sublist_1.addField({
                id: 'custpage_lrc_pedido_de_compra',
                type: UI.FieldType.TEXT,
                label: 'Pedido de Compra',
            });
            sublist_1.addField({
                id: 'custpage_rsc_fornecedor',
                label: 'Fornecedor',
                type: UI.FieldType.TEXT,
            });
            sublist_1.addField({
                id: 'custpage_lrc_data',
                type: UI.FieldType.TEXT,
                label: 'Data',
            });
            sublist_1.addField({
                id: 'custpage_lrc_taxa',
                type: UI.FieldType.CURRENCY,
                label: 'Taxa',
            });
            sublist_1.addField({
                id: 'custpage_lrc_quantidade',
                type: UI.FieldType.INTEGER,
                label: 'Quantidade',
            });
            sublist_1.addField({
                id: 'custpage_lrc_moeda',
                type: UI.FieldType.TEXT,
                label: 'Moeda',
            });
            var sublistPageField = form.addField({
                id: 'custpage_lrc_pagina',
                type: UI.FieldType.SELECT,
                label: 'Página',
            });
            var defaultPageSize = 10;
            var x_1 = 0;
            var sublistSearchObj = search_1.default.create({
                type: search_1.default.Type.PURCHASE_ORDER,
                filters: [
                    ["item", "anyof", items],
                    'and',
                    ["memorized", "is", "F"],
                    'and',
                    ['mainline', 'is', 'F'],
                ],
                columns: [
                    search_1.default.createColumn({
                        name: "internalid",
                        summary: search_1.default.Summary.GROUP
                    }),
                    search_1.default.createColumn({
                        name: 'item',
                        summary: search_1.default.Summary.GROUP
                    }),
                    search_1.default.createColumn({
                        name: 'trandate',
                        summary: search_1.default.Summary.GROUP,
                        sort: search_1.default.Sort.DESC // odrnando pela ordem decrescente
                    })
                ]
            });
            var sublistPagedData = sublistSearchObj.runPaged({ pageSize: defaultPageSize });
            log_1.default.error("count", sublistPagedData.count);
            var num_pages = Math.ceil(sublistPagedData.count / defaultPageSize);
            log_1.default.error("num_pages", num_pages);
            for (var i = 1; i <= num_pages; i++) {
                sublistPageField.addSelectOption({
                    value: i.toString(),

                    text: i.toString(),
                });
            }
            var page = parameters.page;
            if (!page) {
                page = 1;
            }
            sublistPageField.defaultValue = page;
            if (num_pages != 0) {
                // Iterar sobre a sublista atraves da busca
                sublistPagedData.fetch({
                    index: (page - 1)
                }).data.forEach(function (result) {
                    log_1.default.error("result", result);
                    var internalId = result.getValue({
                        "name": "internalid",
                        "summary": search_1.default.Summary.GROUP
                    });
                    var itemId = result.getValue({
                        "name": "item",
                        "summary": search_1.default.Summary.GROUP
                    });
                    log_1.default.error("itemId", itemId);
                    log_1.default.error("internalid", internalId);
                    var textoItem = search_1.default.lookupFields({
                        type: 'item',
                        id: itemId,
                        columns: [
                            'itemid',
                            'type'
                        ]
                    });
                    log_1.default.error("textoItem", textoItem);
                    var recordTypeItem = ITEM_TYPE_1[textoItem.type[0].value];
                    log_1.default.error("recordtypeitem", recordTypeItem);
                    var url = url_1.default.resolveRecord({
                        recordType: recordTypeItem,
                        recordId: itemId,
                        isEditMode: false
                    });
                    log_1.default.error("url", url);
                    sublist_1.setSublistValue({
                        id: "custpage_lrc_item",
                        line: x_1,
                        value: "<a href = " + url + "> " + textoItem.itemid + "</a>" // fazer o mesmo com o Pedido de Compra
                    });
                    var purchOrderLookup = search_1.default.lookupFields({
                        type: search_1.default.Type.PURCHASE_ORDER,
                        id: internalId,
                        columns: [
                            'tranid'
                        ]
                    });
                    log_1.default.error("purchorderlookup", purchOrderLookup);
                    url = url_1.default.resolveRecord({
                        recordType: record_1.default.Type.PURCHASE_ORDER,
                        recordId: internalId
                    });
                    url_fornecedor = url_1.default.resolveRecord({
                        recordType: record_1.default.Type.VENDOR,
                    })
                    sublist_1.setSublistValue({
                        id: 'custpage_lrc_pedido_de_compra',
                        line: x_1,
                        value: "<a href = " + url + "> " + purchOrderLookup.tranid + "</a>"
                    });
                    var pedidoCompra = record_1.default.load({
                        type: record_1.default.Type.PURCHASE_ORDER,
                        id: internalId
                    });
                    var qtLinhas = pedidoCompra.getLineCount({
                        sublistId: 'item'
                    });
                    var Data = pedidoCompra.getText({
                        fieldId: 'trandate'
                    });
                    var Moeda = pedidoCompra.getText({
                        fieldId: 'currency'
                    });                   
                    var Fornecedor = pedidoCompra.getText({
                        fieldId: 'entity'
                    });
                    var FornecedorId = pedidoCompra.getValue({
                        fieldId: 'entity'
                    });
                    url_fornecedor = url_1.default.resolveRecord({
                        recordType: record_1.default.Type.VENDOR,
                        recordId: FornecedorId
                    });
                    sublist_1.setSublistValue({
                        id: 'custpage_rsc_fornecedor',
                        line: x_1,
                        value: "<a href = " + url_fornecedor + "> " + Fornecedor + "</a>"
                    })
                    for (var i_1 = 0; i_1 < qtLinhas; i_1++) {
                        var itemline = pedidoCompra.getSublistValue({
                            sublistId: 'item',
                            fieldId: 'item',
                            line: i_1
                        });
                        if (itemId == itemline) {
                            var Taxa = pedidoCompra.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'rate',
                                line: i_1
                            });
                            var Quantidade = pedidoCompra.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: i_1
                            });
                            sublist_1.setSublistValue({
                                id: 'custpage_lrc_taxa',
                                line: x_1,
                                value: Taxa
                            });
                            sublist_1.setSublistValue({
                                id: 'custpage_lrc_quantidade',
                                line: x_1,
                                value: Number(Quantidade).toFixed()
                            });
                        }
                    }
                    sublist_1.setSublistValue({
                        id: 'custpage_lrc_data',
                        line: x_1,
                        value: Data
                    });
                    sublist_1.setSublistValue({
                        id: 'custpage_lrc_moeda',
                        line: x_1,
                        value: Moeda
                    });
                    x_1++;
                    return true;
                });
            }
            ctx.response.writePage(form);
        }
    };
    exports.onRequest = onRequest;
});
