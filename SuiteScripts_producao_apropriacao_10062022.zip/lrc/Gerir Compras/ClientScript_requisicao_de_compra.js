/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/query'],

    function(query) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {

        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {
            var currRecord = scriptContext.currentRecord;
            var fieldId = scriptContext.fieldId;
            var sublistId = scriptContext.sublistId;
            if (sublistId == "item" && fieldId == "item"){


                var item = currRecord.getCurrentSublistValue({
                    fieldId: 'item',
                    sublistId: 'item',
                });
                log.audit({title: 'Item', details: item});
                if (item > 0){


                    var queryResults
                    queryResults = query.runSuiteQL(
                        {
                            query: 'select a.id,  a.trandate, a.entity, b.rate, b.item, b. linesequencenumber from transaction a\n' +
                                'join transactionline b on a.id = b.transaction\n' +
                                'where\n' +
                                '\ttype in (\'PurchOrd\')\n' +
                                'and \n' +
                                '\tmainline = \'F\'\n' +
                                'and item = ? \n' +
                                'order by trandate desc' ,
                            params: [item]
                        }
                    );

                    var records = queryResults.asMappedResults();
                    log.audit({title:'Registros selecionados', details: records.length});
                    if ( records.length > 0 ) {
                        var record = records[0];
                        log.audit({title:'Entidade', details: record['entity']});
                        log.audit({title: 'Rate', details: record['rate'] })
                        currRecord.setCurrentSublistValue({
                            fieldId: 'custpage_lrc_ultimo_fornecedor',
                            sublistId: 'item',
                            value: record['entity']
                        });
                        currRecord.setCurrentSublistValue({
                            fieldId: 'custpage_lrc_ultimo_preco',
                            sublistId: 'item',
                            value: record['rate']
                        });
                    }
                }
            }
        }

        /**
         * Function to be executed when field is slaved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         *
         * @since 2015.2
         */
        function postSourcing(scriptContext) {

        }

        /**
         * Function to be executed after sublist is inserted, removed, or edited.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function sublistChanged(scriptContext) {

        }

        /**
         * Function to be executed after line is selected.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function lineInit(scriptContext) {

        }

        /**
         * Validation function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @returns {boolean} Return true if field is valid
         *
         * @since 2015.2
         */
        function validateField(scriptContext) {
            var currRecord = scriptContext.currentRecord;

            var fieldId = scriptContext.fieldId;

            var sublistId = scriptContext.sublistId;

            if (sublistId == "item" && fieldId == "custpage_lrc_checkbox") {
                var currCheckBoxValue = currRecord.getCurrentSublistValue({
                    fieldId: 'custpage_lrc_checkbox',
                    sublistId: 'item'
                });
                if (currCheckBoxValue) {
                    var currentLineIndex = currRecord.getCurrentSublistIndex({ sublistId: 'item' });
                    var num_lines = currRecord.getLineCount({ sublistId: "item" });
                    for (var line = 0; line < num_lines; line++) {
                        if (line != currentLineIndex) {
                            var checkBoxValueLine = currRecord.getSublistValue({
                                sublistId: "item",
                                fieldId: "custpage_lrc_checkbox",
                                line: line
                            });
                            if (checkBoxValueLine == currCheckBoxValue) {
                                alert("É possível selecionar apenas um item para a visualização de histórico de preço!");
                                return false;
                            }
                        }
                    }
                }
            }
            return true;
        }

        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateLine(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is inserted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateInsert(scriptContext) {

        }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {

        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
        function saveRecord(scriptContext) {

        }

        return {
            // pageInit: pageInit,
            fieldChanged: fieldChanged,
            // postSourcing: postSourcing,
            // sublistChanged: sublistChanged,
            // lineInit: lineInit,
            validateField: validateField,
            // validateLine: validateLine,
            // validateInsert: validateInsert,
            // validateDelete: validateDelete,
            // saveRecord: saveRecord
        };

    });
