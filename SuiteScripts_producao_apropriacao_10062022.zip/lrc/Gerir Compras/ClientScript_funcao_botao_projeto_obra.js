/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/url", "N/currentRecord"], function (require, exports, url_1, currentRecord_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.redirecionarProjetoObra = exports.pageInit = void 0;
    url_1 = __importDefault(url_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var redirecionarProjetoObra = function () {
        var record = currentRecord_1.default.get();
        var redirecionar = url_1.default.resolveRecord({
            recordType: 'purchaserequisition',
            isEditMode: false,
            params: {
                projetoObra: record.id,
            }
        });
        window.location.replace(redirecionar);
    };
    exports.redirecionarProjetoObra = redirecionarProjetoObra;
});
