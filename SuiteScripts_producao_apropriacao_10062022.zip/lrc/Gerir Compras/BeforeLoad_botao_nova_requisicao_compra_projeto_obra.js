/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* UserEvent_processoDistrato.js
*
*
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/record", "N/ui/serverWidget", "N/search"], function (require, exports, log_1, record_1, UI, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    UI = __importStar(UI);
    search_1 = __importDefault(search_1);
    var beforeLoad = function (ctx) {
        var form = ctx.form;
        var newRecord = ctx.newRecord;
        var modelo = newRecord.getValue('custentity_rsc_id_modelo_projeto');
        log_1.default.error('modelo', modelo);
        if (ctx.type == ctx.UserEventType.VIEW) {
            // form.addButton({
            //     label: 'Criar Requisição',
            //     id: 'custpage_criar_requisicao',
            //     functionName: 'criarRequisicao'
            // });
        }
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.XEDIT || ctx.type == ctx.UserEventType.VIEW || ctx.type == ctx.UserEventType.EDIT) {
            // form.addTab({
            //     id: 'custpage_lrc_requisicao',
            //     label: 'Modelos de Requisição'
            // });
            // form.addSublist({
            //     id: 'custpage_lrc_sublista_requisicao',
            //     label: 'Lista de Modelos',
            //     type: UI.SublistType.INLINEEDITOR,
            //     tab: 'custpage_lrc_requisicao'
            // });
            ctx.form.addButton({
                id: 'custpage_btn_criar_req',
                label: 'Criar Modelo de Requisição',
                functionName: 'abrirInterfaceCriacaoModeloRequisicao',
            });
            form.clientScriptModulePath = "./clientScript_botao_modelo.js";
            // var sublist_1 = form.getSublist({
            //     id: 'custpage_lrc_sublista_requisicao'
            // });
            // sublist_1.addField({
            //     id: 'custpage_id_interna',
            //     label: 'ID Interna',
            //     type: UI.FieldType.TEXT
            // }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            // sublist_1.addField({
            //     id: 'custpage_data',
            //     label: 'Data',
            //     type: UI.FieldType.DATE,
            // });
            // sublist_1.addField({
            //     id: 'custpage_data_entrega',
            //     label: 'Data entrega',
            //     type: UI.FieldType.DATE,
            // });
            // sublist_1.addField({
            //     id: 'custpage_tipo',
            //     label: 'Tipo',
            //     type: UI.FieldType.TEXT,
            // });
            // sublist_1.addField({
            //     id: 'custpage_tarefa_relacionada',
            //     label: 'Tarefa relacionada',
            //     type: UI.FieldType.SELECT,
            //     source: 'projecttask'
            // });
            // sublist_1.addField({
            //     id: 'custpage_item',
            //     label: 'Item',
            //     type: UI.FieldType.SELECT,
            //     source: 'noninventoryitem'
            // });
            // sublist_1.addField({
            //     id: 'custpage_quantidade',
            //     label: 'Quantidade',
            //     type: UI.FieldType.FLOAT,
            // });
            // sublist_1.addField({
            //     id: 'custpage_valor',
            //     label: 'Valor Estimado',
            //     type: UI.FieldType.CURRENCY,
            // }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            // sublist_1.addField({
            //     id: 'custpage_num_document',
            //     label: 'Número Documento',
            //     type: UI.FieldType.SELECT,
            //     source: 'purchaserequisition'
            // });
            // // sublist.addField({
            // //     id: 'custpage_fornecedor',
            // //     label: 'Fornecedor',
            // //     type: UI.FieldType.SELECT,
            // //     source: 'vendor'
            // // });
            // sublist_1.addField({
            //     id: 'custpage_unidades',
            //     label: 'Unidades',
            //     type: UI.FieldType.SELECT,
            //     source: 'unitstype'
            // });
            // sublist_1.addField({
            //     id: 'custpage_descricao',
            //     label: 'Descrição',
            //     type: UI.FieldType.TEXTAREA,
            // });
            // sublist_1.addField({
            //     id: 'custpage_taxa_estimada',
            //     label: 'Taxa Estimada',
            //     type: UI.FieldType.FLOAT,
            // });
            // sublist_1.addField({
            //     id: 'custpage_param_requi',
            //     label: 'Parametro de requisição',
            //     type: UI.FieldType.SELECT,
            //     source: 'customrecord_lrc_param_req_mod_projeto'
            // }).updateDisplayType({
            //     displayType: UI.FieldDisplayType.HIDDEN
            // });
            // // sublist.addField({
            // //     id:'custpage_transformar',
            // //     label: 'Transformar em requisição',
            // //     type: UI.FieldType.CHECKBOX
            // // })
            // var lineCount_1 = 0;
            // if (ctx.type == ctx.UserEventType.VIEW || ctx.type == ctx.UserEventType.EDIT) {
            //     search_1.default.create({
            //         type: 'customrecord_lrc_param_req_mod_projeto',
            //         filters: [
            //             ['custrecord_lrc_mod_proj', 'IS', ctx.newRecord.id],
            //             'AND',
            //             ['custrecord_lrc_processado_modelo', 'IS', 'F'],
            //             'AND',
            //             ['custrecord_lrc_criar_requi', 'IS', 'F']
            //         ],
            //         columns: [
            //             'custrecord_lrc_mod_proj_subsidiaria',
            //             'custrecord_lrc_mod_proj_solicitante',
            //             'custrecord_lrc_mod_proj_data',
            //             'custrecord_lrc_mod_proj',
            //             'custrecord_lrc_mod_proj_data_entrega',
            //             'custrecord_lrc_taf_proj_relacionada',
            //             'custrecord_lrc_sublist_itens_data',
            //             'custrecord_lrc_num_document',
            //             'custrecord_lrc_mod_proj_data_entrega'
            //         ]
            //     }).run().each(function (paramReq) {
            //         search_1.default.create({
            //             type: 'customrecord_lrc_sublista_parametros',
            //             filters: [
            //                 ['custrecord_lrc_parametros_sub', 'IS', paramReq.id]
            //             ],
            //             columns: [
            //                 'custrecord_lrc_itens',
            //                 'custrecord_lrc_quantidade',
            //                 'custrecord_lrc_unidades',
            //                 'custrecord_lrc_descricao2',
            //                 'custrecord_lrc_taxaesti',
            //                 'custrecord_lrc_valoresti',
            //             ]
            //         }).run().each(function (item) {
            //             if (paramReq.getValue('custrecord_lrc_taf_proj_relacionada')) {
            //                 sublist_1.setSublistValue({
            //                     id: 'custpage_tarefa_relacionada',
            //                     line: lineCount_1,
            //                     value: String(paramReq.getValue('custrecord_lrc_taf_proj_relacionada'))
            //                 });
            //             }
            //             sublist_1.setSublistValue({
            //                 id: 'custpage_id_interna',
            //                 line: lineCount_1,
            //                 value: paramReq.id
            //             });
            //             sublist_1.setSublistValue({
            //                 line: lineCount_1,
            //                 id: 'custpage_tipo',
            //                 value: 'Requisição'
            //             });
            //             sublist_1.setSublistValue({
            //                 line: lineCount_1,
            //                 id: 'custpage_param_requi',
            //                 value: paramReq.id
            //             });
            //             if (paramReq.getValue('custrecord_lrc_mod_proj_data')) {
            //                 sublist_1.setSublistValue({
            //                     id: 'custpage_data',
            //                     line: lineCount_1,
            //                     value: String(paramReq.getValue('custrecord_lrc_mod_proj_data'))
            //                 });
            //             }
            //             if (paramReq.getValue('custrecord_lrc_mod_proj_data_entrega')) {
            //                 sublist_1.setSublistValue({
            //                     id: 'custpage_data_entrega',
            //                     line: lineCount_1,
            //                     value: String(paramReq.getValue('custrecord_lrc_mod_proj_data_entrega'))
            //                 });
            //             }
            //             // Log.error('item atual for', item[i])
            //             sublist_1.setSublistValue({
            //                 line: lineCount_1,
            //                 id: 'custpage_item',
            //                 value: item.getValue('custrecord_lrc_itens')
            //             });
            //             // Log.error('parsedTaxa', item[i].taxaEstimada)
            //             sublist_1.setSublistValue({
            //                 line: lineCount_1,
            //                 id: 'custpage_quantidade',
            //                 value: String(item.getValue('custrecord_lrc_quantidade')).split(',').join('.') || ""
            //             });
            //             sublist_1.setSublistValue({
            //                 line: lineCount_1,
            //                 id: 'custpage_valor',
            //                 value: String(item.getValue('custrecord_lrc_valoresti')).split(',').join('.') || ""
            //             });
            //             log_1.default.error('unidades', item.getValue('custrecord_lrc_unidades'));
            //             if (item.getValue('custrecord_lrc_unidades')) {
            //                 sublist_1.setSublistValue({
            //                     id: 'custpage_unidades',
            //                     line: lineCount_1,
            //                     value: String(item.getValue('custrecord_lrc_unidades')) || ""
            //                 });
            //             }
            //             if (item.getValue('custrecord_lrc_descricao2')) {
            //                 sublist_1.setSublistValue({
            //                     id: 'custpage_descricao',
            //                     line: lineCount_1,
            //                     value: String(item.getValue('custrecord_lrc_descricao2')) || ""
            //                 });
            //             }
            //             sublist_1.setSublistValue({
            //                 id: 'custpage_taxa_estimada',
            //                 line: lineCount_1,
            //                 value: String(item.getValue('custrecord_lrc_taxaesti')).split(',').join('.') || ""
            //             });
            //             if (paramReq.getValue('custrecord_lrc_num_document')) {
            //                 sublist_1.setSublistValue({
            //                     line: lineCount_1,
            //                     id: 'custpage_num_document',
            //                     value: String(paramReq.getValue('custrecord_lrc_num_document')) || ""
            //                 });
            //             }
            //             lineCount_1++;
            //             return true;
            //         });
            //         return true;
            //     });
            // }
            // sublist.addButton({
            //    label: 'Nova Requisição de Compra',
            //    id: 'custpage_lrc_botao_requisicao_de_compra',
            //    functionName: 'redirecionarProjetoObra'
            // });
        }
    };
    exports.beforeLoad = beforeLoad;
    var afterSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var linhas = newRecord.getLineCount({ sublistId: 'custpage_lrc_sublista_requisicao' });
        var objInicial = {};
        var statusPrice = newRecord.getValue('custentity27');
        if (statusPrice != "Em andamento") {
            for (var i = 0; i < linhas; i++) {
                var parametroModelo = newRecord.getSublistValue({
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    fieldId: 'custpage_param_requi',
                    line: i
                });
                var data = newRecord.getSublistValue({
                    fieldId: 'custpage_data',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                data = data.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                var date = new Date(data);
                var dataEntrega = newRecord.getSublistValue({
                    fieldId: 'custpage_data_entrega',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                dataEntrega = dataEntrega.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                dataEntrega = new Date(dataEntrega);
                var tarefa = newRecord.getSublistValue({
                    fieldId: 'custpage_tarefa_relacionada',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                var item = newRecord.getSublistValue({
                    fieldId: 'custpage_item',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                var quantidade = newRecord.getSublistValue({
                    fieldId: 'custpage_quantidade',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                var valor = newRecord.getSublistValue({
                    fieldId: 'custpage_valor',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                var numero = newRecord.getSublistValue({
                    fieldId: 'custpage_num_document',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                var taxa = newRecord.getSublistValue({
                    fieldId: 'custpage_taxa_estimada',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                var fornecedor = newRecord.getSublistValue({
                    fieldId: 'custpage_fornecedor',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                var descricao = newRecord.getSublistValue({
                    fieldId: 'custpage_descricao',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                var unidades = newRecord.getSublistValue({
                    fieldId: 'custpage_unidades',
                    sublistId: 'custpage_lrc_sublista_requisicao',
                    line: i
                });
                var objSublista = {};
                objSublista['dataEntrega'] = dataEntrega || "";
                objSublista['data'] = date || "";
                objSublista['tarefa'] = tarefa || "";
                objSublista['numeroDoc'] = numero || "";
                objSublista['item'] = item || "";
                objSublista['quantidade'] = quantidade || "";
                objSublista['fornecedor'] = fornecedor || "";
                objSublista['unidades'] = unidades || "";
                objSublista['descricao'] = descricao || "";
                objSublista['taxaEstimada'] = taxa || "";
                objSublista['valorEstimado'] = valor || "";
                var arrayObjInicial = objInicial[parametroModelo.toString()];
                log_1.default.error('objSublista', objSublista);
                if (arrayObjInicial) {
                    arrayObjInicial.push(objSublista);
                }
                else {
                    objInicial[parametroModelo.toString()] = [objSublista];
                }
            }
            Object.keys(objInicial).forEach(function (key) {
                var array = objInicial[key];
                var parametroRecord = record_1.default.load({
                    id: key,
                    type: 'customrecord_lrc_param_req_mod_projeto'
                });
                parametroRecord.setValue({
                    fieldId: 'custrecord_lrc_mod_proj_data',
                    value: array[0].data
                });
                parametroRecord.setValue({
                    fieldId: 'custrecord_lrc_mod_proj_data_entrega',
                    value: array[0].dataEntrega
                });
                parametroRecord.setValue({
                    fieldId: 'custrecord_lrc_taf_proj_relacionada',
                    value: array[0].tarefa
                });
                parametroRecord.setValue({
                    fieldId: 'custrecord_lrc_num_document',
                    value: array[0].numeroDoc
                });
                var arrayDadosItens = [];
                // Log.error('array lenght', array.length)
                var i = 0;
                search_1.default.create({
                    type: 'customrecord_lrc_sublista_parametros',
                    filters: [
                        ['custrecord_lrc_parametros_sub', 'IS', key]
                    ]
                }).run().each(function (sublista) {
                    var objDadosItens = {};
                    var recordSublista = record_1.default.load({
                        type: 'customrecord_lrc_sublista_parametros',
                        id: sublista.id
                    });
                    recordSublista.setValue({
                        fieldId: 'custrecord_lrc_itens',
                        value: array[i].item
                    });
                    recordSublista.setValue({
                        fieldId: 'custrecord_lrc_quantidade',
                        value: array[i].quantidade
                    });
                    recordSublista.setValue({
                        fieldId: 'custrecord_lrc_unidades',
                        value: array[i].unidades
                    });
                    recordSublista.setValue({
                        fieldId: 'custrecord_lrc_descricao2',
                        value: array[i].descricao
                    });
                    recordSublista.setValue({
                        fieldId: 'custrecord_lrc_taxaesti',
                        value: array[i].taxaEstimada
                    });
                    recordSublista.setValue({
                        fieldId: 'custrecord_lrc_valoresti',
                        value: array[i].valorEstimado
                    });
                    recordSublista.save({
                        ignoreMandatoryFields: true
                    });
                    i++;
                    return true;
                });
                parametroRecord.save({
                    ignoreMandatoryFields: true
                });
            });
            log_1.default.error('teste', 'done');
        }
    };
    exports.afterSubmit = afterSubmit;
});
