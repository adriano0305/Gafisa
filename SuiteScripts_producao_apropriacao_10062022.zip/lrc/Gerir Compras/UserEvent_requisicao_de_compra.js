/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* userevent_gerir_compras.ts
* 
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget"], function (require, exports, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    UI = __importStar(UI);
    var beforeLoad = function (ctx) {
        var form = ctx.form;
        form.clientScriptModulePath = "./ClientScript_funcao_botao.js";
        var sublist = form.getSublist({
            id: 'item'
        });
        log.debug('sublista', sublist);
        
        sublist.addButton({
            id: 'custpage_lrc_botao_historico_preco',
            label: 'Exibir Histórico de Preço',
            functionName: 'exibirHistoricoDePreco'
        });
        sublist.addField({
            type: UI.FieldType.CHECKBOX,
            id: 'custpage_lrc_checkbox',
            label: 'Histórico de Preço'
        });
    };
    exports.beforeLoad = beforeLoad;
});
