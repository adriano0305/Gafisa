/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
 var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/url", "N/currentRecord", "N/record"], function (require, exports, url_1, currentRecord_1, record) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.redirecionarTarefaDeProjetoEtapa = exports.pageInit = void 0;
    url_1 = __importDefault(url_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var redirecionarTarefaDeProjetoEtapa = function () {
        var rec = currentRecord_1.default.get();
        console.log('rec : ', rec);

        var get_rec = record.load({
            type: 'projecttask',
            id: rec.id
        });
        console.log('get_rec : ', get_rec);

        var etapaProjeto = get_rec.getValue({
            fieldId: 'custevent_rsc_etapa_projeto'
        });
        console.log('etapaProjeto : ', etapaProjeto);

        var projetoObra = rec.getValue({
            fieldId: 'company'
        });
        console.log('projetoObra : ', projetoObra);

        var redirecionar = url_1.default.resolveRecord({
            recordType: 'purchaserequisition',
            isEditMode: false,
            params: {
                projetoObra: projetoObra,
                etapaProjeto: etapaProjeto,
                faseDeProjeto: rec.id
            }
        });
        window.open(redirecionar);
    };
    exports.redirecionarTarefaDeProjetoEtapa = redirecionarTarefaDeProjetoEtapa;
});
