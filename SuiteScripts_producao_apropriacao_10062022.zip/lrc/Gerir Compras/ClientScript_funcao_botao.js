/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/url", "N/currentRecord"], function (require, exports, url_1, currentRecord_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.exibirHistoricoDePreco = exports.pageInit = void 0;
    url_1 = __importDefault(url_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var exibirHistoricoDePreco = function () {
        var currRecord = currentRecord_1.default.get();
        var array = [];
        var linhaSublista = currRecord.getLineCount({
            sublistId: 'item'
        });
        console.log(linhaSublista);
        var currentCheckBox = currRecord.getCurrentSublistValue({
            sublistId: 'item',
            fieldId: 'custpage_lrc_checkbox'
        });
        if (currentCheckBox == true) {
            var item = currRecord.getCurrentSublistValue({
                sublistId: 'item',
                fieldId: 'item',
            });
            array.push(item);
        }
        for (var i = 0; i < linhaSublista; i++) {
            var checkBox = currRecord.getSublistValue({
                sublistId: 'item',
                fieldId: 'custpage_lrc_checkbox',
                line: i
            });
            if (checkBox == true && currRecord.getCurrentSublistIndex({ sublistId: 'item' }) != i) {
                var item = currRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'item',
                    line: i
                });
                array.push(item);
            }
        }
        if (array.length == 0) {
            alert('Não foi selecionado nenhum item');
            return;
        }
        var redirecionar = url_1.default.resolveScript({
            scriptId: 'customscript_lrc_tela_historico_preco',
            deploymentId: 'customdeploy_lrc_tela_historico_preco',
            params: {
                page: 1,
                items: JSON.stringify(array)
            },
            
        });
        window.open(redirecionar);
    };
    exports.exibirHistoricoDePreco = exibirHistoricoDePreco;
});
