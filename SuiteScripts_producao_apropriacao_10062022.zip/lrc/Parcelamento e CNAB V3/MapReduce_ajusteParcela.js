/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* Script responsável por realizar a consolidação das atualizações das parcelas parametrizadas em registro
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log", "N/record"], function (require, exports, search_1, log_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    var getInputData = function () {
        return search_1.default.create({
            type: 'customrecord_lrc_agend_ajuste_parcela',
            columns: [
                'custrecord_lrc_agend_data_pag',
                'custrecord_lrc_agend_parc_att',
                'custrecord_lrc_agend_conta_pag',
                'custrecord_lrc_agend_status_parcela',
                'custrecord_lrc_agend_met_pagamento'
            ]
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var req = JSON.parse(ctx.value);
        log_1.default.debug('json', req);
        var agendAjusteParcelaId = req.id;
        var agendAjusteParcela = req.values;
        var dataPagamento = agendAjusteParcela.custrecord_lrc_agend_data_pag;
        log_1.default.debug('data', dataPagamento);
        var statusParcela = agendAjusteParcela.custrecord_lrc_agend_status_parcela.value;
        log_1.default.debug('status', statusParcela);
        var metodoPagamento = agendAjusteParcela.custrecord_lrc_agend_met_pagamento.value;
        log_1.default.debug('metodo', metodoPagamento);
        var contaPagamento = agendAjusteParcela.custrecord_lrc_agend_conta_pag.value;
        log_1.default.debug('conta', contaPagamento);
        var parcelasSeremAtualizadas = JSON.parse(agendAjusteParcela.custrecord_lrc_agend_parc_att);
        log_1.default.debug('parcelasSeremAtualizadas', parcelasSeremAtualizadas);
        dataPagamento = dataPagamento.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
        dataPagamento = new Date(dataPagamento);
        parcelasSeremAtualizadas.forEach(function (idParcela) {
            log_1.default.debug('idParcela', idParcela);
            try {
                var parcelaRecord = record_1.default.load({
                    type: 'invoice',
                    id: idParcela
                });
                parcelaRecord.setValue({
                    fieldId: 'trandate',
                    value: dataPagamento
                });
                parcelaRecord.setValue({
                    fieldId: 'approvalstatus',
                    value: statusParcela
                });
                parcelaRecord.setValue({
                    fieldId: 'custbody_lrc_inv_parc_metd_pag',
                    value: metodoPagamento
                });
                parcelaRecord.setValue({
                    fieldId: 'custbody_lrc_inv_parc_conta_prev_pag',
                    value: contaPagamento
                });
                log_1.default.debug('idParcela', idParcela);
                parcelaRecord.save({
                    ignoreMandatoryFields: true
                });
            }
            catch (error) {
                log_1.default.error('update Parcela error', error);
            }
        });
        record_1.default.delete({
            type: 'customrecord_lrc_agend_ajuste_parcela',
            id: agendAjusteParcelaId
        });
    };
    exports.map = map;
});
