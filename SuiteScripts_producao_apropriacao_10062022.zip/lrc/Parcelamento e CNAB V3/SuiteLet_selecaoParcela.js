/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_ajusteParcela.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget", "./utils/formFunctions"], function (require, exports, UI, FormFunctions) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    FormFunctions = __importStar(FormFunctions);
    var onRequest = function (ctx) {
        var params = ctx.request.parameters;
        var vendorBills = [];
        if (params.hasOwnProperty('vendorbills'))
            vendorBills = JSON.parse(params.vendorbills);
        if (ctx.request.method == 'GET') {
            var form = UI.createForm({
                title: 'Seleção das parcelas'
            });
            // Field para armazenar dados do parâmetro da requisição
            form.addField({
                id: 'custpage_campo_array_ids',
                label: 'Parcelas Ids',
                type: UI.FieldType.LONGTEXT
            }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = JSON.stringify(vendorBills);
            // Botões
            form.addButton({
                id: 'custpage_btn_buscar',
                label: 'Buscar',
                functionName: 'buscarParcelas'
            });
            form.addButton({
                id: 'custpage_btn_att_em_massa',
                label: 'Atualizar em massa',
                functionName: 'atualizarEmMassa'
            });
            // FieldGroups
            var fieldGroupFilters = form.addFieldGroup({
                id: 'custpage_fieldgroup_filtros',
                label: 'Filtros de Busca',
            });
            fieldGroupFilters.isCollapsible = true;
            form = FormFunctions.createParcelasSublist(form);
            form = FormFunctions.createFieldsForSearch(form);
            form.clientScriptModulePath = './Clientscript_ajusteParcela.js';
            ctx.response.writePage(form);
        }
        // Interface de ajustes de parcelas
        // else if(ctx.request.method == 'POST' && params.isAjuste == true) { 
        // }
    };
    exports.onRequest = onRequest;
});
