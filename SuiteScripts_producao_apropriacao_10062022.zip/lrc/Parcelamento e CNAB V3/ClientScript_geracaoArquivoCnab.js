/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript_geracaoArquivoCnab.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/search", "N/url", "N/record", "./utils/sublistFunctions", "N/ui/dialog"], function (require, exports, currentRecord_1, search_1, url_1, record_1, SublistFunctions, dialog_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.geracaoArquivoCnab_session3 = exports.geracaoArquivoCnab_session2 = exports.geracaoArquivoCnab_session1 = exports.viewInvoices = exports.createArquivoCnab = exports.removeInvoices = exports.next = exports.searchInvoices = exports.selecionarTudo = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    search_1 = __importDefault(search_1);
    url_1 = __importDefault(url_1);
    record_1 = __importDefault(record_1);
    SublistFunctions = __importStar(SublistFunctions);
    dialog_1 = __importDefault(dialog_1);
    var pageInit = function (ctx) {
        var currentArquivoCnab = ctx.currentRecord;
        var invoices = currentArquivoCnab.getValue('custpage_campo_array_ids');
        var parcelasExec = Boolean(currentArquivoCnab.getValue('custpage_executar'));
        if (invoices) {
            if (parcelasExec) {
                SublistFunctions.setSublistExecutarValues(JSON.parse(JSON.parse(JSON.stringify(invoices))));
            }
            else {
                SublistFunctions.setSublistParcelaValues(JSON.parse(JSON.parse(JSON.stringify(invoices))));
                SublistFunctions.selectAllSublistItens();
            }
        }
    };
    exports.pageInit = pageInit;
    var selecionarTudo = function () {
        SublistFunctions.selectAllSublistItens();
    };
    exports.selecionarTudo = selecionarTudo;
    var searchInvoices = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var preFilters = [
            ['subsidiary', 'IS', 'custpage_campo_subsidiaria'],
            ['location', 'IS', 'custpage_campo_localidade'],
            ['approvalstatus', 'IS', '2'],
            ['custbody_lrc_vendor_prev_pagamento', 'IS', 'custpage_campo_contapgt'],
            ['custbody_lrc_vendor_metodo_pagamento', 'IS', 'custpage_campo_metodopgt'],
            ['startdate', 'ONORAFTER', 'custpage_campo_vencimentode'],
            ['enddate', 'BEFORE', 'custpage_campo_vencimentoate'],
            ['trandate', 'ONORAFTER', 'custpage_campo_pagamentode'],
            ['duedate', 'BEFORE', 'custpage_campo_pagamentoate'],
            ['department', 'IS', 'custpage_campo_departamento'],
            ['class', 'IS', 'custpage_campo_centrodecusto'],
            ['internalid', 'IS', 'custpage_campo_numerodoc'],
            ['entity', 'IS', 'custpage_campo_entidades'], // Entidade (Cliente)
        ];
        var filters = [];
        preFilters.forEach(function (preFilter) {
            var fieldValue = String(currentAjusteParcelaRecord.getValue(preFilter[2]));
            if (fieldValue) {
                var filter = void 0;
                if (preFilter[0] === 'approvalstatus') {
                    filter = [preFilter[0], preFilter[1], preFilter[2]];
                }
                else if (preFilter[1] === 'BEFORE' || preFilter[1] === 'ONORAFTER') {
                    filter = [preFilter[0], preFilter[1], dateToString(new Date(String(fieldValue)))];
                }
                else {
                    filter = [preFilter[0], preFilter[1], fieldValue];
                }
                filters.push(filter);
                filters.push('AND');
            }
        });
        filters.push(['mainline', 'IS', 'T']);
        console.log('filtros', filters);
        var pagedInvoice = search_1.default.create({
            type: 'vendorbill',
            filters: filters,
            columns: [
                'approvalstatus',
                'internalid',
                'entity',
                'total',
                'duedate',
                'enddate',
                'custbody_lrc_vendor_metodo_pagamento',
                'custbody_lrc_vendor_prev_pagamento'
            ]
        }).runPaged({
            pageSize: 50
        });
        var vendorBills = [];
        if (pagedInvoice.pageRanges.length) {
            for (var i = 0; i < pagedInvoice.pageRanges.length; i++) {
                var currentPage = pagedInvoice.fetch({
                    index: i
                });
                currentPage.data.forEach(function (result) {
                    var vendorBill = {
                        internalid: '',
                    };
                    vendorBill.approvalstatus = String(result.getValue('approvalstatus'));
                    vendorBill.internalid = String(result.getValue('internalid'));
                    vendorBill.entity = String(result.getValue('entity'));
                    vendorBill.total = String(result.getValue('total'));
                    vendorBill.duedate = String(result.getValue('duedate'));
                    vendorBill.enddate = String(result.getValue('enddate'));
                    vendorBill.custbodyLrcInvoiceMetPagFatura = String(result.getValue('custbody_lrc_vendor_metodo_pagamento'));
                    vendorBill.custpageCampoContaPgts = String(result.getValue('custbody_lrc_vendor_prev_pagamento'));
                    vendorBill.internalid && vendorBills.push(vendorBill);
                });
            }
            SublistFunctions.setSublistParcelaValues(vendorBills);
        }
        else {
            alert('Nenhum registro encontrado!');
        }
    };
    exports.searchInvoices = searchInvoices;
    var next = function () {
        exports.geracaoArquivoCnab_session2();
    };
    exports.next = next;
    var removeInvoices = function () {
        var currentArquivoCnab = currentRecord_1.default.get();
        var quantidadeItensSublist = currentArquivoCnab.getLineCount({
            sublistId: 'custpage_sublist_parcelas'
        });
        for (var i = 0; i < quantidadeItensSublist; i++) {
            var isParcelaSelecionada = currentArquivoCnab
                .getSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_selecionar',
                line: i
            });
            if (isParcelaSelecionada) {
                currentArquivoCnab
                    .removeLine({
                    sublistId: 'custpage_sublist_parcelas',
                    line: i
                });
            }
        }
    };
    exports.removeInvoices = removeInvoices;
    var createArquivoCnab = function () {
        var currentArquivoCnab = currentRecord_1.default.get();
        var invoices = JSON.parse(String(currentArquivoCnab.getValue({ fieldId: 'custpage_campo_array_ids' })));
        invoices.forEach(function (invoice) {
            try {
                var newProgramacaoRemessa = record_1.default.create({
                    type: 'customrecord_lrc_tabela_prog_remessa',
                });
                if (invoice.duedate) {
                    var dataPagamento = invoice.duedate.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                    newProgramacaoRemessa.setValue({
                        fieldId: 'custrecord_lrc_data_esperada_pagamento',
                        value: new Date(dataPagamento)
                    });
                }
                else {
                    newProgramacaoRemessa.setValue({
                        fieldId: 'custrecord_lrc_data_esperada_pagamento',
                        value: new Date()
                    });
                }
                newProgramacaoRemessa.setValue({
                    fieldId: 'custrecord_lrc_status_arquivo',
                    value: invoice.approvalstatus || ''
                });
                newProgramacaoRemessa.setValue({
                    fieldId: 'custrecord_lrc_metodo_pagamento',
                    value: invoice.custbodyLrcInvoiceMetPagFatura || ''
                });
                newProgramacaoRemessa.setValue({
                    fieldId: 'custrecord_lrc_banco_pagamento',
                    value: invoice.custpageCampoContaPgts || ''
                });
                newProgramacaoRemessa.setValue({
                    fieldId: 'custrecord_lrc_saldo_pago_arquivo',
                    value: invoice.total || ''
                });
                newProgramacaoRemessa.save({ ignoreMandatoryFields: true });
            }
            catch (error) {
                console.log('executar error', error);
            }
            alert('Arquivo gerado com sucesso!');
        });
    };
    exports.createArquivoCnab = createArquivoCnab;
    var viewInvoices = function () {
        // alert('visualizarPagamentos');
        var invoices = SublistFunctions.getSublistParcelaValues();
        var contaPagamento;
        var dataPagamento;
        var stringTabela = '';
        var saldo = 0;
        invoices.forEach(function (invoice) {
            //stringTabela = stringTabela + '<tr> ';
            if (contaPagamento == invoice.custpageCampoContaPgts) {
                if (dataPagamento == invoice.duedate) {
                    saldo += Number(invoice.total);
                }
            }
            else {
                contaPagamento = invoice.custpageCampoContaPgts;
                stringTabela = stringTabela + '<tr><td> ' + contaPagamento + ' </td>';
                dataPagamento = invoice.duedate;
                stringTabela = stringTabela + '<td> ' + dataPagamento + ' </td>';
                saldo += Number(invoice.total);
            }
            stringTabela = stringTabela + '<td> ' + saldo + ' </td><tr>';
        });
        dialog_1.default.create({
            title: 'Visualizar Pagamentos',
            message: '<tr> ' +
                '<th>Conta de pagamento</th>' +
                '<th>Data de pagamento</th>' +
                '<th>Saldo R$</th>' +
                '</tr>' + stringTabela
        });
    };
    exports.viewInvoices = viewInvoices;
    var geracaoArquivoCnab_session1 = function () {
        var invoices = SublistFunctions.getSublistParcelaValues();
        var url = url_1.default.resolveScript({
            deploymentId: 'customdeploy_lrc_sel_parc_arq_cnab',
            scriptId: 'customscript_lrc_sel_parcela_arq_cnab',
            params: {
                invoices: JSON.stringify(invoices)
            }
        });
        window.location.replace(url);
    };
    exports.geracaoArquivoCnab_session1 = geracaoArquivoCnab_session1;
    var geracaoArquivoCnab_session2 = function () {
        var invoices = SublistFunctions.getSublistParcelaValues();
        var url = url_1.default.resolveScript({
            scriptId: "customscript_lrc_gerar_arq_cnab",
            deploymentId: 'customdeploy_lrc_gerar_arq_cnab',
            params: {
                invoices: JSON.stringify(invoices)
            }
        });
        window.location.replace(url);
    };
    exports.geracaoArquivoCnab_session2 = geracaoArquivoCnab_session2;
    var geracaoArquivoCnab_session3 = function () {
        var invoices = SublistFunctions.getSublistParcelaValues();
        //const gerarExec = SublistFunctions.getSublistExecutarValues();
        var url = url_1.default.resolveScript({
            scriptId: "customscript_lrc_exec_arq_cnab",
            deploymentId: 'customdeploy_lrc_exec_arq_cnab',
            params: {
                invoices: JSON.stringify(invoices)
            }
        });
        window.location.replace(url);
    };
    exports.geracaoArquivoCnab_session3 = geracaoArquivoCnab_session3;
    var dateToString = function (date) {
        return date.getDay() + "/" + date.getMonth() + "/" + date.getFullYear();
    };
});
