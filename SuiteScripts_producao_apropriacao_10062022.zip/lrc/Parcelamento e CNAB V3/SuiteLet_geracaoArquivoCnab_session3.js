/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_geracaoArquivoCnab_session3.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget"], function (require, exports, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    var onRequest = function (ctx) {
        //Verifica se a tela já possui uma lista de Invoices
        var invoices = [];
        var params = ctx.request.parameters;
        if (params.hasOwnProperty('invoices'))
            invoices = JSON.parse(params.invoices);
        if (ctx.request.method == 'GET') {
            var form = UI.createForm({
                title: 'Lista de visualização dos pagamentos'
            });
            // Field para armazenar dados do parâmetro da requisição
            form.addField({
                id: 'custpage_campo_array_ids',
                label: 'Parcelas Ids',
                type: UI.FieldType.LONGTEXT
            }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = JSON.stringify(invoices);
            form.addField({
                id: 'custpage_executar',
                label: 'Parcelas Ids',
                type: UI.FieldType.TEXT
            }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = 'true';
            form.addButton({
                id: 'custpage_btn_executar',
                label: 'Executar',
                functionName: 'createArquivoCnab'
            });
            form.addButton({
                id: 'custpage_btn_voltar',
                label: 'Voltar',
                functionName: 'geracaoArquivoCnab_session1'
            });
            var sublistParcelas = form.addSublist({
                id: 'custpage_sublist_parcelas_exec',
                type: UI.SublistType.INLINEEDITOR,
                label: 'Lista de pagamentos'
            });
            sublistParcelas.addField({
                id: 'custpage_campo_conta_pag',
                label: 'Conta',
                type: UI.FieldType.SELECT
            });
            sublistParcelas.addField({
                id: 'custpage_campo_data_pag',
                label: 'Data de pagamento',
                type: UI.FieldType.TEXT,
            });
            sublistParcelas.addField({
                id: 'custpage_campo_saldo',
                label: 'Saldo',
                type: UI.FieldType.TEXT
            });
            form.clientScriptModulePath = './ClientScript_geracaoArquivoCnab.js';
            ctx.response.writePage(form);
        }
        ;
    };
    exports.onRequest = onRequest;
});
