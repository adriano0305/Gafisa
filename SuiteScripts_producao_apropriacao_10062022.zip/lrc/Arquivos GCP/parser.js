define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var Parser = /** @class */ (function () {
        function Parser() {
        }
        /**
         *  Transforma uma string que foi lida de um arquivo .csv em um objeto de ParsedData.
         *
         * @static
         * @param {string} data O que foi lido do arquivo
         * @returns {ParsedData} Objeto criado a partir do que foi lido, ou algum erro que ocorreu no processo.
         * @memberof Parser
         */
        Parser.parseCSV = function (data, delim) {
            var parsed = { headers: [], data: [] }; // Declara o objeto que será retornado no final
            if (data.indexOf("\"") != -1) { // Se o item possuir aspas (atrapalha muito no processo de parsing)
                parsed.error = "Arquivo mal-formatado: faz o uso de aspas."; // Retorna um erro
                return parsed;
            }
            var lines = data.split("\n").map(function (line) {
                return line.split(delim);
            });
            if (lines.length < 2) { // Se o arquivo não tiver no mínimo 2 linhas(cabeçalho e 1 item)
                parsed.error = "Arquivo mal-formatado: não possui a quantidade mínima de 2 linhas."; // Retorna um erro
                return parsed;
            }
            var header = (lines.shift() || []).map(function (col) {
                col = col.toLowerCase().replace(/[^a-zA-Z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u024F#]/g, ""); // Transforma o valor em lowercase e remove tudo que não for letra
                if (["#", "situaçãodaremessa", "datadafatura", "tipodocumento", "codempresa", "lançamento", "referência", "textocabeçalho", "codfornecedor", "valor", "divisão", "condiçãodepagamento", "database", "atribuição", "textoitem", "contadébito", "divisãodébito", "centrodecusto", "idprocesso", "nprocesso", "referência", "autor"].indexOf(col) == -1) { // Se um dos valores não for algum dos cabeçalhos aceitos
                    parsed.error = "Arquivo mal-formatado: possui cabeçalho inválido: " + col; // Coloca um erro no objeto
                }
                return col; // Salva o valor lowercase formatado
            });
            if (parsed.error) { // Se algum erro foi colocado no objeto
                return parsed; // Returna um erro
            }
            // if(header.indexOf("id") == -1 || header.indexOf("status") == -1) {             // Se não houver o cabeçalho serial ou quantidade(obrigatórios)
            //     parsed.error = "Arquivo mal-formatado: não possui colunas obrigatórias(serial e quantidade).";  // Retorna um erro
            //     return parsed;
            // }
            parsed.headers = header; // Salva o cabeçalho no objeto
            lines.forEach(function (line, index) {
                if (line.length == header.length) { // Se possuir exatamente o número de valores quanto o número de cabeçalhos
                    var lineObj_1 = {}; // Cria o objeto da linha
                    line.forEach(function (val, i) {
                        lineObj_1[header[i]] = val; // Associa o valor da linha com o nome da coluna(cabeçalho)
                    });
                    parsed.data.push(lineObj_1); // Salva o objeto da linha na lista do objeto que será retornado
                }
                else if (line.length > 0 && line[0].length > 0) { // Caso contrário, se a linha não for vazia
                    parsed.error = "Arquivo mal-formatado: a linha " + (index + 1) + " possui uma quantidade de colunas incorreta."; // Retorna um erro
                }
            });
            return parsed; // Retorna o objeto no final.
        };
        return Parser;
    }());
    exports.default = Parser;
});
