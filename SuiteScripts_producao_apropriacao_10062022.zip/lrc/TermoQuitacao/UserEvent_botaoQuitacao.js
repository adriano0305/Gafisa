/**
 *@NApiVersion 2.x
*@NScriptType UserEventScript
*
* 
* 
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/runtime"], function (require, exports, search_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    search_1 = __importDefault(search_1);
    runtime_1 = __importDefault(runtime_1);
    var beforeLoad = function (ctx) {
        var user = runtime_1.default.getCurrentUser();
        var employeeLookup = search_1.default.lookupFields({
            type: 'employee',
            id: user.id,
            columns: ['custentity_rsc_termo_quit']
        });
        if (employeeLookup.custentity_rsc_termo_quit) {
            var form = ctx.form;
            var newRecord = ctx.newRecord;
            var status_1 = newRecord.getValue({
                fieldId: 'status'
            });
            if (status_1 == "Pago integralmente") {
                form.addButton({
                    id: "custpage_emitir_termo",
                    label: "Emitir termo de quitação",
                    functionName: "Emitir"
                });
                form.clientScriptModulePath = "./Client_termoQuitacao.js";
            }
        }
    };
    exports.beforeLoad = beforeLoad;
});
