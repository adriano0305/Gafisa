/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* Suitelet para criação dos parâmetros de modelo de requisição
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/search", "N/log"], function (require, exports, record_1, search_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.verificaMes = exports.onRequest = exports.rowTable = exports.headerTable = exports.endTable = exports.parcelasBaixadas = exports.contentResumo = exports.resumoReceita = exports.beginTable = exports.assinatura = exports.declaracao = exports.observacoes = exports.valoresPagos = exports.receitaImobiliaria = exports.termoQuitacao = exports.breakPage = exports.styleInHead = exports.cabecalho = exports.endPage = exports.beginPage = exports.endBody = exports.beginBody = exports.endHtml = exports.beginHtml = void 0;
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    var beginHtml = function () {
        return "\n    <!DOCTYPE html>\n        <html>\n        <head>\n            <meta charset=\"utf-8\">\n            <title></title>\n    ";
    };
    exports.beginHtml = beginHtml;
    var endHtml = function () {
        return "</html>";
    };
    exports.endHtml = endHtml;
    var beginBody = function () {
        return "<body>";
    };
    exports.beginBody = beginBody;
    var endBody = function () {
        return "</body>";
    };
    exports.endBody = endBody;
    var beginPage = function () {
        return "<div class='page'>";
    };
    exports.beginPage = beginPage;
    var endPage = function () {
        return "</div>";
    };
    exports.endPage = endPage;
    var cabecalho = function () {
        return "\n        <div>\n            <div style=\"width: 10%; float: left; margin-left: ;\">\n                <img src=\"https://www.meioemensagem.com.br/wp-content/uploads/2017/05/Gafisa.jpg\" style=\"width: 150px; height: 110px;\">\n            </div>\n            <div style=\"width: 80%;border-bottom: 1px solid #000;display: inline-block; margin-top: 50px; margin-left: 40px;text-align: right;\">\n                <b><span style=\"\">GAFISA SA - SAO PAULO-SP</span></b>\n            </div>\n        </div>\n    ";
    };
    exports.cabecalho = cabecalho;
    var styleInHead = function () {
        return "\n            <style type='text/css'>\n                *{\n                    margin: 0;\n                    padding: 0;\n                }\n                .tabela-parcelas td{\n                    padding-left: 10px;\n                    padding-right: 10px;\n                    width: 120px;\n                    text-align: center;\n                }\n                .pagebreak{\n                \tpage-break-before: always;\n                }\n            </style>\n        </head>\n    ";
    };
    exports.styleInHead = styleInHead;
    var breakPage = function () {
        return "\n        <div class=\"pagebreak\"> </div>\n    ";
    };
    exports.breakPage = breakPage;
    var termoQuitacao = function (Obra, DataEscritura, CPF, Nome, Endereco) {
        return "\n        <div>\n\t\t\t<div style=\"text-align: center;\">\n                <br>\n                <br>\n\t\t\t\t<b><span style=\"font-size: 25px;\">TERMO DE QUITA\u00C7\u00C3O</span></b>\n\t\t\t</div>\n\t\t</div>\n        <div style=\"text-align: justify; margin-left: 150px;width: 400px\">\n            <div>\n                <br>\n                <b><span style=\"font-size: 19px;\">Obra/Bloco: </span></b><span>  " + Obra + "</span>\n            </div>\n            <div>\n                <b><span style=\"font-size: 19px;\">CPF do Promitente Comprador:</span></b><span>  " + CPF + "</span>\n            </div>\n            <div>\n                <b><span style=\"font-size: 19px;\">Promitente Comprador:</span></b><span>  " + Nome + "</span>\n            </div>\n            <div>\n                <b><span style=\"font-size: 19px;\">Endere\u00E7o:</span></b><span>  " + Endereco + "</span>\n            </div>\n            <div>\n                <b><span style=\"font-size: 19px;\">Promitente Vendedor:</span></b><span>  GAFISA SA - SAO PAULO-SP</span>\n            </div>\n            <div>\n                <b><span style=\"font-size: 19px;\">Data da Escritura:</span></b><span>  " + DataEscritura + "</span>\n            </div>\n        </div>\t\n    ";
    };
    exports.termoQuitacao = termoQuitacao;
    var receitaImobiliaria = function () {
        return "\n        <div>\n            <div style=\"text-align: center;\">\n                <br>\n                <br>\n                <b><span style=\"font-size: 25px; border-bottom: 1px solid #000;\">RECEITA IMOBILI\u00C1RIA</span></b>\n            </div>\n        </div>\n        <div>\n            <div style=\"text-align: center;\">\n                <br>\n                <span style=\"\">NADA CONSTA</span>\n            </div>\n        </div>\n    ";
    };
    exports.receitaImobiliaria = receitaImobiliaria;
    var valoresPagos = function () {
        return "\n        <div>\n            <div style=\"text-align: center;\">\n                <br>\n                <br>\n                <b><span style=\"font-size: 25px; border-bottom: 1px solid #000;\">VALORES PAGOS HIST\u00D3RICOS</span></b>\n            </div>\n        </div>\n        <div>\n            <div style=\"text-align: center;\">\n                <br>\n                <span style=\"\">Pre\u00E7o de venda integralmente pago nos termos da(s) escritura(s).</span>\n            </div>\n        </div>\n    ";
    };
    exports.valoresPagos = valoresPagos;
    var observacoes = function () {
        return "\n        <div>\n            <div style=\"text-align: center;\">\n                <br>\n                <br>\n                <b><span style=\"font-size: 25px; border-bottom: 1px solid #000;\">OBSERVA\u00C7\u00D5ES</span></b>\n            </div>\n        </div>\n        <div>\n            <div style=\"text-align: center;\">\n                <br>\n                <span style=\"\">UNIDADE QUITADA</span>\n            </div>\n        </div>\n    ";
    };
    exports.observacoes = observacoes;
    var declaracao = function (date) {
        return "\n        <div>\n            <div style=\"text-align: center;\">\n                <br>\n                <b><span style=\"font-size: 25px; border-bottom: 1px solid #000;\">DECLARA\u00C7\u00C3O DE QUITA\u00C7\u00C3O</span></b>\n            </div>\n        </div>\n        <div>\n            <div style=\"text-align: justify; margin-left: 50px;\">\n                <br>\n                <span style=\" margin-left: 30px;\">Esta empresa, na qualidade de vendedora da unidade acima referida, declara que se encontrada quitado o pre\u00E7o ajustado para a compra e venda, nos termos da respectiva escritura de promessa de venda e compra firmada com o seu promitente comprador, tamb\u00E9m mencionado acima. Esta quita\u00E7\u00E3o refere-se t\u00E3o somente ao pre\u00E7o da venda, n\u00E3o englobando outras obriga\u00E7\u00F5es de pagamento eventualmente decorrentes da citada escritura, tais como: IPTU, contribui\u00E7\u00F5es condominiais, despesas de decora\u00E7\u00E3o, liga\u00E7\u00F5es de servi\u00E7os publicos, eventuais modifica\u00E7\u00F5es e servi\u00E7os extraordin\u00E1rios.</span>\n            </div>\n            <div style= \"text-align: center;\">\n                <br>\n                <br>\n                <span style=\"text-align:center\">S\u00C3O PAULO, " + date + "</span>\n                <br>\n                <span style=\"text-align:center;\">GAFISA SA - SAO PAULO-SP</span>\n                <span>CNPJ: 01.545.826/0001-07</span>\n            </div>\n        </div>\n    ";
    };
    exports.declaracao = declaracao;
    var assinatura = function (assinatura) {
        return "\n        <div style=\"text-align:center;\">\n  <br><br>          <br>\n            <span style=\"\"> </span\t>\n            <div style=\"text-align:center;border-top:1px solid #000;width: 250px; margin-left:220px;\">\n                <b><span style=\"\">"+ assinatura +"</span></b>\n            </div>\n        </div>\n    ";
    };
    exports.assinatura = assinatura;
    var beginTable = function (obra, comprador, endereco, cpf) {
        return "\n        <div>\n                <br>\n                <br>\n                <table style=\"border: 1px solid #000; width: 700px; margin-left: 30px;\" class=\"tabela-parcelas\">\n                    <tr>\n                        <td>\n                            <span>EMPREENDIMENTO: " + obra + "</span><br>\n                            <span>COMPRADOR: " + comprador + "</span><br>\n                            <span>ENDERE\u00C7O: " + endereco + "</span><br>\n                            <span>CPF: " + cpf + "</span><br>\n                        </td>  \n                    </tr>\n    ";
    };
    exports.beginTable = beginTable;
    var resumoReceita = function () {
        return "\n        <tr style=\"background-color:#e5e5e5;\">\n            <td style=\"border: 1px solid #000; text-align: center;\"><b><span>RESUMO RECEITA IMOBILIARIA</span></b></td>\n        </tr>\n    ";
    };
    exports.resumoReceita = resumoReceita;
    var contentResumo = function (valorPago, valorAntecipado, saldoDevedor, dataEscrituracao, DAF, caucao, unidadeHipotecada, ordemVenda) {
        return "\n        <tr>\n            <td style=\"text-align:   left;display: inline-block; width: 200px; margin-right: 500px;\">\n                <span>Total Pago: " + valorPago + "</span><br>\n                <span>Total Antecipado: " + valorAntecipado + "</span><br>\n                <span>Saldo Devedor Corrigido: " + saldoDevedor + "</span><br>\n                <span>Data da Escritura: " + dataEscrituracao + "</span><br>\n            </td>\n            <td style=\"text-align:   left;display: inline-block; width: 200px;\">\n                <span>DAF: " + DAF + "</span><br>\n                <span>Cau\u00E7\u00E3o: " + caucao + "</span><br>\n                <span>Unidade Hipotecada: " + unidadeHipotecada + "</span><br>\n                <span>Ordem de venda: " + ordemVenda + "</span><br>\n            </td>\n        </tr>\n    ";
    };
    exports.contentResumo = contentResumo;
    var parcelasBaixadas = function () {
        return "\n        <tr style=\"background-color:#e5e5e5;\">\n            <td style=\"border: 1px solid #000; text-align: center;\"><b><span>PARCELAS BAIXADAS</span></b></td>\n        </tr>\n    ";
    };
    exports.parcelasBaixadas = parcelasBaixadas;
    var endTable = function () {
        return "\n        </table>\n    ";
    };
    exports.endTable = endTable;
    var headerTable = function () {
        return "\n        <tr style=\"display: flex;justify-content: center; border-bottom: 1px solid #000; text-align: center;\">\n            <td>\n                <b><span>Tipo Parcela</span></b>\n            </td>\n            <td>\n                <b><span>Natureza</span></b>\n            </td>\n            <td>\n                <b><span>\u00CDndice</span></b>\n            </td>\n            <td>\n                <b><span>Valor Parcela</span></b>\n            </td>\n            <td>\n                <b><span>Vencimento</span></b>\n            </td>\n            <td >\n                <b><span>Pagamento</span></b>\n            </td>\n            <td>\n                <b><span>Valor Pago</span></b>\n            </td>\n        </tr>\n    ";
    };
    exports.headerTable = headerTable;
    var rowTable = function (tipoParcela, natureza, indice, valorParcela, vencimento, pagamento, valorPago) {
        return "\n        <tr style=\"display: flex;justify-content: center;\">\n            <td style=\"border-right: 1px solid #000; \">\n                <span>" + tipoParcela + "</span>\n            </td>\n            <td style=\"border-right: 1px solid #000; \">\n                <span>" + natureza + "</span>\n            </td>\n            <td style=\"border-right: 1px solid #000; \">\n                <span>" + indice + "</span>\n            </td>\n            <td style=\"border-right: 1px solid #000; \">\n                <span>" + valorParcela + "</span>\n            </td>\n            <td style=\"border-right: 1px solid #000; \">\n                <span>" + vencimento + "</span>\n            </td>\n            <td style=\"border-right: 1px solid #000;\">\n                <span>" + pagamento + "</span>\n            </td>\n            <td style=\"\">\n                <span>" + valorPago + "</span>\n            </td>\n        </tr>\n    ";
    };
    exports.rowTable = rowTable;
    var onRequest = function (ctx) {
        var parametros = ctx.request.parameters;
        log_1.default.error("parametros", parametros);
        var clienteID = parametros.cliente;
        var obra = parametros.obra;
        var moeda = parametros.moeda;
        var faturaId = parametros.idFatura;
        var data = parametros.data;
        var valor = parametros.valor;
        log_1.default.error('clienteId', clienteID);
        var clienteRecord = record_1.default.load({
            type: 'customer',
            id: clienteID,
        });
        // const emissor = Search.create({
        //     type:'employee',
        //     filters: [
        //         ['custentity_rsc_termo_quit', 'IS', 'T']
        //     ],
        //     columns:[
        //         'firstname',
        //         'lastname'
        //     ]
        // }).run().getRange({
        //     start: 0,
        //     end: 1
        // })
        // const nomeEmissor = emissor[0].getValue('firstname') + " " + emissor[0].getValue('lastname');
        var nomeEmissor = [];
        var searchProcurador = search_1.default.create({
            type: 'customrecord_rsc_procurador',
            filters: [
                ['custrecord_rsc_procurador_atividade', 'IS', 'T'],
            ],
        }).run().each(function (result) {
            var procuradorLookup = search_1.default.lookupFields({
                type: 'customrecord_rsc_procurador',
                id: result.id,
                columns: ['name']
            });
            nomeEmissor.push(procuradorLookup.name);
            return true;
        });
        var endereco = clienteRecord.getText('defaultaddress');
        var nome = "";
        if (clienteRecord.getValue('companyname')) {
            nome = String(clienteRecord.getValue('companyname'));
        }
        else if (clienteRecord.getValue('salutation')) {
            nome = String(clienteRecord.getValue('salutation'));
        }
        else {
            nome = String(clienteRecord.getValue('shipaddressee'));
        }
        var cpf = clienteRecord.getValue('custentity_enl_cnpjcpf');
        var dataAtual = new Date();
        var dia = dataAtual.getDate();
        var mes = exports.verificaMes(dataAtual.getMonth());
        var ano = dataAtual.getFullYear();
        var dataFinal = dia + "/" + mes + "/" + ano;
        log_1.default.error('dataFinal', dataFinal);
        var html = exports.beginHtml();
        html += exports.styleInHead();
        html += exports.beginBody();
        html += exports.beginPage();
        html += exports.cabecalho();
        html += exports.termoQuitacao(obra, String(data), cpf, nome, endereco);
        html += exports.receitaImobiliaria();
        html += exports.valoresPagos();
        html += exports.observacoes();
        html += exports.declaracao(String(dataFinal));
        if (nomeEmissor.length == 1) {
            html += exports.assinatura(String(nomeEmissor[0]));
        }
        else if (nomeEmissor.length == 0) {
            html += exports.assinatura("");
        }
        else {
            for (var i = 0; i < nomeEmissor.length; i++) {
                html += exports.assinatura(String(nomeEmissor[i]));
            }
        }
        html += exports.endPage();
        // html += breakPage();
        // html += beginPage();
        // html += cabecalho();
        // html += beginTable(obra, nome, endereco, cpf);
        // html += resumoReceita();
        // html += parcelasBaixadas();
        // html += headerTable();
        // const InvoiceRecord = Record.load({
        //     type:'invoice',
        //     id: faturaId
        // })
        // const dataPagamento = InvoiceRecord.getSublistText({
        //     sublistId:'links',
        //     fieldId:'trandate',
        //     line: 0
        // })
        // const valorPagamento = InvoiceRecord.getSublistValue({
        //     sublistId:'links',
        //     fieldId:'total',
        //     line: 0
        // })
        // html += rowTable('Mensal', 'ATO DE VENDA', moeda, valor, String(data),dataPagamento, String(valorPagamento))
        // Search.create ({
        //     type: 'customsale_rsc_financiamento',
        //     filters: [
        //         ['custbody_lrc_fatura_principal', 'IS', faturaId],
        //     ]
        // }).run().each((result) =>{
        //     const financiamentoRecord = Record.load({
        //         type:'customsale_rsc_financiamento',
        //         id: result.id
        //     })
        //     const vencimento = financiamentoRecord.getText('duedate');
        //     const valorParcela = financiamentoRecord.getValue('total');
        //     const pagamentoParcela = financiamentoRecord.getSublistValue({
        //         sublistId:'links',
        //         fieldId:'total',
        //         line: 0
        //     })
        //     const dataParcela = financiamentoRecord.getSublistText({
        //         sublistId:'links',
        //         fieldId:'trandate',
        //         line: 0
        //     })
        //     html += rowTable('Mensal', 'RECIBO', 'BRL', String(valorParcela), String(vencimento), dataParcela, String(pagamentoParcela))
        //     return true
        // })
        // html += endTable();
        // html += endPage();
        // html += endPage();
        // html += endBody();
        // html += endHtml();
        ctx.response.write(html);
    };
    exports.onRequest = onRequest;
    var verificaMes = function (mes) {
        var final = "";
        switch (mes) {
            case 0:
                final = "01";
                break;
            case 1:
                final = "02";
                break;
            case 2:
                final = "03";
                break;
            case 3:
                final = "04";
                break;
            case 4:
                final = "05";
                break;
            case 5:
                final = "06";
                break;
            case 6:
                final = "07";
                break;
            case 7:
                final = "08";
                break;
            case 8:
                final = "09";
                break;
            case 9:
                final = "10";
                break;
            case 10:
                final = "11";
                break;
            case 11:
                final = "12";
                break;
        }
        return final;
    };
    exports.verificaMes = verificaMes;
});
