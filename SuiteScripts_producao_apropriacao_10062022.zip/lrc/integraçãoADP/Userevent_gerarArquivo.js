/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* User_botoesTelaItem.ts
* 
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.VIEW) {
            var newRecord = ctx.newRecord;
            var form = ctx.form;
            var empresa = newRecord.getText('entity');
            var nDocto = newRecord.getValue('transactionnumber');
            var conta = newRecord.getValue('account');
            var entregar = newRecord.getValue('duedate');
            log_1.default.error('empresa', empresa);
            log_1.default.error('nDocto', nDocto);
            log_1.default.error('conta', conta);
            log_1.default.error('entregar', entregar);
            form.addButton({
                label: 'Exportar arquivo ADP',
                id: 'custpage_lrc_btt_exportarADP',
                functionName: 'exportar'
            });
            newRecord.setValue({
                fieldId: 'custbody_lrc_arquivo_adp',
                value: ""
            });
            form.clientScriptModulePath = "./ClientScript_gerarArquivo.js";
        }
    };
    exports.beforeLoad = beforeLoad;
});
