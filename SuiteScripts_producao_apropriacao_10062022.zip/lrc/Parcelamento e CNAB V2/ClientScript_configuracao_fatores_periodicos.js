/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/record", "N/search"], function (require, exports, currentRecord_1, record_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateInsert = exports.validateLine = exports.craindoRegistroFatoresPeriodicos = exports.fieldChanged = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    var pageInit = function (ctx) {
        var currRecord = ctx.currentRecord;
        var correcaoPai = currRecord.getValue({
            fieldId: 'custpage_lrc_unidade_correcao_pai'
        });
        if (correcaoPai) {
            var search = search_1.default.create({
                type: 'customrecord_lrc_unidade_correcao',
                filters: [
                    ['internalid', 'ANYOF', correcaoPai]
                ],
                columns: ['custrecord_lrc_tipo_correcao',
                    'custrecord_lrc_valor_fixo',
                    'custrecord_lrc_fator_add_sub_uc']
            }).run().getRange({
                start: 0,
                end: 1
            });
            var tipo = search[0].getValue('custrecord_lrc_tipo_correcao');
            var valor = search[0].getValue('custrecord_lrc_valor_fixo');
            var fator = search[0].getValue('custrecord_lrc_fator_add_sub_uc');
            if (valor) {
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_tipo_de_correcao',
                    sublistId: 'custpage_lrc_unidade_de_correcao',
                    value: tipo
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_fator_periodico',
                    sublistId: 'custpage_lrc_unidade_de_correcao',
                    value: valor
                });
            }
            else {
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_tipo_de_correcao',
                    sublistId: 'custpage_lrc_unidade_de_correcao',
                    value: tipo
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_fator_periodico',
                    sublistId: 'custpage_lrc_unidade_de_correcao',
                    value: fator
                });
            }
        }
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var currRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        if (fieldId == 'custpage_lrc_unidade_correcao_pai') {
            var correcaoPai = currRecord.getValue({
                fieldId: 'custpage_lrc_unidade_correcao_pai'
            });
            if (correcaoPai) {
                var search = search_1.default.create({
                    type: 'customrecord_lrc_unidade_correcao',
                    filters: [
                        ['internalid', 'ANYOF', correcaoPai]
                    ],
                    columns: ['custrecord_lrc_tipo_correcao',
                        'custrecord_lrc_valor_fixo',
                        'custrecord_lrc_fator_add_sub_uc']
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                var tipo = search[0].getValue('custrecord_lrc_tipo_correcao');
                var valor = search[0].getValue('custrecord_lrc_valor_fixo');
                var fator = search[0].getValue('custrecord_lrc_fator_add_sub_uc');
                if (valor) {
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_tipo_de_correcao',
                        sublistId: 'custpage_lrc_unidade_de_correcao',
                        value: tipo
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_fator_periodico',
                        sublistId: 'custpage_lrc_unidade_de_correcao',
                        value: valor
                    });
                }
                else {
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_tipo_de_correcao',
                        sublistId: 'custpage_lrc_unidade_de_correcao',
                        value: tipo
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_fator_periodico',
                        sublistId: 'custpage_lrc_unidade_de_correcao',
                        value: fator
                    });
                }
            }
        }
    };
    exports.fieldChanged = fieldChanged;
    var craindoRegistroFatoresPeriodicos = function () {
        var record = currentRecord_1.default.get();
        console.log('começo');
        var correcaoPai = record.getValue({
            fieldId: 'custpage_lrc_unidade_correcao_pai'
        });
        console.log(correcaoPai);
        console.log('começo for');
        record.selectLine({
            sublistId: 'custpage_lrc_unidade_de_correcao',
            line: 0
        });
        var tipoDeCorrecao = record.getCurrentSublistValue({
            fieldId: 'custpage_lrc_tipo_de_correcao',
            sublistId: 'custpage_lrc_unidade_de_correcao'
        });
        var fatorPeriodico = record.getCurrentSublistValue({
            fieldId: 'custpage_lrc_fator_periodico',
            sublistId: 'custpage_lrc_unidade_de_correcao'
        });
        console.log(fatorPeriodico);
        var dataDeVigencia = record.getCurrentSublistValue({
            fieldId: 'custpage_lrc_data_de_vigencia',
            sublistId: 'custpage_lrc_unidade_de_correcao'
        });
        var newRecord = record_1.default.create({
            type: 'customrecord_lrc_fatores_periodicos',
        });
        newRecord.setValue({
            fieldId: 'custrecord_lrc_tipo_de_correcao',
            value: tipoDeCorrecao
        });
        newRecord.setValue({
            fieldId: 'custrecord_lrc_campo_fator',
            value: fatorPeriodico
        });
        console.log('fator');
        newRecord.setValue({
            fieldId: 'custrecord_lrc_campo_data_de_vigencia',
            value: dataDeVigencia
        });
        console.log('data');
        newRecord.setValue({
            fieldId: 'custrecord_lrc_unidade_correcao_pai',
            value: correcaoPai
        });
        console.log('correcao pai');
        newRecord.save({
            ignoreMandatoryFields: true
        });
        var lineSublist = record.getLineCount({
            sublistId: 'custpage_lrc_unidade_de_correcao'
        });
        alert('Configurações atualizadas.');
        record.setValue({
            fieldId: 'custpage_lrc_unidade_correcao_pai',
            value: ''
        });
        if (lineSublist < 1) {
            record.cancelLine({
                sublistId: 'custpage_lrc_unidade_de_correcao'
            });
        }
        else {
            record.removeLine({
                sublistId: 'custpage_lrc_unidade_de_correcao',
                line: 0
            });
        }
        console.log('final');
    };
    exports.craindoRegistroFatoresPeriodicos = craindoRegistroFatoresPeriodicos;
    var validateLine = function (ctx) {
        var sublistLine = ctx.currentRecord.getLineCount({
            sublistId: 'custpage_lrc_unidade_de_correcao'
        });
        if (ctx.sublistId == "custpage_lrc_unidade_de_correcao") {
            if (sublistLine >= 1) {
                alert("Você não pode inserir linhas.");
                return false;
            }
            return true;
        }
        return true;
    };
    exports.validateLine = validateLine;
    var validateInsert = function (ctx) {
        var sublistLine = ctx.currentRecord.getLineCount({
            sublistId: 'custpage_lrc_unidade_de_correcao'
        });
        if (ctx.sublistId == "custpage_lrc_unidade_de_correcao") {
            if (sublistLine >= 1) {
                alert("Você não pode inserir linhas.");
                return false;
            }
            return true;
        }
        return true;
    };
    exports.validateInsert = validateInsert;
});
