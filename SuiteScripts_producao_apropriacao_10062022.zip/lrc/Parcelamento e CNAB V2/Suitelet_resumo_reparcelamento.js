/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 *
 *  Suitelet_resumo_reparcelamento.ts
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget"], function (require, exports, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    var onRequest = function (ctx) {
        var parameters = ctx.request.parameters;
        var form = UI.createForm({
            title: "Resumo"
        });
        var valor = parameters.vlrParcela;
        var jurosAdicionais = parameters.jurosAdicionais;
        var qtdParcelas = parameters.qtdParcela;
        var arrayParcela = parameters.arraysParcelas;
        var totalFinanciado = parameters.valorFinanciado;
        var arrayUnidade = parameters.arrayUnidade;
        var faturaPai = parameters.faturaPai;
        var checkBox = parameters.checkBox;
        var jsonObj = {};
        jsonObj['valorParcela'] = valor;
        jsonObj['jurosAdicionais'] = jurosAdicionais;
        jsonObj['qtdParcelas'] = qtdParcelas;
        jsonObj['totalFinanciado'] = totalFinanciado;
        jsonObj['faturaPai'] = faturaPai;
        jsonObj['arrayUnidade'] = JSON.parse(arrayUnidade);
        jsonObj['array'] = JSON.parse(arrayParcela);
        jsonObj['checkBox'] = JSON.parse(checkBox);
        form.addField({
            id: 'custpage_lrc_json',
            label: 'Json',
            type: UI.FieldType.TEXT
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.HIDDEN
        }).defaultValue = JSON.stringify(jsonObj);
        var dados = form.addSublist({
            id: "custpage_lrc_orders",
            type: UI.SublistType.INLINEEDITOR,
            label: "Resumo geral"
        });
        dados.addField({
            id: 'custpage_lrc_parcela',
            label: 'Parcela',
            type: UI.FieldType.TEXT
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        dados.addField({
            type: UI.FieldType.DATE,
            id: "custpage_lrc_data",
            label: "Date de Vencimento"
        });
        dados.addField({
            type: UI.FieldType.CURRENCY,
            id: "custpage_lrc_valor",
            label: "Valor",
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        dados.addField({
            type: UI.FieldType.CURRENCY,
            id: "custpage_lrc_juros",
            label: "Juros"
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        form.addButton({
            id: "button",
            label: "Salvar",
            functionName: "salvar"
        });
        form.clientScriptModulePath = "./clienteScript_resumo_parcelamento.js";
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
});
