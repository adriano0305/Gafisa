/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* suitelet_gerir_compras.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/search"], function (require, exports, UI, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    search_1 = __importDefault(search_1);
    var onRequest = function (ctx) {
        var form = UI.createForm({
            title: "Seleção de Reparcelamento"
        });
        form.clientScriptModulePath = "./ClientScript_selecao_de_parcelamento.js";
        var faturaPrincipal = form.addField({
            id: 'custpage_lrc_fatura_principal',
            type: UI.FieldType.SELECT,
            label: 'Fatura Principal'
        });
        faturaPrincipal.addSelectOption({
            text: ' ',
            value: ' '
        });
        search_1.default.create({
            type: "invoice",
            filters: [
                ['custbody_lrc_fatura_principal', 'ANYOF', '@NONE@'],
                'AND',
                ['mainline', 'IS', 'T'],
            ],
            columns: [
                'tranid'
            ]
        }).run().each(function (result) {
            var invoiceRecord = search_1.default.lookupFields({
                type: 'invoice',
                id: result.id,
                columns: [
                    'tranid'
                ]
            });
            faturaPrincipal.addSelectOption({
                text: "Fatura #" + invoiceRecord['tranid'],
                value: result.id
            });
            return true;
        });
        form.addField({
            id: 'custpage_lrc_total_valor_parcelas',
            type: UI.FieldType.TEXT,
            label: 'Valor total das parcelas'
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        form.addField({
            id: 'custpage_lrc_seleciona_todas_parcelas',
            type: UI.FieldType.CHECKBOX,
            label: 'Selecionar todas as parcelas'
        });
        form.addField({
            id: 'custpage_lrc_soma_total_parcelas',
            type: UI.FieldType.TEXT,
            label: 'Soma das parcelas'
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        form.addField({
            id: 'custpage_lrc_programa_alterou',
            type: UI.FieldType.CHECKBOX,
            label: 'programa alterou'
        }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN });
        var sublist = form.addSublist({
            id: 'custpage_lrc_selecao_de_reparcelamento',
            label: 'Seleção de Reparcelamento',
            type: UI.SublistType.INLINEEDITOR
        });
        sublist.addField({
            id: 'custpage_lrc_fatura',
            type: UI.FieldType.SELECT,
            source: 'invoice',
            label: 'Fatura'
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublist.addField({
            id: 'custpage_lrc_data_de_vencimento',
            type: UI.FieldType.TEXT,
            label: 'Data de Vencimento'
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublist.addField({
            id: 'custpage_lrc_valor',
            type: UI.FieldType.TEXT,
            label: 'Valor'
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublist.addField({
            id: 'custpage_lrc_reparcelar',
            type: UI.FieldType.CHECKBOX,
            label: 'Reparcelar'
        });
        form.addButton({
            id: 'custpage_lrc_simular',
            label: 'Simular',
            functionName: 'redirecionar'
        });
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
});
