/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 *  clientscript_resumo_reparcelamento.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/currentRecord", "N/search", "N/url", "N/runtime"], function (require, exports, record_1, currentRecord_1, search_1, url_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.salvar = exports.pageInit = void 0;
    record_1 = __importDefault(record_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    search_1 = __importDefault(search_1);
    url_1 = __importDefault(url_1);
    runtime_1 = __importDefault(runtime_1);
    var pageInit = function (ctx) {
        var record = currentRecord_1.default.get();
        var json = String(record.getValue('custpage_lrc_json'));
        // json = JSON.stringify(json)
        var jsonObj = JSON.parse(json);
        var valor = jsonObj.valorParcela;
        var jurosAdicionais = jsonObj.jurosAdicionais;
        var qtdParcelas = jsonObj.qtdParcelas;
        var totalFinanciado = jsonObj.totalFinanciado;
        var arrayUnidade = jsonObj.arrayUnidade;
        // arrayUnidade = JSON.parse(arrayUnidade)
        var verifica = 0;
        var mensalidadeComposta = [];
        var juros = 0;
        var aux = 0;
        var jurosSimples = 0;
        aux = totalFinanciado;
        var price = 0;
        for (var i = 1; i < arrayUnidade.length; i++) {
            var searchHistorico = search_1.default.create({
                type: 'customrecord_lrc_fatores_periodicos',
                filters: ['custrecord_lrc_unidade_correcao_pai', 'IS', arrayUnidade[i]],
                columns: [
                    search_1.default.createColumn({
                        name: 'custrecord_lrc_campo_data_de_vigencia',
                        sort: search_1.default.Sort.DESC
                    }),
                    search_1.default.createColumn({
                        name: 'custrecord_lrc_campo_fator'
                    })
                ],
            }).run().getRange({
                start: 0,
                end: 1
            });
            var unidadeLookup = search_1.default.lookupFields({
                type: 'customrecord_lrc_unidade_correcao',
                id: arrayUnidade[i],
                columns: [
                    'custrecord_lrc_tipo_correcao',
                    'custrecord_lrc_valor_fixo'
                ]
            });
            var fatorAdicao = 0;
            if (searchHistorico[0]) {
                fatorAdicao = Number(searchHistorico[0].getValue('custrecord_lrc_campo_fator'));
            }
            aux = totalFinanciado;
            var mes = 0;
            if (unidadeLookup.custrecord_lrc_tipo_correcao[0].value == 2) {
                verifica++;
                //calculo juros composto
                for (var j = 0; j < qtdParcelas; j++) {
                    // if(j != 0){
                    //     totalFinanciado = (totalFinanciado/1) + juros;
                    // }
                    mes = totalFinanciado / qtdParcelas + juros;
                    juros = mes / 100 * Number(fatorAdicao);
                    // juros = juros/qtdParcelas
                    mensalidadeComposta.push(juros);
                }
            }
            else if (unidadeLookup.custrecord_lrc_tipo_correcao[0].value == 1) {
                verifica++;
                jurosSimples = Number(unidadeLookup['custrecord_lrc_valor_fixo']);
            }
        }
        var compostaMensalidade = 0;
        var simplesMensalidade = 0;
        console.log('mensalidade', mensalidadeComposta);
        for (var j = 0; j < qtdParcelas; j++) {
            if (verifica == 0) {
            }
            compostaMensalidade = mensalidadeComposta[j] || 0;
            simplesMensalidade = jurosSimples || 0;
            // record.selectLine({
            //     sublistId: 'custpage_lrc_orders',
            //     line: j
            // })
            var p = j + 1;
            record.setCurrentSublistValue({
                sublistId: 'custpage_lrc_orders',
                fieldId: 'custpage_lrc_valor',
                value: (aux / qtdParcelas) + compostaMensalidade + simplesMensalidade
            });
            record.setCurrentSublistValue({
                sublistId: 'custpage_lrc_orders',
                fieldId: 'custpage_lrc_parcela',
                value: 'Parcela ' + p,
            });
            record.setCurrentSublistValue({
                sublistId: 'custpage_lrc_orders',
                fieldId: 'custpage_lrc_juros',
                value: Number(compostaMensalidade) + Number(simplesMensalidade),
            });
            record.commitLine({
                sublistId: 'custpage_lrc_orders'
            });
        }
    };
    exports.pageInit = pageInit;
    var salvar = function () {
        alert('Aguarde enquanto as novas faturas então sendo criadas.');
        var record = currentRecord_1.default.get();
        var item = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_item_de_reparcelamento' });
        var json = String(record.getValue('custpage_lrc_json'));
        var jsonObj = JSON.parse(json);
        var checkBox = jsonObj['checkBox'];
        console.log("CheckBox", checkBox);
        var qtdNovasParcelas = jsonObj['qtdParcelas'];
        var parcelasSelecionadas = jsonObj['array'];
        var searchedFaturas = search_1.default.lookupFields({
            type: 'invoice',
            id: jsonObj.faturaPai,
            columns: [
                "customform",
                "entity",
                "approvalstatus",
                "postingperiod",
                "duedate",
                "trandate",
                "saleseffectivedate",
                "class",
                "location",
                "custbody_lrc_fatura_principal",
                "subsidiary",
                "approvalstatus"
            ]
        });
        var novasParcelas = [];
        for (var i = 0; i < Number(qtdNovasParcelas); i++) {
            var data = record.getSublistText({
                fieldId: 'custpage_lrc_data',
                sublistId: 'custpage_lrc_orders',
                line: i
            });
            if (!data) {
                alert('Adicione uma data na linha ' + i);
                return false;
            }
        }
        if (checkBox) {
            console.log('checkbox true');
            for (var i = 0; i < Number(qtdNovasParcelas); i++) {
                var faturaRecord = record_1.default.create({
                    type: 'invoice',
                });
                faturaRecord.setValue({
                    fieldId: 'entity',
                    value: searchedFaturas.entity[0].value
                });
                console.log('trandate', record.getSublistValue({
                    fieldId: 'custpage_lrc_data',
                    sublistId: 'custpage_lrc_orders',
                    line: i
                }));
                var date = record.getSublistText({
                    fieldId: 'custpage_lrc_data',
                    sublistId: 'custpage_lrc_orders',
                    line: i
                });
                date = date.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                date = new Date(date);
                console.log('trandate', date);
                faturaRecord.setValue({
                    fieldId: 'trandate',
                    value: date
                });
                faturaRecord.setValue({
                    fieldId: 'class',
                    value: searchedFaturas.class[0].value
                });
                faturaRecord.setValue({
                    fieldId: 'location',
                    value: searchedFaturas.location[0].value
                });
                faturaRecord.setValue({
                    fieldId: 'custbody_lrc_fatura_principal',
                    value: jsonObj.faturaPai
                });
                faturaRecord.setValue({
                    fieldId: 'custbody_lrc_parcela_reparcelamento',
                    value: true
                });
                faturaRecord.setValue({
                    fieldId: 'subsidiary',
                    value: searchedFaturas.subsidiary[0].value
                });
                // faturaRecord.selectNewLine({
                //     sublistId: 'item',
                // });
                faturaRecord.setSublistValue({
                    fieldId: 'item',
                    sublistId: 'item',
                    line: 0,
                    value: item
                });
                var quantidade = 1;
                faturaRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'quantity',
                    line: 0,
                    value: quantidade
                });
                var valor = record.getSublistValue({
                    fieldId: 'custpage_lrc_valor',
                    sublistId: 'custpage_lrc_orders',
                    line: i
                });
                faturaRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: 0,
                    value: valor
                });
                // faturaRecord.commitLine({
                //     sublistId: 'item'
                // });
                var faturaId = faturaRecord.save({
                    ignoreMandatoryFields: true
                });
                novasParcelas.push(faturaId);
            }
        }
        else {
            for (var i = 0; i < Number(qtdNovasParcelas); i++) {
                var faturaRecord = record_1.default.create({
                    type: 'invoice',
                });
                faturaRecord.setValue({
                    fieldId: 'entity',
                    value: searchedFaturas.entity[0].value
                });
                faturaRecord.setValue({
                    fieldId: 'subsidiary',
                    value: searchedFaturas.subsidiary[0].value
                });
                faturaRecord.setValue({
                    fieldId: 'approvalstatus',
                    value: 2
                });
                // console.log('trandate', record.getSublistText({
                //     fieldId:'custpage_lrc_data',
                //     sublistId:'custpage_lrc_orders',
                //     line: i
                // }));
                var date = record.getSublistText({
                    fieldId: 'custpage_lrc_data',
                    sublistId: 'custpage_lrc_orders',
                    line: i
                });
                date = date.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                date = new Date(date);
                faturaRecord.setValue({
                    fieldId: 'trandate',
                    value: date
                });
                faturaRecord.setValue({
                    fieldId: 'class',
                    value: searchedFaturas.class[0].value
                });
                faturaRecord.setValue({
                    fieldId: 'location',
                    value: searchedFaturas.location[0].value
                });
                faturaRecord.setValue({
                    fieldId: 'custbody_lrc_fatura_principal',
                    value: jsonObj.faturaPai
                });
                // faturaRecord.selectNewLine({
                //     sublistId: 'item',
                // });
                console.log('item', item);
                faturaRecord.setSublistValue({
                    fieldId: 'item',
                    sublistId: 'item',
                    line: 0,
                    value: item
                });
                // const quantidade = 1
                // faturaRecord.setSublistValue({
                //     sublistId: 'item',
                //     fieldId: 'quantity',
                //     line: 0,
                //     value: quantidade
                // });
                var valor = record.getSublistValue({
                    fieldId: 'custpage_lrc_valor',
                    sublistId: 'custpage_lrc_orders',
                    line: i
                });
                console.log('valor', valor);
                faturaRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: 0,
                    value: valor
                });
                var faturaId = faturaRecord.save({
                    ignoreMandatoryFields: true
                });
                novasParcelas.push(faturaId);
            }
            for (var i = 0; i < parcelasSelecionadas.length; i++) {
                var faturaSelectRecord = record_1.default.load({
                    type: 'invoice',
                    id: parcelasSelecionadas[i]
                });
                faturaSelectRecord.setValue({
                    fieldId: 'custbody_lrc_parcela_cancelada',
                    value: true
                });
                faturaSelectRecord.save({ ignoreMandatoryFields: true });
            }
        }
        var recordReparcelamento = record_1.default.create({
            type: 'customrecord_lrc_config_reparcelamento',
        });
        recordReparcelamento.setValue({
            fieldId: 'custrecord_lrc_fatura_principal',
            value: jsonObj.faturaPai
        });
        recordReparcelamento.setValue({
            fieldId: 'custrecord_lrc_faturas_selecionadas',
            value: jsonObj.array
        });
        recordReparcelamento.setValue({
            fieldId: 'custrecord_lrc_novas_parcelas',
            value: novasParcelas
        });
        var registroReparcelado = recordReparcelamento.save({
            ignoreMandatoryFields: true
        });
        alert('Reparcelamento concluido com sucesso!');
        var url = url_1.default.resolveRecord({
            recordType: 'customrecord_lrc_config_reparcelamento',
            recordId: registroReparcelado,
            isEditMode: false
        });
        window.location.replace(url);
    };
    exports.salvar = salvar;
});
