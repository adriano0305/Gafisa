/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScprit_simulacao_reparcelamento.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/search", "N/url", "N/log"], function (require, exports, currentRecord_1, search_1, url_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validadeField = exports.validateDelete = exports.fieldChanged = exports.enviarReparcelamento = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    search_1 = __importDefault(search_1);
    url_1 = __importDefault(url_1);
    log_1 = __importDefault(log_1);
    var pageInit = function (ctx) {
        var currRecord = ctx.currentRecord;
        var valorTotal = currRecord.getValue({
            fieldId: 'custpage_lrc_valor_total_parcelas'
        });
        var entrada = currRecord.getValue({
            fieldId: 'custpage_lrc_entrada'
        });
        var totalFinanciado = Number(valorTotal) - Number(entrada);
        if (valorTotal) {
            currRecord.setValue({
                fieldId: 'custpage_lrc_total_financiado',
                value: totalFinanciado
            });
        }
        var lineCount = currRecord.getLineCount({
            sublistId: 'custpage_lrc_resumo_valores'
        });
        var soma = 0;
        for (var i = 1; i < lineCount; i++) {
            // console.log('i',i)
            var valorTotalSublist = currRecord.getSublistValue({
                fieldId: 'custpage_lrc_vlr_total',
                line: i,
                sublistId: 'custpage_lrc_resumo_valores'
            });
            console.log('valorTotalSublist', valorTotalSublist);
            soma += Number(valorTotalSublist);
        }
        currRecord.setValue({
            fieldId: 'custpage_lrc_juros_adicionais',
            value: soma || 0
        });
        var custoTotalReparcelamento = Number(totalFinanciado) + Number(soma);
        if (totalFinanciado && soma) {
            currRecord.setValue({
                fieldId: 'custpage_lrc_total_reparcelamento',
                value: custoTotalReparcelamento
            });
        }
        var qtdNovasParcelas = currRecord.getValue({
            fieldId: 'custpage_lrc_qnt_novas_parcelas'
        });
        var valorNovasParcelas = Number(totalFinanciado) / Number(qtdNovasParcelas);
        if (totalFinanciado && qtdNovasParcelas) {
            currRecord.setValue({
                fieldId: 'custpage_lrc_vlr_novas_parcelas',
                value: valorNovasParcelas
            });
        }
        currRecord.selectLine({
            line: 0,
            sublistId: 'custpage_lrc_resumo_valores'
        });
        currRecord.setCurrentSublistValue({
            fieldId: 'custpage_lrc_item_parcelas_acrescimos',
            sublistId: 'custpage_lrc_resumo_valores',
            value: 'Valor do Reparcelamento'
        });
        currRecord.setCurrentSublistValue({
            fieldId: 'custpage_lrc_vlr_total',
            sublistId: 'custpage_lrc_resumo_valores',
            value: totalFinanciado
        });
        var valorTotalParcelas = Number(totalFinanciado) / Number(qtdNovasParcelas);
        if (totalFinanciado && qtdNovasParcelas) {
            currRecord.setCurrentSublistValue({
                fieldId: 'custpage_lrc_vlr_total_parcelas',
                sublistId: 'custpage_lrc_resumo_valores',
                value: valorTotalParcelas
            });
        }
        var unidadeCorrecao = currRecord.getValue('custpage_lrc_unidade_correcao');
        console.log('entrou aqui', unidadeCorrecao);
        if (unidadeCorrecao) {
            var lookupUnidade = search_1.default.lookupFields({
                type: 'customrecord_lrc_unidade_correcao',
                id: unidadeCorrecao,
                columns: ['custrecord_lrc_fator_add_sub_uc', 'custrecord_lrc_valor_fixo', 'custrecord_lrc_tipo_correcao']
            });
            console.log('entrou aqui', lookupUnidade);
            if (lookupUnidade['custrecord_lrc_fator_add_sub_uc'] == true) {
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_fator_mensal',
                    sublistId: 'custpage_lrc_resumo_valores',
                    value: lookupUnidade['custrecord_lrc_fator_add_sub_uc']
                });
            }
            else if (lookupUnidade['custrecord_lrc_valor_fixo'] == true) {
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_fator_mensal',
                    sublistId: 'custpage_lrc_resumo_valores',
                    value: lookupUnidade['custrecord_lrc_valor_fixo']
                });
            }
            if ('custpage_lrc_fator_mensal' == lookupUnidade['custrecord_lrc_fator_add_sub_uc']) {
                var valorTotalMultiplicado = Number(lookupUnidade['custrecord_lrc_fator_add_sub_uc']) * Number(qtdNovasParcelas);
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_vlr_total',
                    sublistId: 'custpage_lrc_resumo_valores',
                    value: valorTotalMultiplicado
                });
            }
        }
        currRecord.commitLine({
            sublistId: 'custpage_lrc_resumo_valores'
        });
    };
    exports.pageInit = pageInit;
    //funcionalidade do botão
    var enviarReparcelamento = function () {
        var record = currentRecord_1.default.get();
        var qtdParcela = record.getValue('custpage_lrc_qnt_novas_parcelas');
        var vlrParcela = record.getValue('custpage_lrc_vlr_novas_parcelas');
        var jurosAdicionais = record.getValue('custpage_lrc_juros_adicionais');
        var arraysParcelas = record.getValue('custpage_lrc_array_parcelas');
        var valorFinanciado = record.getValue('custpage_lrc_total_financiado');
        var checkBox = record.getValue('custpage_lrc_efetivar_primeiro_pagamento');
        var qtLinhas = record.getLineCount({
            sublistId: 'custpage_lrc_resumo_valores'
        });
        var faturaPai = record.getValue('custpage_lrc_fatura_pai');
        var arrayUnidade = [];
        for (var i = 0; i < qtLinhas; i++) {
            var unidade = record.getSublistValue({
                line: i,
                fieldId: 'custpage_lrc_unidade_correcao',
                sublistId: 'custpage_lrc_resumo_valores'
            });
            arrayUnidade.push(unidade);
        }
        var enviar = url_1.default.resolveScript({
            scriptId: 'customscript_irc_resumo_parcelament',
            deploymentId: 'customdeploy1',
            params: {
                qtdParcela: qtdParcela, vlrParcela: vlrParcela,
                jurosAdicionais: jurosAdicionais, arraysParcelas: arraysParcelas,
                valorFinanciado: valorFinanciado, arrayUnidade: JSON.stringify(arrayUnidade),
                faturaPai: faturaPai, checkBox: checkBox
            },
        });
        log_1.default.error("Enviar", enviar);
        window.location.replace(enviar);
    };
    exports.enviarReparcelamento = enviarReparcelamento;
    var fieldChanged = function (ctx) {
        var sublistId = ctx.sublistId;
        var fieldId = ctx.fieldId;
        var currentRecord = ctx.currentRecord;
        var primeiraPassagem = 0;
        // quando altera o campo entrada
        var campoEntrada = Number(currentRecord.getValue('custpage_lrc_entrada'));
        var valorTotalParcelas = Number(currentRecord.getValue('custpage_lrc_valor_total_parcelas'));
        if (campoEntrada) {
            console.log(campoEntrada);
            console.log(valorTotalParcelas);
            if (fieldId == 'custpage_lrc_entrada') {
                currentRecord.setValue({
                    fieldId: 'custpage_lrc_total_financiado',
                    value: valorTotalParcelas - campoEntrada
                });
            }
        }
        //alterar o campo total total Financiado
        if (valorTotalParcelas) {
            if (fieldId == 'custpage_lrc_valor_total_parcelas') {
                currentRecord.setValue({
                    fieldId: 'custpage_lrc_total_financiado',
                    value: valorTotalParcelas - campoEntrada
                });
            }
        }
        //Ao alterar o campo "Valor Total" 
        var jurosAdicionais = Number(currentRecord.getValue('custpage_lrc_juros_adicionais'));
        if (fieldId == 'custpage_lrc_vlr_total') {
            var jurosTotalSomado = 0;
            var totalLinhasResumoValores = currentRecord.getLineCount("custpage_lrc_resumo_valores");
            console.log('total linhas', totalLinhasResumoValores);
            var valorSublista = Number(currentRecord.getCurrentSublistValue({
                sublistId: 'custpage_lrc_resumo_valores',
                fieldId: 'custpage_lrc_vlr_total',
            }));
            console.log('valor sublista', valorSublista);
            // if(Number(currentRecord.getCurrentSublistIndex) == 0){
            jurosTotalSomado = jurosTotalSomado + valorSublista;
            // }
            for (var i = 1; i < totalLinhasResumoValores; i++) {
                if (currentRecord.getCurrentSublistIndex({
                    sublistId: "custpage_lrc_resumo_valores"
                }) != 0) {
                    var valorSublista_1 = Number(currentRecord.getSublistValue({
                        sublistId: 'custpage_lrc_resumo_valores',
                        fieldId: 'custpage_lrc_vlr_total',
                        line: i
                    }));
                    console.log('valor sublista', valorSublista_1);
                    jurosTotalSomado = jurosTotalSomado + valorSublista_1;
                    console.log('entra aqui', jurosTotalSomado);
                }
            }
            if (Number(currentRecord.getCurrentSublistIndex({ sublistId: 'custpage_lrc_resumo_valores' })) > 0) {
                currentRecord.setValue({
                    fieldId: "custpage_lrc_juros_adicionais",
                    value: jurosTotalSomado
                });
                var qtdParcelas = Number(currentRecord.getValue('custpage_lrc_qnt_novas_parcelas'));
                if (qtdParcelas) {
                    currentRecord.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_resumo_valores',
                        fieldId: 'custpage_lrc_vlr_total_parcelas',
                        value: valorSublista / qtdParcelas
                    });
                }
            }
            var valorTotal = Number(currentRecord.getCurrentSublistValue({
                sublistId: 'custpage_lrc_resumo_valores',
                fieldId: 'custpage_lrc_vlr_total'
            }));
        }
        //Ao alterar o campo "Juros e Adicionais" 
        var totalFinanciado = Number(currentRecord.getValue('custpage_lrc_total_financiado'));
        var totalReparcelamento = Number(currentRecord.getValue('custpage_lrc_total_reparcelamento'));
        if (totalFinanciado) {
            if (fieldId == 'custpage_lrc_total_financiado') {
                console.log(jurosAdicionais);
                currentRecord.setValue({
                    fieldId: 'custpage_lrc_total_reparcelamento',
                    value: totalFinanciado
                });
            }
        }
        if (jurosAdicionais) {
            if (fieldId == 'custpage_lrc_juros_adicionais') {
                console.log(jurosAdicionais);
                currentRecord.setValue({
                    fieldId: 'custpage_lrc_total_reparcelamento',
                    value: totalFinanciado + jurosAdicionais
                });
            }
        }
        //Ao alterar o campo "Valor Financiado" 
        var qtdNovasParcelas = Number(currentRecord.getValue('custpage_lrc_qnt_novas_parcelas'));
        // if (qtdNovasParcelas && totalFinanciado && valorTotalParcelas && jurosAdicionais) {
        //     if (fieldId == 'custpage_lrc_total_financiado') {
        //         console.log(totalFinanciado);
        //         console.log(qtdNovasParcelas);
        //         console.log(jurosAdicionais);
        //         currentRecord.setValue({
        //             fieldId: 'custpage_lrc_vlr_novas_parcelas',
        //             value: totalFinanciado / qtdNovasParcelas
        //         })
        //         currentRecord.setValue({
        //             fieldId: 'custpage_lrc_vlr_total_parcelas',
        //             value: valorTotalParcelas + qtdNovasParcelas
        //         })
        //         currentRecord.setValue({
        //             fieldId: 'custpage_lrc_total_reparcelamento',
        //             value: jurosAdicionais + totalFinanciado
        //         })
        //     }
        // }
        //alterar campo total reparcelamento
        if (totalReparcelamento && qtdNovasParcelas) {
            if (fieldId == 'custpage_lrc_total_reparcelamento') {
                currentRecord.setValue({
                    fieldId: 'custpage_lrc_vlr_novas_parcelas',
                    value: totalReparcelamento / qtdNovasParcelas
                });
            }
        }
        //ao alterar o campo "Quantidades de novas Parcelas"
        if (qtdNovasParcelas && valorTotalParcelas && totalReparcelamento) {
            if (fieldId == 'custpage_lrc_qnt_novas_parcelas') {
                console.log(totalFinanciado);
                console.log(qtdNovasParcelas);
                var qtLinhas = currentRecord.getLineCount({ sublistId: 'custpage_lrc_resumo_valores' });
                for (var i = 0; i < qtLinhas; i++) {
                    currentRecord.selectLine({
                        line: i,
                        sublistId: 'custpage_lrc_resumo_valores'
                    });
                    var valorTotalSublista = currentRecord.getCurrentSublistValue({
                        fieldId: 'custpage_lrc_vlr_total',
                        sublistId: 'custpage_lrc_resumo_valores'
                    });
                    currentRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_vlr_total_parcelas',
                        value: Number(valorTotalSublista) / qtdNovasParcelas,
                        sublistId: 'custpage_lrc_resumo_valores'
                    });
                    currentRecord.commitLine({
                        sublistId: 'custpage_lrc_resumo_valores'
                    });
                }
                currentRecord.setValue({
                    fieldId: 'custpage_lrc_vlr_novas_parcelas',
                    value: totalReparcelamento / qtdNovasParcelas
                });
            }
        }
        console.log('entrou no if unidadecorrecao');
        if (fieldId == 'custpage_lrc_unidade_correcao' && sublistId == 'custpage_lrc_resumo_valores') {
            console.log('entrou no if');
            if (currentRecord.getCurrentSublistIndex({ sublistId: 'custpage_lrc_resumo_valores' }) > 0) {
                var unidadeCorrecao = currentRecord.getCurrentSublistValue({
                    sublistId: 'custpage_lrc_resumo_valores',
                    fieldId: 'custpage_lrc_unidade_correcao'
                });
                var lookupUnidade = search_1.default.lookupFields({
                    type: 'customrecord_lrc_unidade_correcao',
                    id: unidadeCorrecao,
                    columns: [
                        'custrecord_lrc_valor_fixo',
                        'custrecord_lrc_tipo_correcao'
                    ]
                });
                var valorFixo = Number(lookupUnidade['custrecord_lrc_valor_fixo']);
                var valorFinanciado = Number(currentRecord.getValue('custpage_lrc_total_financiado'));
                var valorTotalParcelas_1 = Number(currentRecord.getValue('custpage_lrc_valor_total_parcelas'));
                var qtdParcelas = Number(currentRecord.getValue('custpage_lrc_qnt_novas_parcelas'));
                console.log("Entrou no lookupUnidade", lookupUnidade);
                console.log('Valor fixo', valorFixo);
                if (Number(lookupUnidade['custrecord_lrc_tipo_correcao'][0].value) == 1) { //valor absoluto
                    if (qtdParcelas) {
                        currentRecord.setCurrentSublistValue({
                            sublistId: 'custpage_lrc_',
                            fieldId: 'custpage_lrc_fator_mensal',
                            value: valorFixo
                        });
                        currentRecord.setCurrentSublistValue({
                            sublistId: 'custpage_lrc_resumo_valores',
                            fieldId: 'custpage_lrc_vlr_total',
                            value: valorFixo * qtdParcelas
                        });
                    }
                    else {
                        alert('Necessário preencher o campo quantidade de novas parcelas, favor preencher e selecionar novamente a unidade de correção');
                        return false;
                    }
                }
                else if (lookupUnidade['custrecord_lrc_tipo_correcao'][0].value == 2) { //valor progressivo
                    var searchHistorico = search_1.default.create({
                        type: 'customrecord_lrc_fatores_periodicos',
                        filters: ['custrecord_lrc_unidade_correcao_pai', 'IS', unidadeCorrecao],
                        columns: [
                            search_1.default.createColumn({
                                name: 'custrecord_lrc_campo_data_de_vigencia',
                                sort: search_1.default.Sort.DESC
                            }),
                            search_1.default.createColumn({
                                name: 'custrecord_lrc_campo_fator'
                            })
                        ],
                    }).run().getRange({
                        start: 0,
                        end: 1
                    });
                    currentRecord.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_resumo_valores',
                        fieldId: 'custpage_lrc_fator_mensal',
                        value: searchHistorico[0].getValue('custrecord_lrc_campo_fator')
                    });
                    currentRecord.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_resumo_valores',
                        fieldId: 'custpage_lrc_vlr_total',
                        value: Number(valorFinanciado) / 100 * Number(searchHistorico[0].getValue('custrecord_lrc_campo_fator'))
                    });
                }
                currentRecord.commitLine({
                    sublistId: 'custpage_lrc_resumo_valores'
                });
            }
        }
        // efetivar pagamento
        // if (currentRecord.getValue('custpage_lrc_efetivar_primeiro_pagamento')) {
        //     const lineCount = currentRecord.getLineCount({
        //         sublistId: 'custpage_lrc_orders'
        //     });
        //     for (let i = 0; i < lineCount; i++) {
        //         currentRecord.selectLine({
        //             sublistId: 'custpage_lrc_orders',
        //             line: i
        //         });
        //         const checkBox = currentRecord.getValue({
        //             fieldId: 'custpage_lrc_efetivar_primeiro_pagamento',
        //         });
        //         if (checkBox == false) {
        //             currentRecord.setCurrentSublistValue({
        //                 fieldId: 'approvalstatus',
        //                 sublistId: 'custpage_lrc_orders',
        //                 value: 2
        //             });
        //         }
        //         if (checkBox == true) {
        //             currentRecord.setCurrentSublistValue({
        //                 fieldId: 'approvalstatus',
        //                 sublistId: 'custpage_lrc_orders',
        //                 value: 3
        //             });
        //         }
        //     }
        // }   
    };
    exports.fieldChanged = fieldChanged;
    //validateDelete
    var validateDelete = function (ctx) {
        if (ctx.sublistId == "custpage_lrc_resumo_valores" && ctx.lineCount == 0) {
            return true;
        }
        else {
            return false;
        }
    };
    exports.validateDelete = validateDelete;
    var validadeField = function (ctx) {
        var fieldId = ctx.fieldId;
        var sublistId = ctx.sublistId;
        var currRecord = ctx.currentRecord;
        var line = ctx.line;
        var unidadeCorrecao = currRecord.getSublistValue({
            fieldId: 'custpage_lrc_unidade_correcao',
            sublistId: 'custpage_lrc_resumo_valores',
            line: Number(line)
        });
        if (fieldId == 'custpage_lrc_unidade_correcao' && sublistId == 'custpage_lrc_resumo_valores') {
            var searchHistorico = search_1.default.create({
                type: 'customrecord_lrc_fatores_periodicos',
                filters: ['custrecord_lrc_unidade_correcao_pai', 'IS', unidadeCorrecao],
                columns: [
                    search_1.default.createColumn({
                        name: 'custrecord_lrc_campo_data_de_vigencia',
                        sort: search_1.default.Sort.DESC
                    }),
                    search_1.default.createColumn({
                        name: 'custrecord_lrc_campo_fator'
                    })
                ],
            }).run().getRange({
                start: 0,
                end: 1
            });
            if (!searchHistorico[0]) {
                alert('Não existe vigência para este índice financeiro.');
                return false;
            }
        }
        return true;
    };
    exports.validadeField = validadeField;
});
