/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 *changeField_unidade_correcao.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = void 0;
    log_1 = __importDefault(log_1);
    var fieldChanged = function (ctx) {
        var fieldId = ctx.fieldId;
        var currentRecord = ctx.currentRecord;
        var campoCorrecao = currentRecord.getValue('custrecord_lrc_tipo_correcao');
        log_1.default.error('Campo correção', campoCorrecao);
        if (fieldId == 'custrecord_lrc_tipo_correcao') {
            console.log(campoCorrecao);
            if (campoCorrecao == 1) {
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_valor_fixo'
                }).isVisible = true;
            }
            else {
                log_1.default.error('entrou', 'if');
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_valor_fixo'
                }).isVisible = false;
            }
        }
    };
    exports.fieldChanged = fieldChanged;
    var pageInit = function (ctx){
        ctx.currentRecord.getField({
            fieldId: 'custrecord_lrc_valor_fixo'
        }).isVisible = false;
        var fieldId = ctx.fieldId;
        var currentRecord = ctx.currentRecord;
        var campoCorrecao = currentRecord.getValue('custrecord_lrc_tipo_correcao');

        if (campoCorrecao == 1) {
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_valor_fixo'
            }).isVisible = true;
        }
        else {
            log_1.default.error('entrou', 'if');
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_valor_fixo'
            }).isVisible = false;
        }

    }
    exports.pageInit = pageInit;
        var validateField = function(ctx){
            var fieldId = ctx.fieldId;

            var currentRecord = ctx.currentRecord;
            var campoCorrecao = currentRecord.getValue('custrecord_lrc_tipo_correcao');
            log_1.default.error('Campo correção', campoCorrecao);
            if (fieldId == 'custrecord_lrc_valor_fixo') {
                var campoCorrecao = currentRecord.getValue('custrecord_lrc_tipo_correcao');
                if (campoCorrecao == 1) {
                    if (currentRecord.getValue('custrecord_lrc_valor_fixo') <= 0){
                        return false;
                    }
                }

            }
            return true;
        }
        exports.validateField = validateField;

});
