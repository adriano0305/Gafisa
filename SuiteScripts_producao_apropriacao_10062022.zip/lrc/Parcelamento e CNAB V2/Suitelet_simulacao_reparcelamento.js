/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
*Suitelet_Simulacao_Reparcelamento.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget"], function (require, exports, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    var onRequest = function (ctx) {
        var parameters = ctx.request.parameters;
        var array = parameters.parcela;
        var valorTotal = parameters.valor;
        var faturaPai = parameters.faturaPai;
        if (ctx.request.method == "GET") {
            var form = UI.createForm({
                title: 'Simulação Reparcelamento'
            });
            var formId = form.addField({
                id: 'custpage_lrc_entrada',
                type: UI.FieldType.CURRENCY,
                label: 'Entrada',
            });
            form.addField({
                id: 'custpage_lrc_valor_total_parcelas',
                type: UI.FieldType.CURRENCY,
                label: 'Valor total das parcelas selecionadas',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED }).defaultValue = valorTotal;
            form.addField({
                id: 'custpage_lrc_total_financiado',
                type: UI.FieldType.CURRENCY,
                label: 'Total Financiado',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            form.addField({
                id: 'custpage_lrc_juros_adicionais',
                type: UI.FieldType.CURRENCY,
                label: 'Juros e Adicionais',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            form.addField({
                id: 'custpage_lrc_total_reparcelamento',
                type: UI.FieldType.CURRENCY,
                label: 'Custo total do reparcelamentos',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            form.addField({
                id: 'custpage_lrc_periodicidade',
                type: UI.FieldType.TEXT,
                label: 'Periodicidade',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED }).defaultValue = 'Mensal';
            form.addField({
                id: 'custpage_lrc_qnt_novas_parcelas',
                type: UI.FieldType.INTEGER,
                label: 'Quantidade de novas Parcelas',
            });
            form.addField({
                id: 'custpage_lrc_vlr_novas_parcelas',
                type: UI.FieldType.CURRENCY,
                label: 'Valor das Novas Parcelas:',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            form.addField({
                id: 'custpage_lrc_array_parcelas',
                type: UI.FieldType.TEXT,
                label: 'Array'
            }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = array;
            form.addField({
                id: 'custpage_lrc_fatura_pai',
                type: UI.FieldType.TEXT,
                label: 'Fatura Pai'
            }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = faturaPai;
            form.addField({
                id: 'custpage_lrc_efetivar_primeiro_pagamento',
                type: UI.FieldType.CHECKBOX,
                label: 'Efetivar somente após primeiro pagamento'
            });
            var sublist = form.addSublist({
                id: 'custpage_lrc_resumo_valores',
                type: UI.SublistType.INLINEEDITOR,
                label: 'Resumo de valores'
            });
            sublist.addField({
                id: 'custpage_lrc_item_parcelas_acrescimos',
                type: UI.FieldType.TEXT,
                label: 'Itens das Parcelas e Acréscimos'
            });
            sublist.addField({
                id: 'custpage_lrc_unidade_correcao',
                type: UI.FieldType.SELECT,
                source: 'customrecord_lrc_unidade_correcao',
                label: 'Unidade de Correção'
            });
            sublist.addField({
                id: 'custpage_lrc_fator_mensal',
                type: UI.FieldType.CURRENCY,
                label: 'Fator Mensal',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist.addField({
                id: 'custpage_lrc_vlr_total',
                type: UI.FieldType.CURRENCY,
                label: 'Valor Total',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist.addField({
                id: 'custpage_lrc_vlr_total_parcelas',
                type: UI.FieldType.CURRENCY,
                label: 'Valor total das parcelas',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            form.addButton({
                id: 'button_lrc_enviar',
                label: 'Enviar',
                functionName: 'enviarReparcelamento',
            });
            form.clientScriptModulePath = "./ClientScript_simulacao_reparcelamento.js";
            ctx.response.writePage(form);
        }
    };
    exports.onRequest = onRequest;
});
