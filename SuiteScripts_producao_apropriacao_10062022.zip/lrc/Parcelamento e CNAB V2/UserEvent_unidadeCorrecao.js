/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
*
*
*
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.VIEW) {
            var newRecord = ctx.newRecord;
            if (newRecord.getValue('custrecord_lrc_tipo_correcao') == 2) {
                newRecord.getField({
                    fieldId: 'custrecord_lrc_valor_fixo'
                }).isVisible = false;
                newRecord.getField({
                    fieldId: 'custrecord_lrc_fator_add_sub_uc'
                }).isVisible = true;
            }
            else {
                newRecord.getField({
                    fieldId: 'custrecord_lrc_valor_fixo'
                }).isVisible = true;
                newRecord.getField({
                    fieldId: 'custrecord_lrc_fator_add_sub_uc'
                }).isVisible = false;
            }
        }
    };
    exports.beforeLoad = beforeLoad;
});
