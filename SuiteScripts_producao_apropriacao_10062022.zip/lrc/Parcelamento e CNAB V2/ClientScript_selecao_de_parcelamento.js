/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/url", "N/currentRecord", "N/search"], function (require, exports, url_1, currentRecord_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateInsert = exports.validateLine = exports.validateDelete = exports.redirecionar = exports.fieldChanged = exports.pageInit = void 0;
    url_1 = __importDefault(url_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    search_1 = __importDefault(search_1);
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var currentRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        var soma = 0;
        if (fieldId == 'custpage_lrc_fatura_principal') {
            var campoInvisivel = currentRecord.setValue({
                fieldId: 'custpage_lrc_programa_alterou',
                value: true
            });
            // verefica se o campo foi alterado
            var faturaPai = currentRecord.getValue('custpage_lrc_fatura_principal');
            currentRecord.cancelLine({
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            var lineCount = currentRecord.getLineCount({
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            for (var i = lineCount - 1; i >= 0; i--) {
                currentRecord.removeLine({
                    line: i,
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                });
            }
            search_1.default.create({
                type: "invoice",
                filters: [
                    ['custbody_lrc_fatura_principal', 'IS', faturaPai],
                    'AND',
                    ['custbody_lrc_parcela_cancelada', 'IS', 'F'],
                    'AND',
                    ['custbody_lrc_parcela_reparcelamento', 'IS', 'F'],
                    'AND',
                    ['mainline', 'IS', 'T'],
                ]
            }).run().each(function (result) {
                var invoiceLoockup = search_1.default.lookupFields({
                    type: 'invoice',
                    id: result.id,
                    columns: ['tranid', 'total', 'trandate']
                });
                currentRecord.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                    fieldId: 'custpage_lrc_fatura',
                    value: result.id
                });
                currentRecord.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                    fieldId: 'custpage_lrc_data_de_vencimento',
                    value: String(invoiceLoockup['trandate'])
                });
                currentRecord.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                    fieldId: 'custpage_lrc_valor',
                    value: String(invoiceLoockup['total'])
                });
                currentRecord.setValue({
                    fieldId: 'custpage_lrc_total_valor_parcelas',
                    value: soma += Number(invoiceLoockup['total'])
                });
                currentRecord.commitLine({
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                });
                return true;
            });
            currentRecord.setValue({
                fieldId: 'custpage_lrc_programa_alterou',
                value: false
            });
            //   anoParcela.removeSelectOption({
            //     value: null
            //   });
            //  anoParcela.insertSelectOption({
            //    text: '',
            //    value: ''
            //  });
            // for(let i = 0; i < array.length; i++){
            //   anoParcela.insertSelectOption({
            //     text: array[i],
            //     value: array[i]
            //   });
            // } 
            // }
            // if(fieldId == 'custpage_lrc_ano_da_parcela'){
            //   const lineCount = currentRecord.getLineCount({
            //     sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            //   });
            //   for(let i = lineCount -1; i >= 0; i--){
            //     currentRecord.removeLine({
            //       line: i,
            //       sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            //     });
            //   }
            // const faturaPai = currentRecord.getValue('custpage_lrc_fatura_principal');
            // const anoParcela = currentRecord.getValue('custpage_lrc_ano_da_parcela');
            // Search.create({
            //   type: "invoice",
            //   filters:[
            //       ['custbody_lrc_fatura_principal', 'IS', faturaPai],
            //       'AND',
            //       ['mainline', 'IS', 'T'],  
            //   ],
            //   columns: [
            //      'trandate'
            //   ]
            // }).run().each((result) => {
            //   const invoiceLoockup = Search.lookupFields({
            //       type: 'invoice',
            //       id: result.id,
            //       columns: ['trandate', 'tranid', 'total']
            //   });
            //   const data = String(invoiceLoockup['trandate']);
            //   const dataSplited = data.split('/');
            //   const ano = dataSplited[2];
            //   console.log('passou aqui');
            //   if(anoParcela == ano){
            //     console.log('entrou no if');
            //   currentRecord.setCurrentSublistValue({
            //     sublistId: 'custpage_lrc_selecao_de_reparcelamento',
            //     fieldId: 'custpage_lrc_fatura',
            //     value: result.id
            //   });
            //   currentRecord.setCurrentSublistValue({
            //     sublistId: 'custpage_lrc_selecao_de_reparcelamento',
            //     fieldId: 'custpage_lrc_data_de_vencimento',
            //     value: String(invoiceLoockup['trandate'])
            //   });
            //   currentRecord.setCurrentSublistValue({
            //     sublistId: 'custpage_lrc_selecao_de_reparcelamento',
            //     fieldId: 'custpage_lrc_valor',
            //     value: String(invoiceLoockup['total'])
            //   });
            //   currentRecord.commitLine({
            //     sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            //   });
            // }
            //   return true;
            // });
        }
        if (fieldId == 'custpage_lrc_seleciona_todas_parcelas') {
            var lineCount = currentRecord.getLineCount({
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            for (var i = 0; i < lineCount; i++) {
                currentRecord.selectLine({
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                    line: i
                });
                currentRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_reparcelar',
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                    value: true
                });
                var checkBox = currentRecord.getValue({
                    fieldId: 'custpage_lrc_seleciona_todas_parcelas',
                });
                if (checkBox == false) {
                    currentRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_reparcelar',
                        sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                        value: false
                    });
                }
            }
        }
        if (fieldId == 'custpage_lrc_reparcelar') {
            var lineCount = currentRecord.getLineCount({
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            var valor = void 0;
            var valorTotal = 0;
            var valorInicial = 0;
            for (var i = 0; i < lineCount; i++) {
                var currentCheckBoxReparcelar_1 = currentRecord.getSublistValue({
                    fieldId: 'custpage_lrc_reparcelar',
                    line: i,
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                });
                if (currentCheckBoxReparcelar_1 == true && currentRecord.getCurrentSublistIndex({ sublistId: 'custpage_lrc_selecao_de_reparcelamento' }) != i) {
                    valor = currentRecord.getSublistValue({
                        fieldId: 'custpage_lrc_valor',
                        line: i,
                        sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                    });
                    valorTotal += Number(valor);
                    currentRecord.setValue({
                        fieldId: 'custpage_lrc_soma_total_parcelas',
                        value: valorTotal
                    });
                }
            }
            var currentCheckBoxReparcelar = currentRecord.getCurrentSublistValue({
                fieldId: 'custpage_lrc_reparcelar',
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            if (currentCheckBoxReparcelar == true) {
                valor = currentRecord.getCurrentSublistValue({
                    fieldId: 'custpage_lrc_valor',
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                });
                valorTotal += Number(valor);
                currentRecord.setValue({
                    fieldId: 'custpage_lrc_soma_total_parcelas',
                    value: valorTotal
                });
            }
            else if (currentCheckBoxReparcelar == false) {
                currentRecord.setValue({
                    fieldId: 'custpage_lrc_soma_total_parcelas',
                    value: valorTotal
                });
            }
        }
    };
    exports.fieldChanged = fieldChanged;
    var redirecionar = function () {
        var record = currentRecord_1.default.get();
        var array = [];
        var parcela;
        var valor;
        var valorTotal = 0;
        var lineCount = record.getLineCount({
            sublistId: 'custpage_lrc_selecao_de_reparcelamento'
        });
        var faturaPai = record.getValue({
            fieldId: 'custpage_lrc_fatura_principal'
        });
        for (var i = 0; i < lineCount; i++) {
            var currentCheckBoxReparcelar_2 = record.getSublistValue({
                fieldId: 'custpage_lrc_reparcelar',
                line: i,
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            if (currentCheckBoxReparcelar_2 == true && record.getCurrentSublistIndex({ sublistId: 'custpage_lrc_selecao_de_reparcelamento' }) != i) {
                parcela = record.getSublistValue({
                    fieldId: 'custpage_lrc_fatura',
                    line: i,
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                });
                array.push(parcela);
                valor = record.getSublistValue({
                    fieldId: 'custpage_lrc_valor',
                    line: i,
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                });
                valorTotal += Number(valor);
            }
        }
        var currentCheckBoxReparcelar = record.getCurrentSublistValue({
            fieldId: 'custpage_lrc_reparcelar',
            sublistId: 'custpage_lrc_selecao_de_reparcelamento'
        });
        if (currentCheckBoxReparcelar == true) {
            parcela = record.getCurrentSublistValue({
                fieldId: 'custpage_lrc_fatura',
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            array.push(parcela);
            valor = record.getCurrentSublistValue({
                fieldId: 'custpage_lrc_valor',
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            valorTotal += Number(valor);
        }
        var redirecionar = url_1.default.resolveScript({
            scriptId: 'customscript_lrc_simulacao_reparcelament',
            deploymentId: 'customdeploy_lrc_simulacao_reparcelament',
            params: {
                valor: valorTotal,
                parcela: JSON.stringify(array),
                faturaPai: faturaPai
            }
        });
        window.location.replace(redirecionar);
    };
    exports.redirecionar = redirecionar;
    var validateDelete = function (ctx) {
        var record = ctx.currentRecord;
        var valorCampo = record.getValue({
            fieldId: 'custpage_lrc_programa_alterou'
        });
        if (valorCampo == true) {
            return true;
        }
        else {
            alert();
            return false;
        }
    };
    exports.validateDelete = validateDelete;
    var validateLine = function (ctx) {
        var record = ctx.currentRecord;
        var sublistIndex = record.getCurrentSublistIndex({
            sublistId: 'custpage_lrc_selecao_de_reparcelamento'
        });
        var lineCount = record.getLineCount({
            sublistId: 'custpage_lrc_selecao_de_reparcelamento'
        });
        var valorCampo = record.getValue({
            fieldId: 'custpage_lrc_programa_alterou'
        });
        if (valorCampo == true) {
            return true;
        }
        else { // se estiver adicionando uma, ele impede
            return sublistIndex < lineCount;
        }
    };
    exports.validateLine = validateLine;
    var validateInsert = function (ctx) {
        var record = ctx.currentRecord;
        var valorCampo = record.getValue({
            fieldId: 'custpage_lrc_programa_alterou'
        });
        if (valorCampo == true) {
            return true;
        }
        else {
            return false;
        }
    };
    exports.validateInsert = validateInsert;
});
