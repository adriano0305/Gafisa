/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript para definir as funções da criação de modelo de requisição das tarefas de modelo de projeto
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record", "N/currentRecord", "N/query"], function (require, exports, search_1, record_1, currentRecord_1, query) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.cancelarParamsReq = exports.salvarParamsReq = exports.fieldChanged = exports.pageInit = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    query = __importDefault(query);
    // import * as CriarRequisicao from "./criarRequisicao";
    var pageInit = function (ctx) {
        var currentRecord = ctx.currentRecord;
        if (currentRecord.getValue('custpage_lrc_modelo_relacionado')) {
            atualizarSelectTarefaRelacionada(ctx);
            var projetoLookup = search_1.default.lookupFields({
                type: 'job',
                id: currentRecord.getValue('custpage_lrc_modelo_relacionado'),
                columns: [
                    'subsidiary'
                ]
            });
            currentRecord.setValue({
                fieldId: 'custpage_lrc_subsidiaria',
                value: projetoLookup.subsidiary[0].value
            });
        }
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var currRecord = ctx.currentRecord;
        // Verifica se o campo modificado é o "Modelo Relacionado"
        if (ctx.fieldId === 'custpage_lrc_modelo_relacionado') {
            atualizarSelectTarefaRelacionada(ctx);
        }
        if (ctx.fieldId === 'custpage_lrc_mod_proj_taf_relacionada') {
            if (currRecord.getValue('custpage_lrc_mod_proj_taf_relacionada')) {
                var tarefaLookup = search_1.default.lookupFields({
                    type: 'projecttask',
                    id: currRecord.getValue('custpage_lrc_mod_proj_taf_relacionada'),
                    columns: [
                        'startdate',
                        'enddate'
                    ]
                });
                var dataInicio = tarefaLookup.startdate.split(' ');
                dataInicio[0] = dataInicio[0].replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                dataInicio[0] = new Date(dataInicio[0]);
                var dataFinal = tarefaLookup.enddate.split(' ');
                console.log(dataFinal[0]);
                dataFinal[0] = dataFinal[0].replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                dataFinal[0] = new Date(dataFinal[0]);
                currRecord.setValue({
                    fieldId: 'custpage_lrc_data',
                    value: dataInicio[0]
                });
                currRecord.setValue({
                    fieldId: 'custpage_lrc_data_entrega',
                    value: dataFinal[0]
                });
            }
        }
        if (ctx.fieldId == 'custpage_taxa_estimada' || ctx.fieldId == 'custpage_quantidade') {
            currRecord.selectLine({
                sublistId: 'custpage_itens',
                line: ctx.line
            });
            var taxa = currRecord.getCurrentSublistValue({
                fieldId: 'custpage_taxa_estimada',
                sublistId: 'custpage_itens',
            });
            var qtd = currRecord.getCurrentSublistValue({
                fieldId: 'custpage_quantidade',
                sublistId: 'custpage_itens',
            });
            if (taxa && qtd) {
                var valor = Number(taxa) * Number(qtd);
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_valor_estimado',
                    sublistId: 'custpage_itens',
                    value: valor
                });
                currRecord.commitLine({
                    sublistId: 'custpage_itens'
                });
                currRecord.selectLine({
                    sublistId: 'custpage_itens',
                    line: ctx.line
                });
            }
        }
        if (ctx.fieldId == 'custpage_item') {
            currRecord.selectLine({
                sublistId: 'custpage_itens',
                line: ctx.line
            });
            var item = currRecord.getCurrentSublistValue({
                fieldId: 'custpage_item',
                sublistId: 'custpage_itens',
            });
            if (item) {
                var queryResults = query.default.runSuiteQL({
                    query: "select purchaseunit from item where id = ?",
                    params: [item]
                })
                var records = queryResults.asMappedResults();
                var unidade = 0;
                if (records.length > 0) {
                    unidade = records[0].purchaseunit
                }
                var unidadeText = void 0;
                // var unidade = itemRecord.getValue('purchaseunit');
                if (unidade != 0) {
                    unidadeText = itemRecord.getText('purchaseunit');
                }
                if (unidadeText) {
                    var unidadeSearch = search_1.default.create({
                        type: 'unitstype',
                        filters: [
                            ['name', 'is', unidadeText]
                        ]
                    }).run().getRange({
                        start: 0,
                        end: 1
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_unidades',
                        sublistId: 'custpage_itens',
                        value: unidadeSearch[0].id
                    });
                    currRecord.commitLine({
                        sublistId: 'custpage_itens'
                    });
                    currRecord.selectLine({
                        sublistId: 'custpage_itens',
                        line: ctx.line
                    });
                }
            }
        }
    };
    exports.fieldChanged = fieldChanged;
    // Adicionar as opções no campo de Tarefa Relacionada baseado no modelo de requisição selecionado
    var atualizarSelectTarefaRelacionada = function (ctx) {
        var modeloProjetoId = String(ctx.currentRecord.getValue('custpage_lrc_modelo_relacionado'));
        var tarefaRelacionadaField = ctx.currentRecord.getField({
            fieldId: 'custpage_lrc_mod_proj_taf_relacionada'
        });
        tarefaRelacionadaField.removeSelectOption({
            value: null,
        });
        tarefaRelacionadaField.insertSelectOption({
            text: '',
            value: ''
        });
        search_1.default.create({
            type: 'projecttask',
            filters: [
                ['company', 'IS', modeloProjetoId]
            ],
            columns: [
                'title'
            ]
        }).run().each(function (tarefaProjeto) {
            tarefaRelacionadaField.insertSelectOption({
                value: String(tarefaProjeto.id),
                text: String(tarefaProjeto.getValue('title'))
            });
            return true;
        });
    };
    // export const abrirInterfaceCriacaoModeloRequisicao = () => {
    //     let currentRecord = CurrentRecord.get();
    //     let url = URL.resolveScript({
    //         deploymentId: 'customdeploy_criacao_param_req',
    //         scriptId:'customscript_lrc_suitelet_criac_par_req',
    //         params: {
    //             modeloDeProjetoId: String(currentRecord.getValue('id'))
    //         }
    //     });
    //     window.open(url, "_blank");
    // }
    //botão salvar requisção (SuiteLet_criacaoParametrosReq)
    var salvarParamsReq = function () {
        var currentRecord = currentRecord_1.default.get();
        var newParamReqRecord = record_1.default.create({
            type: 'customrecord_lrc_param_req_mod_projeto'
        });
        if (currentRecord.getValue('custpage_lrc_solicitante')) {
            newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_mod_proj_solicitante',
                value: currentRecord.getValue('custpage_lrc_solicitante')
            });
        }
        else {
            alert('Preencha o campo solicitante.');
            return;
        }
        if (currentRecord.getValue('custpage_lrc_data_entrega')) {
            newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_mod_proj_data_entrega',
                value: currentRecord.getValue('custpage_lrc_data_entrega')
            });
        }
        else {
            alert('Preencha o campo data de entrega.');
            return;
        }
        newParamReqRecord.setValue({
            fieldId: 'custrecord_lrc_mod_proj_subsidiaria',
            value: currentRecord.getValue('custpage_lrc_subsidiaria')
        });
        if (currentRecord.getValue('custpage_lrc_data')) {
            newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_mod_proj_data',
                value: currentRecord.getValue('custpage_lrc_data')
            });
        }
        else {
            alert('Preencha o campo data.');
            return;
        }
        newParamReqRecord.setValue({
            fieldId: 'custrecord_lrc_mod_proj',
            value: currentRecord.getValue('custpage_lrc_modelo_relacionado')
        });
        if (currentRecord.getValue('custpage_lrc_mod_proj_taf_relacionada')) {
            var tarefaProjeto = newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_taf_proj_relacionada',
                value: currentRecord.getValue('custpage_lrc_mod_proj_taf_relacionada')
            });
        }
        else {
            alert('Preencha o campo tarefa relacionada.');
            return;
        }
        var quantidadeLinhasSublistItens = currentRecord.getLineCount({ sublistId: 'custpage_itens' });
        var itens = [];
        var auxCamposVazios = 1;
        for (var i = 0; i < quantidadeLinhasSublistItens; i++) {
            var itemId = currentRecord.getSublistValue({
                sublistId: 'custpage_itens',
                line: i,
                fieldId: 'custpage_item'
            });
            if (!itemId) {
                alert('Preencha o campo "item" da linha ' + i + ".");
                return;
            }
            // const fornecedor = currentRecord.getSublistValue({
            //     sublistId: 'custpage_itens',
            //     line: i,
            //     fieldId: 'custpage_fornecedor'
            // });   
            var unidades = currentRecord.getSublistValue({
                sublistId: 'custpage_itens',
                line: i,
                fieldId: 'custpage_unidades'
            });
            var descricao = currentRecord.getSublistValue({
                sublistId: 'custpage_itens',
                line: i,
                fieldId: 'custpage_descricao'
            });
            if (!descricao) {
                alert('Preencha o campo "descricao" da linha ' + i + ".");
                return;
            }
            var taxaEstimada = Number(currentRecord.getSublistValue({
                sublistId: 'custpage_itens',
                line: i,
                fieldId: 'custpage_taxa_estimada'
            }));
            if (!taxaEstimada) {
                alert('Preencha o campo "Taxa Estimada" da linha ' + i + ".");
                return;
            }
            var quantidade = Number(currentRecord.getSublistValue({
                sublistId: 'custpage_itens',
                line: i,
                fieldId: 'custpage_quantidade'
            }));
            var valor = Number(currentRecord.getSublistValue({
                sublistId: 'custpage_itens',
                line: i,
                fieldId: 'custpage_valor_estimado'
            }));
            if (!quantidade) {
                alert('Preencha o campo "quantidade" da linha ' + i + ".");
                return;
            }
            var item = {
                item: String(itemId),
                quantidade: String(quantidade),
                // fornecedor: String(fornecedor),
                unidades: String(unidades),
                descricao: String(descricao),
                taxaEstimada: String(taxaEstimada),
                valorEstimado: String(valor),
            };
            itens.push(item);
            if (quantidade == null || taxaEstimada == null) {
                auxCamposVazios = 1;
            }
            else {
                auxCamposVazios = 0;
            }
        }
        // newParamReqRecord.setValue({
        //     fieldId: 'custrecord_lrc_sublist_itens_data',
        //     value: JSON.stringify(itens)
        // });
        if (tarefaProjeto == null || itens == null || auxCamposVazios == 1) {
            alert("Você precisa preencher os campos obrigatórios!");
        }
        else {
            try {
                var parametroId = newParamReqRecord.save();
                for (var i = 0; i < itens.length; i++) {
                    var sublistaRecord = record_1.default.create({
                        type: 'customrecord_lrc_sublista_parametros'
                    });
                    sublistaRecord.setValue({
                        fieldId: 'custrecord_lrc_itens',
                        value: itens[i].item
                    });
                    sublistaRecord.setValue({
                        fieldId: 'custrecord_lrc_quantidade',
                        value: itens[i].quantidade
                    });
                    sublistaRecord.setValue({
                        fieldId: 'custrecord_lrc_unidades',
                        value: itens[i].unidades
                    });
                    sublistaRecord.setValue({
                        fieldId: 'custrecord_lrc_descricao2',
                        value: itens[i].descricao
                    });
                    sublistaRecord.setValue({
                        fieldId: 'custrecord_lrc_taxaesti',
                        value: itens[i].taxaEstimada
                    });
                    sublistaRecord.setValue({
                        fieldId: 'custrecord_lrc_valoresti',
                        value: itens[i].valorEstimado
                    });
                    sublistaRecord.setValue({
                        fieldId: 'custrecord_lrc_valoresti',
                        value: itens[i].valorEstimado
                    });
                    sublistaRecord.setValue({
                        fieldId: 'custrecord_lrc_parametros_sub',
                        value: parametroId
                    });
                    sublistaRecord.save({
                        ignoreMandatoryFields: true
                    });
                }
                alert("Requisição Salva!");
                console.log();
                window.close();
            }
            catch (_a) {
                alert("Ocorreu um erro ao salvar a requisição!");
            }
        }
    };
    exports.salvarParamsReq = salvarParamsReq;
    //botão cancelar requisição (SuiteLet_criacaoParametrosReq)
    var cancelarParamsReq = function () {
        window.close();
    };
    exports.cancelarParamsReq = cancelarParamsReq;
});
