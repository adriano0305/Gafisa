var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log"], function (require, exports, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.criarRequisicao = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    var criarRequisicao = function (requisicoesCompra) {
        var createdRequisicoesCompraId = [];
        try {
            log_1.default.debug('requisicoesCompra', requisicoesCompra);
            requisicoesCompra.forEach(function (requisicaoCompra) {
                var newRequisicaoCompraRecord = record_1.default.create({
                    type: 'purchaserequisition',
                });
                log_1.default.debug('afterCreate', 'afterCreate');
                newRequisicaoCompraRecord.setValue({
                    fieldId: 'entity',
                    value: String(requisicaoCompra.solicitante)
                });
                newRequisicaoCompraRecord.setValue({
                    fieldId: 'subsidiary',
                    value: String(requisicaoCompra.subsidiaria)
                });
                requisicaoCompra.data = requisicaoCompra.data.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                newRequisicaoCompraRecord.setValue({
                    fieldId: 'trandate',
                    value: new Date(requisicaoCompra.data)
                });
                requisicaoCompra.dataEntrega = requisicaoCompra.dataEntrega.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                newRequisicaoCompraRecord.setValue({
                    fieldId: 'custbody_budgetdate_cc',
                    value: new Date(requisicaoCompra.dataEntrega)
                });
                requisicaoCompra.itens.forEach(function (item, index) {
                    log_1.default.debug('item', item);
                    newRequisicaoCompraRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'item',
                        line: index,
                        value: String(item.item)
                    });
                    newRequisicaoCompraRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'quantity',
                        line: index,
                        value: String(item.quantidade)
                    });
                    newRequisicaoCompraRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'vendor',
                        line: index,
                        value: String(item.fornecedor)
                    });
                    newRequisicaoCompraRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'units',
                        line: index,
                        value: String(item.unidades)
                    });
                    newRequisicaoCompraRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'description',
                        line: index,
                        value: String(item.descricao)
                    });
                    newRequisicaoCompraRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'estimatedrate',
                        line: index,
                        value: item.taxaEstimada
                    });
                    newRequisicaoCompraRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'estimatedamount',
                        line: index,
                        value: item.taxaEstimada * item.quantidade
                    });
                    newRequisicaoCompraRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'rate',
                        line: index,
                        value: 0
                    });
                    newRequisicaoCompraRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'amount',
                        line: index,
                        value: 0
                    });
                });
                createdRequisicoesCompraId.push(newRequisicaoCompraRecord.save({ ignoreMandatoryFields: true }));
            });
            alert("Requisição criada com sucesso!");
            return createdRequisicoesCompraId;
        }
        catch (error) {
            log_1.default.debug('criarRequisicao error', error);
            alert("Ocorreu um erro! " + error);
            return [0];
        }
    };
    exports.criarRequisicao = criarRequisicao;
});
