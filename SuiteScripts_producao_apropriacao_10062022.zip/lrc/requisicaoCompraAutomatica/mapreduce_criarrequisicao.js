/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* Deve ser implementado um script programado mapReduce para realizar a criação das requisições de compra de um projeto.
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record", "N/log"], function (require, exports, search_1, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    var getInputData = function () {
        return search_1.default.create({
            type: 'customrecord_lrc_param_req_mod_projeto',
            filters: [
                ['custrecord_lrc_criar_requi', 'IS', 'T'],
                'AND',
                ['custrecord_lrc_processado_modelo', 'IS', 'F']
            ],
            columns: [
                'custrecord_lrc_mod_proj_subsidiaria',
                'custrecord_lrc_mod_proj_data_entrega',
                'custrecord_lrc_mod_proj_solicitante',
                'custrecord_lrc_mod_proj_data',
                'custrecord_lrc_mod_proj',
                'custrecord_lrc_mod_proj_data_entrega',
                'custrecord_lrc_taf_proj_relacionada',
                'custrecord_lrc_sublist_itens_data',
            ]
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var req = JSON.parse(ctx.value);
        log_1.default.error('entrou no map', req);
        var dados = req.values;
        log_1.default.error("dados", dados);
        log_1.default.error('entidade', dados.custrecord_lrc_mod_proj_solicitante.value);
        var requiRecord = record_1.default.create({
            type: 'purchaserequisition'
        });
        log_1.default.error('entidade', dados.custrecord_lrc_mod_proj_solicitante.value);
        requiRecord.setValue({
            fieldId: 'entity',
            value: dados.custrecord_lrc_mod_proj_solicitante.value
        });
        requiRecord.setValue({
            fieldId: 'subsidiary',
            value: dados.custrecord_lrc_mod_proj_subsidiaria.value
        });
        var data = dados.custrecord_lrc_mod_proj_data;
        data = data.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
        data = new Date(data);
        requiRecord.setValue({
            fieldId: 'trandate',
            value: data
        });
        var entrega = dados.custrecord_lrc_mod_proj_data_entrega;
        entrega = entrega.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
        entrega = new Date(entrega);
        requiRecord.setValue({
            fieldId: 'duedate',
            value: entrega
        });
        log_1.default.error('duedate', dados.custrecord_lrc_mod_proj_data_entrega);
        requiRecord.setValue({
            fieldId: 'custbody_rsc_projeto_obra_gasto_compra',
            value: dados.custrecord_lrc_mod_proj.value
        });
        var tarefaId = parseInt(dados.custrecord_lrc_taf_proj_relacionada.value);
        var tarefaLookup = search_1.default.lookupFields({
            type: 'projecttask',
            id: tarefaId,
            columns: [
                'custevent_rsc_etapa_projeto',
                'custevent_rsc_tipo_tarefa'
            ]
        });
        requiRecord.setValue({
            fieldId: 'class',
            value: tarefaLookup.custevent_rsc_etapa_projeto[0].value
        });
        log_1.default.error('class', tarefaLookup.custevent_rsc_etapa_projeto[0].value);
        requiRecord.setValue({
            fieldId: 'custbody_lrc_modelo',
            value: req.id
        });
        var i = 0;
        search_1.default.create({
            type: 'customrecord_lrc_sublista_parametros',
            filters: [
                ['custrecord_lrc_parametros_sub', 'IS', req.id]
            ],
            columns: [
                'custrecord_lrc_itens',
                'custrecord_lrc_quantidade',
                'custrecord_lrc_unidades',
                'custrecord_lrc_descricao2',
                'custrecord_lrc_taxaesti',
                'custrecord_lrc_valoresti'
            ]
        }).run().each(function (item) {
            requiRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'item',
                value: item.getValue('custrecord_lrc_itens'),
                line: i
            });
            // Log.error('item', item.getText('custrecord_lrc_itens'))
            requiRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'class',
                value: tarefaLookup.custevent_rsc_etapa_projeto[0].value,
                line: i
            });
            requiRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'estimatedamount',
                value: item.getValue('custrecord_lrc_valoresti'),
                line: i
            });
            requiRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'customer',
                value: dados.custrecord_lrc_mod_proj.value,
                line: i
            });
            requiRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'projecttask',
                value: dados.custrecord_lrc_taf_proj_relacionada.value,
                line: i
            });
            requiRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'quantity',
                value: item.getValue('custrecord_lrc_quantidade'),
                line: i
            });
            requiRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'description',
                value: item.getValue('custrecord_lrc_descricao2'),
                line: i
            });
            i++;
            log_1.default.error('fimSublista', 'done');
            return true;
        });
        try {
            var idRequi = requiRecord.save({
                ignoreMandatoryFields: true
            });
            var paramRecord = record_1.default.load({
                type: 'customrecord_lrc_param_req_mod_projeto',
                id: String(req.id)
            });
            paramRecord.setValue({
                fieldId: 'custrecord_lrc_processado_modelo',
                value: true
            });
            paramRecord.setValue({
                fieldId: 'custrecord_rsc_data_limite_contratacao',
                value: new Date()
            });
            log_1.default.error('date', new Date());
            paramRecord.save({
                ignoreMandatoryFields: true
            });
            log_1.default.error('id', idRequi);
        }
        catch (e) {
            log_1.default.error('error', e);
        }
    };
    exports.map = map;
});
