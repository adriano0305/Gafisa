/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * RecordTransformTest.ts
 * Teste de "Record Transform" de uma PARCELA RSC para uma Venda a Vista
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/record", "N/search", "N/redirect"], function (require, exports, log_1, record_1, search_1, redirect_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    redirect_1 = __importDefault(redirect_1);
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            log_1.default.error("parameters", ctx.request.parameters);
            var installmentId = ctx.request.parameters.id;
            log_1.default.error("installmentId", installmentId);
            var installmentLookup = search_1.default.lookupFields({
                type: "customsale_termos_rsc",
                id: installmentId,
                columns: ["trandate"]
            });
            var installmentTrandate = installmentLookup["trandate"];
            var cashSale = record_1.default.transform({
                fromType: "customsale_termos_rsc",
                fromId: installmentId,
                toType: record_1.default.Type.CASH_SALE,
            });
            var postingPeriod = cashSale.getValue("postingperiod");
            log_1.default.error("postingPeriod", postingPeriod);
            cashSale.setText({
                fieldId: "trandate",
                text: String(installmentTrandate)
            });
            cashSale.setValue({
                fieldId: "custbody_lrc_parcela_rsc",
                value: installmentId
            });
            var cashSaleId = cashSale.save({
                ignoreMandatoryFields: true
            });
            redirect_1.default.toRecord({
                type: String(record_1.default.Type.CASH_SALE),
                id: cashSaleId
            });
        }
        else {
            ctx.response.write({ output: "Metodo invalido" });
        }
    };
});
