/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * RestletTranslateSymbols.ts
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/log", "./lib/parser", "N/record", "N/runtime", "N/redirect"], function (require, exports, UI, log_1, parser_1, record_1, runtime_1, redirect_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    log_1 = __importDefault(log_1);
    parser_1 = __importDefault(parser_1);
    record_1 = __importDefault(record_1);
    runtime_1 = __importDefault(runtime_1);
    redirect_1 = __importDefault(redirect_1);
    var onRequest = function (ctx) {
        if (ctx.request.method == 'GET') {
            var form = UI.createForm({
                title: 'Informações GCP'
            });
            form.clientScriptModulePath = "./clientScript_menssagem.js";
            form.addField({
                id: 'custpage_lrc_anexar_documento',
                label: 'Anexar Documento',
                type: UI.FieldType.FILE
            });
            form.addSubmitButton({
                label: 'Enviar'
            });
            ctx.response.writePage(form);
        }
        else {
            var folderId = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_caminho_pasta_csv' });
            var file = ctx.request.files['custpage_lrc_anexar_documento'];
            var contents = file.getContents();
            // const fileObj = File.create({
            //     fileType: File.Type.PLAINTEXT,
            //     name: file
            // })
            log_1.default.error('contents', contents);
            log_1.default.error('File', file);
            file.folder = folderId;
            var fileId_1 = file.save();
            log_1.default.error('fileId', fileId_1);
            var parsedContent = parser_1.default.parseCSV(contents, ";");
            log_1.default.error('parserdContent', parsedContent);
            if (parsedContent.error) {
                throw Error(parsedContent.error);
            }
            var fieldObj_1 = {
                'situaçãodaremessa': 'custrecord_lrc_status_',
                'datadafatura': 'custrecord_lrc_data',
                'tipodocumento': 'custrecord_lrc_tipo_do_documento',
                'codempresa': 'custrecord_lrc_fornecedor_numero',
                'textocabeçalho': 'custrecord_lrc_memo',
                'codfornecedor': 'custrecord_lrc_fornecedor',
                'valor': 'custrecord_lrc_valor',
                'condiçãodepagamento': 'custrecord_lrc_condicoes',
                'database': 'custrecord_lrc_entregar_ate',
                'textoitem': 'custrecord_lrc_item',
                'contadébito': 'custrecord_lrc_conta_despesa_padrao',
                'divisãodébito': 'custrecord_lrc_forma_de_parcelamento',
                'centrodecusto': 'custrecord_lrc_conta',
                'idprocesso': 'custrecord_lrc_id_interno_da_cobranca',
                'nprocesso': 'custrecord_lrc_numero_da_transacao',
                'referencia': 'custrecord_lrc_numero_de_referencia',
                'autor': 'custrecord_lrc_proprietario',
                'lançamento': 'custrecord_lrc_lancamento',
            };
            var data = parsedContent.data; // um array de objetos, em que cada obj representa uma linha do CSV.
            data.forEach(function (row) {
                var record = record_1.default.create({
                    type: 'customrecord_lrc_informa_gcp',
                });
                Object.keys(fieldObj_1).forEach(function (key) {
                    var rowValue = row[key]; // pegando valor da coluna "key" na linha.
                    var fieldId = fieldObj_1[key]; // pegando o campo correspondente a coluna "Key".   
                    if (rowValue) {
                        record.setValue({
                            fieldId: fieldId,
                            value: rowValue,
                        });
                    }
                });
                record.setValue({
                    fieldId: 'custrecord_lrc_documento_recebido',
                    value: fileId_1
                });
                record.save();
            });
            redirect_1.default.toSuitelet({
                deploymentId: 'customdeploy1',
                scriptId: 'customscript_lrc_informa_gcp',
                parameters: {
                    message: 'Sucesso!'
                }
            });
        }
    };
    exports.onRequest = onRequest;
});
