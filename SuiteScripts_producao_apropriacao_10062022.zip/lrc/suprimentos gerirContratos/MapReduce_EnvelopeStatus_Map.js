/**
 *@NApiVersion 2.x
 *@NScriptType MapReduceScript
 *
 * EnvelopeStatus_Map.ts
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log", "N/https", "N/record", "N/runtime"], function (require, exports, search_1, log_1, https_1, record_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    https_1 = __importDefault(https_1);
    record_1 = __importDefault(record_1);
    runtime_1 = __importDefault(runtime_1);
    var getInputData = function () {
        return search_1.default.create({
            type: "customrecord_lrc_envelopedocusign",
            filters: [
                ['id', 'greaterthan', 0]
            ],
            columns: [
                'custrecord_lrc_camp_campo',
                'custrecord_lrc_status_envelopeducusign'
            ]
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var req = JSON.parse(ctx.value);
        var envelopeRecord = req.values;
        var envelopeRecordId = req.id;
        var GUID = envelopeRecord.custrecord_lrc_camp_campo;
        var status = envelopeRecord.custrecord_lrc_status_envelopeducusign;
        var base_uri = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_base_uri' });
        var account_id = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_account_id' });
        var access_token = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_access_token' });
        log_1.default.error('entrou no map', GUID);
        var response = https_1.default.request({
            method: https_1.default.Method.GET,
            url: base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID,
            headers: {
                "Authorization": "Bearer" + " " + access_token
            }
        });
        log_1.default.debug("response", response);
        var record = record_1.default.load({
            type: 'customrecord_lrc_envelopedocusign',
            id: envelopeRecordId,
            isDynamic: true
        });
        var bodyobj = JSON.parse(response.body);
        log_1.default.error('objetos', bodyobj);
        record.setValue({
            fieldId: 'custrecord_lrc_camp_campo',
            value: bodyobj.status
        });
    };
    exports.map = map;
});
