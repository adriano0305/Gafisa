/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * DocumentSHipping.js
 * 
 * 
 * 
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/task", "N/file", "N/runtime", "N/log", "N/record", "N/https"], function (require, exports, task_1, file_1, runtime_1, log_1, record_1, https_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    task_1 = __importDefault(task_1);
    file_1 = __importDefault(file_1);
    runtime_1 = __importDefault(runtime_1);
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    https_1 = __importDefault(https_1);
    //  import { getAcessToken } from "./Suitelet_getToken";
    var beforeSubmit = function (ctx) {
        var record = ctx.newRecord;
        var envelope_id = record.getValue('custrecord_lrc_envelope');
        var envelopeRecord = record_1.default.load({
            type: 'customrecord_lrc_envelopedocusign',
            id: envelope_id,
            isDynamic: true,
        });
        var GUID = envelopeRecord.getValue('custrecord_lrc_camp_campo');
        var access_token = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_access_token' });
        var base_uri = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_base_uri' });
        var account_id = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_account_id' });
        var contratoPdf = record.getValue('custrecord_lrc_contrato_pdf');
        //Conversão em BASE_64
        var Fileobj = file_1.default.load({
            id: contratoPdf
        });
        log_1.default.error("Fileobj", Fileobj);
        var stringFile = Fileobj.getContents();
        log_1.default.error("stringFile", stringFile);
        var base64EncodedString = stringFile;
        log_1.default.error("base64XML", base64EncodedString);
        log_1.default.error('acess token', access_token);
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT) {
            var evelopeLocks = https_1.default.request({
                method: https_1.default.Method.POST,
                url: base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID + "/lock",
                body: JSON.stringify({
                    "lockType": "edit"
                }),
                headers: {
                    'Authorization': "Bearer" + " " + access_token,
                    'Content-Type': "application/json"
                }
            });
            log_1.default.error("evelopeLocks", evelopeLocks);
            log_1.default.error("lock create url", base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID + "/lock");
            var body = JSON.parse(evelopeLocks.body);
            var lockToken = body.lockToken;
            log_1.default.error("body", body);
            if (evelopeLocks.code.toString().substring(0, 1) == "2") {
                var changeEnvelope = https_1.default.request({
                    method: https_1.default.Method.PUT,
                    url: base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID + "/documents",
                    body: JSON.stringify({
                        "documents": [
                            {
                                "documentId": ctx.newRecord.getValue('custrecord_lrc_documentid'),
                                "name": Fileobj.name,
                                "order": ctx.newRecord.getValue('custrecord_lrc_ordem'),
                                "documentBase64": base64EncodedString
                            }
                        ]
                    }),
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": "Bearer" + " " + access_token,
                        "X-DocuSign-Edit": JSON.stringify({ "LockToken": lockToken })
                    }
                });
                log_1.default.error('documents', JSON.stringify({
                    "documents": [
                        {
                            "documentId": ctx.newRecord.getValue('custrecord_lrc_documentid'),
                            "name": Fileobj.name,
                            "order": ctx.newRecord.getValue('custrecord_lrc_ordem'),
                            "documentBase64": base64EncodedString
                        }
                    ]
                }));
                log_1.default.error('url changeenvelope', base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID + "/documents");
                log_1.default.error('change envelope', changeEnvelope);
                var lockRemove = https_1.default.request({
                    method: https_1.default.Method.DELETE,
                    url: base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID + "/lock",
                    body: "",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": "Bearer" + " " + access_token,
                        "X-DocuSign-Edit": JSON.stringify({ "LockToken": lockToken })
                    }
                });
                log_1.default.error('url lockremove', base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID + "/lock");
                log_1.default.error("lockRemove", lockRemove);
            }
            else {
                var mapReduceScriptId = task_1.default.create({
                    taskType: task_1.default.TaskType.MAP_REDUCE,
                    scriptId: 'customscript_lrc_mapreduce_envelope',
                    deploymentId: 'customdeploy_lrc_imple_mapreduce_envelop'
                });
                log_1.default.error('entrou no else', mapReduceScriptId);
                var activemapReduce = mapReduceScriptId.submit();
                log_1.default.error('mapreduce', activemapReduce);
                throw Error("O documento está sendo editado por outra pessoa. Em breve, um script programado irá realizar as mudanças solicitadas.");
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
