/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_botao_preview.ts
* 
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/redirect", "N/https", "N/runtime"], function (require, exports, log_1, redirect_1, https_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    log_1 = __importDefault(log_1);
    redirect_1 = __importDefault(redirect_1);
    https_1 = __importDefault(https_1);
    runtime_1 = __importDefault(runtime_1);
    // import { getAcessToken } from "./Suitelet_getToken";
    var onRequest = function (ctx) {
        var parametros = ctx.request.parameters;
        // let access_token = request.access_token;
        var base_uri = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_base_uri' });
        var account_id = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_account_id' });
        var access_token = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_access_token' });
        var GUID = parametros.GUID;
        var dootaxApiResponse = https_1.default.request({
            method: https_1.default.Method.POST,
            url: base_uri + "/restapi/v2.1/accounts/" + account_id + "/envelopes/" + GUID + "/views/recipient_preview",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + access_token.toString()
            },
            body: JSON.stringify({
                "authentication_method": "None",
                "returnUrl": "https://google.com"
                // URL.resolveRecord({
                //     recordId: parametros.envelopeId,
                //     recordType: 'customrecord_lrc_envelopedocusign'
                // })
            })
        });
        log_1.default.error('url', base_uri + "/restapi/v2.1/accounts/" + account_id + "/envelopes/" + GUID + "/views/recipient_preview");
        log_1.default.error('access_token', access_token);
        if (dootaxApiResponse.code.toString().substring(0, 1) == "2") {
            var bodyobj = JSON.parse(dootaxApiResponse.body);
            log_1.default.error('objetos', bodyobj);
            var redirectUrl = bodyobj.url;
            redirect_1.default.redirect({
                url: redirectUrl,
            });
        }
        else {
            throw Error('Erro na requisição: ' + dootaxApiResponse.body);
        }
        3;
    };
    exports.onRequest = onRequest;
});
