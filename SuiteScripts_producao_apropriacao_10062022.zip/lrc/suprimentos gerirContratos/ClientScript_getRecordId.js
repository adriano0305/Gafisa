/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * ClientScript_getRecordId.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url", "N/log"], function (require, exports, currentRecord_1, url_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getRecordId = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    log_1 = __importDefault(log_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var getRecordId = function () {
        var record = currentRecord_1.default.get();
        log_1.default.debug("currentRecord", record);
        var GUID = record.getValue('custrecord_lrc_camp_campo');
        window.open(url_1.default.resolveScript({
            scriptId: 'customscript_lrc_script_botao_envelope',
            deploymentId: 'customdeploy_lrc_suitelet_botaoenvelope',
            params: {
                recordId: record.id,
                GUID: GUID
            },
        }));
    };
    exports.getRecordId = getRecordId;
});
