/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * TestClientSublist.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log"], function (require, exports, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.sublistChanged = exports.validateLine = exports.validateInsert = exports.validateDelete = exports.fieldChanged = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    exports.fieldChanged = function (ctx) {
        var currRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        log_1.default.error("fieldId", fieldId);
        if (fieldId == "custrecord1409") {
            currRecord.setValue({
                fieldId: "custpage_lrc_check_validate",
                value: false
            });
            var rec = void 0;
            if (currRecord.getValue(fieldId)) {
                rec = record_1.default.load({
                    type: "customrecord_lrc_teste2",
                    id: currRecord.getValue(fieldId)
                });
            }
            var n = 0;
            if (rec) {
                n = rec.getValue("custrecord1410") || 0;
            }
            var sublistSize = currRecord.getLineCount("custpage_lrc_test");
            log_1.default.error("sublistSize", sublistSize);
            for (var i = sublistSize - 1; i >= 0; i--) {
                currRecord.removeLine({
                    sublistId: "custpage_lrc_test",
                    line: i
                });
            }
            for (var i = 0; i < n; i++) {
                currRecord.selectNewLine({
                    sublistId: "custpage_lrc_test"
                });
                currRecord.setCurrentSublistValue({
                    sublistId: "custpage_lrc_test",
                    fieldId: "custpage_lrc_criterio",
                    value: currRecord.getValue("custrecord1409"),
                    ignoreFieldChange: true
                });
                currRecord.setCurrentSublistValue({
                    sublistId: "custpage_lrc_test",
                    fieldId: "custpage_lrc_criterio_description",
                    value: "Descrição",
                    ignoreFieldChange: true
                });
                currRecord.setCurrentSublistValue({
                    sublistId: "custpage_lrc_test",
                    fieldId: "custpage_lrc_criterio_peso",
                    value: 10 * i,
                    ignoreFieldChange: true
                });
                currRecord.commitLine({
                    sublistId: "custpage_lrc_test"
                });
            }
            currRecord.setValue({
                fieldId: "custpage_lrc_check_validate",
                value: true
            });
        }
    };
    exports.validateDelete = function (ctx) {
        log_1.default.error("validateInsert", { ctx: ctx, validate: ctx.currentRecord.getValue("custpage_lrc_check_validate") });
        if (ctx.sublistId == "custpage_lrc_test") {
            if (ctx.currentRecord.getValue("custpage_lrc_check_validate")) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos a partir do modelo");
                return false;
            }
            return true;
        }
    };
    exports.validateInsert = function (ctx) {
        log_1.default.error("validateInsert", { ctx: ctx, validate: ctx.currentRecord.getValue("custpage_lrc_check_validate") });
        if (ctx.sublistId == "custpage_lrc_test") {
            if (ctx.currentRecord.getValue("custpage_lrc_check_validate")) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos a partir do modelo");
                return false;
            }
            return true;
        }
    };
    exports.validateLine = function (ctx) {
        log_1.default.error("validateLine", { ctx: ctx, validate: ctx.currentRecord.getValue("custpage_lrc_check_validate") });
        var sublistIndex = ctx.currentRecord.getCurrentSublistIndex({ sublistId: "custpage_lrc_test" });
        log_1.default.error("sublistIndex", sublistIndex);
        var sublistCount = ctx.currentRecord.getLineCount({ sublistId: "custpage_lrc_test" });
        log_1.default.error("sublistCount", sublistCount);
        if (ctx.sublistId == "custpage_lrc_test") {
            if (ctx.currentRecord.getValue("custpage_lrc_check_validate") && sublistIndex == sublistCount) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos a partir do modelo");
                return false;
            }
            else if (sublistIndex != sublistCount) {
                var avaliacao = Number(ctx.currentRecord.getCurrentSublistValue({
                    sublistId: ctx.sublistId,
                    fieldId: "custpage_lrc_avaliacao"
                }));
                log_1.default.error("avaliacao", avaliacao);
                if ((avaliacao < 0 || avaliacao > 100)) {
                    alert("Avaliação deve ser entre 0 e 100");
                    return false;
                }
                else {
                    var pesoCriterio = Number(ctx.currentRecord.getCurrentSublistValue({
                        sublistId: ctx.sublistId,
                        fieldId: "custpage_lrc_criterio_peso"
                    }));
                    log_1.default.error("pesoCriterio", pesoCriterio);
                    // Verificar se a soma dos pontos ultrapassa 100
                    var sublistCount_1 = ctx.currentRecord.getLineCount({
                        sublistId: "custpage_lrc_test"
                    });
                    log_1.default.error("sublistCount", sublistCount_1);
                    var somaPontos = 0;
                    for (var line = 0; line < sublistCount_1; line++) {
                        if (line != sublistIndex) {
                            somaPontos += Number(ctx.currentRecord.getSublistValue({
                                sublistId: "custpage_lrc_test",
                                fieldId: "custpage_lrc_pontos",
                                line: line
                            }));
                        }
                    }
                    somaPontos += (pesoCriterio / 100) * avaliacao;
                    log_1.default.error("somaPontos", somaPontos);
                    if (somaPontos > 100) {
                        alert("A soma dos pontos ultrapassou o valor de 100");
                        return false;
                    }
                    ctx.currentRecord.setCurrentSublistValue({
                        sublistId: ctx.sublistId,
                        fieldId: "custpage_lrc_pontos",
                        value: (pesoCriterio / 100) * avaliacao,
                    });
                }
            }
            return true;
        }
    };
    exports.sublistChanged = function (ctx) {
        log_1.default.error("sublistChanged", { ctx: ctx, validate: ctx.currentRecord.getValue("custpage_lrc_check_validate") });
        var sublistCount = ctx.currentRecord.getLineCount({
            sublistId: "custpage_lrc_test"
        });
        log_1.default.error("sublistCount", sublistCount);
        var somaPontos = 0;
        for (var line = 0; line < sublistCount; line++) {
            somaPontos += Number(ctx.currentRecord.getSublistValue({
                sublistId: "custpage_lrc_test",
                fieldId: "custpage_lrc_pontos",
                line: line
            }));
        }
        ctx.currentRecord.setValue({
            fieldId: "custrecord_lrc_total",
            value: somaPontos
        });
    };
});
