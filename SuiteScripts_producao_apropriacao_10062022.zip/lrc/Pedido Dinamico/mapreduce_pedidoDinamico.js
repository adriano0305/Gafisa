/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* MapReduce_fluxoEscritura.js
*
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record", "N/log"], function (require, exports, search_1, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.reduce = exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    var getInputData = function () {
        return search_1.default.create({
            type: 'customrecord_lrc_prog_pedido_dinamico',
            filters: [
                ['custrecord_lrc_indefinido', 'IS', true],
                'OR',
                ['custrecord_lrc_numero_restante', 'greaterthan', 0]
            ],
            columns: ['custrecord_lrc_periodo_pedido',
                'custrecord_lrc_prox_data',
                'custrecord_lrc_data_ped_dinamico',
                'custrecord_lrc_tipo_pedido',
                'custrecord_lrc_departamento',
                'custrecord_lrc_centro_custo',
                'custrecord_lrc_buscasalva',
                'custrecord_lrc_item_prog_dinamic',
                'custrecord_lrc_fator_pedido',
                'custrecord_lrc_descricao',
                'custrecord_lrc_indefinido',
                'custrecord_lrc_parceiro',
                'custrecord_lrc_cliente',
                'custrecord_lrc_localidade',
                'custrecord_lrc_subsidiaria'
            ]
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        log_1.default.error("entrou no map", "done");
        var req = JSON.parse(ctx.value);
        log_1.default.error('req', req);
        var progDinamic = req.values;
        log_1.default.error('progDinamic', progDinamic);
        var periodo = progDinamic.custrecord_lrc_periodo_pedido;
        var descricao = progDinamic.custrecord_lrc_descricao;
        var cliente = progDinamic.custrecord_lrc_cliente.value;
        var subsidiaria = progDinamic.custrecord_lrc_subsidiaria.value;
        var localidade = progDinamic.custrecord_lrc_localidade.value;
        var parceiro = progDinamic.custrecord_lrc_parceiro.value;
        var tipoPedido = progDinamic.custrecord_lrc_tipo_pedido.value;
        var fator = progDinamic.custrecord_lrc_fator_pedido;
        var proxData = progDinamic.custrecord_lrc_prox_data;
        proxData = proxData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
        log_1.default.error('proxdata', proxData);
        var item = progDinamic.custrecord_lrc_item_prog_dinamic.value;
        // const status = progDinamic.custrecord_lrc_status_apr.value;
        // const subsidiaria = progDinamic.custrecord_lrc_subsidiaria_ped.value;
        var departamento = progDinamic.custrecord_lrc_departamento.value;
        var centroCusto = progDinamic.custrecord_lrc_centro_custo.value;
        var buscaSalvaId = progDinamic.custrecord_lrc_buscasalva.value;
        var dataPedido = progDinamic.custrecord_lrc_data_ped_dinamico;
        dataPedido = dataPedido.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
        dataPedido = new Date(dataPedido);
        log_1.default.error('dataPedido', dataPedido);
        var dataAtual = new Date();
        var valorColName = '';
        var valorColJoin = '';
        var entidadeColName = '';
        var entidadeColJoin = '';
        var subsidiariaColName = '';
        var subsidiariaColJoin = '';
        var localidadeColName = '';
        var localidadeColJoin = '';
        var buscaSalva = search_1.default.load({
            id: String(buscaSalvaId)
        });
        var colunas = buscaSalva.columns;
        for (var i = 0; i < colunas.length; i++) {
            if (colunas[i].label.toLowerCase() == 'valor') {
                valorColName = colunas[i].name;
                valorColJoin = colunas[i].join;
            }
            if (colunas[i].label.toLowerCase() == 'entidade') {
                entidadeColName = colunas[i].name;
                entidadeColJoin = colunas[i].join;
            }
            if (colunas[i].label.toLowerCase() == 'subsidiaria') {
                subsidiariaColName = colunas[i].name;
                subsidiariaColJoin = colunas[i].join;
            }
            if (colunas[i].label.toLowerCase() == 'localidade') {
                localidadeColName = colunas[i].name;
                localidadeColJoin = colunas[i].join;
            }
        }
        if (proxData) {
            log_1.default.error("proxdata tem", "done");
            var proxDataobj = new Date(proxData);
            log_1.default.error('proxDataobj', proxDataobj);
            var data = new Date(proxDataobj.getFullYear(), proxDataobj.getMonth(), proxDataobj.getDate());
            log_1.default.error('dataAtual', dataAtual);
            var newDataAtual = new Date(dataAtual.getFullYear(), dataAtual.getMonth(), dataAtual.getDate());
            var millisecondsPerDay = 1000 * 60 * 60 * 24;
            var millisBetween = newDataAtual.getTime() - data.getTime();
            var days = millisBetween / millisecondsPerDay;
            var pedido_1 = 0;
            log_1.default.error("calculo", days);
            log_1.default.error("periodo", periodo);
            // Log.error('Periodo', lookupPeriodo['daysuntilnetdue'])
            if (days >= periodo) {
                log_1.default.error("criando pedido de venda", "done");
                buscaSalva.run().each(function (result) {
                    try {
                        var obj = {};
                        obj['entity'] = cliente || result.getValue({ name: entidadeColName, join: entidadeColJoin });
                        obj['date'] = dataPedido;
                        obj['location'] = localidade || result.getValue({ name: localidadeColName, join: localidadeColJoin });
                        obj['subsidiary'] = subsidiaria || result.getValue({ name: subsidiariaColName, join: subsidiariaColJoin });
                        obj['centroCusto'] = centroCusto;
                        obj['department'] = departamento;
                        obj['item'] = item;
                        obj['parceiro'] = parceiro;
                        obj['fator'] = Number(result.getValue({ name: valorColName, join: valorColJoin })) * fator;
                        obj['pedido'] = req.id;
                        obj['tipoPedido'] = tipoPedido;
                        ctx.write({
                            key: pedido_1++,
                            value: JSON.stringify(obj)
                        });
                    }
                    catch (e) {
                        log_1.default.error('Error', e);
                    }
                    return true;
                });
                newDataAtual.getTime();
                var diasDataAtual = newDataAtual.getTime() / millisecondsPerDay;
                var proxDataAtual = (newDataAtual + periodo);
                log_1.default.error('proxDataAtual', proxDataAtual);
                proxDataAtual = new Date(proxDataAtual);
                var pediRecord = record_1.default.load({
                    id: req.id,
                    type: 'customrecord_lrc_prog_pedido_dinamico'
                });
                pediRecord.setValue({
                    fieldId: 'custrecord_lrc_prox_data',
                    value: proxDataAtual
                });
                if (pediRecord.getValue('custrecord_lrc_indefinido') == false) {
                    pediRecord.setValue({
                        fieldId: 'custrecord_lrc_numero_restante',
                        value: Number(pediRecord.getValue('custrecord_lrc_numero_restante')) - 1
                    });
                }
                log_1.default.error('indefinido', pediRecord.getValue('custrecord_lrc_indefinido'));
                log_1.default.error('calc', Number(pediRecord.getValue('custrecord_lrc_numero_restante')) - 1);
                pediRecord.save({
                    ignoreMandatoryFields: true
                });
            }
        }
        else {
            var proxDataobj = new Date(dataPedido);
            log_1.default.error('proxDataobj', proxDataobj);
            var data = new Date(proxDataobj.getFullYear(), proxDataobj.getMonth(), proxDataobj.getDate());
            log_1.default.error('dataAtual', dataAtual);
            var newDataAtual = new Date(dataAtual.getFullYear(), dataAtual.getMonth(), dataAtual.getDate());
            var millisecondsPerDay = 1000 * 60 * 60 * 24;
            var millisBetween = newDataAtual.getTime() - data.getTime();
            var days = millisBetween / millisecondsPerDay;
            if (days >= periodo) {
                buscaSalva.run().each(function (result) {
                    var obj = {};
                    obj['entity'] = cliente || result.getValue({ name: entidadeColName, join: entidadeColJoin });
                    obj['date'] = dataPedido;
                    obj['location'] = localidade || result.getValue({ name: localidadeColName, join: localidadeColJoin });
                    obj['subsidiary'] = subsidiaria || result.getValue({ name: subsidiariaColName, join: subsidiariaColJoin });
                    obj['centroCusto'] = centroCusto;
                    obj['department'] = departamento;
                    obj['item'] = item;
                    obj['parceiro'] = parceiro;
                    obj['fator'] = Number(result.getValue({ name: valorColName, join: valorColJoin })) * fator;
                    obj['pedido'] = req.id;
                    obj['tipoPedido'] = tipoPedido;
                    ctx.write({
                        key: pedido++,
                        value: JSON.stringify(obj)
                    });
                    return true;
                });
                var pediRecord = record_1.default.load({
                    id: req.id,
                    type: 'customrecord_lrc_prog_pedido_dinamico'
                });
                pediRecord.setValue({
                    fieldId: 'custrecord_lrc_prox_data',
                    value: dataAtual + periodo
                });
                if (pediRecord.getValue('custrecord_lrc_indefinido') == false) {
                    pediRecord.setValue({
                        fieldId: 'custrecord_lrc_numero_restante',
                        value: Number(pediRecord.getValue('custrecord_lrc_numero_restante')) - 1
                    });
                }
                else {
                    pediRecord.setValue({
                        fieldId: 'custrecord_lrc_indefinido',
                        value: true
                    });
                }
                pediRecord.save({
                    ignoreMandatoryFields: true
                });
            }
        }
    };
    exports.map = map;
    var reduce = function (ctx) {
        var pedido = JSON.parse(ctx.values[0]);
        log_1.default.error('pedido', pedido);
        var entidade = pedido.entity;
        var date = pedido['date'];
        date = new Date(date);
        var localidade = pedido.location;
        var subsidiaria = pedido.subsidiary;
        var centroCusto = pedido.centroCusto;
        var departamento = pedido.department;
        var item = pedido.item;
        var fator = pedido.fator;
        var parceiro = pedido.parceiro;
        var pedidoDinamic = pedido.pedido;
        var tipoPedido = pedido.tipoPedido;
        log_1.default.error('tipoPedido', tipoPedido);
        if (tipoPedido == 1) {
            try {
                var sallesRecord = record_1.default.create({
                    type: 'salesorder'
                });
                sallesRecord.setValue({
                    fieldId: 'entity',
                    value: entidade
                });
                sallesRecord.setValue({
                    fieldId: 'partner',
                    value: parceiro
                });
                sallesRecord.setValue({
                    fieldId: 'trandate',
                    value: date
                });
                sallesRecord.setValue({
                    fieldId: 'location',
                    value: localidade
                });
                sallesRecord.setValue({
                    fieldId: 'subsidiary',
                    value: subsidiaria
                });
                sallesRecord.setValue({
                    fieldId: 'class',
                    value: centroCusto
                });
                sallesRecord.setValue({
                    fieldId: 'department',
                    value: departamento
                });
                sallesRecord.setSublistValue({
                    fieldId: 'item',
                    sublistId: 'item',
                    value: item,
                    line: 0
                });
                sallesRecord.setSublistValue({
                    fieldId: 'quantity',
                    sublistId: 'item',
                    line: 0,
                    value: 1
                });
                sallesRecord.setSublistValue({
                    fieldId: 'rate',
                    sublistId: 'item',
                    line: 0,
                    value: fator
                });
                sallesRecord.setValue({
                    fieldId: 'custbody_lrc_pedido_recorrente',
                    value: pedidoDinamic
                });
                sallesRecord.save({
                    ignoreMandatoryFields: true
                });
            }
            catch (e) {
                log_1.default.error('Error', e);
            }
        }
        else {
            try {
                if (tipoPedido == 2) {
                    var sallesRecord = record_1.default.create({
                        type: 'purchaseorder'
                    });
                    sallesRecord.setValue({
                        fieldId: 'entity',
                        value: entidade
                    });
                    sallesRecord.setValue({
                        fieldId: 'trandate',
                        value: date
                    });
                    sallesRecord.setValue({
                        fieldId: 'location',
                        value: localidade
                    });
                    sallesRecord.setValue({
                        fieldId: 'subsidiary',
                        value: subsidiaria
                    });
                    sallesRecord.setValue({
                        fieldId: 'class',
                        value: centroCusto
                    });
                    sallesRecord.setValue({
                        fieldId: 'department',
                        value: departamento
                    });
                    sallesRecord.setSublistValue({
                        fieldId: 'item',
                        sublistId: 'item',
                        value: item,
                        line: 0
                    });
                    sallesRecord.setSublistValue({
                        fieldId: 'quantity',
                        sublistId: 'item',
                        line: 0,
                        value: 1
                    });
                    sallesRecord.setSublistValue({
                        fieldId: 'rate',
                        sublistId: 'item',
                        line: 0,
                        value: fator
                    });
                    sallesRecord.setValue({
                        fieldId: 'custbody_lrc_prog_pedido_recorrente',
                        value: pedidoDinamic
                    });
                    sallesRecord.save({
                        ignoreMandatoryFields: true
                    });
                }
            }
            catch (e) {
                log_1.default.error('Error', e);
            }
        }
    };
    exports.reduce = reduce;
});
