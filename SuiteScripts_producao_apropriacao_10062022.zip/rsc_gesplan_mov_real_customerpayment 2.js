/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/query', 'N/search', 'N/record'], (query, search, record) => {

        /**
         * Defines the function that is executed when a POST request is sent to a RESTlet.
         * @param {string | Object} requestBody - The HTTP request body; request body is passed as a string when request
         *     Content-Type is 'text/plain' or parsed into an Object when request Content-Type is 'application/json' (in which case
         *     the body must be a valid JSON)
         * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
         *     Object when request Content-Type is 'application/json' or 'application/xml'
         * @since 2015.2
         */
        const post = (requestBody) => {
                log.debug({ title: 'Params', details: requestBody })

                if (!requestBody.hasOwnProperty('dataInicio') || !requestBody.hasOwnProperty('dataFinal')){
                        throw 'Parâmetros dataInicio ou dataFinal inválidos';
                }
                
                


                const operation = requestBody.tipoRegistro;
                log.debug({ title: 'Resultado', details: operation })
                return doAction(requestBody);
        }

        function doAction(body) {
                var retorno = []
                try {
                        retorno = getReal(body);
                } catch (e) {
                        retorno = JSON.stringify({ erro: e.toString() });
                }
                return retorno;
        }

        const ZERO = Number('0').toFixed(2);


        //gera o retorn
        class GesplanReturnEngine {
                constructor(jsonExtractor) {
                        this.jsonExtractor = jsonExtractor;
                        this.prefix = "_";
                }
                setPrefix(prefix) {
                        this.prefix = prefix;
                }
                getPrefix() {
                        return this.prefix;
                }
                calculate() {
                        
                        var _items       = this.jsonExtractor.getItems();
                        var _instalments = this.jsonExtractor.getInstalments();
                        let returnList   = [];
                        

                        //[[{"id":"112654_1","quantity":1,"rate":5000,"refamt":5000,"origrate":5000,"grossamt":4692.5,"amount":5000}]]
                        _items.forEach((itemBox) => {

                                let _return = {
                                        id: itemBox.transactiontype + itemBox.transactionid,
                                        records: []
                                }

                                //log.debug("item box",  "item box id "+itemBox.transactionid +" : " + JSON.stringify(itemBox));

                                //para cada item dentro da caixa de itens
                                itemBox.items.forEach((item, idxItem) => {
                                        log.debug("--item-- ", "itembox.item : " + idxItem + "  " + item.id + " - qty: " + item.quantity + " - amount: " + item.amount);

                                        //filtra as parcelas que sao da transaction id igual a transactionid dos itens                                       
                                        _instalments.filter((parcelaBox) => {

                                                return (itemBox.transactionid == parcelaBox.transactionid)

                                        }).forEach((parcelaBox) => {
                                                log.debug("---parcelaBox---", 'parcelaBox qtde: ' + JSON.stringify(parcelaBox));

                                                //run through all the instalments
                                                /**
                                                 * parcela - item dentro do array instalments
                                                 * idx - index do array instalments
                                                 * iAndI array 
                                                 */
                                                parcelaBox.instalments.forEach((parcela, idx, iAndI) => {
                                                        log.debug("parcela: " + idx, JSON.stringify(parcela));

                                                        let qtdeParcelas = iAndI.length;
                                                        let gesplanValorItem = 0;
                                                        try {
                                                                gesplanValorItem = parseInt(item.amount) / parseInt(qtdeParcelas);

                                                        } catch (e) {
                                                                log.error("erro", "erro ao calcular item para gesplan: " + e.toString());

                                                        }


                                                        let _gesplanRec = new GesplanRetorno();

                                                        let _record = {
                                                                id: this.getPrefix() + "." + (idxItem + 1) + "." + (idx + 1),
                                                                itemSeq: idxItem + 1,
                                                                itemValue: item.amount,
                                                                instalmentQty: qtdeParcelas,
                                                                instalmentSeq: idx + 1,
                                                                instalmentDueDate: parcela.dtvcto,
                                                                instalmentValue: parcela.valor,
                                                                instalmentPaymentDate: parcela.dtpgto,
                                                                instalmentPaidValue: parcela.valorpago,
                                                                instalmentCalculatedValue: gesplanValorItem,
                                                                instalmentDifference: gesplanValorItem - parcela.valorpago,
                                                                instalmentDifferencePercentage: new String(Number(((gesplanValorItem - parcela.valorpago) / gesplanValorItem) * 100).toFixed(2)) + " %",
                                                        }

                                                        _return.records.push(_record);

                                                })

                                        })

                                });
                                returnList.push(_return);
                        });
                        return returnList;

                }
        }

        class JsonExtractor {
                constructor() {
                        this.instalments = [];
                        this.items = [];
                }
                setInstalments(instalments) {
                        if (!instalments) {
                                log.warning("customer Payment Item Reader  ", "cannot read from : " + this.instalments);
                        }
                        this.instalments = JSON.parse(instalments);
                }
                setItems(items) {
                        if (!items) {
                                log.warning("customer Payment Item Reader  ", "cannot read from : " + this.items);
                        }
                        this.items = JSON.parse(items);
                }

                getInstalments(transactionId) {
                        /*
                        let allInstalments = this._getAllInstalments();
                        if (transactionId) {
                                return allInstalments.filter(transaction => transaction.transactionid == transactionId);
                        }
                        return allInstalments;
                        */
                        return this.instalments;

                }
                _getAllInstalments() {
                        let instalments = this.instalments;
                        return instalments.map(transaction => transaction.instalments)
                }
                _getAllItems() {
                        let items = this.items;
                        return items.map(transaction => transaction.items)
                }

                getItems(transactionId) {
                        /*
                        let allItems = this._getAllItems();
                        if (transactionId) {
                                return allItems.filter(items => items.transactionid == transactionId);
                        }
                        return allItems;
                        */
                        return this.items;
                }


        }




        /*deprecated*/
        function getReal(body) {
                log.debug({ title: 'Select', details: 'Entrou no processo' });

                var tb_stage_empresa = [];
                var msg = "";
                // Run the query.
                try {
                        //select TO_CHAR(lastModifiedDate,'DD/MM/YYYY HH:MI:SS') lastModifiedDate, b.subsidiary, a.id, a.trandate, a.duedate, a.trandate, a.memo, a.custbody4, a.transactionNumber, c.account, b.class, a. CUSTBODY_ENL_VENDORPAYMENTACCOUNT, currency, a.foreigntotal total, c.amount, a.exchangerate, a.entity, a.type from transaction a join transactionline b on a.id = b.transaction join transactionaccountingline c on a.id = c.transaction and b.id = c.transactionline where  type in ('VendPymt', 'CustPymt') and void = 'F'
                        var queryResults
                        var sql = 'select TO_CHAR(a.lastModifiedDate,\'DD/MM/YYYY HH:MI:SS\') lastModifiedDate, b.department departament,b.subsidiary, a.id, a.trandate, a.duedate, a.memo, ' +
                                'a.custbody4, a.transactionNumber, c1.acctnumber account, b.class, a.enddate, a. CUSTBODY_ENL_VENDORPAYMENTACCOUNT, ' +
                                'd.symbol currency, a.foreigntotal total, c.amount, a.exchangerate, a.entity, a.type, a.closedate, e.tipo, b.class, a.custbody_lrc_invoice_met_pag_fatura,  ' +
                                //'b.item as itemid, ' +
                                //'b.linesequencenumber as itemsequence, ' +
                                'c2.custrecord_rsc_cnab_bank_code_ds || \'|\' || custrecord_rsc_cnab_ba_agencynumber_ls || custrecord_rsc_cnab_ba_dvagencynumber_ds || \'|\' || custrecord_rsc_cnab_ba_number_ds || custrecord_rsc_cnab_ba_dvnumber_ds as conta, ' +
                                'a.custbody_rsc_installments, ' +
                                'a.custbody_rsc_gesplan_items_json ' +

                                'from transaction a ' +

                                'join transactionline b on a.id = b.transaction ' +
                                'join transactionaccountingline c on a.id = c.transaction and b.id = c.transactionline ' +
                                'join currency d on a.currency = d.id ' +
                                'join account c1 on c.account = c1.id ' +
                                'left join customrecord_rsc_cnab_bankaccount c3 on c3.custrecord_rsc_cnab_ba_accounting_ls = b.expenseaccount ' +
                                'left join customrecord_rsc_cnab_bank c2 on c3.custrecord_rsc_cnab_ba_bank_ls = c2.id ' +
                                'join (select e1.id, externalCode, e2.altname, e1.tipo, e1.custentity_enl_cnpjcpf, dataupdate from (select id, entityid externalCode, custentity_enl_cnpjcpf, \'1\' tipo, custentity_lrc_data_modifica_cliente dataupdate from customer\n' +
                                '            union\n' +
                                '            select id, entityid externalCode, custentity_enl_cnpjcpf, \'2\' tipo, custentity_lrc_data_modifica_fornec dataupdate from employee \n' +
                                '            union\n' +
                                '            select id, entityid externalCode, custentity_enl_cnpjcpf, \'3\' tipo, custentity_lrc_data_modifica_fornec dataupdate from vendor ) e1\n' +
                                '            join entity e2 on e1.externalCode = e2.entityid) e on e.id = a.entity ' +
                                'where  ' +
                                'type in (\'VendPymt\')' +
                                ' and void = \'F\'' +
                                ' and status in (\'C\', \'Y\')' +
                                ' and a.lastModifiedDate between TO_TIMESTAMP (\' ' + body.dataInicio + '\', \'DD/MM/YYYY HH24:MI:SS\') and TO_TIMESTAMP (\'' + body.dataFinal + '\', \'DD/MM/YYYY HH24:MI:SS\') ';
                        //' ORDER BY a.id, a.type, a.transactionNumber, b.linesequencenumber ASC ';

                        /*
                                                      
                        
                        */

                        /*
                        var queryParams = new Array();
                        var arrResults = selectAllRows(sql, queryParams);
                        log.audit({ title: 'gesplan_mov_real_vendpy - number of rows selected', details: arrResults.length });

                        var records = arrResults;
                        */

                        var records = [];
                        var global = "";


                        const buildGesplanRecord = (searchResult) => {



                                //get JSON fields from searchResult
                                let jsonItems = searchResult.getValue({ name: 'custbody_rsc_gesplan_items_json' });
                                let jsonInstalments = searchResult.getValue({ name: 'custbody_rsc_installments' });

                                //global += gCalculator.calculate();

                                let jsonExtractor = new JsonExtractor();
                                if (jsonItems && jsonItems != '') {
                                        jsonExtractor.setItems(jsonItems);

                                        if (jsonInstalments && jsonInstalments != '') {
                                                jsonExtractor.setInstalments(jsonInstalments);

                                                let ii = jsonExtractor.getItems();
                                                let ij = jsonExtractor.getInstalments();

                                                log.debug("CustPymt id:" + searchResult.id + "  ----ITEMS:", JSON.stringify(ii));
                                                log.debug("CustPymt id:" + searchResult.id + "  ----INSTALMENTS:", JSON.stringify(ij));


                                                let gCalculator = new GesplanReturnEngine(jsonExtractor);
                                                gCalculator.setPrefix(searchResult.getValue({ name: 'transactionnumber' }));

                                                //FAZ O CALCULO DOS ITENS E PARCELAS PARA ENVIO AO GESPLAN
                                                let gesplanRecords = gCalculator.calculate();

                                                //inserir o header aqui nessa sessao.

                                                gesplanRecords.forEach((calcLine) => {

                                                        calcLine.records.forEach((record, idx, records) => {

                                                                let gRet = new GesplanRetorno();
                                                                gRet.setExternalCode(record.id);
                                                                gRet.setDateOfIssue(searchResult.getValue({ name: 'trandate' }));
                                                                gRet.setDataAtualizacao(searchResult.getValue({ name: 'custbody_rsc_gesplan_lastmodifdate_dt' }));
                                                                gRet.setIntegrationType("");
                                                                gRet.setScenario("01");
                                                                gRet.setBusinessUnit(searchResult.getValue({ name: 'subsidiary' }));
                                                                gRet.setOriginSystem("CR");
                                                                gRet.setBeneficiaryOrigin(searchResult.getValue({ name: 'entity' }));
                                                                gRet.setEventType("S");
                                                                gRet.setDocumentNumber(searchResult.getValue({ name: 'transactionnumber' }));
                                                                gRet.setDocumentType("V");
                                                                gRet.setValue(Number(record.instalmentCalculatedValue).toFixed(2));
                                                                gRet.setDueDate((record.instalmentDueDate) ? record.instalmentDueDate : gRet.getDateOfIssue());
                                                                gRet.setPayday(record.instalmentPaymentDate);
                                                                gRet.setDocumentNumber(gRet.getDocumentNumber);
                                                                gRet.setDocumentType(searchResult.getValue({ name: 'type' }));
                                                                gRet.setAccountingAccountPlan("01");
                                                                gRet.setAccountingAccount(searchResult.getValue({ name: 'account' }));
                                                                //gRet.setAccountingAccount(searchResult.getValue({ name: 'account.name' }));

                                                                gRet.setCostCenter(searchResult.getValue({ name: 'class' }));
                                                                gRet.setCostCenterPlan("01");
                                                                //gRet.setCurrentAccount(searchResult.getValue({ name: 'custbody_rsc_conta_corrente' }));
                                                                gRet.setCurrency(searchResult.getValue({ name: 'currency' }));

                                                                //identifica quando for ultima iteracao.
                                                                global += JSON.stringify(gRet.toJson()) + ",\n";


                                                        })
                                                })

                                                // global += JSON.stringify(gesplanRecords);
                                        }
                                }





                                //fazer o calculo
                                //let _externalCode = record['transactionnumber'] + '.' + (parseInt(record['itemsequence']) + 1) + '.' + instalmnt.seq;
                                //gRet.setExternalCode(_externalCode);

                                /*
                                const empresa = {
                                        'externalCode': record['transactionnumber'],
                                        'dateOfIssue': record['trandate'],
                                        'dueDate': record['duedate'] == null ? record['trandate'] : record['duedate'],
                                        'payday': record['closedate'],
                                        'description': record['transactionnumber'] + ' - ' + (record['memo'] == null ? '' : record['memo']),
                                        'observation': '',
                                        'documentType': record['type'],
                                        'documentNumber': record['transactionnumber'],
                                        'accountingAccountPlan': '01',
                                        'accountingAccount': record['account'],
                                        'costCenterPlan': '01',
                                        'costCenter': (record['departament'] == null ? 0 : record['departament']),
                                        'currentAccount': record['conta'],
                                        'paymentNumber': '',
                                        'currency': record['currency'],
                                        'eventType': eventType,
                                        'value': (originSystem == 'CP' ? record['total'] * -1 : record['total']),
                                        'valueBusiness': '',
                                        'conversionBusiness': '',
                                        'fixedRateBusiness': '',
                                        'valueAccount': '',
                                        'conversionAccount': '',
                                        'fixedRateAccount': '',
                                        //'beneficiaryOrigin': record['entity'],
                                        'beneficiaryOrigin': originSystem,
                                        'beneficiary': record['entity'],
                                        'beneficiaryType': record['tipo'],
                                        'motionWay': (record['custbody_lrc_invoice_met_pag_fatura'] == null ? 2 : record['custbody_lrc_invoice_met_pag_fatura']),
                                        'flexField001': (record['class'] == null ? 0 : record['class'])
                                }

                                                search.createColumn({ name: "custbody_rsc_gesplan_lastmodifdate_dt", label: "RSC Gesplan LastModifiedDate" }),
                                                search.createColumn({ name: "approvalstatus", label: "Status de aprovação" }),
                                                search.createColumn({ name: "statusref", label: "Status" }),
                                                search.createColumn({
                                                        name: "lastmodifieddate",
                                                        sort: search.Sort.DESC,
                                                        label: "Última alteração"
                                                }),
                                                search.createColumn({ name: "type", label: "Tipo" }),
                                                search.createColumn({ name: "tranid", label: "Número do documento" }),
                                                search.createColumn({ name: "transactionnumber", label: "Número da transação" }),
                                                search.createColumn({ name: "datecreated", label: "Data de criação" }),
                                                search.createColumn({ name: "trandate", label: "Data" }),
                                                search.createColumn({ name: "entity", label: "Nome" }),
                                                search.createColumn({ name: "account", label: "Conta" }),
                                                search.createColumn({ name: "currency", label: "Moeda" }),
                                                search.createColumn({ name: "amount", label: "Valor" }),
                                                search.createColumn({ name: "custbody_rsc_fornecedor_exclusivo", label: "Fornecedor exclusivo" }),
                                                search.createColumn({ name: "custbody_rsc_installments", label: "RSC Gesplan Installments JSON" }),
                                                search.createColumn({ name: "custbody_rsc_gesplan_items_json", label: "RSC Gesplan Items JSON" }),
                                                search.createColumn({ name: "subsidiary", label: "Subsidiária" }),
                                                search.createColumn({ name: "internalid", label: "ID interno" }),
                                                search.createColumn({ name: "duedate", label: "Data de vencimento/Receber até" }),
                                                search.createColumn({ name: "memo", label: "Memorando" }),
                                                search.createColumn({ name: "accountgrouped", label: "Conta (agrupada)" }),
                                                search.createColumn({
                                                        name: "name",
                                                        join: "account",
                                                        label: "Nome"
                                                }),
                                                search.createColumn({ name: "department", label: "Departamento" }),
                                                search.createColumn({ name: "class", label: "Etapa do Projeto" }),
                                                search.createColumn({ name: "custcol_appliedamount_cc", label: "Applied Amount" }),
                                                search.createColumn({ name: "enddate", label: "Data de término" }),
                                                search.createColumn({ name: "actualshipdate", label: "Data real de envio/recebimento" }),
                                                search.createColumn({ name: "payingtransaction", label: "Transação de pagamento" })
                                        ]

*/







                                /*
                        let jsonItems = searchResult.getValue({
                                name: 'custbody_rsc_gesplan_items_json'
                        });

                        let jsonInstalments = searchResult.getValue({
                                name: 'custbody_rsc_installments'
                        });
*/



                                //log.debug({ title: 'trannum', details: trannum });

                                // global += trannum + ": " + searchResult.id + "\n items: " + ((jsonItems) ? jsonItems : []);
                                // global += "\ninstalments: " + ((jsonInstalments) ? jsonInstalments : []) + "\n";
                                //global += JSON.stringify(gRet.toJson()) + "\n-----------------------------------------------------\n";

                                /*
                                if (jsonItems) {
                                        //log.debug("JSON itens: ", JSON.parse(items));
                                        let allItemsList = JSON.parse(jsonItems);
                                        allItemsList.map(

                                                transaction => transaction.items

                                        ).forEach((items, idx) => {

                                                log.debug("vendorpayment(" + searchResult.id + ") Items: " + (idx + 1), items);

                                        });



                                }
                                if (jsonInstalments) {
                                        let allInstalmentsList = JSON.parse(jsonInstalments);

                                        //log.debug("vendorpayment("+searchResult.id+") Parcelas: ", JSON.parse(instalments));

                                        allInstalmentsList.map(
                                                transaction => transaction.instalments
                                        )
                                                .forEach((instalments, idx) => {

                                                        log.debug("vendorpayment(" + searchResult.id + ") Instalments: " + (idx + 1), instalments);

                                                });

                                }


                                */

                                //global += "applied: " + ( (apList) ? apList : []  ) +"\n";




                                //log.debug({ title: 'items', details: items });
                                //log.debug({ title: 'instalments', details: instalments });

                                //global += trannum +": "+searchResult.id+ "\n items: " + ((items) ? items : []);
                                //global += "\ninstalments: " + ( (instalments) ? instalments : []  ) +"\n";

                                /*
                                let vP = record.load({
                                        type: 'vendorpayment',
                                        id: searchResult.id
                                })

                                let vbInstalmentReader = new InstalmentSublistReader(vP);
                                let vbItemReader       = new ItemSublistReader(vP);
                                let vpApplyReader         = new ApplySubListReader(vP);

                                let inList = JSON.stringify(vbInstalmentReader.read());
                                let itList = JSON.stringify(vbItemReader.read());
                                let apList = JSON.stringify(vpApplyReader.readApplied());
                                //log.debug("teste intalment", inList);
                                //log.debug("teste item", itList);
                                
                                global += trannum +": "+searchResult.id+ "\n items: " + ((itList) ? itList : []);
                                global += "\ninstalments: " + ( (inList) ? inList : []  ) +"\n";
                                global += "applied: " + ( (apList) ? apList : []  ) +"\n";
                                */






                                /*
                                if(!items){
                                        log.debug("campo vazio", "campo de item vazio");
                                }

                                if(!instalments){
                                        log.debug("campo vazio", "campo de instalments vazio");
                                }
                                */

                                return true;
                        }



                        //const search = getSearchRealizado(n,body.dataInicio,body.dataFinal);
                        const search = getSearchRealizado("customsearch_rsc_gesplan_custpy_view_ss", body.dataInicio, body.dataFinal);
                        //log.debug({ title: 'search result obj', details: search.run() });

                        search.run().each(
                                buildGesplanRecord
                        );

                        return "[" + global + "]";


                } catch (e) {
                        log.error({ title: 'Error Recuperar informaçoes (pgto de cliente)', details: e })
                        throw e;
                }
        }






        // function _isValidJsonInstalmentFormat(instalmentBodyField) {

        //         if (!instalmentBodyField || instalmentBodyField == '') {
        //                 return false;
        //         }

        //         let instalmentsFromTransactionBodyField = JSON.parse(instalmentBodyField);
        //         let instalmntList = instalmentsFromTransactionBodyField;
        //         if (instalmntList.length == 0) {
        //                 log.audit("Validação do campo custbody_rsc_installments", "TAMANHO INVÁLIDO -> " + instalmentBodyField);
        //                 return false;
        //         }
        //         instalmntList.forEach(function (instalment) {
        //                 if (instalment.hasOwnProperty('transactionid')
        //                         && instalment.hasOwnProperty('seq')
        //                         //&& instalment.hasOwnProperty('data')
        //                         && instalment.hasOwnProperty('dtvcto')
        //                         && instalment.hasOwnProperty('valor')
        //                         && instalment.hasOwnProperty('dtpgto')
        //                         && instalment.hasOwnProperty('multa')
        //                         && instalment.hasOwnProperty('juros')
        //                         && instalment.hasOwnProperty('status')
        //                 ) {

        //                         log.audit("Validação do campo custbody_rsc_installments", "FORMATO OK");
        //                         return true;
        //                         /*
        //                         log.debug("instalment.transactionid:", instalment.transactionid);
        //                         log.debug("instalment.seq:", instalment.seq);
        //                         log.debug("instalment.dtvcto:", instalment.dtvcto);
        //                         log.debug("instalment.valor:", instalment.valor);
        //                         */

        //                 } else {
        //                         log.audit("Validação do campo custbody_rsc_installments", "FORMATO INVALIDO -> " + instalmentBodyField);
        //                         return false;

        //                 }
        //         });
        //         return false;
        // }




        function selectAllRows(sql, queryParams = new Array()) {
                try {
                        var moreRows = true;
                        var rows = new Array();
                        var paginatedRowBegin = 1;
                        var paginatedRowEnd = 5000;

                        do {
                                var paginatedSQL = 'SELECT * FROM ( SELECT ROWNUM AS ROWNUMBER, * FROM (' + sql + ' ) ) WHERE ( ROWNUMBER BETWEEN ' + paginatedRowBegin + ' AND ' + paginatedRowEnd + ')';
                                log.debug("mov_real_vendpy QUERY:", paginatedSQL);

                                var queryResults = query.runSuiteQL({ query: paginatedSQL, params: queryParams }).asMappedResults();
                                rows = rows.concat(queryResults);
                                if (queryResults.length < 5000) { moreRows = false; }
                                paginatedRowBegin = paginatedRowBegin + 5000;
                        } while (moreRows);
                } catch (e) {
                        log.error({ title: 'selectAllRows - error', details: { 'sql': sql, 'queryParams': queryParams, 'error': e } });
                }
                return rows;



        }



        function getSearchRealizado(searchId, dataInicio, dataFinal) {
                var transactionSearchObj;
                
                log.debug("Search range:", dataInicio + " - " + dataFinal);
                
                if (searchId && searchId != '') {
                        log.debug("Loading busca salva id:", searchId);
                        transactionSearchObj = search.load({ id: searchId });
                        
                } else {

                        transactionSearchObj = search.create({
                                type: "transaction",
                                filters:
                                        [
                                                ["mainline", "is", "T"],
                                                "AND",
                                                ["type", "anyof", "CustPymt"],
                                                "AND",
                                                ["voided", "is", "F"],
                                                "AND",
                                                ["custbody_rsc_gesplan_lastmodifdate_dt", "within", dataInicio, dataFinal]
                                        ],

                                columns:
                                        [
                                                search.createColumn({ name: "custbody_rsc_gesplan_lastmodifdate_dt", label: "RSC Gesplan LastModifiedDate" }),
                                                search.createColumn({ name: "approvalstatus", label: "Status de aprovação" }),
                                                search.createColumn({ name: "statusref", label: "Status" }),
                                                search.createColumn({
                                                        name: "lastmodifieddate",
                                                        sort: search.Sort.DESC,
                                                        label: "Última alteração"
                                                }),
                                                search.createColumn({ name: "type", label: "Tipo" }),
                                                search.createColumn({ name: "tranid", label: "Número do documento" }),
                                                search.createColumn({ name: "transactionnumber", label: "Número da transação" }),
                                                search.createColumn({ name: "datecreated", label: "Data de criação" }),
                                                search.createColumn({ name: "trandate", label: "Data" }),
                                                search.createColumn({ name: "entity", label: "Nome" }),
                                                search.createColumn({ name: "account", label: "Conta" }),
                                                search.createColumn({ name: "currency", label: "Moeda" }),
                                                search.createColumn({ name: "amount", label: "Valor" }),
                                                search.createColumn({ name: "custbody_rsc_fornecedor_exclusivo", label: "Fornecedor exclusivo" }),
                                                search.createColumn({ name: "custbody_rsc_installments", label: "RSC Gesplan Installments JSON" }),
                                                search.createColumn({ name: "custbody_rsc_gesplan_items_json", label: "RSC Gesplan Items JSON" }),
                                                search.createColumn({ name: "subsidiary", label: "Subsidiária" }),
                                                search.createColumn({ name: "internalid", label: "ID interno" }),
                                                search.createColumn({ name: "duedate", label: "Data de vencimento/Receber até" }),
                                                search.createColumn({ name: "memo", label: "Memorando" }),
                                                search.createColumn({ name: "accountgrouped", label: "Conta (agrupada)" }),
                                                search.createColumn({
                                                        name: "name",
                                                        join: "account",
                                                        label: "Nome"
                                                }),
                                                search.createColumn({ name: "department", label: "Departamento" }),
                                                search.createColumn({ name: "class", label: "Etapa do Projeto" }),
                                                search.createColumn({ name: "custcol_appliedamount_cc", label: "Applied Amount" }),
                                                search.createColumn({ name: "enddate", label: "Data de término" }),
                                                search.createColumn({ name: "actualshipdate", label: "Data real de envio/recebimento" }),
                                                search.createColumn({ name: "payingtransaction", label: "Transação de pagamento" })
                                        ]
                        });
                }


                var searchResultCount = transactionSearchObj.runPaged().count;
                //log.debug("transactionSearchObj result count", searchResultCount);
                /*
                transactionSearchObj.run().each(function (result) {
                        // .run().each has a limit of 4,000 results
                        return true;
                });
                */

                return transactionSearchObj;

        }

        //================================== RunSmart-Gesplan API begin =====================================================//

        const SUBLISTNAME = {
                apply: 'apply',
                item: "item",
                instalment: "installment",
                expense: "expense",
                links: "links",
                financiamento: "custpage_rsc_parcelas"
        }
        const TRANBODYFLDNAME = {

                instalments: "custbody_rsc_installments",
                items: "custbody_rsc_gesplan_items_json",
        }

        class Instalment {
                constructor(transactionid, seq, dtvcto, valor, valorpago, valordevido, dtpgto, multa, juros, status) {
                        this.transactionid = transactionid;
                        this.seq = seq;
                        this.dtvcto = dtvcto;
                        this.valor = valor;
                        this.valordevido = valordevido;
                        this.valorpago = valorpago;
                        this.dtpgto = dtpgto;
                        this.multa = multa;
                        this.juros = juros;
                        this.status = status;
                }
        }

        class Item {
                constructor(
                        id, type, subtype, quantity, rate, refamt, origrate, grossamt, amount
                ) {
                        this.id = id;
                        this.type = type;
                        this.subtype = subtype;
                        this.quantity = quantity;
                        this.rate = rate;
                        this.refamt = refamt;
                        this.origrate = origrate;
                        this.grossamt = grossamt;
                        this.amount = amount;

                }
        }
        class LinksList {
                constructor(id, linkurl, status, total, trandate, tranid, type) {
                        this.id = id;
                        this.linkurl = linkurl;
                        this.status = status;
                        this.total = total;
                        this.trandate = trandate;
                        this.tranid = tranid;
                        this.type = type;
                }
        }

        class ApplySublist {
                constructor(trantype, amount, type, apply, applydate, createdfrom,
                        currency, doc, due, internalid, installmentnumber, total, pymt, duedate, refnum, discdate,
                        discamount, disc, userenteredamount, userentereddiscount, line, discountrate
                ) {

                        this.trantype = trantype;
                        this.amount = amount;
                        this.type = type;
                        this.apply = apply;
                        this.applydate = applydate;
                        this.createdfrom = createdfrom;
                        this.currency = currency;
                        this.doc = doc;
                        this.due = due;
                        this.installmentnumber = installmentnumber;
                        this.internalid = internalid;
                        this.total = total;
                        this.pymt = pymt;
                        this.duedate = duedate;
                        this.refnum = refnum;
                        this.discdate = discdate;
                        this.discamount = discamount;
                        this.disc = disc;
                        this.userenteredamount = userenteredamount;
                        this.userentereddiscount = userentereddiscount;
                        this.line = line;
                        this.discountrate = discountrate;

                }
        }

        class ApplySubListReader {
                constructor(transactionRecord) {

                        this.record = transactionRecord;

                        log.debug('ApplySubListReader', 'Apply Itemlist length: ' + this.length());

                }

                length() {
                        return this.record.getLineCount(SUBLISTNAME.apply);
                }

                read() {
                        let sublistApplyList = [];

                        for (let i = 0; i < this.length(); i++) {


                                try {


                                        sublistApplyList.push(new ApplySublist(
                                                this.record.getSublistText(SUBLISTNAME.apply, 'trantype', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'type', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'apply', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'applydate', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'createdfrom', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'currency', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'doc', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'due', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'internalid', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'installmentnumber', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'total', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'duedate', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'refnum', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'discdate', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'discamount', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'disc', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'userenteredamount', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'userentereddiscount', i),
                                                this.record.getSublistText(SUBLISTNAME.apply, 'line', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'discountrate', i)
                                        ));

                                } catch (e) {

                                        log.warning('ApplySubListReader', 'Apply Sublist Error: ' + e.message);
                                        //use this code only on edit mode
                                        sublistApplyList.push(new ApplySublist(
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'trantype', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'type', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'apply', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'applydate', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'createdfrom', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'currency', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'doc', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'due', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'internalid', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'installmentnumber', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'total', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'duedate', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'refnum', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'discdate', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'discamount', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'disc', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'userenteredamount', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'userentereddiscount', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'line', i),
                                                this.record.getSublistValue(SUBLISTNAME.apply, 'discountrate', i)

                                        ));


                                }
                        }
                        //log.audit("ApplySubListReader.read()", "applyList: " + JSON.stringify(sublistApplyList));

                        return sublistApplyList;
                }

                readApplied() {
                        let ret = this.read().filter(item => item.apply == true);
                        if (ret.length == 0) {
                                ret = this.read().filter(item => item.apply == "T");
                        }

                        log.audit("ApplySubListReader.readApplied().filter", "appliedList:  " + JSON.stringify(ret));
                        return ret;
                }
        }

        class ItemSublistReader {
                constructor(transactionRecord) {
                        this.record = transactionRecord;
                }
                length() {
                        return this.record.getLineCount(SUBLISTNAME.item);
                }
                read() {
                        let itemList = [];
                        for (var i = 0; i < this.length(); i++) {
                                try {

                                        itemList.push(new Item(
                                                this.record.getSublistText(SUBLISTNAME.item, 'id', i),
                                                this.record.getSublistText(SUBLISTNAME.item, 'type', i),
                                                this.record.getSublistText(SUBLISTNAME.item, 'subtype', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'quantity', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'rate', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'refamt', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'origrate', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'grossamt', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'amount', i)
                                        ));

                                } catch (e) {

                                        log.error('ItemSublistReader', 'Item Sublist Error: ' + e.message);
                                        itemList.push(new Item(
                                                this.record.getSublistValue(SUBLISTNAME.item, 'id', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'type', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'subtype', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'quantity', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'rate', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'refamt', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'origrate', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'grossamt', i),
                                                this.record.getSublistValue(SUBLISTNAME.item, 'amount', i)
                                        ));

                                }
                        }
                        log.audit("ItemSublistReader.read(" + this.record.type + " - " + this.record.id + ")", "ItemList:  " + JSON.stringify(itemList));

                        return itemList;
                }
        }

        /**
         * Cria um array de objetos Installment lendo da sublista Installment do registro netsuite.
         * e ja calculando o valor pago da parcela. ValorPAgo = Total - ValorDevido
         */
        class DefaultInstalmentSublistBuilder {
                constructor(transactionRecord) {
                        this.record = transactionRecord;
                        //this.logMsg = "DefaultInstalmentSublistBuilder.build("+this.record.type+" - "+this.record.id+")"

                }
                length() {
                        return this.record.getLineCount(SUBLISTNAME.instalment);
                }

                build() {
                        let instalmentList = [];

                        for (let i = 0; i < this.length(); i++) {
                                log.debug(DefaultInstalmentSublistBuilder.name, "lendo sublista intalments  " + (i + 1));


                                //Pra ler o instalment corretamente, tem que calcular o valor pago e dt pgto
                                //pois a sublist de instalment, nao deixa pegar o valor pago e dt pgto
                                /*
                                let dtPgto = this.record.getText("trandate");
                                let amt = this.record.getSublistValue(SUBLISTNAME.instalment, 'amount', i);
                                let amtDue = this.record.getSublistValue(SUBLISTNAME.instalment, 'due', i);
                                let amtPaid = 0;//
                                if (amtDue !== amt) {
                                    amtPaid = parseFloat(amt) - parseFloat(amtDue);;
                                }
                                if (amtPaid == 0) {
                                    dtPgto = "";
                                }*/
                                let dtPgto = this.record.getValue("trandate");
                                let amtDue = this.record.getSublistValue(SUBLISTNAME.instalment, 'due', i);
                                let amtPaid = 0.00;
                                let _instalmentstatus = this.record.getSublistValue(SUBLISTNAME.instalment, 'status', i)

                                log.debug("valor devido", amtDue);

                                //Alterar futuramente para trabalhar com o id do status e nao o nome do status 
                                log.debug("status of instalment vendorbill", _instalmentstatus);
                                if (_instalmentstatus === "Não pago") {
                                        log.debug("status Nao pago encopntrado", _instalmentstatus);
                                        amtPaid = 0.00;
                                        dtPgto = "";
                                }
                                // }

                                //valida se calulo ocorreu corretamente, se resultado e NaN, entao seta o valor como 0
                                //isNaN(amtPaid) ? amtPaid = 0 : amtPaid = amtPaid;
                                //log.debug(this.logMsg, " calculo do valor pago:   amt: " + amt + " amtDue: " + amtDue + " amtPaid: " + amtPaid);


                                let instalmentContent = {
                                        transactionid: this.record.id,
                                        seq: (i + 1),
                                        dtvcto: this.record.getSublistValue(SUBLISTNAME.instalment, 'duedate', i),
                                        valor: this.record.getSublistValue(SUBLISTNAME.instalment, 'amount', i),
                                        valordevido: this.record.getSublistValue(SUBLISTNAME.instalment, 'due', i),
                                        valorpago: (_instalmentstatus === 'Não pago') ? '0.00' : this.record.getSublistValue(SUBLISTNAME.instalment, 'amount', i),
                                        dtpgto: (_instalmentstatus === 'Não pago') ? "" : this.record.getValue("trandate"),
                                        multa: 0.00,
                                        juros: 0.00,
                                        status: _instalmentstatus
                                        //installmentid: this.record.getSublistText(SUBLISTNAME.instalment, 'id', i)
                                }

                                //log.audit(this.logMsg, "Conteudo da sublista installment depois do calculo: " + JSON.stringify(instalmentList));


                                instalmentList.push(
                                        new Instalment(
                                                instalmentContent.transactionid,
                                                instalmentContent.seq,
                                                instalmentContent.dtvcto,
                                                instalmentContent.valor,
                                                instalmentContent.valorpago,
                                                //instalmentContent.valordevido,
                                                instalmentContent.dtpgto,
                                                instalmentContent.multa,
                                                instalmentContent.juros,
                                                instalmentContent.status
                                        ));



                                //lookupLinks(vendPymtRecord, 'links', 'total', seq),
                                //lookupLinks(vendPymtRecord, 'links', 'trandate', seq),


                        }

                        log.debug("instalmentlist in defaultbuilder", JSON.stringify(instalmentList));
                        return instalmentList;

                }


        }

        class FinanciamentoInvoiceInstalmentSublistBuilder extends DefaultInstalmentSublistBuilder {

                constructor(transactionRecord) {
                        super(transactionRecord);

                }
                length() {
                        return this.record.getLineCount(SUBLISTNAME.financiamento);
                }
                build() {
                        let instalmentList = [];

                        if (this.length() > 0) {
                                for (i = 0; i < this.length(); i++) {
                                        log.debug(FinanciamentoInvoiceInstalmentSublistBuilder.name, "Criando parcelas");

                                        instalmentList.push(
                                                new Instalment(
                                                        this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_ver', i),
                                                        this.record.getSublistText(SUBLISTNAME.financiamento, 'custpage_rsc_numero_parcela', i),
                                                        this.record.getSublistText(SUBLISTNAME.financiamento, 'duedate', i),
                                                        this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_valor_original', i),
                                                        this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_valor_original', i),
                                                        this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_valor_pago', i),
                                                        this.record.getSublistText(SUBLISTNAME.financiamento, 'custpage_rsc_data_pagamento', i),
                                                        this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_juros', i),
                                                        this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_multa', i),
                                                        this.record.getSublistText(SUBLISTNAME.financiamento, 'custpage_rsc_status', i)
                                                ));
                                        log.debug("***FINANCIAM***", JSON.stringify(instalmentList));
                                }
                        }
                        return instalmentList;

                }
        }
        class PaidInstalmentsFromApplyListBuilder extends DefaultInstalmentSublistBuilder {

                constructor(transactionRecord) {
                        super(transactionRecord);
                        this.applyedList = [];
                        this._loadApplyedList(transactionRecord);
                }
                _loadApplyedList(record) {
                        let reader = new ApplySubListReader(record);
                        this.applyedList = reader.readApplied();
                        log.debug("***APLICADOS***", JSON.stringify(this.applyedList));
                }

                length() {
                        return this.applyedList.length;
                }
                build() {
                        let instalmentList = [];

                        if (this.length() > 0) {
                                for (let i = 0; i < this.length(); i++) {

                                        /*
                                        //SUBLIST APPLY 
                                           this.record.getSublistText(SUBLISTNAME.apply, 'trantype', i),
                                        this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'type', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'apply', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'applydate', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'createdfrom', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'currency', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'doc', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'due', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'internalid', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'installmentnumber', i),
                                        this.record.getSublistValue(SUBLISTNAME.apply, 'total', i),
                                        this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'duedate', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'refnum', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'discdate', i),
                                        this.record.getSublistValue(SUBLISTNAME.apply, 'discamount', i),
                                        this.record.getSublistValue(SUBLISTNAME.apply, 'disc', i),
                                        this.record.getSublistValue(SUBLISTNAME.apply, 'userenteredamount', i),
                                        this.record.getSublistValue(SUBLISTNAME.apply, 'userentereddiscount', i),
                                        this.record.getSublistText(SUBLISTNAME.apply, 'line', i),
                                        this.record.getSublistValue(SUBLISTNAME.apply, 'discountrate', i)
                                        
                                        */


                                        log.debug("sublista apply - doc", this.record.getSublistValue(SUBLISTNAME.apply, 'doc', i));
                                        log.debug("sublista apply - seqnum", this.record.getSublistValue(SUBLISTNAME.apply, 'seqnum', i));
                                        log.debug("sublista apply - duedate", this.record.getSublistValue(SUBLISTNAME.apply, 'duedate', i));
                                        log.debug("sublista apply - amount", this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i));
                                        log.debug("sublista apply - due", this.record.getSublistValue(SUBLISTNAME.apply, 'due', i));
                                        log.debug("sublista apply - pymt", this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i));
                                        log.debug("sublista apply - pymt", this.record.getSublistValue(SUBLISTNAME.apply, 'applydate', i));

                                        instalmentList.push(
                                                new Instalment(
                                                        this.record.getSublistValue(SUBLISTNAME.apply, 'doc', i),
                                                        (i + 1),
                                                        this.record.getSublistValue(SUBLISTNAME.apply, 'duedate', i),
                                                        this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i),
                                                        this.record.getSublistValue(SUBLISTNAME.apply, 'due', i),
                                                        this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                                                        //this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                                                        this.record.getSublistValue(SUBLISTNAME.apply, 'applydate', i),
                                                        0.00,
                                                        0.00,
                                                        "pago"
                                                ));
                                        log.debug("***Paid instalennts***", JSON.stringify(instalmentList));
                                }
                        }
                        return instalmentList;

                }
        }




        class SinglePaidInstalmentSublistBuilder extends DefaultInstalmentSublistBuilder {
                constructor(transactionRecord) {
                        super(transactionRecord);
                }

                //override
                length() {
                        return 1;
                }

                build() {

                        log.debug("SinglePaidInstalmentSublistBuilder", "building single paid instalment");


                        let iList = [];
                        let instalmentContent = {};
                        //let amtDue  = amt;


                        //valida se calulo ocorreu corretamente, se resultado e NaN, entao seta o valor como 0
                        //isNaN(amtPaid) ? amtPaid = amt : amtPaid = amtPaid;
                        //log.debug(this.logMsg, " calculo do valor pago:   amt: " + amt + " amtDue: " + amtDue + " amtPaid: " + amtPaid);

                        try {


                                instalmentContent = {
                                        transactionid: this.record.id,
                                        seq: 1,
                                        dtvcto: this.record.getText('trandate'),
                                        valor: this.record.getValue('total'),
                                        valordevido: this.record.getValue('total'),
                                        valorpago: this.record.getValue('total'),
                                        dtpgto: this.record.getText("trandate"),
                                        multa: 0.00,
                                        juros: 0.00,
                                        status: "Pago"
                                        //installmentid: this.record.getSublistText(SUBLISTNAME.instalment, 'id', i)
                                }
                        } catch (e) {

                                instalmentContent = {
                                        transactionid: this.record.id,
                                        seq: 1,
                                        dtvcto: this.record.getValue('trandate'),
                                        valor: this.record.getValue('total'),
                                        valordevido: this.record.getValue('total'),
                                        valorpago: this.record.getValue('total'),
                                        dtpgto: this.record.getValue("trandate"),
                                        multa: 0.00,
                                        juros: 0.00,
                                        status: "Pago"
                                        //installmentid: this.record.getSublistText(SUBLISTNAME.instalment, 'id', i)
                                }

                        }
                        iList.push(
                                new Instalment(
                                        instalmentContent.transactionid,
                                        instalmentContent.seq,
                                        instalmentContent.dtvcto,
                                        instalmentContent.valor,
                                        instalmentContent.valordevido,
                                        instalmentContent.valorpago,
                                        instalmentContent.dtpgto,
                                        instalmentContent.multa,
                                        instalmentContent.juros,
                                        instalmentContent.status
                                ));

                        log.debug("SinglePaidInstalmentSublistBuilder", "build instalment: " + JSON.stringify(iList));

                        return iList;

                }



        }

        class SingleOpenInstalmentSublistBuilder extends DefaultInstalmentSublistBuilder {
                constructor(transactionRecord) {
                        super(transactionRecord);
                }

                //override
                length() {
                        return 1;
                }
                //override
                build() {

                        //log.debug("building single open instalment");

                        let instalmentList = [];
                        let instalmentContent = {
                                transactionid: this.record.id,
                                seq: 1,
                                dtvcto: this.record.getValue('trandate'),
                                valor: this.record.getValue('total'),
                                valordevido: this.record.getValue('total'),
                                valorpago: 0.00,
                                dtpgto: "",
                                multa: ZERO,
                                juros: ZERO,
                                status: "Não pago"
                                //installmentid: this.record.getSublistText(SUBLISTNAME.instalment, 'id', i)
                        }
                        //log.debug("conteudo do instalment", instalmentContent)


                        instalmentList.push(
                                new Instalment(
                                        instalmentContent.transactionid,
                                        instalmentContent.seq,
                                        instalmentContent.dtvcto,
                                        instalmentContent.valor,
                                        instalmentContent.valorpago, //valordevido
                                        instalmentContent.valordevido,
                                        instalmentContent.dtpgto,
                                        instalmentContent.multa,
                                        instalmentContent.juros,
                                        instalmentContent.status
                                )
                        );
                        //log.debug("SingleOpenInstalmentSublistBuilder", "built instalment: " + JSON.stringify(instalmentList));



                        return instalmentList;

                }



        }


        class InstalmentSublistReader {
                constructor(transactionRecord) {
                        this.record = transactionRecord;
                        this.builder = new DefaultInstalmentSublistBuilder(transactionRecord)
                        this.logMsg = "InstalmentSublistReader.read(" + this.record.type + " - " + this.record.id + ")";
                        //log.audit(this.logMsg, "Qtde Parcelas: " + this.length());
                }
                length() {
                        return this.record.getLineCount(SUBLISTNAME.instalment);
                }

                setBuilder(instalmentBuilder) {
                        this.builder = instalmentBuilder;
                }

                read() {

                        //o DefaultInstalmentSublistBuilder le a sublista de instalment e monta um array de instalment
                        //Ja calculando o valor pago e dt pgto
                        //log.debug("usando builder", (typeof this.builder));
                        log.debug(InstalmentSublistReader.name, "using " + this.builder.constructor.name + " builder");
                        let instalmentList = this.builder.build();
                        return instalmentList;

                }
        }
        class LinksSublistReader {
                constructor(transactionRecord) {
                        this.record = transactionRecord;
                }
                length() {
                        return this.record.getLineCount(SUBLISTNAME.links);
                }
                read() {
                        let linksList = [];

                        for (var i = 0; i < this.length(); i++) {
                                linksList.push(new LinksList(
                                        this.record.id,
                                        this.record.getSublistValue(SUBLISTNAME.links, 'linkurl', i),
                                        this.record.getSublistValue(SUBLISTNAME.links, 'ststus', i),
                                        this.record.getSublistValue(SUBLISTNAME.links, 'total', i),
                                        this.record.getSublistValue(SUBLISTNAME.links, 'trandate', i),
                                        this.record.getSublistValue(SUBLISTNAME.links, 'tranid', i),
                                        this.record.getSublistValue(SUBLISTNAME.links, 'type', i)
                                ));

                        }
                        log.audit("LinksSublistReader.read()", "linksList: " + JSON.stringify(linksList));

                        return linksList;
                }
        }
        class TranBodyJsonReader {
                constructor(transactionRecord) {
                        this.record = transactionRecord;
                }
                readInstalments() {
                        let value = this.record.getValue(TRANBODYFLDNAME.instalments);
                        if (value) {
                                return JSON.parse(value);
                        }
                        return [];
                }
                readItems() {
                        let value = this.record.getValue(TRANBODYFLDNAME.items);
                        if (value) {
                                return JSON.parse(value);
                        }
                        return [];
                }
        }

        class TranBodyJsonWriter {
                constructor(transactionRecord) {
                        this.record = transactionRecord;
                }
                setInstalments(_list) {
                        //log.debug("TranBodyJsonWriter.setInstalments: ", JSON.stringify(_list));

                        this.record.setValue({ fieldId: TRANBODYFLDNAME.instalments, value: JSON.stringify(_list) });

                }
                setItems(list) {
                        //log.debug("TranBodyJsonWriter.setItems: ", JSON.stringify(list));
                        this.record.setValue({ fieldId: TRANBODYFLDNAME.items, value: JSON.stringify(list) });

                }
                write() {
                        //log.audit("TranBodyJsonWriter", " saving record: " + this.record.type + ":" + this.record.id);
                        let id = this.record.save();
                        log.audit("TranBodyJsonWriter", "Record  " + this.record.type + " saved sucessfully id: " + id);

                }
        }

        //================================== RunSmart-Gesplan API end ===================================





        class GesplanRetorno {
                constructor() {


                        this.dataAtualizacao = "";
                        this.integrationType = "";
                        this.scenario = "";
                        this.businessUnit = "";
                        this.originSystem = "";
                        this.externalCode = "";
                        this.dateOfIssue = "";
                        this.dueDate = "";
                        this.payday = "";
                        this.description = "";
                        this.observation = "";
                        this.documentType = "";
                        this.documentNumber = "";
                        this.accountingAccountPlan = "";
                        this.accountingAccount = "";
                        this.costCenterPlan = "";
                        this.costCenter = "";
                        this.currentAccount = "";
                        this.paymentNumber = "";
                        this.currency = "";
                        this.eventType = "";
                        this.value = "";
                        this.valueBusiness = "";
                        this.conversionBusiness = "";
                        this.fixedRateAccount = "";
                        this.beneficiaryOrigin = "";
                        this.beneficiary = "";
                        this.beneficiaryType = "";
                        this.motionWay = "";
                        this.flexField001 = "";

                }

                //getter and setter
                getDataAtualizacao() {
                        return this.dataAtualizacao;
                }
                setDataAtualizacao(dataAtualizacao) {
                        this.dataAtualizacao = dataAtualizacao;
                }
                getIntegrationType() {
                        return this.integrationType;
                }
                setIntegrationType(integrationType) {
                        this.integrationType = integrationType;
                }
                getScenario() {
                        return this.scenario;
                }
                setScenario(scenario) {
                        this.scenario = scenario;
                }
                getBusinessUnit() {
                        return this.businessUnit;
                }
                setBusinessUnit(businessUnit) {
                        this.businessUnit = businessUnit;
                }
                getOriginSystem() {
                        return this.originSystem;
                }
                setOriginSystem(originSystem) {
                        this.originSystem = originSystem;
                }
                getExternalCode() {
                        return this.externalCode;
                }
                setExternalCode(externalCode) {
                        this.externalCode = externalCode;
                }
                getDateOfIssue() {
                        return this.dateOfIssue;
                }
                setDateOfIssue(dateOfIssue) {
                        this.dateOfIssue = dateOfIssue;
                }
                getDueDate() {
                        return this.dueDate;
                }
                setDueDate(dueDate) {
                        this.dueDate = dueDate;
                }
                getPayday() {
                        return this.payday;
                }
                setPayday(payday) {
                        this.payday = payday;
                }
                getDescription() {
                        return this.description;
                }
                setDescription(description) {
                        this.description = description;
                }
                getObservation() {
                        return this.observation;
                }
                setObservation(observation) {
                        this.observation = observation;
                }
                getDocumentType() {
                        return this.documentType;
                }
                setDocumentType(documentType) {
                        this.documentType = documentType;
                }
                getDocumentNumber() {
                        return this.documentNumber;
                }
                setDocumentNumber(documentNumber) {
                        this.documentNumber = documentNumber;
                }
                getAccountingAccountPlan() {
                        return this.accountingAccountPlan;
                }
                setAccountingAccountPlan(accountingAccountPlan) {
                        this.accountingAccountPlan = accountingAccountPlan;
                }
                getAccountingAccount() {
                        return this.accountingAccount;
                }
                setAccountingAccount(accountingAccount) {
                        this.accountingAccount = accountingAccount;
                }
                getCostCenterPlan() {
                        return this.costCenterPlan;
                }
                setCostCenterPlan(costCenterPlan) {
                        this.costCenterPlan = costCenterPlan;
                }
                getCostCenter() {
                        return this.costCenter;
                }
                setCostCenter(costCenter) {
                        this.costCenter = costCenter;
                }
                getCurrentAccount() {
                        return this.currentAccount;
                }
                setCurrentAccount(currentAccount) {
                        this.currentAccount = currentAccount;
                }
                getPaymentNumber() {
                        return this.paymentNumber;
                }
                setPaymentNumber(paymentNumber) {
                        this.paymentNumber = paymentNumber;
                }
                getCurrency() {
                        return this.currency;
                }
                setCurrency(currency) {
                        this.currency = currency;
                }
                getEventType() {
                        return this.eventType;
                }
                setEventType(eventType) {
                        this.eventType = eventType;
                }
                getValue() {
                        return this.value;
                }
                setValue(value) {
                        this.value = value;
                }
                getValueBusiness() {
                        return this.valueBusiness;
                }
                setValueBusiness(valueBusiness) {
                        this.valueBusiness = valueBusiness;
                }
                getConversionBusiness() {
                        return this.conversionBusiness;
                }
                setConversionBusiness(conversionBusiness) {
                        this.conversionBusiness = conversionBusiness;
                }
                getFixedRateAccount() {
                        return this.fixedRateAccount;
                }
                setFixedRateAccount(fixedRateAccount) {
                        this.fixedRateAccount = fixedRateAccount;
                }
                getBeneficiaryOrigin() {
                        return this.beneficiaryOrigin;
                }
                setBeneficiaryOrigin(beneficiaryOrigin) {
                        this.beneficiaryOrigin = beneficiaryOrigin;
                }
                getBeneficiary() {
                        return this.beneficiary;
                }
                setBeneficiary(beneficiary) {
                        this.beneficiary = beneficiary;
                }
                getBeneficiaryType() {
                        return this.beneficiaryType;
                }
                setBeneficiaryType(beneficiaryType) {
                        this.beneficiaryType = beneficiaryType;
                }
                getMotionWay() {
                        return this.motionWay;
                }
                setMotionWay(motionWay) {
                        this.motionWay = motionWay;
                }
                getFlexField001() {
                        return this.flexField001;
                }
                setFlexField001(flexField001) {
                        this.flexField001 = flexField001;
                }

                toJson() {
                        return {
                                "dataAtualizacao": this.dataAtualizacao,
                                "integrationType": this.integrationType,
                                "scenario": this.scenario,
                                "businessUnit": this.businessUnit,
                                "originSystem": this.originSystem,
                                "externalCode": this.externalCode,
                                "dateOfIssue": this.dateOfIssue,
                                "dueDate": this.dueDate,
                                "payday": this.payday,
                                "description": this.description,
                                "observation": this.observation,
                                "documentType": this.documentType,
                                "documentNumber": this.documentNumber,
                                "accountingAccountPlan": this.accountingAccountPlan,
                                "accountingAccount": this.accountingAccount,
                                "costCenterPlan": this.costCenterPlan,
                                "costCenter": this.costCenter,
                                "currentAccount": this.currentAccount,
                                "paymentNumber": this.paymentNumber,
                                "currency": this.currency,
                                "eventType": this.eventType,
                                "value": this.value,
                                "valueBusiness": this.valueBusiness,
                                "conversionBusiness": this.conversionBusiness,
                                "fixedRateAccount": this.fixedRateAccount,
                                "beneficiaryOrigin": this.beneficiaryOrigin,
                                "beneficiary": this.beneficiary,
                                "beneficiaryType": this.beneficiaryType,
                                "motionWay": this.motionWay,
                                "flexField001": this.flexField001
                        }
                }

        }








        return {
                post
        }


});
