
    function customizeGlImpact(transactionRecord, standardLines, customLines, book)
    {
        var countStandard=standardLines.getCount();
        nlapiLogExecution("DEBUG", "Line Count",standardLines.getCount());
        //To get the first standard line which appear in the GL impact
        var currLine = standardLines.getLine(0);
        //To get the entity from the standard line
        var entityId = currLine.getEntityId();
        //To get the subsidiary which is chosen on the transaction
        var tranSubsidiary=transactionRecord.getFieldValue('subsidiary');
        //To get the record type of the transaction
        var recordType=transactionRecord.getRecordType();
        nlapiLogExecution("DEBUG", "Subsidiary",tranSubsidiary);
        //To get the custom field value which is on the transaction
        if(recordType == 'invoice'){
                nlapiLogExecution("DEBUG", "commission",commission);
                //To add new custom line in the GL impact
                var newLine = customLines.addNewLine();
                newLine.setDebitAmount(standardLines.getLine(0).getCreditAmount());
                //set debit account- commissions account - 140 is the internal id of the respective account
                newLine.setAccountId(standardLines.getLine(0).getAccountId());
                newLine.setEntityId(entityId);
                newLine.setMemo("Zerar Primeiro Lançamento");
                //To add new custom line in the GL impact
                var newLine = customLines.addNewLine();
                //To set Credit amount
                newLine.setCreditAmount(standardLines.getLine(1).getDebitAmount());
//set credit account- commission liability account - 120 is the internal id of the respective account
                newLine.setAccountId(standardLines.getLine(1).getAccountId());
                newLine.setEntityId(entityId);
                newLine.setMemo("Zerar Segundo Lançamento");
        }
    }
