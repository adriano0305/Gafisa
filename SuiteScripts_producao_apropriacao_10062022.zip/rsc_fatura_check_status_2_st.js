/**
 *@NApiVersion 2.1
 *@NScriptType Suitelet
 */
define(['N/log', 'N/task'], function(log, task) {
function onRequest(context) {
    log.audit('onRequest', context);

    const request = context.request;

    const response = context.response;
    
    const parameters = request.parameters;
    log.audit('parameters', parameters);

    if (request.method == 'POST') {
        log.audit('método', request.method);
    }
}

return {
    onRequest: onRequest
}
});
