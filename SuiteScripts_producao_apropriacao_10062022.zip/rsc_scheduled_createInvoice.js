/**
 *@NApiVersion 2.x
 *@NScriptType ScheduledScript
 */
define(['N/runtime', 'N/record'], function(runtime, record) {

    function execute(context) {
        var scriptObj = runtime.getCurrentScript()
        var othersObj = JSON.parse(scriptObj.getParameter({name: 'custscript_rsc_get_recfatura'}))
        var objList = JSON.parse(scriptObj.getParameter({name: 'custscript_rsc_get_objlist'}))
        var objSublist = JSON.parse(scriptObj.getParameter({name: 'custscript_rsc_get_objsublist'}))
        var qtdFaturas = scriptObj.getParameter({name: 'custscript_rsc_qtdfaturas'})

        record.load({type: 'invoice', id: othersObj['id']}).setValue({fieldId: 'custbody_rsc_checkparcelas', value: true}).save()

        var get_month = -1;
        function tratarData(data) {
            var dataCadastro = data.split('T');
            var dateCadastro = dataCadastro[0].split('-');
            var cadastroData = dateCadastro[2] + '/' + dateCadastro[1] + '/' + dateCadastro[0];
            cadastroData = cadastroData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            cadastroData = new Date(cadastroData);
            return cadastroData;
    }       

        switch (parseInt(qtdFaturas)){
            case 3: 
                var new_qtdFaturas = 2
                objSublist['amount'] = (othersObj['total']) / new_qtdFaturas

                for (var i = 0; i < new_qtdFaturas; i++) {
                    try {
                        var new_invoice = record.create({
                            type: 'customsale_rsc_financiamento'
                        });
                        Object.keys(objList).forEach(function (field) {
                            if(field == 'duedate'){
                                get_month += 1  
                                var dt_month = tratarData(objList[field])                            
                                var new_date = new Date(dt_month.setMonth(dt_month.getMonth() + get_month))

                                return new_invoice.setValue({ fieldId: field, value: new_date})

                            } else if (field == 'startdate' || field == 'enddate'){
                                return  new_invoice.setValue({ fieldId: field, value: tratarData(objList[field])})
                            }

                            new_invoice.setValue({ fieldId: field, value: objList[field] })
                            
                        });
                        Object.keys(objSublist).forEach(function (field) {
                            new_invoice.setSublistValue({sublistId: 'item', line: 0, fieldId: field, value: objSublist[field] })
                        });

                        new_invoice.save({
                            ignoreMandatoryFields: true
                        });
                    }
                    catch (e) {
                    log.debug('error', e)
                    }
                }
                break;

            case 2:
                var new_qtdFaturas = 241
                objSublist['amount'] = (othersObj['total']) / new_qtdFaturas

                for (var i = 0; i < new_qtdFaturas; i++) {
                    try {
                        var new_invoice = record.create({
                            type: 'customsale_rsc_financiamento'
                        });
                        Object.keys(objList).forEach(function (field) {
                            if(field == 'duedate'){
                                get_month += 1  
                                var dt_month = tratarData(objList[field])                            
                                var new_date = new Date(dt_month.setMonth(dt_month.getMonth() + get_month))

                                return new_invoice.setValue({ fieldId: field, value: new_date})

                            } else if (field == 'startdate' || field == 'enddate'){
                                return  new_invoice.setValue({ fieldId: field, value: tratarData(objList[field])})
                            }

                            new_invoice.setValue({ fieldId: field, value: objList[field] })
                            
                        });
                        Object.keys(objSublist).forEach(function (field) {
                            new_invoice.setSublistValue({sublistId: 'item', line: 0, fieldId: field, value: objSublist[field] })
                        });

                        new_invoice.save({
                            ignoreMandatoryFields: true
                        });
                    }
                    catch (e) {
                    log.debug('error', e)
                    }
                }
                break

            case 1:
                var new_qtdFaturas = 100
                objSublist['amount'] = (othersObj['total']) / new_qtdFaturas

                for (var i = 0; i < new_qtdFaturas; i++) {
                    try {
                        var new_invoice = record.create({
                            type: 'customsale_rsc_financiamento'
                        });
                        Object.keys(objList).forEach(function (field) {
                            if(field == 'duedate'){
                                get_month += 1  
                                var dt_month = tratarData(objList[field])                            
                                var new_date = new Date(dt_month.setMonth(dt_month.getMonth() + get_month))

                                return new_invoice.setValue({ fieldId: field, value: new_date})

                            } else if (field == 'startdate' || field == 'enddate'){
                                return  new_invoice.setValue({ fieldId: field, value: tratarData(objList[field])})
                            }

                            new_invoice.setValue({ fieldId: field, value: objList[field] })
                            
                        });
                        Object.keys(objSublist).forEach(function (field) {
                            new_invoice.setSublistValue({sublistId: 'item', line: 0, fieldId: field, value: objSublist[field] })
                        });

                        new_invoice.save({
                            ignoreMandatoryFields: true
                        });
                    }
                    catch (e) {
                    log.debug('error', e)
                    }
                }
                break
        }


    }

    return {
        execute: execute
    }
});
