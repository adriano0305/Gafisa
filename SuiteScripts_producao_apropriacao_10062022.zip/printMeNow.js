/**
 *@NApiVersion 2.1
*@NScriptType ClientScript
*/
define(['N/record'], (record) => {
const pageInit = (context) => {}

const printMeNow = () => {
    var id = record.id;
    show_preview(document.forms['main_form'].orderid.value, id); //Standard Print Button on Item Fulfillment
    print_shipping_label(document.forms['main_form'].orderid.value, id); //Standard Print Label Button on Item Fulfillment
    window.open('/app/accounting/print/barcodeprinter.nl?trantype=itemfulfillment&tranid=' + id); // Standard Print Item Labels Button on Item Fulfillment
}

return {
    printMeNow: printMeNow,
    pageInit: pageInit,
    // saveRecord: saveRecord,
    // validateField: validateField,
    // fieldChanged: fieldChanged,
    // postSourcing: postSourcing,
    // lineInit: lineInit,
    // validateDelete: validateDelete,
    // validateInsert: validateInsert,
    // validateLine: validateLine,
    // sublistChanged: sublistChanged
}
});