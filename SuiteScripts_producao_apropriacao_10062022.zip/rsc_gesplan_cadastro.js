/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/search', 'N/query'],
    
    (search,queryModule) => {

        /**
         * Defines the function that is executed when a POST request is sent to a RESTlet.
         * @param {string | Object} requestBody - The HTTP request body; request body is passed as a string when request
         *     Content-Type is 'text/plain' or parsed into an Object when request Content-Type is 'application/json' (in which case
         *     the body must be a valid JSON)
         * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
         *     Object when request Content-Type is 'application/json' or 'application/xml'
         * @since 2015.2
         */
        const post = (requestBody) => {
                log.debug({title:'Params', details:requestBody})
                const operation = requestBody.tipoRegistro;

                log.debug({title: 'Resultado', details: operation})
                return doAction(requestBody);
        }

        function doAction(body){
                    var retorno = []
                    try {
                            /*
                                Conta Contábil
                                Centro de Custo
                                Beneficiário
                                Forma de movimento
                                Tipo de documento
                             */
                            var lista = ["contaContabil", "centroCusto", "beneficiario", "formaMov", "tpDoc"];

                            log.debug({title: 'Lista', details: lista.indexOf(body.tipoRegistro)})
                            switch (lista.indexOf(body.tipoRegistro)) {
                                    case 0:
                                            log.debug({title:'Conta Contabil', details:retorno})
                                            retorno = getContaContabil(body);
                                            log.debug({title:'Retorno', details:retorno})
                                            break;
                                    case 1:
                                            retorno = getCentroCusto(body);
                                            break;
                                    case 2:
                                            retorno = getBeneficiario(body);
                                            break;
                                    case 3:
                                            retorno = getFormaMovimento(body);
                                            break;
                                    case 4:
                                            retorno = getTpDoc(body);
                                            break;
                                    default:
                                            retorno = null;
                                            break;
                            }
                    } catch (e) {
                            retorno = JSON.stringify({erro: e});
                    }


                    return retorno;
            }

        function getContaContabil(body) {
               log.debug({title:'Select', details:'Entrou no processo'});
                var columns = ['name', 'type', 'number', 'displayname'];
                var filters = [];
                filters.push(["number", "is", body.externalCode]);

                var searchObj = search.create({
                    type: "account",
                    filters: filters,
                    columns: columns
                });

                var searchResultCount = searchObj.runPaged().count;
                log.debug("subsidiarySearchObj result count",searchResultCount);

                log.debug({title:'Select', details:'Montou select'})
                var pagedData = searchObj.runPaged({
                    pageSize: 1000
                });
                log.debug({title:'Select', details:'Rodou a query'})
                var tb_stage_empresa = [];
                // iterate the pages
                for( var i=0; i < pagedData.pageRanges.length; i++ ) {

                    // fetch the current page data
                    var currentPage = pagedData.fetch(i);

                    // and forEach() thru all results
                    currentPage.data.forEach( function(result) {

                            const empresa = {
                                    'name': result.getValue('displayname'),
                                    'externalCode': result.getValue('number'),
                                    'chartOfAccounts': '01',
                                    'classification': result.getValue('number').substr(0,1)
                            }

                            tb_stage_empresa.push(empresa);

                    });

                }
                log.debug({title:'Dados', details:tb_stage_empresa})

                return JSON.stringify(tb_stage_empresa);

        }

        function getCentroCusto(body) {
            log.debug({title:'Select', details:'Entrou no processo'});
            // Run the query.
            try {

                var queryResults

                    queryResults = queryModule.runSuiteQL(
                        {
                            query: 'select * from (select name, \'CC\' || id id , \'1\' categoria, custrecord_lrc_modifica_departamento dataupdate from department \n' +
                                'union\n' +
                                'select name, \'OI\' || id id, \'3\' categoria, custrecord_lrc_data_modifica_class dataupdate from classification\n' +
                                'union\n' +
                                'select companyname, \'CL\' || id id, \'2\' categoria, lastmodifieddate dataupdate from job) a\n' +
                                'where id = ?  ',
                            params: [body.externalCode]
                        }
                    );


                var tb_stage_empresa = [];
                var records = queryResults.asMappedResults();
                // If records were returned...
                if ( records.length > 0 ) {


                    // Add the records to the sublist...
                    for ( r = 0; r < records.length; r++ ) {
                        // Get the record.
                        var record = records[r];

                        const empresa = {
                            'name': record['name'],
                            'externalCode': record['id'],
                            'category': record['categoria'],
                            'costCenterPlan': '01'
                        }

                        tb_stage_empresa.push(empresa);


                    }
                }
                log.debug({title:'Dados', details:tb_stage_empresa})
            } catch (e){
                log.debug({title: 'Error Recuperar informaçoes', details: e.toString()})
            }
            return JSON.stringify(tb_stage_empresa);

        }

        function getBeneficiario(body) {
            log.debug({title:'Select', details:'Entrou no processo'});
            // Run the query.
            try {

                var queryResults

                queryResults = queryModule.runSuiteQL(
                    {
                        query: 'select externalCode, b.altname, a.tipo, a.custentity_enl_cnpjcpf, dataupdate from (select entityid externalCode, custentity_enl_cnpjcpf, \'1\' tipo, custentity_lrc_data_modifica_cliente dataupdate from customer\n' +
                            '            union\n' +
                            '            select entityid externalCode, custentity_enl_cnpjcpf, \'2\' tipo, custentity_lrc_data_modifica_fornec dataupdate from employee\n' +
                            '            union\n' +
                            '            select entityid externalCode, custentity_enl_cnpjcpf, \'3\' tipo, custentity_lrc_data_modifica_fornec dataupdate from vendor ) a\n' +
                            '            join entity b on a.externalCode = b.entityid\n' +
                            '            where b.entityid = ?',
                        params: [body.externalCode]
                    }
                );


            var tb_stage_empresa = [];
            var records = queryResults.asMappedResults();
            // If records were returned...
            if ( records.length > 0 ) {


                // Add the records to the sublist...
                for ( r = 0; r < records.length; r++ ) {
                    // Get the record.
                    var record = records[r];

                    const empresa = {
                        name: record['altname'],
                        externalCode: record['entityid'],
                        federalCode: record['custentity_enl_cnpjcpf'],
                        beneficiaryOrigin: record['entityid'],
                        beneficiaryType: record['tipo']
                    }

                    tb_stage_empresa.push(empresa);


                }
            }
            log.debug({title:'Dados', details:tb_stage_empresa})
            } catch (e){
                log.debug({title: 'Error Recuperar informaçoes', details: e.toString()})
            }
            return JSON.stringify(tb_stage_empresa);
        }

        function getFormaMovimento(body) {
            var retorno = [];
            try {
                var queryResults;
                queryResults = queryModule.runSuiteQL(
                    {
                        query: 'select * from customlistlrc_metodos_pagamento ' +
                            '            where recordid = ?',
                        params: [body.externalCode]
                    }
                );
                var tb_stage_empresa = [];
                var records = queryResults.asMappedResults();
                // If records were returned...
                if ( records.length > 0 ) {


                    // Add the records to the sublist...
                    for (r = 0; r < records.length; r++) {
                        // Get the record.
                        var record = records[r];

                        const empresa = {
                            name: record['name'],
                            externalCode: record.id,
                            transaction: '1 , 2'

                        }

                        tb_stage_empresa.push(empresa);
                    }
                }


            } catch (e){
                log.debug({title: 'Error Recuperar informaçoes', details: e.toString()})
            }

            return JSON.stringify(tb_stage_empresa);

        }

        function getTpDoc(body) {
            var retorno = [];
            var estrutura = {
                externalCode: 'modelo',
                description: 'Descrição Teste'
            }
            retorno.push(estrutura);

            return JSON.stringify(retorno);
        }



            return {post}

    });
