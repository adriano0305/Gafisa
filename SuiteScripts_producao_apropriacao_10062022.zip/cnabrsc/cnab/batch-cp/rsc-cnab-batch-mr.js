/**
 * @NApiVersion 2.0
 * @NScriptType MapReduceScript
 * @scriptName rsc-cnab-batch-mr
 */
 define([ 'N/record', 'N/log', 'N/runtime', './rsc-cnab-batch', 'N/error', './rsc-cnab-batch-file', 'N/file' , 'N/search', 'N/transaction'],
 /**
  *
  * @param record
  * @param log
  * @param runtime
  * @param lib
  * @param Nerror
  * @param files
  * @return {{getInputData: getInputData, summarize: summarize, map: map}}
  */
 function( record, log, runtime, lib, Nerror, file, nFile , search , Transaction)
 {
	 /**
	  * @function getInputData - get the expense report list to be processed
	  * @return {Object}
	  */
	 function getInputData()
	 {
		 try
		 {
			 const script = runtime.getCurrentScript();
			 const installments = script.getParameter({ name:'custscript_rsc_cnab_batchdata_cp_ds' });
			 log.debug( 'getInputData', installments );
			 return JSON.parse( installments );
 
		 } catch (e) {
			 throw 'MR.getInputData: '+e;
		 }
	 }
 
	 /**
	  * @function
	  * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
	  */
	 function map( context )
	 {
		 var installment = JSON.parse( context.value );
		 var id = context.key;
		 log.debug("BD TST",installment)
		 var t = record.load({ type: installment.transactionType, id: installment.transaction, isDynamic: true });
		 //Criacao do registro para controle do pagamento
		//  var accountSubPayment;
		 var registroPagamento = record.create({
			 type: "customrecord_rsc_cnab_pay_trans",
			 isDynamic: true            
		 })
		 registroPagamento.setValue({
			 fieldId: 'custrecord_rsc_cnab_pay_trans_cont', // controlador
			 value: installment.controller
		 })
		 registroPagamento.setValue({
			 fieldId: 'custrecord_rsc_cnab_bill_trans', // transacao
			 value: installment.transaction
		 })
		 registroPagamento.setValue({
			 fieldId: 'custrecord_rsc_cnab_id_parc', // parcela
			 value: id
		 })
		 registroPagamento.setValue({
			 fieldId: 'custrecordrsc_cnab_pay_status', // Status
			 value: "Criado"
		 })
		 registroPagamento.setValue({
			 fieldId: 'custrecord_rsc_cnab_id_conta_pay', // bankAccount
			 value: installment.bankAccount
		 })
		 registroPagamento.setValue({
			 fieldId: 'custrecord_rsc_cnab_pay_data', // paymentDate
			 value: installment.paymentDate
		 })
		 if(t.getValue('subsidiary') != installment.subsidiary_payer){
			registroPagamento.setValue({
				fieldId:'custrecord_rsc_subsidiaria_pagadora',
				value: installment.subsidiary_payer
			})
			registroPagamento.setValue({
				fieldId: 'custrecord_rsc_cnab_id_conta_pay', // subsidiaria pagadora
				value: t.getValue('custbody_rsc_cnab_bankaccountloc_ls')
			})
		 }
 
		 //bankAccount
		 //paymentDate
		 registroPagamento.save()
 
		 try
		 {
			var transaction = record.load({ type: installment.transactionType, id: installment.transaction, isDynamic: true });
			 var line = transaction.findSublistLineWithValue({ sublistId: 'installment', fieldId: 'id', value: id });
			 var linhasItem = transaction.getLineCount({
				 sublistId: 'item'
			 })
			 var departamento;
			 var location;
			 var etapa;
			 // var projeto = custbody_rsc_projeto_obra_gasto_compra;
 
			 if(linhasItem > 0){
				 departamento = transaction.getSublistValue({sublistId:'item', fieldId:'department', line: 0})
				 location = transaction.getSublistValue({sublistId:'item', fieldId:'location', line: 0})
				 etapa = transaction.getSublistValue({sublistId:'item', fieldId:'class', line: 0})
			 }else{
				 departamento = transaction.getSublistValue({sublistId:'expense', fieldId:'department', line: 0})
				 location = transaction.getSublistValue({sublistId:'expense', fieldId:'location', line: 0})
				 // etapa = transaction.getSublistValue({sublistId:'expense', fieldId:'class', line: 0})
			 }
			 
			 if( line > -1 )
			 {	 var accountSubPayment;
				 var intercompanyJournalentry = transaction.getSublistValue({
					 sublistId: 'installment',
					 fieldId:'custrecord_rsc_lancamento_intercompany',
					 line: line
				 })
				 var vendorLookup = search.lookupFields({
					 type:'vendor',
					 id: transaction.getValue('entity'),
					 columns:['payablesaccount']
				 })
				 var subPaymentLookup = search.lookupFields({
					 type:'subsidiary',
					 id: transaction.getValue('subsidiary'),
					 columns:['custrecord_rsc_conta_intercia_pagar']
				 })
				 var subReceiveLookup = search.lookupFields({
					 type:'subsidiary',
					 id: installment.subsidiary_payer,
					 columns:['custrecord_rsc_conta_intercia_receber']
				 })
				 var bankAccountLookup = search.lookupFields({
					 type:'customrecord_rsc_cnab_bankaccount',
					 id: installment.bankAccount,
					 columns: ['custrecord_rsc_cnab_ba_accounting_ls']
				 })
				
				 log.debug('subpaymentLookup', subPaymentLookup.custrecord_rsc_conta_intercia_pagar.length)
				 if(subPaymentLookup.custrecord_rsc_conta_intercia_pagar.length > 0){
					 accountSubPayment = subPaymentLookup.custrecord_rsc_conta_intercia_pagar[0].value
				 }
				 var accountVendor;
				 if(vendorLookup.payablesaccount.length > 0){
					 accountVendor = vendorLookup.payablesaccount[0].value;
				 }
				 var accountSubReceive;
				 if(subReceiveLookup.custrecord_rsc_conta_intercia_receber.length > 0){
					 accountSubReceive = subReceiveLookup.custrecord_rsc_conta_intercia_receber[0].value
				 } 
				 var accountBankAccount;
				 if(bankAccountLookup.custrecord_rsc_cnab_ba_accounting_ls.length > 0){
					 accountBankAccount = bankAccountLookup.custrecord_rsc_cnab_ba_accounting_ls[0].value
				 }
				 var intercompanyID;
				 if(intercompanyJournalentry){
					 if(transaction.getValue('subsidiary') != installment.subsidiary_payer){
						 var oldjournalentry = record.load({
							 type: 'advintercompanyjournalentry',
							 id: intercompanyJournalentry
						 })
						 var cancelado = oldjournalentry.getSublistValue({
							 sublistId:'line',
							 fieldId:'memo',
							 line:0
						 })
						 if(cancelado == 'VOID'){
							 Transaction.void({
								 type:'advintercompanyjournalentry',
								 id:intercompanyJournalentry
							 })
						 }
						 var journalentry = record.create({
							 type:'advintercompanyjournalentry'
						 })
						 journalentry.setValue({
							 fieldId: 'subsidiary',
							 value: transaction.getValue('subsidiary')
						 })
						 journalentry.setValue({
							 fieldId: 'custbody_gaf_vendor',
							 value: transaction.getValue('entity')
						 })
						 var trandate = installment.paymentDate
						 trandate = trandate.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
						 trandate = new Date(trandate);
						 journalentry.setValue({
							 fieldId:'trandate',
							 value: trandate
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'linesubsidiary',
							 line:0,
							 value: transaction.getValue('subsidiary')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'account',
							 line:0,
							 value: accountVendor
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'debit',
							 line:0,
							 value: installment.amount
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'entity',
							 line:0,
							 value: transaction.getValue('entity')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'department',
							 line:0,
							 value: departamento
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'location',
							 line:0,
							 value: location
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'class',
							 line: 0,
							 value: etapa
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'linesubsidiary',
							 line:1,
							 value: transaction.getValue('subsidiary')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'account',
							 line:1,
							 value: accountSubPayment
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'credit',
							 line:1,
							 value: installment.amount
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'custcol_rsc_fieldcliente',
							 line:1,
							 value: transaction.getValue('custbody_rsc_projeto_obra_gasto_compra')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'location',
							 line:1,
							 value: location
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'department',
							 line:1,
							 value: departamento
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'class',
							 line:1,
							 value: etapa
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'custcol_rsc_devido_subsidiary',
							 line:1,
							 value: installment.subsidiary_payer
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'custcol_rsc_fieldcliente',
							 line:2,
							 value: transaction.getValue('custbody_rsc_projeto_obra_gasto_compra')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'linesubsidiary',
							 line:2,
							 value: installment.subsidiary_payer
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'custcol_rsc_devido_subsidiary',
							 line:2,
							 value:transaction.getValue('subsidiary')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'account',
							 line:2,
							 value: accountSubReceive
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'debit',
							 line:2,
							 value: installment.amount
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'linesubsidiary',
							 line:3,
							 value: installment.subsidiary_payer
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'account',
							 line:3,
							 value: accountBankAccount
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'credit',
							 line:3,
							 value: installment.amount
						 })
						 intercompanyID = journalentry.save({
							 ignoreMandatoryFields: true
						 })
						 log.debug('intercompanyID', intercompanyID)
					 }
				 }else{
					 if(transaction.getValue('subsidiary') != installment.subsidiary_payer){
						 // log.debu("subPrimeiraTela")
						 var journalentry = record.create({
							 type:'advintercompanyjournalentry'
						 })
						 journalentry.setValue({
							 fieldId: 'subsidiary',
							 value: transaction.getValue('subsidiary')
						 })
						 journalentry.setValue({
							 fieldId: 'custbody_gaf_vendor',
							 value: transaction.getValue('entity')
						 })
						 var trandate = installment.paymentDate
						 trandate = trandate.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
						 trandate = new Date(trandate);
						 journalentry.setValue({
							 fieldId:'trandate',
							 value: trandate
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'linesubsidiary',
							 line:0,
							 value: transaction.getValue('subsidiary')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'account',
							 line:0,
							 value: accountVendor
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'debit',
							 line:0,
							 value: installment.amount
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'entity',
							 line:0,
							 value: transaction.getValue('entity')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'department',
							 line:0,
							 value: departamento
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'location',
							 line:0,
							 value: location
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'class',
							 line: 0,
							 value: etapa
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'linesubsidiary',
							 line:1,
							 value: transaction.getValue('subsidiary')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'account',
							 line:1,
							 value: accountSubPayment
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'credit',
							 line:1,
							 value: installment.amount
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'custcol_rsc_fieldcliente',
							 line:1,
							 value: transaction.getValue('custbody_rsc_projeto_obra_gasto_compra')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'location',
							 line:1,
							 value: location
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'department',
							 line:1,
							 value: departamento
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'class',
							 line:1,
							 value: etapa
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'custcol_rsc_devido_subsidiary',
							 line:1,
							 value: installment.subsidiary_payer
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'linesubsidiary',
							 line:2,
							 value: installment.subsidiary_payer
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'custcol_rsc_devido_subsidiary',
							 line:2,
							 value:transaction.getValue('subsidiary')
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'account',
							 line:2,
							 value: accountSubReceive
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'debit',
							 line:2,
							 value: installment.amount
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'linesubsidiary',
							 line:3,
							 value: installment.subsidiary_payer
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'account',
							 line:3,
							 value: accountBankAccount
						 })
						 journalentry.setSublistValue({
							 sublistId:'line',
							 fieldId:'credit',
							 line:3,
							 value: installment.amount
						 })
						 intercompanyID = journalentry.save({
							 ignoreMandatoryFields: true
						 })
						 log.debug('intercompanyID', intercompanyID)
					 }
				 }
				 lib.setInstallmentValue( transaction, installment, line, intercompanyID);
				 var values = lib.getInstallmentValue( transaction, line, id, installment.entityType, installment.layout );
				 nFile.create({
					 name: 'installment_contas_a_pagar.json',
					 fileType: nFile.Type.JSON,
					 contents: JSON.stringify(values, null, 2),
					 encoding: nFile.Encoding.UTF8,
					 folder: -15
				 })
					 .save()
 
				 lib.updateSequentialBank( values.custrecord_rsc_cnab_inst_locationba_ls.bankId );
				 values.controller = installment.controller;
				 values.layout = installment.layout;
				 values.transaction = installment.transaction;
				 values.cnabType = installment.cnabType;
				 context.write({ key: id, value: values });
			 }
 
		 } catch( e ) {
			 log.error( 'map', 'installment id: ' + id + ' -- error: ' + e );
			 log.debug('installment.transaction', installment.transaction);
			 var fatura = record.load({
				 type:'vendorbill',
				 id: installment.transaction
			 })
			 var lines = fatura.getLineCount({
				 sublistId:'installment'
			 })
			 log.debug('lines', lines);
			 for(var i = 0;i<lines;i ++){
				 var idInstallment = fatura.getSublistValue({
					 sublistId:'installment',
					 fieldId: 'id',
					 line: i
				 })
				 log.debug('id', id);
				 log.debug('idInstallment', idInstallment);
				 if(idInstallment == id){
					 var idInstallment = fatura.setSublistValue({
						 sublistId:'installment',
						 fieldId: 'custrecord_rsc_cnab_inst_status_ls',
						 value: 1,
						 line: i
					 })
				 }
			 }
			 //Rollback da contabilizacao
			 var customrecord_rsc_cnab_pay_transSearchObj = search.create({
				 type: "customrecord_rsc_cnab_pay_trans",
				 filters:
				 [
					["custrecord_rsc_cnab_bill_trans","is",installment.transaction], 
					"AND", 
					["custrecord_rsc_cnab_id_parc","is",id]
				 ],
				 columns:
				 [
					search.createColumn({
					   name: "scriptid",
					   sort: search.Sort.ASC
					}),
					"custrecord_rsc_cnab_pay_trans_cont",
					"custrecord_rsc_cnab_bill_trans",
					"custrecord_rsc_cnab_id_parc",
					"custrecord_rsc_cnab_transpay",
					"custrecordrsc_cnab_pay_status"
				 ]
			  });
			  var searchresult = customrecord_rsc_cnab_pay_transSearchObj.run().getRange(0,2)
			  var paymentTransaction = searchresult[0].getValue("custrecord_rsc_cnab_transpay")
			  record.delete({type: "vendorpayment", id: paymentTransaction});
			 //
			 try{
				 fatura.save({ignoreMandatoryFields: true});
			 }catch(e){
				 log.error('error save -> disponivel', e)
			 }
			 
			 throw Nerror.create({ name: installment.controller, message: e });
		 }
	 }
 
	 /**
	  * @function
	  * @param context
	  */
	 function summarize( context )
	 {
		 var errors = [];
		 var controllerId = 0;
		 var installments = {};
		 var segments = [];
		 var layout = 0;
		 var folder = 0;
		 var fileId = undefined;
		 /** Errors Iterator */
		 context.mapSummary.errors.iterator().each( function( key, error )
		 {
			 log.error({ title: 'error', details: error });
			 var e = JSON.parse( error );
			 controllerId = e.name;
			 errors.push( key );
			 return true;
		 });
		 /** Output Iterator */
		 context.output.iterator().each( function( key, value )
		 {
			 installments[ key ] = {};
			 installments[ key ] = JSON.parse( value );
			 controllerId = installments[ key ].controller;
			 layout = installments[ key ].layout;
			 folder = installments[ key ].custrecord_rsc_cnab_inst_locationba_ls.folder;
			 lib.includeSegmentType( segments, installments[ key ].custrecord_rsc_cnab_inst_paymentmetho_ls.segment );
			 return true;
		 });
	 
	 log.debug({ title: 'installments', details: installments });
		try {
			 /** Create File */
			 if( Object.getOwnPropertyNames(installments).length > 0 )
			 {
				 var _segments = lib.getSegments( layout, lib.filterSegmentType( segments ) );
				 var fileContent = file.buildFile( _segments, installments );			
				 fileId = lib.createFile( fileContent, folder );
			 }
		 log.debug({ title: 'controllerId', details: controllerId });
			 /** Update Controller */
			 lib.updateController( controllerId, errors, fileId );
		} catch ( e ) {
			log.error("e",e)
			log.error("controllerId",controllerId)
			log.error("errors",errors)
			log.error("fileId",fileId)

			var x = record.create({
				type:"customrecord_log",
				isDynamic: true            
			})
			x.setValue({
				fieldId:"custrecord_log",
				value:JSON.stringify(e)
			})
			x.save()
		} 
	
	 }
 
	 return {
		 getInputData: getInputData,
		 map: map,
		 summarize: summarize
	 };
 });