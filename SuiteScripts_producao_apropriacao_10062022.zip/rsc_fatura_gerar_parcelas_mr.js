/**
 *@NApiVersion 2.1
 *@NScriptType MapReduceScript
 */
define(['N/log', 'N/query', 'N/record', 'N/runtime', 'N/search'], (log, query, record, runtime, search) => {
const getInputData = (context) => {
    log.audit('getInputData', context);

    const scriptAtual = runtime.getCurrentScript();
    log.audit('scriptAtual', scriptAtual);

    const parametro = JSON.parse(scriptAtual.getParameter({name: 'custscript_rsc_json_fatura'}));
    log.audit('parametro', parametro);                

    for (n=0; n<parametro.quantidadeParcelas; n++) {
        const financiamentoInvoice = record.copy({type: 'customsale_rsc_financiamento', 
            id: parametro.ato,
            isDynamic: true
        });

        financiamentoInvoice.setValue('memo', (n+1)+'ª Parcela')
        .setValue('custbodyrsc_tpparc', parametro.custbodyrsc_tpparc);

        var duedate = new Date(parametro.duedate);
        
        duedate.setMonth(duedate.getMonth()+(n+1));

        financiamentoInvoice.setValue('duedate', duedate);         
            
        var financiamentoInvoiceId = financiamentoInvoice.save({ìgnoreMandatoryFields: true});
        log.audit((n+1)+'ª parcela', {financiamentoInvoiceId: financiamentoInvoiceId, duedate: duedate});                  
    }
}

const map = (context) => {}

const reduce = (context) => {}

const summarize = (summary) => {
    var type = summary.toString();
    log.audit(type, 
        '"Uso Consumido:" '+summary.usage+
        ', "Número de Filas:" '+summary.concurrency+
        ', "Quantidade de Saídas:" '+summary.yields
    );
    var contents = '';
    summary.output.iterator().each(function (key, value) {
        contents += (key + ' ' + value + '\n');
        return true;
    });
} 

return {
    getInputData: getInputData,
    map: map,
    reduce: reduce,
    summarize: summarize
}
});
