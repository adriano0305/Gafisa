/**
 *@NApiVersion 2.1
 *@NScriptType Suitelet
 */
define(['N/log', 'N/record', 'N/search', 'N/runtime'], function(log, record, search,runtime) {
    function onRequest(context) {
        log.audit('onRequest', context);

        const request = context.request;
        const response = context.response;

        if (request.method == 'GET') {
            try {
                const campo = runtime.getCurrentScript().getParameter({name: 'custscript_rsc_id_accountify'})

                const busca = search.load({
                    id: campo
                })

                const columns = busca.columns

                log.debug('Colunas', columns)

                return JSON.parse(columns[0])
            } catch (e) {
                log.debug('Error', e)
            }
        }
    }

    return {
        onRequest: onRequest
    }
});