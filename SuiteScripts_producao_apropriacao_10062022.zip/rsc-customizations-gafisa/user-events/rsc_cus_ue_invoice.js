/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/task'],
  (task) => {
    /**
     * Defines the function definition that is executed after record is submitted.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @since 2015.2
     */
    const afterSubmit = (scriptContext) => {
      if (scriptContext.type !== scriptContext.UserEventType.CREATE) return

      const newRecord = scriptContext.newRecord
      const projectId = newRecord.getValue({ fieldId: 'job' })
      const termsId = newRecord.getValue({ fieldId: 'custbody_rsc_terms' })
      const tranDate = newRecord.getValue({ fieldId: 'trandate' }).getTime()
      const total = newRecord.getValue({ fieldId: 'total' })

      if (!(termsId && projectId)) return

      const fieldsToCopy = [
        'entity',
        'job',
        'subsidiary',
        'class',
        'location'
      ]
        .reduce((a, fieldId) => {
          a[fieldId] = newRecord.getValue({ fieldId })
          return a
        }, {})

      task.create({
        taskType: task.TaskType.MAP_REDUCE,
        scriptId: 'customscript_rsc_cus_mr_create_installme',
        params: {
          custscript_rsc_inst_data: JSON.stringify({
            mainTransactionType: newRecord.type,
            mainTransactionId: newRecord.id,
            projectId,
            termsId,
            tranDate,
            total,
            fieldsToCopy
          })
        }
      })
        .submit()
    }

    return { afterSubmit }
  })
