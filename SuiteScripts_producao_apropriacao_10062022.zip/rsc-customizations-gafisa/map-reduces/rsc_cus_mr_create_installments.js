/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
define(['N/runtime', 'N/search', 'N/record'],
  (runtime, search, record) => {
    /**
     * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
     *
     * @param {Object} inputContext
     * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
     *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
     * @param {Object} inputContext.ObjectRef - Object that references the input data
     * @typedef {Object} ObjectRef
     * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
     * @property {string} ObjectRef.type - Type of the record instance that contains the input data
     * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
     * @since 2015.2
     */
    const getInputData = (inputContext) => {
      const data = _getData()
      const installmentSetup = _getInstallmentSetup(data.projectId)
      const termsColumns = ['custrecord_rsc_ter_installment_quantity']
      const termsValues = search.lookupFields({ type: 'customrecord_rsc_terms', id: data.termsId, columns: termsColumns })
      const installmentQuantity = termsValues[termsColumns[0]]
      const tranDate = new Date(data.tranDate)
      const amount = data.total / installmentQuantity
      const installments = []

      for (let i = 0; i < installmentQuantity; i++) {
        tranDate.setDate(tranDate.getDate() + 30)
        installments.push({
          mainTransactionType: data.mainTransactionType,
          mainTransactionId: data.mainTransactionId,
          fieldsToCopy: data.fieldsToCopy,
          tranDate: tranDate.getTime(),
          amount,
          ...installmentSetup
        })
      }

      return installments
    }

    /**
     * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
     * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
     * context.
     *
     * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
     *     is provided automatically based on the results of the getInputData stage.
     * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
     *     function on the current key-value pair
     * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
     *     pair
     * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
     *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
     * @param {string} mapContext.key - Key to be processed during the map stage
     * @param {string} mapContext.value - Value to be processed during the map stage
     * @since 2015.2
     */
    const map = (mapContext) => {
      const data = JSON.parse(mapContext.value)
      const mainTransactionType = data.mainTransactionType
      const installmentType = mainTransactionType === 'invoice'
        ? 'customsale_rsc_financiamento'
        : 'custompurchase_rsc_financiamento_pag'

      const installmentInvoice = record.create({ type: installmentType, isDynamic: true })

      Object.entries(data.fieldsToCopy).forEach(([fieldId, value]) => {
        installmentInvoice.setValue({ fieldId, value })
      })

      installmentInvoice.setValue({ fieldId: 'trandate', value: new Date(data.tranDate) })
      installmentInvoice.setValue({ fieldId: 'custbody_lrc_fatura_principal', value: data.mainTransactionId })
      installmentInvoice.setValue({ fieldId: 'custbody_enl_order_documenttype', value: data.documentFiscalTypeId })

      data.items
        .filter(item => item.isMain)
        .forEach(item => {
          installmentInvoice.selectNewLine({ sublistId: 'item' })
          installmentInvoice.setCurrentSublistValue({ sublistId: 'item', fieldId: 'item', value: item.id })
          installmentInvoice.setCurrentSublistValue({ sublistId: 'item', fieldId: 'quantity', value: 1 })
          installmentInvoice.setCurrentSublistValue({ sublistId: 'item', fieldId: 'rate', value: data.amount })
          installmentInvoice.commitLine({ sublistId: 'item' })
        })

      data.items
        .filter(item => !item.isMain)
        .forEach(item => {
          installmentInvoice.selectNewLine({ sublistId: 'item' })
          installmentInvoice.setCurrentSublistValue({ sublistId: 'item', fieldId: 'item', value: item.id })
          installmentInvoice.setCurrentSublistValue({ sublistId: 'item', fieldId: 'quantity', value: 1 })
          installmentInvoice.setCurrentSublistValue({ sublistId: 'item', fieldId: 'rate', value: 0 })
          installmentInvoice.commitLine({ sublistId: 'item' })
        })

      installmentInvoice.save({ ignoreMandatoryFields: true })
    }

    /**
     * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
     * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
     *
     * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
     * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
     *     script
     * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
     * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
     *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
     * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
     * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
     * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
     *     script
     * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
     * @param {Object} summaryContext.inputSummary - Statistics about the input stage
     * @param {Object} summaryContext.mapSummary - Statistics about the map stage
     * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
     * @since 2015.2
     */
    const summarize = (summaryContext) => {
      const inputSummaryError = summaryContext.inputSummary.error

      if (inputSummaryError) log.error({ title: 'Input Error', details: inputSummaryError })

      summaryContext.mapSummary.errors.iterator().each((key, error) => {
        log.error({ title: 'Map Error for key: ' + key, details: error })
        return true
      })

      record.submitFields({
        type: record.Type.INVOICE,
        id: _getData().mainTransactionId,
        values: {
          custbody_rsc_is_installment_complete: true
        },
        options: {
          enablesourcing: false,
          ignoreMandatoryFields: true
        }
      })
    }

    /**
     * Get data.
     *
     * @returns {any}
     * @private
     */
    const _getData = () => {
      return JSON.parse(runtime.getCurrentScript().getParameter({ name: 'custscript_rsc_inst_data' }))
    }

    /**
     * Get installment setup.
     *
     * @param projectId
     * @returns {{}}
     * @private
     */
    const _getInstallmentSetup = (projectId) => {
      return search.create({
        type: 'customrecord_rsc_installment_setup',
        filters: [{
          name: 'custrecord_rsc_ist_project',
          operator: search.Operator.ANYOF,
          values: projectId
        }],
        columns: [{
          name: 'custrecord_rsc_ist_project',
          sort: search.Sort.ASC
        }, {
          name: 'custrecord_rsc_ist_doc_fisc_type'
        }, {
          name: 'custrecord_rsc_isi_item',
          join: 'custrecord_rsc_isi_installment_setup'
        }, {
          name: 'custrecord_rsc_isi_main_item',
          join: 'custrecord_rsc_isi_installment_setup'
        }, {
          name: 'custrecord_rsc_isi_correction_unit',
          join: 'custrecord_rsc_isi_installment_setup'
        }]
      })
        .run()
        .getRange({
          start: 0,
          end: 1000
        })
        .reduce((a, result) => {
          const columns = result.columns

          a.documentFiscalTypeId = result.getValue(columns[1])

          if (!a.items) a.items = []

          a.items.push({
            id: result.getValue(columns[2]),
            isMain: result.getValue(columns[3])
          })

          return a
        }, {})
    }

    return { getInputData, map, summarize}

  });
