/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* Deve ser implementado um script programado mapReduce para realizar a criação das requisições de compra de um projeto.
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/runtime"], function (require, exports, search_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    runtime_1 = __importDefault(runtime_1);
    var getInputData = function (ctx) {
        return search_1.default.create({
            type: "customrecord_lrc_param_req_mod_projeto",
            filters: [["custrecord_lrc_num_document", "ISEMPTY", ""]],
            columns: [
                'custrecord_lrc_mod_proj_subsidiaria',
                'custrecord_lrc_mod_proj_solicitante',
                'custrecord_lrc_mod_proj_data_entrega',
                'custrecord_lrc_mod_proj_valor_total',
                'custrecord_lrc_sublist_itens_data',
                'custrecord_lrc_mod_proj_data',
                'custrecord_lrc_mod_proj' //modelo porjeto
            ]
        });
    };
    exports.getInputData = getInputData;
    //usar o reduce para reduzir as requisoes que devem ser criadas
    var map = function (ctx) {
        var _a;
        var req = JSON.parse(ctx.value);
        var obj = search_1.default.lookupFields({
            type: 'projecttemplate',
            id: req.values.custrecord_lrc_mod_proj.value,
            columns: ['startdate'] //aqui será colocado a data do modelo projeto
        });
        console.log(obj.startdate);
        var folderId = runtime_1.default.getCurrentScript().getParameter({ name: "custscript_lrc_prazo_criacao_req_compra" });
        // id parametro custscript_lrc_prazo_criacao_req_compra
        var date = new Date();
        var dataAtual = date.getDate;
        calculateDaysDiffIniciarOutorga(req.values.data.startdate);
        if (dataAtual == ((_a = obj.startdate) === null || _a === void 0 ? void 0 : _a.valueOf)) {
        }
    };
    exports.map = map;
    var calculateDaysDiffIniciarOutorga = function (dataInicioEscrituracao) {
        var dataInicioEscrituracaoObj = stringToDate(dataInicioEscrituracao);
        var diffInMiliseconds = Math.abs(new Date().getTime() - dataInicioEscrituracaoObj.getTime());
        return Math.floor(diffInMiliseconds / (1000 * 60 * 60 * 24));
    };
    //regex
    var stringToDate = function (date) {
        return new Date(date.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3"));
    };
});
