/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/query', 'N/search'], (query, search) => {

        /**
         * Defines the function that is executed when a POST request is sent to a RESTlet.
         * @param {string | Object} requestBody - The HTTP request body; request body is passed as a string when request
         *     Content-Type is 'text/plain' or parsed into an Object when request Content-Type is 'application/json' (in which case
         *     the body must be a valid JSON)
         * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
         *     Object when request Content-Type is 'application/json' or 'application/xml'
         * @since 2015.2
         */
        const post = (requestBody) => {
                log.debug({ title: 'Params', details: requestBody })
                const operation = requestBody.tipoRegistro;
                log.debug({ title: 'Resultado', details: operation })
                return doAction(requestBody);
        }

        function doAction(body) {
                var retorno = []
                try {
                        retorno = getReal(body);
                } catch (e) {
                        retorno = JSON.stringify({ erro: e.toString() });
                }
                return retorno;
        }

        function getReal(body) {
                log.debug({ title: 'Select', details: 'Entrou no processo' });

                var tb_stage_empresa = [];
                // Run the query.
                try {
                        //select TO_CHAR(lastModifiedDate,'DD/MM/YYYY HH:MI:SS') lastModifiedDate, b.subsidiary, a.id, a.trandate, a.duedate, a.trandate, a.memo, a.custbody4, a.transactionNumber, c.account, b.class, a. CUSTBODY_ENL_VENDORPAYMENTACCOUNT, currency, a.foreigntotal total, c.amount, a.exchangerate, a.entity, a.type from transaction a join transactionline b on a.id = b.transaction join transactionaccountingline c on a.id = c.transaction and b.id = c.transactionline where  type in ('VendPymt', 'CustPymt') and void = 'F'
                        var queryResults
                        var sql = 'select TO_CHAR(a.lastModifiedDate,\'DD/MM/YYYY HH:MI:SS\') lastModifiedDate, b.department departament,b.subsidiary, a.id, a.trandate, a.duedate, a.memo, ' +
                                'a.custbody4, a.transactionNumber, c1.acctnumber account, b.class, a.enddate, a. CUSTBODY_ENL_VENDORPAYMENTACCOUNT, ' +
                                'd.symbol currency, a.foreigntotal total, c.amount, a.exchangerate, a.entity, a.type, a.closedate, e.tipo, b.class, a.custbody_lrc_invoice_met_pag_fatura,  ' +
                                ' c2.custrecord_rsc_cnab_bank_code_ds || \'|\' || custrecord_rsc_cnab_ba_agencynumber_ls || custrecord_rsc_cnab_ba_dvagencynumber_ds || \'|\' || custrecord_rsc_cnab_ba_number_ds || custrecord_rsc_cnab_ba_dvnumber_ds as conta, a.custbody_rsc_installments from transaction a ' +
                                'join transactionline b on a.id = b.transaction ' +
                                'join transactionaccountingline c on a.id = c.transaction and b.id = c.transactionline ' +
                                'join currency d on a.currency = d.id ' +
                                'join account c1 on c.account = c1.id ' +
                                'left join customrecord_rsc_cnab_bankaccount c3 on c3.custrecord_rsc_cnab_ba_accounting_ls = b.expenseaccount ' +
                                'left join customrecord_rsc_cnab_bank c2 on c3.custrecord_rsc_cnab_ba_bank_ls = c2.id ' +
                                'join (select e1.id, externalCode, e2.altname, e1.tipo, e1.custentity_enl_cnpjcpf, dataupdate from (select id, entityid externalCode, custentity_enl_cnpjcpf, \'1\' tipo, custentity_lrc_data_modifica_cliente dataupdate from customer\n' +
                                '            union\n' +
                                '            select id, entityid externalCode, custentity_enl_cnpjcpf, \'2\' tipo, custentity_lrc_data_modifica_fornec dataupdate from employee \n' +
                                '            union\n' +
                                '            select id, entityid externalCode, custentity_enl_cnpjcpf, \'3\' tipo, custentity_lrc_data_modifica_fornec dataupdate from vendor ) e1\n' +
                                '            join entity e2 on e1.externalCode = e2.entityid) e on e.id = a.entity ' +
                                'where  ' +
                                'type in (\'VendPymt\', \'CustPymt\')' +
                                ' and void = \'F\'' +
                                ' and status in (\'C\', \'Y\')' +
                                ' and a.lastModifiedDate between TO_TIMESTAMP (\' ' + body.dataInicio + '\', \'DD/MM/YYYY HH24:MI:SS\') and TO_TIMESTAMP (\'' + body.dataFinal + '\', \'DD/MM/YYYY HH24:MI:SS\')';

                        var queryParams = new Array();
                        var arrResults = selectAllRows(sql, queryParams);
                        log.audit({ title: 'gesplan_mov_real - number of rows selected', details: arrResults.length });

                        var records = arrResults;
                        log.debug({ title: 'Qtd registros', details: records.length })

                        log.debug('Records', JSON.stringify(records));
                        // If records were returned...
                        let gesplanReturnList = new Array();
                        if (records.length > 0) {
                                //itera sobre os registros retornados na query
                                for (let r = 0; r < records.length; r++) {
                                        // Get the record.
                                        const record = records[r];
                                        log.debug({ title: 'Registro ' + r, details: JSON.stringify(record) });

                                        let originSystem = '';
                                        let eventType = '';
                                        switch (record['type']) {
                                                case 'VendPymt':
                                                        originSystem = 'CP';
                                                        eventType = 'S';
                                                        break;
                                                case 'CustPymt':
                                                        originSystem = 'CR';
                                                        eventType = 'E';
                                                        break;
                                                default: break;

                                        }

                                        log.debug("InstalmentsFromTransactionBodyField", record['custbody_rsc_installments']);


                                        if (_isValidJsonInstalmentFormat(record['custbody_rsc_installments'])) {


                                                //FAZ OP FOR EACH INSTALMENT


                                                let gesplanRecordId = record['transactionNumber'];
                                                let gesplanReturn = {
                                                        dataAtualizacao: record['lastmodifieddate'],
                                                        integrationType: '',
                                                        scenario: '01',
                                                        businessUnit: record['subsidiary'],
                                                        originSystem: originSystem,
                                                        externalCode: record['transactionnumber'],
                                                        dateOfIssue: record['trandate'],
                                                        dueDate: record['duedate'] == null ? record['trandate'] : record['duedate'],
                                                        payday: record['closedate'],
                                                        description: record['transactionnumber'] + ' - ' + (record['memo'] == null ? '' : record['memo']),
                                                        observation: '',
                                                        documentType: record['type'],
                                                        documentNumber: record['transactionnumber'],
                                                        accountingAccountPlan: '01',
                                                        accountingAccount: record['account'],
                                                        costCenterPlan: '01',
                                                        costCenter: (record['departament'] == null ? 0 : record['departament']),
                                                        currentAccount: record['conta'],
                                                        paymentNumber: '',
                                                        currency: record['currency'],
                                                        eventType: eventType,
                                                        value: (originSystem == 'CP' ? record['total'] * -1 : record['total']),
                                                        valueBusiness: '',
                                                        conversionBusiness: '',
                                                        fixedRateBusiness: '',
                                                        valueAccount: '',
                                                        conversionAccount: '',
                                                        fixedRateAccount: '',
                                                        beneficiaryOrigin: originSystem,
                                                        beneficiary: record['entity'],
                                                        beneficiaryType: record['tipo'],
                                                        motionWay: (record['custbody_lrc_invoice_met_pag_fatura'] == null ? 2 : record['custbody_lrc_invoice_met_pag_fatura']),
                                                        flexField001: (record['class'] == null ? 0 : record['class'])
                                                };



                                                log.debug('Data de vencimento', record['duedate'])
                                                log.debug('Data da transação', record['trandate'])
                                                /*
                                                if (record['trandate'] == null) {
                                                        log.error('É NULL')
                                                } else {
                                                        log.error('Não é NULL')
                                                }
                                                */
                                                const empresa = {
                                                        'dataAtualizacao': record['lastmodifieddate'],
                                                        'integrationType': '',
                                                        'scenario': '01',
                                                        'businessUnit': record['subsidiary'],
                                                        'originSystem': originSystem,
                                                        'externalCode': record['transactionnumber'],
                                                        'dateOfIssue': record['trandate'],
                                                        'dueDate': record['duedate'] == null ? record['trandate'] : record['duedate'],
                                                        'payday': record['closedate'],
                                                        'description': record['transactionnumber'] + ' - ' + (record['memo'] == null ? '' : record['memo']),
                                                        'observation': '',
                                                        'documentType': record['type'],
                                                        'documentNumber': record['transactionnumber'],
                                                        'accountingAccountPlan': '01',
                                                        'accountingAccount': record['account'],
                                                        'costCenterPlan': '01',
                                                        'costCenter': (record['departament'] == null ? 0 : record['departament']),
                                                        'currentAccount': record['conta'],
                                                        'paymentNumber': '',
                                                        'currency': record['currency'],
                                                        'eventType': eventType,
                                                        'value': (originSystem == 'CP' ? record['total'] * -1 : record['total']),
                                                        'valueBusiness': '',
                                                        'conversionBusiness': '',
                                                        'fixedRateBusiness': '',
                                                        'valueAccount': '',
                                                        'conversionAccount': '',
                                                        'fixedRateAccount': '',
                                                        /*'beneficiaryOrigin': record['entity'],*/
                                                        'beneficiaryOrigin': originSystem,
                                                        'beneficiary': record['entity'],
                                                        'beneficiaryType': record['tipo'],
                                                        'motionWay': (record['custbody_lrc_invoice_met_pag_fatura'] == null ? 2 : record['custbody_lrc_invoice_met_pag_fatura']),
                                                        'flexField001': (record['class'] == null ? 0 : record['class'])
                                                }

                                                //tb_stage_empresa.push(empresa);
                                                tb_stage_empresa.push(gesplanReturn);
                                        }


                                }



                        }
                        log.debug({ title: 'Dados', details: tb_stage_empresa })

                } catch (e) {
                        log.error({ title: 'Error Recuperar informaçoes', details: e.toString() })
                }
        }

        function _isValidJsonInstalmentFormat(instalmentBodyField) {

                if (!instalmentBodyField || instalmentBodyField == '') {
                        return false;
                }

                let instalmentsFromTransactionBodyField = JSON.parse(instalmentBodyField);
                let instalmntList = instalmentsFromTransactionBodyField;
                if (instalmntList.length == 0) {
                        log.debug("Validação do campo custbody_rsc_installments", "TAMANHO INVÁLIDO -> " + instalmentBodyField);
                        return false;
                }
                instalmntList.forEach(function (instalment) {
                        if (instalment.hasOwnProperty('transactionid')
                                && instalment.hasOwnProperty('dtvcto')
                                && instalment.hasOwnProperty('valor')
                                && instalment.hasOwnProperty('dtpgto')
                                && instalment.hasOwnProperty('multa')
                                && instalment.hasOwnProperty('juros')
                                && instalment.hasOwnProperty('status')
                        ) {

                                log.debug("Validação do campo custbody_rsc_installments", "FORMATO OK");
                                return true;
                                /*
                                log.debug("instalment.transactionid:", instalment.transactionid);
                                log.debug("instalment.seq:", instalment.seq);
                                log.debug("instalment.dtvcto:", instalment.dtvcto);
                                log.debug("instalment.valor:", instalment.valor);
                                */

                        } else {
                                log.debug("Validação do campo custbody_rsc_installments", "FORMATO INVALIDO -> " + instalmentBodyField);
                                return false;

                        }
                });
                return false;
        }




        function selectAllRows(sql, queryParams = new Array()) {
                try {
                        var moreRows = true;
                        var rows = new Array();
                        var paginatedRowBegin = 1;
                        var paginatedRowEnd = 5000;

                        do {
                                var paginatedSQL = 'SELECT * FROM ( SELECT ROWNUM AS ROWNUMBER, * FROM (' + sql + ' ) ) WHERE ( ROWNUMBER BETWEEN ' + paginatedRowBegin + ' AND ' + paginatedRowEnd + ')';
                                log.debug("mov_real QUERY:", paginatedSQL);

                                var queryResults = query.runSuiteQL({ query: paginatedSQL, params: queryParams }).asMappedResults();
                                rows = rows.concat(queryResults);
                                if (queryResults.length < 5000) { moreRows = false; }
                                paginatedRowBegin = paginatedRowBegin + 5000;
                        } while (moreRows);
                } catch (e) {
                        log.error({ title: 'selectAllRows - error', details: { 'sql': sql, 'queryParams': queryParams, 'error': e } });
                }
                return rows;



        }
        return {
                post
        }


});
