/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* MapReduce_fluxoEscritura.js
*
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record", "N/log"], function (require, exports, search_1, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.monthDiff = exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    var getInputData = function () {
        log_1.default.debug('começo', 'get');
        return search_1.default.create({
            type: "customsale_rsc_financiamento",
            filters: [
                ['internalid', 'ANYOF', [85793, 85794]],
                'AND',
                ['mainline', 'IS', 'T'],
                "AND",
                ["shipping", "is", "F"],
                "AND",
                ["taxline", "is", "F"],
                "AND",
                ["status", "anyof", "CuTrSale123:A"]
            ],
            columns: [
                'duedate',
                'total',
                'custbody_rsc_projeto_obra_gasto_compra',
                'custbody_lrc_fatura_principal'
            ]
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        log_1.default.debug('começo', 'map');
        var dataAtual = new Date("02/01/2022");
        var verificaINCC = false;
        var verificaIGPM = false;
        var verificaPrice = false;
        var addLineINCC = true;
        var lineINCC = 0;
        var linePrincipal = 0;
        var lineIGPM = 0;
        var linePrice = 0;
        var valorINCC = 0;
        var valorIGPM = 0;
        var req = JSON.parse(ctx.value);
        log_1.default.debug("req", req);
        var financiamento = req.values;
        var financiamentoRecord = record_1.default.load({
            type: 'customsale_rsc_financiamento',
            id: req.id
        });
        var indice = financiamentoRecord.getValue('custbody_rsc_indice');
        var indiceText = financiamentoRecord.getText('custbody_rsc_indice');
        var qtLinhas = financiamentoRecord.getLineCount({
            sublistId: 'item'
        });
        log_1.default.debug("financiamento", financiamento);
        var projetoLookup = search_1.default.lookupFields({
            type: 'job',
            id: financiamento.custbody_rsc_projeto_obra_gasto_compra.value,
            columns: [
                'custentity_rsc_novo_inidice',
                'custentity_rsc_juros',
                'custentity_rsc_project_date_habite',
                'custentity_rsc_liberado'
            ]
        });
        var searchIndice = search_1.default.create({
            type: 'customrecord_rsc_correction_unit',
            filters: [
                ['name', 'IS', 'PRICE 1']
            ]
        }).run().getRange({
            start: 0,
            end: 1
        });
        log_1.default.debug('searchIndice[0]', searchIndice[0]);
        var searchIndiceLookup = search_1.default.lookupFields({
            type: 'customrecord_rsc_correction_unit',
            id: searchIndice[0].id,
            columns: [
                'custrecord_rsc_ucr_calc_base_item'
            ]
        });
        log_1.default.debug("projetoLookup", projetoLookup);
        var dataParcela = financiamento.duedate;
        dataParcela = dataParcela.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
        dataParcela = new Date(dataParcela);
        var dateHabite;
        var dataIGPM;
        log_1.default.debug('projetoLookup.custentity_rsc_novo_inidice.length', projetoLookup.custentity_rsc_project_date_habite.length);
        if (projetoLookup.custentity_rsc_project_date_habite) {
            dateHabite = String(projetoLookup.custentity_rsc_project_date_habite);
            dateHabite = dateHabite.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            dateHabite = new Date(dateHabite);
        }
        var price;
        if (projetoLookup.custentity_rsc_novo_inidice.length != 0) {
            price = projetoLookup.custentity_rsc_novo_inidice[0].value;
        }
        log_1.default.debug('indice', price);
        var unidadeLookup;
        if (price) {
            unidadeLookup = search_1.default.lookupFields({
                type: 'customrecord_rsc_correction_unit',
                id: price,
                columns: [
                    'custrecord_rsc_ucr_calc_base_item'
                ]
            });
        }
        // Laço que verifica todas as linhas de item existentes na parcela
        for (var i = 0; i < qtLinhas; i++) {
            var itemDisplayLinhas = financiamentoRecord.getSublistValue({
                sublistId: 'item',
                fieldId: 'item_display',
                line: i
            });
            var itemLinhas = financiamentoRecord.getSublistValue({
                sublistId: 'item',
                fieldId: 'item',
                line: i
            });
            var amountLine = financiamentoRecord.getSublistValue({
                sublistId: 'item',
                fieldId: 'amount',
                line: i
            });
            var dataVigenciaInicio = financiamentoRecord.getSublistValue({
                sublistId: 'item',
                fieldId: 'custcol_rsc_datavigenciainicio',
                line: i
            });
            var dataVigenciaFim = financiamentoRecord.getSublistValue({
                fieldId: 'custcol_rsc_vigenciafim',
                sublistId: 'item',
                line: i
            });
            log_1.default.debug('dataVigenciaFim', dataVigenciaFim);
            log_1.default.debug('itemDisplayLinhas', itemDisplayLinhas);
            if (itemDisplayLinhas == 'FRAÇÃO DO PRINCIPAL') {
                linePrincipal = i;
            }
            var verificaData = false;
            if (itemDisplayLinhas == indiceText) {
                addLineINCC = false;
                if (!dataVigenciaInicio) {
                    var contratoLookup = search_1.default.lookupFields({
                        type: 'invoice',
                        id: financiamento.custbody_lrc_fatura_principal.value,
                        columns: [
                            'custbody_rsc_data_venda',
                            'custbody_rsc_finan_indice_base_cont'
                        ]
                    });
                    var dataVenda = contratoLookup.custbody_rsc_data_venda;
                    dataVenda = dataVenda.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                    dataVenda = new Date(dataVenda);
                    financiamentoRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_rsc_datavigenciainicio',
                        line: i,
                        value: dataVenda
                    });
                    verificaData = true;
                }
            }
            log_1.default.debug('verificaData', verificaData);
            if (verificaData) {
                dataVigenciaInicio = dataVenda;
            }
            // Verificação do que será feito na rotina
            if (dataVigenciaInicio != "") {
                if (dataVigenciaFim == "") {
                    if (itemDisplayLinhas == indiceText && dataVigenciaInicio.getTime() < dataAtual.getTime()) {
                        verificaINCC = true;
                        lineINCC = i;
                        valorINCC = Number(amountLine);
                    }
                    if (unidadeLookup) {
                        if (itemLinhas == searchIndiceLookup.custrecord_rsc_ucr_calc_base_item[0].value && projetoLookup.custentity_rsc_liberado && dataVigenciaInicio.getTime() < dataAtual.getTime()) {
                            verificaPrice = true,
                                linePrice = i;
                        }
                    }
                    if (itemDisplayLinhas == 'IGP-M' && dataVigenciaInicio.getTime() < dataAtual.getTime()) {
                        verificaIGPM = true;
                        lineIGPM = i;
                        dataIGPM = dataVigenciaInicio;
                        valorIGPM = Number(amountLine);
                    }
                }
                else {
                    if (itemDisplayLinhas == indiceText && dataVigenciaFim.getTime() > dataAtual.getTime() && dataVigenciaInicio.getTime() < dataAtual.getTime()) {
                        verificaINCC = true;
                        lineINCC = i;
                        valorINCC = Number(amountLine);
                    }
                    if (unidadeLookup) {
                        if (itemLinhas == searchIndiceLookup.custrecord_rsc_ucr_calc_base_item[0].value && projetoLookup.custentity_rsc_liberado && dataVigenciaFim.getTime() > dataAtual.getTime() && dataVigenciaInicio.getTime() < dataAtual.getTime()) {
                            verificaPrice = true,
                                linePrice = i;
                        }
                    }
                    if (itemDisplayLinhas == 'IGP-M' && dataVigenciaFim.getTime() > dataAtual.getTime() && dataVigenciaInicio.getTime() < dataAtual.getTime()) {
                        verificaIGPM = true;
                        lineIGPM = i;
                        dataIGPM = dataVigenciaInicio;
                        valorIGPM = Number(amountLine);
                    }
                }
            }
        }
        log_1.default.debug('verificaIGPM', verificaIGPM);
        log_1.default.debug('verificaINCC', verificaINCC);
        log_1.default.debug('addLineINCC', addLineINCC);
        log_1.default.debug('verificaPrice', verificaPrice);
        //Adição de uma linha baseado no Indice de correção monetária
        if (addLineINCC) {
            var contrato = financiamento.custbody_lrc_fatura_principal.value;
            var contratoLookup = search_1.default.lookupFields({
                type: 'invoice',
                id: contrato,
                columns: [
                    'custbody_rsc_data_venda',
                    'custbody_rsc_finan_indice_base_cont'
                ]
            });
            var dataVencimento = contratoLookup.custbody_rsc_data_venda;
            dataVencimento = dataVencimento.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            dataVencimento = new Date(dataVencimento);
            log_1.default.debug('dataVencimento', dataVencimento);
            var searchItem = search_1.default.create({
                type: 'serviceitem',
                filters: ['itemid', 'IS', indiceText]
            }).run().getRange({
                start: 0,
                end: 1
            });
            financiamentoRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'item',
                line: qtLinhas,
                value: searchItem[0].id
            });
            financiamentoRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'custcol_rsc_datavigenciainicio',
                line: qtLinhas,
                value: dataVencimento
            });
            var total = financiamento.total;
            var valor = getAttMonetaria(new Date(dataVencimento), indice, total);
            log_1.default.debug('valor', valor);
            if (valor != 0) {
                financiamentoRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: qtLinhas,
                    value: (valor - total).toFixed(2)
                });
                financiamentoRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: qtLinhas,
                    value: (valor - total).toFixed(2)
                });
            }
            else {
                financiamentoRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: qtLinhas,
                    value: 0
                });
                financiamentoRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: qtLinhas,
                    value: 0
                });
            }
        }
        //Caso verifica INCC seja true, realiza o calculo da correção baseado no indice da parcela
        if (verificaINCC) {
            // Log.debug('financiamento', financiamento)
            var contrato = financiamento.custbody_lrc_fatura_principal.value;
            var contratoLookup = search_1.default.lookupFields({
                type: 'invoice',
                id: contrato,
                columns: [
                    'custbody_rsc_finan_dateativacontrato',
                    'custbody_rsc_finan_indice_base_cont'
                ]
            });
            var dataVencimento = contratoLookup.custbody_rsc_finan_dateativacontrato;
            // const INCC = contratoLookup.custbody_rsc_finan_indice_base_cont[0].value
            dataVencimento = dataVencimento.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            dataVencimento = new Date(dataVencimento);
            log_1.default.debug('data', dataVencimento);
            log_1.default.debug('INCC', indice);
            var total = Number(financiamentoRecord.getSublistValue({
                sublistId: 'item',
                fieldId: 'amount',
                line: linePrincipal
            }));
            // const somaTotal = total + Number(valorINCC)
            log_1.default.debug('total', total);
            var valor = getAttMonetaria(new Date(dataVencimento), indice, total);
            // Log.debug('valor', valor);
            if (Number((valor - total).toFixed(2)) >= Number(valorINCC)) {
                financiamentoRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: lineINCC,
                    value: (valor - total).toFixed(2)
                });
                financiamentoRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: lineINCC,
                    value: (valor - total).toFixed(2)
                });
            }
        }
        // Caso verificaIGPM for true, realiza o calculo da correção monetária, caso
        if (verificaIGPM) {
            // Log.debug('financiamento', financiamento)
            var contrato = financiamento.custbody_lrc_fatura_principal.value;
            var contratoLookup = search_1.default.lookupFields({
                type: 'invoice',
                id: contrato,
                columns: [
                    'custbody_rsc_finan_dateativacontrato',
                ]
            });
            var dataVencimento = contratoLookup.custbody_rsc_finan_dateativacontrato;
            dataVencimento = dataVencimento.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            dataVencimento = new Date(dataVencimento);
            log_1.default.debug('data', dataVencimento);
            var qtLinhasSub = financiamentoRecord.getLineCount({
                sublistId: 'item'
            });
            var total = 0;
            for (var i = 0; i < qtLinhasSub; i++) {
                var displayItem = financiamentoRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'item_display',
                    line: i
                });
                if (displayItem != 'IGP-M' && displayItem != searchIndiceLookup.custrecord_rsc_ucr_calc_base_item[0].text) {
                    var totalLinha = financiamentoRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'amount',
                        line: i
                    });
                    total += Number(totalLinha);
                }
            }
            var searchIGPM = search_1.default.create({
                type: 'customrecord_rsc_correction_unit',
                filters: [
                    ['name', 'IS', 'IGP-M']
                ]
            }).run().getRange({
                start: 0,
                end: 1
            });
            // const somaTotal = total + Number(valorIGPM)
            log_1.default.debug('dataIGPM', dataIGPM);
            log_1.default.debug('total', total);
            var valor = getAttMonetaria(new Date(dataIGPM), searchIGPM[0].id, total);
            log_1.default.debug('valor', valor);
            if (Number((valor - total).toFixed(2)) >= Number(valorIGPM)) {
                financiamentoRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: lineIGPM,
                    value: (valor - total).toFixed(2)
                });
                financiamentoRecord.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: lineIGPM,
                    value: (valor - total).toFixed(2)
                });
            }
        }
        // Caso verificaPrice for true, realiza o calculo do price, baseado no valor corrigido
        if (verificaPrice) {
            // let dataParcela = financiamentoRecord.getValue('duedate')
            var dataHabite = String(projetoLookup.custentity_rsc_project_date_habite);
            dataHabite = dataHabite.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            dataHabite = new Date(dataHabite);
            log_1.default.debug('dataHabite', dataHabite);
            // Log.debug('dataParcela',dataParcela)
            // let dataParcela = financiamento.duedate
            // dataParcela = dataParcela.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            // dataParcela = new Date(dataParcela);
            log_1.default.debug('teste', 'done');
            var parsedjurosAA = parseFloat(projetoLookup.custentity_rsc_juros);
            var base = (1 + (parsedjurosAA / 100));
            var expoente = ((1 / 12));
            var juros = (Math.pow(Number(base), Number(expoente)) - 1).toFixed(6);
            log_1.default.debug('juros', juros);
            var mes = exports.monthDiff(dataAtual, dataHabite);
            log_1.default.debug('mes', mes);
            var qtLinhasSub = financiamentoRecord.getLineCount({
                sublistId: 'item'
            });
            var total = 0;
            for (var i = 0; i < qtLinhasSub; i++) {
                var displayItem = financiamentoRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'item_display',
                    line: i
                });
                if (displayItem != searchIndiceLookup.custrecord_rsc_ucr_calc_base_item[0].text) {
                    var totalLinha = financiamentoRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'amount',
                        line: i
                    });
                    total += Number(totalLinha);
                }
            }
            var valorSublista = ((Number(total) * Number(juros)) * mes).toFixed(2);
            log_1.default.debug('valorSublista', valorSublista);
            financiamentoRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'amount',
                line: linePrice,
                value: valorSublista
            });
            financiamentoRecord.setSublistValue({
                sublistId: 'item',
                fieldId: 'rate',
                line: linePrice,
                value: valorSublista
            });
        }
        financiamentoRecord.save({
            ignoreMandatoryFields: true
        });
    };
    exports.map = map;
    var getAttMonetaria = function (dataVencimento, indiceID, valorPago) {
        var valor = 0;
        if (new Date('02/01/2022').getTime() > dataVencimento.getTime()) {
            dataVencimento.setDate(1);
            dataVencimento.setMonth(dataVencimento.getMonth() - 2);
            log_1.default.debug('dataVencimento', dataVencimento);
            var indiceRecord = record_1.default.load({
                type: 'customrecord_rsc_correction_unit',
                id: indiceID
            });
            var qtdLinhasIndice = indiceRecord.getLineCount({
                sublistId: 'recmachcustrecord_rsc_hif_correction_unit'
            });
            var fatorDataAtual = void 0;
            var fatorDatavencimento = void 0;
            for (var i = 0; i < qtdLinhasIndice; i++) {
                var dataAtual = new Date("02/01/2022");
                dataAtual.setMonth(dataAtual.getMonth() - 2);
                dataAtual.setHours(0, 0, 0);
                dataAtual.setDate(1);
                // Log.debug('dataAtual', String(dataAtual))
                var dataVigenciaLinha = indiceRecord.getSublistValue({
                    sublistId: 'recmachcustrecord_rsc_hif_correction_unit',
                    fieldId: 'custrecord_rsc_hif_effective_date',
                    line: i
                });
                // Log.debug('dataVigenciaLinha', String(dataVigenciaLinha))
                if (String(dataVigenciaLinha) == String(dataVencimento)) {
                    log_1.default.debug("entrou no if?", "sim");
                    fatorDatavencimento = indiceRecord.getSublistValue({
                        sublistId: 'recmachcustrecord_rsc_hif_correction_unit',
                        fieldId: 'custrecord_rsc_hif_factor_percent',
                        line: i
                    });
                    log_1.default.debug('fatorDatavencimento', fatorDatavencimento);
                }
                if (String(dataAtual) == String(dataVigenciaLinha)) {
                    fatorDataAtual = indiceRecord.getSublistValue({
                        sublistId: 'recmachcustrecord_rsc_hif_correction_unit',
                        fieldId: 'custrecord_rsc_hif_factor_percent',
                        line: i
                    });
                    log_1.default.debug('fatorDataAtual', fatorDataAtual);
                }
            }
            valor = Number(fatorDataAtual) / Number(fatorDatavencimento) * valorPago;
        }
        else {
            valor = 0;
        }
        // Log.debug('valorPago', valorPago)
        return valor;
    };
    var monthDiff = function (d1, d2) {
        var d1Y = d1.getFullYear();
        // Log.debug('d1Y', d1Y)
        var d2Y = d2.getFullYear();
        // Log.debug('d2Y', d2Y)
        var diffYears = (d1Y - d2Y) * 12;
        // Log.debug('diffYears', diffYears)
        var d1M = d1.getMonth();
        // Log.debug('d1M', d1M)
        var d2M = d2.getMonth();
        // Log.debug('d2M', d2M)
        var diffMonths = d1M - d2M;
        // Log.debug('diffMonths', diffMonths)
        diffYears + diffMonths;
        // Log.debug('monthDiff', diffYears + diffMonths)
        return diffYears + diffMonths;
    };
    exports.monthDiff = monthDiff;
});
