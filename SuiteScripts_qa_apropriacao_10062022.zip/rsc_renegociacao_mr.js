/**
 *@NApiVersion 2.1
*@NScriptType MapReduceScript
*/
define(['N/file', 'N/https', 'N/log', 'N/search', 'N/record', 'N/runtime'], (https, file, log, search, record, runtime) => {
const getInputData = (context) => {
    log.audit('getInputData', context);

    var bscReneg = search.create({type: "customrecord_rsc_tab_efetiva_reparcela",
        filters: [
           ["custrecord_rsc_status_aprovacao","anyof","2"], "AND", 
           ["custrecord_rsc_boleto","noneof","@NONE@"]
        ],
        columns: [
            "created","name","custrecord_rsc_boleto"
        ]
    });
    log.audit('bscReneg', bscReneg);

    return bscReneg;
}

const map = (context) => {
    log.audit('map', context);

    var srcResult = JSON.parse(context.value);
    log.audit('srcResult', srcResult);
}

const reduce = (context) => {}

const summarize = (summary) => {
    var type = summary.toString();
    log.audit(type, 
        '"Uso Consumido:" '+summary.usage+
        ', "Número de Filas:" '+summary.concurrency+
        ', "Quantidade de Saídas:" '+summary.yields
    );
    var contents = '';
    summary.output.iterator().each(function (key, value) {
        contents += (key + ' ' + value + '\n');
        return true;
    });
}

return {
    getInputData: getInputData,
    map: map,
    reduce: reduce,
    summarize: summarize
}
});
