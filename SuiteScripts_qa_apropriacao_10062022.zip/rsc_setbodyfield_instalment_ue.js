/**
 *@NApiVersion 2.1
*@NScriptType UserEventScript
*/
const ZERO = Number('0').toFixed(2);

define(['N/log', 'N/record', "N/search"], (log, record, search) => {


    const atualizar = (id, tipo, arraySublista) => {
        log.audit('atualizar', { id: id, tipo: tipo, arraySublista: arraySublista });

        record.load({ type: tipo, id: id })
            .setValue('custbody_rsc_installments', arraySublista)
            .save();
    }

    const lookupLinks = (nr, sublista, campo, seq) => {
        log.audit('lookupLinks', { seq: seq, campo: campo, sublista: sublista, nr: nr });

        var loadReg = record.load({ type: nr.type, id: nr.id });

        var totalSublista = loadReg.getLineCount(sublista);
        log.audit({ totalSublista: totalSublista }, loadReg);

        for (i = 0; i < totalSublista; i++) {
            var id = loadReg.getSublistValue(sublista, 'id', i)
            var tipo = loadReg.getSublistValue(sublista, 'type', i);

            if (tipo == 'Pagto. da fatura') {
                var loadPagto = record.load({ type: 'vendorpayment', id: id });
                if (campo == 'trandate') {
                    return loadPagto.getText('trandate');
                } else {
                    var totalSublista = loadPagto.getLineCount('apply');
                    for (linha = 0; linha < totalSublista; linha++) {
                        var aplicado = loadPagto.getSublistValue('apply', 'apply', linha);
                        var installmentnumber = loadPagto.getSublistValue('apply', 'installmentnumber', linha);
                        if (aplicado == 'T' && installmentnumber == seq) {
                            return loadPagto.getSublistValue('apply', 'total', linha);
                        }
                    }
                }
            }
        }
    }

    const beforeLoad = (context) => { }

    const beforeSubmit = (context) => {

        let ctx = context;
        
        //run only on Create and edit and line edition
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var newRecord = ctx.newRecord;
            log.debug("Running on beforesubmit ", " ****** "+context.newRecord.type+" - "+ context.type+ " ******* ");

            //seta data da ultima atualizacao para todas as transacoes
            newRecord.setValue({
                fieldId: 'custbody_rsc_gesplan_lastmodifdate_dt',
                value: new Date()
            });



            //roda so no vendor payment
            if (newRecord.type == 'vendorpayment') {
                //if (newRecord.type == 'vendorbill' || newRecord.type == 'vendorpayment'){ 
                //|| newRecord.type == 'invoice' || newRecord.type == 'vendorbill') {
                VendorPaymentUserEvent.runBeforeSubmit(context);

            }
            if (newRecord.type == 'vendorbill') {
                //if (newRecord.type == 'vendorbill' || newRecord.type == 'vendorpayment'){ 
                //|| newRecord.type == 'invoice' || newRecord.type == 'vendorbill') {
                VendorBillUserEvent.runBeforeSubmit(context);

            }
            if (newRecord.type == 'customerpayment') {
                //if (newRecord.type == 'vendorbill' || newRecord.type == 'vendorpayment'){ 
                //|| newRecord.type == 'invoice' || newRecord.type == 'vendorbill') {
                CustomerPaymentUserEvent.runBeforeSubmit(context);

            }
            if (newRecord.type == 'invoice') {
                //InvoiceUserEvent.runBeforeSubmit(context);

            }




        }


    }

    const afterSubmit = (context) => {

        log.debug("Running on afterSubmit ", " ****** "+context.newRecord.type+" - "+ context.type+ " ******* ");

        const novoRegistro = context.newRecord;

        const tipo = novoRegistro.type;

        var loadReg, sublista, totalSublista;
        var arraySublista = [];

        if (novoRegistro.id) {

            switch (tipo) {
                case 'customerpayment':
                    //log.debug("Running on customer payment ------ ", "****** customerpayment - "+context.type+" *******")

                    /*
    
                    loadReg = record.load({type: tipo, id: novoRegistro.id});
                    sublista = 'apply';
                    totalSublista = novoRegistro.getLineCount(sublista);
                    if (totalSublista > 0) {
                        for (i=0; i<totalSublista; i++) {
                            var aplicado = novoRegistro.getSublistText(sublista, 'apply', i);
                            if (aplicado == 'T') {
                                arraySublista.push({
                                    transactionid: novoRegistro.id,
                                    seq: i+1,
                                    data: novoRegistro.getSublistText(sublista, 'trandate', i), 
                                    dtvcto: novoRegistro.getSublistText(sublista, 'duedate', i),
                                    valor: novoRegistro.getSublistText(sublista, 'amount', i),
                                    valorpago: novoRegistro.getSublistValue(sublista, 'custpage_rsc_valor_pago', i),
                                    dtpgto: novoRegistro.getText('trandate'),
                                    multa: ZERO,
                                    juros: ZERO,
                                    status: loadReg.getValue('status') 
                                });
                            }                    
                        }
                    }
                    */
                    break;

                case 'invoice':
                    //log.debug("Running on invoice ------ ", "****** invoice - "+context.type+" *******")


                    /*
                    loadReg = record.load({type: tipo, id: novoRegistro.id});
                    sublista = 'custpage_rsc_parcelas';
                    totalSublista = novoRegistro.getLineCount(sublista);
                    if (totalSublista > 0) {
                        for (i=0; i<totalSublista; i++) {
                            arraySublista.push({
                                transactionid: novoRegistro.getSublistValue(sublista, 'custpage_rsc_ver', i),
                                seq: novoRegistro.getSublistText(sublista, 'custpage_rsc_numero_parcela', i),
                                data: loadReg.getValue('trandate'),
                                dtvcto: novoRegistro.getSublistText(sublista, 'duedate', i),
                                valor: novoRegistro.getSublistValue(sublista, 'custpage_rsc_valor_original', i),
                                valorpago: novoRegistro.getSublistValue(sublista, 'custpage_rsc_valor_pago', i),
                                dtpgto: novoRegistro.getSublistValue(sublista, 'custpage_rsc_data_pagamento', i),
                                multa: Number(novoRegistro.getSublistValue(sublista, 'custpage_rsc_multa', i)).toFixed(2),
                                juros: Number(novoRegistro.getSublistValue(sublista, 'custpage_rsc_juros', i)).toFixed(2),
                                status: novoRegistro.getSublistValue(sublista, 'custpage_rsc_status', i) 
                            });
                        }
                    }
                    */
                    break;

                case 'vendorbill':
                    //log.debug("Running on vendorbill ------ ", "****** vendorbill - "+context.type+" *******")
                    /*
    
                    loadReg = record.load({type: tipo, id: novoRegistro.id});
                    sublista = 'installment';
                    totalSublista = novoRegistro.getLineCount(sublista);
                    if (totalSublista > 0) {
                        for (i=0; i<totalSublista; i++) {
                            var seq = novoRegistro.getSublistText(sublista, 'seqnum', i);
                            arraySublista.push({
                                transactionid: novoRegistro.id,
                                seq: seq,
                                dtvcto: novoRegistro.getSublistText(sublista, 'duedate', i),
                                valor: novoRegistro.getSublistText(sublista, 'amount', i),
                                valorpago: lookupLinks(novoRegistro, 'links', 'total', seq),
                                dtpgto: lookupLinks(novoRegistro, 'links', 'trandate', seq),
                                multa: '',
                                juros: '',
                                status: novoRegistro.getSublistText(sublista, 'status', i)
                          });
                        }
                    } else {
                        arraySublista.push({
                            transactionid: novoRegistro.id,
                            seq: seq,
                            data: novoRegistro.getValue('trandate'),
                            dtvcto: novoRegistro.getText('trandate'),
                            valor: novoRegistro.getValue('usertotal'),
                            valorpago: ZERO,
                            dtpgto: '',
                            multa: ZERO,
                            juros: ZERO,
                            status: novoRegistro.getValue('status')
                        });
                    }
                    */
                    break;

                case 'vendorpayment':
                    //log.debug("Running on vendorpyment ------ ", "****** vendorpayment - "+context.type+" *******")


                    /*
                    //loadReg = record.load({type: tipo, id: novoRegistro.id, isDynamic: false});
                    let vendorpayment = record.load({type: tipo, id: novoRegistro.id});
                    let vbInstalmentReader = new InstalmentSublistReader(vendorpayment);
                    let vbItemReader = new ItemSublistReader(vendorpayment);
                    
                    let instalmentList = vbInstalmentReader.read();
                    let itemList = vbItemReader.read();
                    log.debug("teste intalment", instalmentList);
                    log.debug("teste item", itemList);
    
    
                    vendorpayment.setValue(TRANBODYFLDNAME.instalments, JSON.stringify(instalmentList));
                    vendorpayment.setValue(TRANBODYFLDNAME.items, JSON.stringify(itemList));
                    vendorpayment.save()
                    //record.setValue(TRANBODYFLDNAME.instalments, JSON.stringify(instalmentList));
                    //record.setValue(TRANBODYFLDNAME.items, JSON.stringify(itemList));
                    */





                    /*
                    loadReg = record.load({type: tipo, id: novoRegistro.id});
                    sublista = 'apply';
                    totalSublista = novoRegistro.getLineCount(sublista);
                    if (totalSublista > 0) {
                        for (i=0; i<totalSublista; i++) {
                            var aplicado = novoRegistro.getSublistText(sublista, 'apply', i);
                            if (aplicado == 'T') {
                                arraySublista.push({
                                    transactionid: novoRegistro.id,
                                    seq: i+1,
                                    data: novoRegistro.getSublistText(sublista, 'trandate', i),
                                    dtvcto: novoRegistro.getSublistText(sublista, 'duedate', i),
                                    valor: novoRegistro.getSublistText(sublista, 'amount', i),
                                    valorpago: novoRegistro.getSublistText(sublista, 'total', i),
                                    dtpgto: novoRegistro.getText('trandate'),
                                    multa: ZERO,
                                    juros: ZERO,
                                    status: 'Aplicado'
                                });
                            }                    
                        }
                    }else {
                        arraySublista.push({
                            transactionid: novoRegistro.id,
                            seq: seq,
                            data: novoRegistro.getValue('trandate'),
                            dtvcto: novoRegistro.getText('trandate'),
                            valor: novoRegistro.getValue('usertotal'),
                            valorpago: ZERO,
                            dtpgto: '',
                            multa: ZERO,
                            juros: ZERO,
                            status: novoRegistro.getValue('status')
                        });
                    }
                    */
                    break;
            }
            //log.audit(tipo, arraySublista);

            //atualizar(novoRegistro.id, tipo, JSON.stringify(arraySublista));
        }




    }




    const SUBLISTNAME = {
        apply: 'apply',
        item: "item",
        instalment: "installment",
        expense: "expense",
        links: "links",
        financiamento: "custpage_rsc_parcelas"
    }
    const TRANBODYFLDNAME = {

        instalments: "custbody_rsc_installments",
        items: "custbody_rsc_gesplan_items_json",
    }

    class Instalment {
        constructor(transactionid, seq, dtvcto, valor, valorpago, valordevido, dtpgto, multa, juros, status) {
            this.transactionid = transactionid;
            this.seq = seq;
            this.dtvcto = dtvcto;
            this.valor = valor;
            this.valordevido = valordevido;
            this.valorpago = valorpago;
            this.dtpgto = dtpgto;
            this.multa = multa;
            this.juros = juros;
            this.status = status;
        }
    }

    class Item {
        constructor(
            id, type, subtype, quantity, rate, refamt, origrate, grossamt, amount
        ) {
            this.id = id;
            this.type = type;
            this.subtype = subtype;
            this.quantity = quantity;
            this.rate = rate;
            this.refamt = refamt;
            this.origrate = origrate;
            this.grossamt = grossamt;
            this.amount = amount;

        }
    }
    class LinksList {
        constructor(id, linkurl, status, total, trandate, tranid, type) {
            this.id = id;
            this.linkurl = linkurl;
            this.status = status;
            this.total = total;
            this.trandate = trandate;
            this.tranid = tranid;
            this.type = type;
        }
    }

    class ApplySublist {
        constructor(trantype, amount, type, apply, applydate, createdfrom,
            currency, doc, due, internalid, installmentnumber, total, pymt, duedate, refnum, discdate,
            discamount, disc, userenteredamount, userentereddiscount, line, discountrate
        ) {

            this.trantype = trantype;
            this.amount = amount;
            this.type = type;
            this.apply = apply;
            this.applydate = applydate;
            this.createdfrom = createdfrom;
            this.currency = currency;
            this.doc = doc;
            this.due = due;
            this.installmentnumber = installmentnumber;
            this.internalid = internalid;
            this.total = total;
            this.pymt = pymt;
            this.duedate = duedate;
            this.refnum = refnum;
            this.discdate = discdate;
            this.discamount = discamount;
            this.disc = disc;
            this.userenteredamount = userenteredamount;
            this.userentereddiscount = userentereddiscount;
            this.line = line;
            this.discountrate = discountrate;

        }
    }

    class ApplySubListReader {
        constructor(transactionRecord) {
            this.record = transactionRecord;

            log.debug('ApplySubListReader', 'Apply Itemlist length: ' + this.length());

        }
        length() {
            return this.record.getLineCount(SUBLISTNAME.apply);
        }
        read() {
            let sublistApplyList = [];

            for (let i = 0; i < this.length(); i++) {


                try {


                    sublistApplyList.push(new ApplySublist(
                        this.record.getSublistText(SUBLISTNAME.apply, 'trantype', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'type', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'apply', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'applydate', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'createdfrom', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'currency', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'doc', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'due', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'internalid', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'installmentnumber', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'total', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'duedate', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'refnum', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'discdate', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'discamount', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'disc', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'userenteredamount', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'userentereddiscount', i),
                        this.record.getSublistText(SUBLISTNAME.apply, 'line', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'discountrate', i)

                    ));

                } catch (e) {

                    log.error('ApplySubListReader', 'Apply Sublist Error: ' + e.message);
                    //use this code only on edit mode
                    sublistApplyList.push(new ApplySublist(
                        this.record.getSublistValue(SUBLISTNAME.apply, 'trantype', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'type', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'apply', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'applydate', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'createdfrom', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'currency', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'doc', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'due', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'internalid', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'installmentnumber', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'total', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'duedate', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'refnum', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'discdate', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'discamount', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'disc', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'userenteredamount', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'userentereddiscount', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'line', i),
                        this.record.getSublistValue(SUBLISTNAME.apply, 'discountrate', i)

                    ));


                }
            }
            //log.audit("ApplySubListReader.read()", "applyList: " + JSON.stringify(sublistApplyList));

            return sublistApplyList;
        }

        readApplied() {
            let ret = this.read().filter(item => item.apply == true);
            if (ret.length == 0) {
                ret = this.read().filter(item => item.apply == "T");
            }

            log.audit("ApplySubListReader.readApplied().filter", "appliedList:  " + JSON.stringify(ret));
            return ret;
        }
    }

    class ItemSublistReader {
        constructor(transactionRecord) {
            this.record = transactionRecord;
        }
        length() {
            return this.record.getLineCount(SUBLISTNAME.item);
        }
        read() {
            let itemList = [];
            for (var i = 0; i < this.length(); i++) {
                try {

                    itemList.push(new Item(
                        this.record.getSublistText(SUBLISTNAME.item, 'id', i),
                        this.record.getSublistText(SUBLISTNAME.item, 'type', i),
                        this.record.getSublistText(SUBLISTNAME.item, 'subtype', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'quantity', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'rate', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'refamt', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'origrate', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'grossamt', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'amount', i)
                    ));
                } catch (e) {
                    log.error('ItemSublistReader', 'Item Sublist Error: ' + e.message);
                    itemList.push(new Item(
                        this.record.getSublistValue(SUBLISTNAME.item, 'id', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'type', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'subtype', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'quantity', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'rate', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'refamt', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'origrate', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'grossamt', i),
                        this.record.getSublistValue(SUBLISTNAME.item, 'amount', i)
                    ));

                }
            }
            log.audit("ItemSublistReader.read(" + this.record.type + " - " + this.record.id + ")", "ItemList:  " + JSON.stringify(itemList));

            return itemList;
        }
    }

    /**
     * Cria um array de objetos Installment lendo da sublista Installment do registro netsuite.
     * e ja calculando o valor pago da parcela. ValorPAgo = Total - ValorDevido
     */
    class DefaultInstalmentSublistBuilder {
        constructor(transactionRecord) {
            this.record = transactionRecord;
            //this.logMsg = "DefaultInstalmentSublistBuilder.build("+this.record.type+" - "+this.record.id+")"

        }
        length() {
            return this.record.getLineCount(SUBLISTNAME.instalment);
        }

        build() {
            let instalmentList = [];

            for (let i = 0; i < this.length(); i++) {
                log.debug(DefaultInstalmentSublistBuilder.name, "lendo sublista intalments  "+(i+1) );



                //Pra ler o instalment corretamente, tem que calcular o valor pago e dt pgto
                //pois a sublist de instalment, nao deixa pegar o valor pago e dt pgto
                /*
                let dtPgto = this.record.getText("trandate");
                let amt = this.record.getSublistValue(SUBLISTNAME.instalment, 'amount', i);
                let amtDue = this.record.getSublistValue(SUBLISTNAME.instalment, 'due', i);
                let amtPaid = 0;//
                if (amtDue !== amt) {
                    amtPaid = parseFloat(amt) - parseFloat(amtDue);;
                }
                if (amtPaid == 0) {
                    dtPgto = "";
                }*/
                let dtPgto  = this.record.getValue("trandate");
                let amtDue  = this.record.getSublistValue(SUBLISTNAME.instalment, 'due', i);
                let amtPaid = 0.00;//
                let _instalmentstatus = this.record.getSublistValue(SUBLISTNAME.instalment, 'status', i)
                
                log.debug("valor devido", amtDue);
            
                //Alterar futuramente para trabalhar com o id do status e nao o nome do status 
                log.debug("status of instalment vendorbill", _instalmentstatus);
                if (_instalmentstatus === "Não pago") {
                    log.debug("status Nao pago encopntrado", _instalmentstatus);
                    amtPaid = 0.00;
                    dtPgto = "";
                }
                // }

                //valida se calulo ocorreu corretamente, se resultado e NaN, entao seta o valor como 0
                //isNaN(amtPaid) ? amtPaid = 0 : amtPaid = amtPaid;
                //log.debug(this.logMsg, " calculo do valor pago:   amt: " + amt + " amtDue: " + amtDue + " amtPaid: " + amtPaid);


                let instalmentContent = {
                    transactionid: this.record.id,
                    seq: (i+1),
                    dtvcto: this.record.getSublistValue(SUBLISTNAME.instalment, 'duedate', i),
                    valor: this.record.getSublistValue(SUBLISTNAME.instalment, 'amount', i),
                    valordevido: this.record.getSublistValue(SUBLISTNAME.instalment, 'due', i),
                    valorpago: (_instalmentstatus === 'Não pago') ? '0.00' :  this.record.getSublistValue(SUBLISTNAME.instalment, 'amount', i),
                    dtpgto: (_instalmentstatus === 'Não pago') ? "" : this.record.getValue("trandate"),
                    multa: 0.00,
                    juros: 0.00,
                    status: _instalmentstatus
                    //installmentid: this.record.getSublistText(SUBLISTNAME.instalment, 'id', i)
                }

                //log.audit(this.logMsg, "Conteudo da sublista installment depois do calculo: " + JSON.stringify(instalmentList));


                instalmentList.push(
                    new Instalment(
                        instalmentContent.transactionid,
                        instalmentContent.seq,
                        instalmentContent.dtvcto,
                        instalmentContent.valor,
                        instalmentContent.valorpago, 
                        instalmentContent.valordevido,
                        instalmentContent.dtpgto,
                        instalmentContent.multa,
                        instalmentContent.juros,
                        instalmentContent.status
                    ));



                //lookupLinks(vendPymtRecord, 'links', 'total', seq),
                //lookupLinks(vendPymtRecord, 'links', 'trandate', seq),


            }

            log.debug("instalmentlist in defaultbuilder", JSON.stringify(instalmentList));
            return instalmentList;

        }


    }

    class FinanciamentoInvoiceInstalmentSublistBuilder extends DefaultInstalmentSublistBuilder {

        constructor(transactionRecord) {
            super(transactionRecord);

        }
        length() {
            return this.record.getLineCount(SUBLISTNAME.financiamento);
        }
        build() {
            let instalmentList = [];

            if (this.length() > 0) {
                for (i = 0; i < this.length(); i++) {
                    log.debug(FinanciamentoInvoiceInstalmentSublistBuilder.name, "Criando parcelas" );

                    instalmentList.push(
                        new Instalment(
                            this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_ver', i),
                            this.record.getSublistText(SUBLISTNAME.financiamento, 'custpage_rsc_numero_parcela', i),
                            this.record.getSublistText(SUBLISTNAME.financiamento, 'duedate', i),
                            this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_valor_original', i),
                            this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_valor_original', i),
                            this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_valor_pago', i),
                            this.record.getSublistText(SUBLISTNAME.financiamento, 'custpage_rsc_data_pagamento', i),
                            this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_juros', i),
                            this.record.getSublistValue(SUBLISTNAME.financiamento, 'custpage_rsc_multa', i),
                            this.record.getSublistText(SUBLISTNAME.financiamento, 'custpage_rsc_status', i)
                        ));
                    log.debug("***FINANCIAM***", JSON.stringify(instalmentList));
                }
            }
            return instalmentList;

        }
    }
    class PaidInstalmentsFromApplyListBuilder extends DefaultInstalmentSublistBuilder {

        constructor(transactionRecord) {
            super(transactionRecord);
            this.applyedList = [];
            this._loadApplyedList(transactionRecord);
        }
        _loadApplyedList(record) {
            let reader = new ApplySubListReader(record);
            this.applyedList = reader.readApplied();
            log.debug("***APLICADOS***", JSON.stringify(this.applyedList));
        }

        length() {
            return this.applyedList.length;
        }
        build() {
            let instalmentList = [];

            if (this.length() > 0) {
                for (let i = 0; i < this.length(); i++) {

                    /*
                    //SUBLIST APPLY 
                       this.record.getSublistText(SUBLISTNAME.apply, 'trantype', i),
                    this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'type', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'apply', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'applydate', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'createdfrom', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'currency', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'doc', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'due', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'internalid', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'installmentnumber', i),
                    this.record.getSublistValue(SUBLISTNAME.apply, 'total', i),
                    this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'duedate', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'refnum', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'discdate', i),
                    this.record.getSublistValue(SUBLISTNAME.apply, 'discamount', i),
                    this.record.getSublistValue(SUBLISTNAME.apply, 'disc', i),
                    this.record.getSublistValue(SUBLISTNAME.apply, 'userenteredamount', i),
                    this.record.getSublistValue(SUBLISTNAME.apply, 'userentereddiscount', i),
                    this.record.getSublistText(SUBLISTNAME.apply, 'line', i),
                    this.record.getSublistValue(SUBLISTNAME.apply, 'discountrate', i)
                    
                    */


                    log.debug("sublista apply - doc", this.record.getSublistValue(SUBLISTNAME.apply, 'doc', i));
                    log.debug("sublista apply - seqnum", this.record.getSublistValue(SUBLISTNAME.apply, 'seqnum', i));
                    log.debug("sublista apply - duedate", this.record.getSublistValue(SUBLISTNAME.apply, 'duedate', i));
                    log.debug("sublista apply - amount", this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i));
                    log.debug("sublista apply - due", this.record.getSublistValue(SUBLISTNAME.apply, 'due', i));
                    log.debug("sublista apply - pymt", this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i));
                    log.debug("sublista apply - pymt", this.record.getSublistValue(SUBLISTNAME.apply, 'applydate', i));
                    
                    instalmentList.push(
                        new Instalment(
                            this.record.getSublistValue(SUBLISTNAME.apply, 'doc', i),
                            (i+1),
                            this.record.getSublistValue(SUBLISTNAME.apply, 'duedate', i),
                            this.record.getSublistValue(SUBLISTNAME.apply, 'amount', i),
                            this.record.getSublistValue(SUBLISTNAME.apply, 'due', i),
                            this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                            //this.record.getSublistValue(SUBLISTNAME.apply, 'pymt', i),
                            this.record.getSublistValue(SUBLISTNAME.apply, 'applydate', i),
                            0.00,
                            0.00,
                            "pago"
                        ));
                    log.debug("***Paid instalennts***", JSON.stringify(instalmentList));
                }
            }
            return instalmentList;

        }
    }




    class SinglePaidInstalmentSublistBuilder extends DefaultInstalmentSublistBuilder {
        constructor(transactionRecord) {
            super(transactionRecord);
        }

        //override
        length() {
            return 1;
        }

        build() {

            log.debug("SinglePaidInstalmentSublistBuilder", "building single paid instalment");


            let iList = [];
            let instalmentContent = {};
            //let amtDue  = amt;



            //valida se calulo ocorreu corretamente, se resultado e NaN, entao seta o valor como 0
            //isNaN(amtPaid) ? amtPaid = amt : amtPaid = amtPaid;
            //log.debug(this.logMsg, " calculo do valor pago:   amt: " + amt + " amtDue: " + amtDue + " amtPaid: " + amtPaid);

            try {


                instalmentContent = {
                    transactionid: this.record.id,
                    seq: 1,
                    dtvcto: this.record.getText('trandate'),
                    valor: this.record.getValue('total'),
                    valordevido: this.record.getValue('total'),
                    valorpago: this.record.getValue('total'),
                    dtpgto: this.record.getText("trandate"),
                    multa: 0.00,
                    juros: 0.00,
                    status: "Pago"
                    //installmentid: this.record.getSublistText(SUBLISTNAME.instalment, 'id', i)
                }
            } catch (e) {

                instalmentContent = {
                    transactionid: this.record.id,
                    seq: 1,
                    dtvcto: this.record.getValue('trandate'),
                    valor: this.record.getValue('total'),
                    valordevido: this.record.getValue('total'),
                    valorpago: this.record.getValue('total'),
                    dtpgto: this.record.getValue("trandate"),
                    multa: 0.00,
                    juros: 0.00,
                    status: "Pago"
                    //installmentid: this.record.getSublistText(SUBLISTNAME.instalment, 'id', i)
                }

            }
            iList.push(
                new Instalment(
                    instalmentContent.transactionid,
                    instalmentContent.seq,
                    instalmentContent.dtvcto,
                    instalmentContent.valor,
                    instalmentContent.valordevido,
                    instalmentContent.valorpago,
                    instalmentContent.dtpgto,
                    instalmentContent.multa,
                    instalmentContent.juros,
                    instalmentContent.status
                ));

            log.debug("SinglePaidInstalmentSublistBuilder", "build instalment: " + JSON.stringify(iList));

            return iList;

        }



    }

    class SingleOpenInstalmentSublistBuilder extends DefaultInstalmentSublistBuilder {
        constructor(transactionRecord) {
            super(transactionRecord);
        }

        //override
        length() {
            return 1;
        }
        //override
        build() {

            //log.debug("building single open instalment");

            let instalmentList = [];
            let instalmentContent = {
                transactionid: this.record.id,
                seq: 1,
                dtvcto: this.record.getValue('trandate'),
                valor: this.record.getValue('total'),
                valordevido: this.record.getValue('total'),
                valorpago: 0.00,
                dtpgto: "",
                multa: ZERO,
                juros: ZERO,
                status: "Não pago"
                //installmentid: this.record.getSublistText(SUBLISTNAME.instalment, 'id', i)
            }
            //log.debug("conteudo do instalment", instalmentContent)
            

            instalmentList.push(
                new Instalment(
                    instalmentContent.transactionid,
                    instalmentContent.seq,
                    instalmentContent.dtvcto,
                    instalmentContent.valor,
                    instalmentContent.valorpago, //valordevido
                    instalmentContent.valordevido,
                    instalmentContent.dtpgto,
                    instalmentContent.multa,
                    instalmentContent.juros,
                    instalmentContent.status
                )
            );
            //log.debug("SingleOpenInstalmentSublistBuilder", "built instalment: " + JSON.stringify(instalmentList));



            return instalmentList;

        }



    }


    class InstalmentSublistReader {
        constructor(transactionRecord) {
            this.record = transactionRecord;
            this.builder = new DefaultInstalmentSublistBuilder(transactionRecord)
            this.logMsg = "InstalmentSublistReader.read(" + this.record.type + " - " + this.record.id + ")";
            //log.audit(this.logMsg, "Qtde Parcelas: " + this.length());
        }
        length() {
            return this.record.getLineCount(SUBLISTNAME.instalment);
        }

        setBuilder(instalmentBuilder) {
            this.builder = instalmentBuilder;
        }

        read() {

            //o DefaultInstalmentSublistBuilder le a sublista de instalment e monta um array de instalment
            //Ja calculando o valor pago e dt pgto
            //log.debug("usando builder", (typeof this.builder));
            log.debug(InstalmentSublistReader.name, "using "+this.builder.constructor.name+" builder");
            let instalmentList = this.builder.build();
            return instalmentList;

        }
    }
    class LinksSublistReader {
        constructor(transactionRecord) {
            this.record = transactionRecord;
        }
        length() {
            return this.record.getLineCount(SUBLISTNAME.links);
        }
        read() {
            let linksList = [];

            for (var i = 0; i < this.length(); i++) {
                linksList.push(new LinksList(
                    this.record.id,
                    this.record.getSublistValue(SUBLISTNAME.links, 'linkurl', i),
                    this.record.getSublistValue(SUBLISTNAME.links, 'ststus', i),
                    this.record.getSublistValue(SUBLISTNAME.links, 'total', i),
                    this.record.getSublistValue(SUBLISTNAME.links, 'trandate', i),
                    this.record.getSublistValue(SUBLISTNAME.links, 'tranid', i),
                    this.record.getSublistValue(SUBLISTNAME.links, 'type', i)
                ));

            }
            log.audit("LinksSublistReader.read()", "linksList: " + JSON.stringify(linksList));

            return linksList;
        }
    }
    class TranBodyJsonReader {
        constructor(transactionRecord) {
            this.record = transactionRecord;
        }
        readInstalments() {
            let value = this.record.getValue(TRANBODYFLDNAME.instalments);
            if (value) {
                return JSON.parse(value);
            }
            return [];
        }
        readItems() {
            let value = this.record.getValue(TRANBODYFLDNAME.items);
            if (value) {
                return JSON.parse(value);
            }
            return [];
        }
    }

    class TranBodyJsonWriter {
        constructor(transactionRecord) {
            this.record = transactionRecord;
        }
        setInstalments(_list) {
            //log.debug("TranBodyJsonWriter.setInstalments: ", JSON.stringify(_list));

            this.record.setValue({ fieldId: TRANBODYFLDNAME.instalments, value: JSON.stringify(_list) });

        }
        setItems(list) {
            //log.debug("TranBodyJsonWriter.setItems: ", JSON.stringify(list));
            this.record.setValue({ fieldId: TRANBODYFLDNAME.items, value: JSON.stringify(list) });

        }
        write() {
            //log.audit("TranBodyJsonWriter", " saving record: " + this.record.type + ":" + this.record.id);
            let id = this.record.save();
            log.audit("TranBodyJsonWriter", "Record  " + this.record.type + " saved sucessfully id: " + id);

        }
    }


    class VendorPaymentUserEvent {
        constructor(vendorPaymentRecord) {
            this.record = vendorPaymentRecord;

        }

        beforeSubmit(context) {
            //ler as vendorbills para compor o json de intalments e items

            let itemList = [];
            let instalmentList = [];

            //carrega o vendor payment
            const vendPymtRecord = context.newRecord;
            log.debug("beforesbmt", "vendorpayment id: " + vendPymtRecord.id + " - " + vendPymtRecord.getValue('transactionnumber'));

            /*
            if (vendPymtRecord.type == 'customerpayment' || vendPymtRecord.type == 'vendorpayment' || vendPymtRecord.type == 'vendorpayment' || vendPymtRecord.type == 'invoice' || vendPymtRecord.type == 'vendorbill') {
                vendPymtRecord.setValue({
                    fieldId: 'custbody_rsc_gesplan_lastmodifdate_dt',
                    value: new Date()
                });
            }
            */

            //instancia o leitor da sublista apply
            const applySublistReader = new ApplySubListReader(vendPymtRecord);
            //filtra as linhas que estão aplicadas    
            let applyedList = applySublistReader.readApplied();
            //corre as linhas apply aplicadas
            applyedList.forEach((applyLine) => {

                log.debug("vpaymt applied sublist " + applyLine.trantype, applyLine.applydate + " - " + applyLine.due + " - " + applyLine.total);
                
                //BUSCAR ITMS NO VENDORBILL
                //carrega a vendor bill que foi selecionada (aplicada)
                const vendorBill = record.load({ type: 'vendorbill', id: applyLine.internalid, isDynamic: false });
                //log.debug("applied transaction load: ", vendorBill.id + " - " + vendorBill.getValue('transactionnumber'));
                //log.debug("loaded applied vendorbill" + applyLine.trantype, applyLine.applydate + " - " + applyLine.due + " - " + applyLine.total);

                //instancia o leitor de da sublista item
                const vbItemListReader = new ItemSublistReader(vendorBill);
                //instancia o leitor da sublista installment
                const vbInstalmentReader = new InstalmentSublistReader(vendorBill);
                vbInstalmentReader.setBuilder(new PaidInstalmentsFromApplyListBuilder(vendPymtRecord));

             
                //adiciona os itens da vendor bill aplicada no array itemList
                // para ser adicionado no campo custbody_rsc_gesplan_items_json do vendor payment

                let vbItemList = vbItemListReader.read();
                log.debug("vendorbill item list", JSON.stringify(vbItemList));
                
                let vbInstalmentList = vbInstalmentReader.read();
                log.debug("vendorbill instalment list", JSON.stringify(vbInstalmentList));

                log.audit("Qtde Parcelas: " + vbInstalmentList.length);


                //Implementar uma factory para definir qual o instalmentBuilder vai usar.
                if (vbInstalmentList && vbInstalmentList.length == 0) {

                    log.audit("Nenhuma instalment encontrada ", " Criando JSON com parcela unica para salvar no corpo da transacao afim de otimizar a Coleta de daddos para Gesplan");

                    log.audit("criando parcela paga ", " ---- ");

                    vbInstalmentReader.setBuilder(new SinglePaidInstalmentSublistBuilder(vendorBill));
                    vbInstalmentList = vbInstalmentReader.read();
                    log.audit("Parcela paga criada", JSON.stringify(vbInstalmentList));

                }

                itemList.push(
                    {
                        transactionid: vendorBill.id,
                        transactiontype: vendorBill.type,
                        items: vbItemList
                    }
                );
                instalmentList.push(
                    {
                        transactionid: vendorBill.id,
                        transactiontype: vendorBill.type,
                        instalments: vbInstalmentList
                    }

                );
            });
            
            //seta os campos json intalemnts e items.
            const jsonWriter2 = new TranBodyJsonWriter(vendPymtRecord);
            jsonWriter2.setItems(itemList);
            jsonWriter2.setInstalments(instalmentList);
            
        }

        afterSubmit(context) {

            
        }

    }
    VendorPaymentUserEvent.runBeforeSubmit = (context) => {
        
        return new VendorPaymentUserEvent(context.newRecord).beforeSubmit(context);
    }
    VendorPaymentUserEvent.runAfterSubmit = (context) => {
        return new VendorPaymentUserEvent(context.newRecord).afterSubmit(context);
    }


    class VendorBillUserEvent {
        constructor(vendorBillRecord) {
            this.record = vendorBillRecord;
        }

        beforeSubmit(context) {

            let itemList = [];
            let instalmentList = [];
            //carrega o vendor payment
            const vendorBill = context.newRecord;
            //instancia o leitor de da sublista item
            const vbItemListReader = new ItemSublistReader(vendorBill);
            //instancia o leitor da sublista installment
            const vbInstalmentReader = new InstalmentSublistReader(vendorBill);

            //adiciona os itens da vendor bill aplicada no array itemList
            // para ser adicionado no campo custbody_rsc_gesplan_items_json do vendor payment
            //log.debug(VendorBillUserEvent.name, "status da vendorbill "+vendorBill.getValue("status"));
                
            let vbItemList = vbItemListReader.read();
            log.debug("vendorbill item list", JSON.stringify(vbItemList));
            let vbInstalmentList = vbInstalmentReader.read();
            log.debug("vendorbill instalment list", JSON.stringify(vbInstalmentList));
            log.audit("Qtde Parcelas: " + vbInstalmentList.length);
            //Implementar uma factory para definir qual o instalmentBuilder vai usar.
            
            
            if (vbInstalmentList && vbInstalmentList.length == 0 && (context.type === 'create' ||  context.type === 'edit')) {

                log.audit("Nenhuma instalment encontrada ", " Criando JSON com parcela unica em aberto");
                vbInstalmentReader.setBuilder(new SingleOpenInstalmentSublistBuilder(vendorBill));
                
                vbInstalmentList = vbInstalmentReader.read();
            }
            

            //grava os items e instalments no corpo do vendorpayment
            //log.debug("antes de setar json na  vendorbill", vendorBill);
            const jsonWriter = new TranBodyJsonWriter(vendorBill);
            jsonWriter.setItems(vbItemList);
            jsonWriter.setInstalments(vbInstalmentList);


        }

        afterSubmit(context) {

            // ler os campos JSON das vendorbills  e verificar se estao preenchidos
            //senao estiverem entao seta os campos
            //tentar settar com submitfields que consome menos recursos

        }

    }
    VendorBillUserEvent.runBeforeSubmit = (context) => {
        return new VendorBillUserEvent(context.newRecord).beforeSubmit(context);
    }
    VendorBillUserEvent.runAfterSubmit = (context) => {
        return new VendorBillUserEvent(context.newRecord).afterSubmit(context);
    }






    class CustomerPaymentUserEvent {
        constructor(paymentRecord) {
            this.record = paymentRecord;

        }

        beforeSubmit(context) {
            //ler as vendorbills para compor o json de intalments e items
            //this.record = context.newRecord;

            //lista de itens que vao no corpo da customer payment
            let _itemList = [];
            //lista de parcelas que vao no corpo da customer payment
            let _instalmentList = [];
            //carrega o vendor payment
            const paymentRecord = context.newRecord;
            log.debug("beforesbmt", "customerpayment id: " + paymentRecord.id + " - " + paymentRecord.getValue('transactionnumber'));

            /*
            if (paymentRecord.type == 'customerpayment' || paymentRecord.type == 'vendorpayment' || paymentRecord.type == 'vendorpayment' || paymentRecord.type == 'invoice' || paymentRecord.type == 'vendorbill') {
                paymentRecord.setValue({
                    fieldId: 'custbody_rsc_gesplan_lastmodifdate_dt',
                    value: new Date()
                });
            }
            */

            //instancia o leitor da sublista apply
            const applySublistReader = new ApplySubListReader(paymentRecord);

            //filtra as linhas que estão aplicadas    
            let applyedList = applySublistReader.readApplied();

            //corre as linhas apply aplicadas e seleciona o id das invoices (contrato).
            //quando o pagamento aplica muitas "parcelas" nao dá pra dá load em todos os registros.
            let _allInvoices = [];
            let _uniqueInvIds = new Set();
            let invoiceRecords = [];
            let contratoIdX = {};


            //varre a lista apllyed e faz o lookup no FinanciamentoInvoice
            //para saber quem é a invoice principal ou que gerou a parcela(FinanciamentoInvoice) 
            applyedList.forEach((applyLine) => {
                if (applyLine.trantype === 'CuTrSale') {

                    contratoIdX = search.lookupFields({
                        type: 'customsale_rsc_financiamento',
                        id: applyLine.internalid,
                        columns: ['custbody_lrc_fatura_principal']
                    }).custbody_lrc_fatura_principal[0].value;

                    _allInvoices.push(contratoIdX);
                    _uniqueInvIds.add(contratoIdX);
                }
            });

            _uniqueInvIds.forEach((invId) => {


                log.debug("invoice id", invId);

                const contratoInvoiceRecord = record.load({ type: "invoice", id: invId, isDynamic: false });

                //instancia o leitor de da sublista item
                const itemListReader = new ItemSublistReader(contratoInvoiceRecord);
                let itemList = itemListReader.read();
                log.debug(itemList + " item list", JSON.stringify(itemList));

                //instancia o leitor da sublista installment
                const instalmentReader = new InstalmentSublistReader(paymentRecord);
                log.debug("item da lista apply", 'item da lista aplicada foi um Financiamento Invoice. Chamando o builder');
                //instalmentReader.setBuilder(new FinanciamentoInvoiceInstalmentSublistBuilder(contratoInvoiceRecord));
                instalmentReader.setBuilder(new PaidInstalmentsFromApplyListBuilder(paymentRecord));
                let instalmentList = instalmentReader.read();
                log.debug(" instalment list", JSON.stringify(instalmentList));


                //Implementar uma factory para definir qual o instalmentBuilder vai usar.
                if (instalmentList && instalmentList.length == 0) {
                    log.audit("Qtde Parcelas: " + instalmentList.length);

                    log.audit("Nenhuma instalment encontrada ", " Criando JSON com parcela unica para salvar no corpo da transacao afim de otimizar a Coleta de daddos para Gesplan");

                    //no caso de customer payment mostar a sublist de instalments da sublista de apply


                    log.audit("criando parcela paga ", " ---- ");

                    instalmentReader.setBuilder(new SinglePaidInstalmentSublistBuilder(contratoInvoiceRecord));
                    instalmentList = instalmentReader.read();
                    log.audit("Parcela paga criada", JSON.stringify(instalmentList));

                }


                _itemList.push(
                    {
                        transactionid: contratoInvoiceRecord.id,
                        transactiontype: contratoInvoiceRecord.type,
                        items: itemList
                    }
                );

                _instalmentList.push(
                    {
                        transactionid: contratoInvoiceRecord.id,
                        transactiontype: contratoInvoiceRecord.type,
                        instalments: instalmentList
                    }

                );


            });

            //seta os campos json intalemnts e items.
            const jsonWriter2 = new TranBodyJsonWriter(paymentRecord);
            jsonWriter2.setItems(_itemList);
            jsonWriter2.setInstalments(_instalmentList);


          
        }

        afterSubmit(context) {

            // ler os campos JSON das vendorbills  e verificar se estao preenchidos
            //senao estiverem entao seta os campos
            //tentar settar com submitfields que consome menos recursos

        }

    }
    CustomerPaymentUserEvent.runBeforeSubmit = (context) => {
        return new CustomerPaymentUserEvent(context.newRecord).beforeSubmit(context);
    }
    CustomerPaymentUserEvent.runAfterSubmit = (context) => {
        return new CustomerPaymentUserEvent(context.newRecord).afterSubmit(context);
    }







    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    }
});
