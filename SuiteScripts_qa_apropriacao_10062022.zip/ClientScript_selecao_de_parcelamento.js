/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/url", "N/currentRecord", "N/search"], function (require, exports, url_1, currentRecord_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.redirecionar = exports.fieldChanged = exports.pageInit = void 0;
    url_1 = __importDefault(url_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    search_1 = __importDefault(search_1);
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var currentRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        if (fieldId == 'custpage_lrc_fatura_principal') {
            // verefica se o campo foi alterado
            var faturaPai = currentRecord.getValue('custpage_lrc_fatura_principal');
            currentRecord.cancelLine({
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            var lineCount = currentRecord.getLineCount({
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            for (var i = lineCount - 1; i >= 0; i--) {
                currentRecord.removeLine({
                    line: i,
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                });
            }
            var array_1 = [];
            var anoParcela = currentRecord.getField({
                fieldId: 'custpage_lrc_ano_da_parcela'
            });
            search_1.default.create({
                type: "invoice",
                filters: [
                    ['custbody_lrc_fatura_principal', 'IS', faturaPai],
                    'AND',
                    ['mainline', 'IS', 'T'],
                ],
                columns: [
                    'trandate'
                ]
            }).run().each(function (result) {
                var invoiceLoockup = search_1.default.lookupFields({
                    type: 'invoice',
                    id: result.id,
                    columns: ['trandate', 'tranid']
                });
                var data = String(invoiceLoockup['trandate']);
                var dataSplited = data.split('/');
                var ano = dataSplited[2];
                var indicador = 0;
                for (var i = 0; i < array_1.length; i++) {
                    if (ano == array_1[i]) {
                        indicador++;
                    }
                }
                if (indicador == 0) {
                    array_1.push(ano);
                }
                return true;
            });
            anoParcela.removeSelectOption({
                value: null
            });
            anoParcela.insertSelectOption({
                text: '',
                value: ''
            });
            for (var i = 0; i < array_1.length; i++) {
                anoParcela.insertSelectOption({
                    text: array_1[i],
                    value: array_1[i]
                });
            }
        }
        if (fieldId == 'custpage_lrc_ano_da_parcela') {
            var lineCount = currentRecord.getLineCount({
                sublistId: 'custpage_lrc_selecao_de_reparcelamento'
            });
            for (var i = lineCount - 1; i >= 0; i--) {
                currentRecord.removeLine({
                    line: i,
                    sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                });
            }
            var faturaPai = currentRecord.getValue('custpage_lrc_fatura_principal');
            var anoParcela_1 = currentRecord.getValue('custpage_lrc_ano_da_parcela');
            search_1.default.create({
                type: "invoice",
                filters: [
                    ['custbody_lrc_fatura_principal', 'IS', faturaPai],
                    'AND',
                    ['mainline', 'IS', 'T'],
                ],
                columns: [
                    'trandate'
                ]
            }).run().each(function (result) {
                var invoiceLoockup = search_1.default.lookupFields({
                    type: 'invoice',
                    id: result.id,
                    columns: ['trandate', 'tranid', 'total']
                });
                var data = String(invoiceLoockup['trandate']);
                var dataSplited = data.split('/');
                var ano = dataSplited[2];
                console.log('passou aqui');
                if (anoParcela_1 == ano) {
                    console.log('entrou no if');
                    currentRecord.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                        fieldId: 'custpage_lrc_url',
                        value: url_1.default.resolveRecord({
                            recordType: "invoice",
                            recordId: result.id,
                            isEditMode: false
                        })
                    });
                    currentRecord.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                        fieldId: 'custpage_lrc_data_de_vencimento',
                        value: String(invoiceLoockup['trandate'])
                    });
                    currentRecord.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                        fieldId: 'custpage_lrc_valor',
                        value: String(invoiceLoockup['total'])
                    });
                    currentRecord.commitLine({
                        sublistId: 'custpage_lrc_selecao_de_reparcelamento'
                    });
                }
                return true;
            });
        }
    };
    exports.fieldChanged = fieldChanged;
    var redirecionar = function () {
        var record = currentRecord_1.default.get();
        var array = [];
        var currentCheckBoxReparcelar = record.getCurrentSublistValue({
            sublistId: 'custpage_lrc_selecao_de_reparcelamento',
            fieldId: 'custpage_lrc_reparcelar'
        });
        if (currentCheckBoxReparcelar == false) {
            alert("Selecione alguma parcela");
        }
        else {
            var item = record.getCurrentSublistValue({
                sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                fieldId: 'custpage_lrc_fatura_principal',
            });
            var valor = record.getCurrentSublistValue({
                sublistId: 'custpage_lrc_selecao_de_reparcelamento',
                fieldId: 'custpage_lrc_valor'
            });
            array.push(item);
            var redirecionar_1 = url_1.default.resolveScript({
                scriptId: 'customscript_lrc_simulacao_reparcelament',
                deploymentId: 'customdeploy_lrc_simulacao_reparcelament',
                params: {
                    valor: valor,
                }
            });
            window.location.replace(redirecionar_1);
        }
    };
    exports.redirecionar = redirecionar;
});
