/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 *
 * Client_unidadesVendidas.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/query", "N/currentRecord"], function (require, exports, search_1, query_1, currentRecord_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.tranformarMeses = exports.lerDataAtual = exports.downloadCSV = exports.relatorio = exports.makelist = exports.procucarUnidades = exports.pageInit = void 0;
    search_1 = __importDefault(search_1);
    query_1 = __importDefault(query_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    function procucarUnidades() {
        var form = currentRecord_1.default.get();
        var data = form.getValue({ fieldId: "cuspage_lrc_data_atual" });
        var projeto = form.getText({ fieldId: "cuspage_lrc_selecao" });
        //console.log(projeto)
        var mes_atual = lerDataAtual(data)[0];
        var ano_atual = lerDataAtual(data)[1];
        mes_atual = mes_atual.toLowerCase();
        var lista = [];
        var id_projeto = "";
        var id_contrato;
        var subsidiaria = "";
        //----------------------------------------------------------------------------
        //Encontrar o projeto selecionado
        search_1.default.create({
            type: "job",
            filters: ["entityid", "IS", projeto],
            columns: ["subsidiary", "entityid"]
        }).run().each(function (result) {
            subsidiaria = result.getText("subsidiary");
            id_projeto = result.id;
            //console.log("id do projeto: " + id_projeto);
            return true;
        });
        //----------------------------------------------------------------------------
        //Pegar todas as unidades vendidas do projeto
        search_1.default.create({
            type: "customrecord_rsc_unidades_empreendimento",
            filters: ["custrecord_rsc_un_emp_projeto", "IS", id_projeto],
            columns: ["custrecord_rsc_un_emp_nr_contrato", "custrecord_rsc_un_emp_projeto",
                "custrecord_rsc_un_emp_coef_aprop", "custrecord_rsc_un_emp_part_gafisa", "custrecord_rsc_junix_unidade_id",
                "custrecord_rsc_un_emp_bloco", "custrecord_rsc_un_emp_unidade"]
        }).run().each(function (resultado) {
            id_contrato = resultado.getValue("custrecord_rsc_un_emp_nr_contrato");
            //----------------------------------------------------------------------------
            //Se as unidades vendidas tiverem contrato, pegar as informações
            if (id_contrato) {
                var divisao = resultado.getText("custrecord_rsc_un_emp_projeto");
                var fator_aprovacao = String(resultado.getValue("custrecord_rsc_un_emp_coef_aprop"));
                var fator_participacao = String(resultado.getValue("custrecord_rsc_un_emp_part_gafisa"));
                var junix_str = String(resultado.getValue("custrecord_rsc_junix_unidade_id"));
                var junix = junix_str.match(/[\d]+/);
                var torre = resultado.getText("custrecord_rsc_un_emp_bloco");
                var unidade = String(resultado.getValue("custrecord_rsc_un_emp_unidade"));
                //Search Contratos
                var pesquisinha = search_1.default.lookupFields({
                    type: "invoice",
                    id: id_contrato,
                    columns: ["custbody_rsc_vlr_venda", "trandate"]
                });
                var venda_acumulada = Number(pesquisinha.custbody_rsc_vlr_venda);
                if (!venda_acumulada)
                    venda_acumulada = 0;
                var data_venda = String(pesquisinha.trandate);
                //console.log("id_contrato:", id_contrato)
                var datinha_1 = data_venda.slice(3, 5);
                var venda_do_mes = 0;
                if (mes_atual === String(datinha_1[0]))
                    venda_do_mes = venda_acumulada;
                else
                    venda_do_mes = 0;
                //----------------------------------------------------------------------------
                //Procurando por parcelas do contrato encontrado
                var sql = "SELECT " +
                    "t.id, t.custbody_rsc_tran_unidade as unidade, t.custbody_lrc_fatura_principal as contrato, t.foreignamountpaid as pago, " +
                    "t.foreignamountunpaid as nao_pago, t.custbody_rsc_projeto_obra_gasto_compra as projeto, tl.estgrossprofit AS incc, " +
                    "tl2.estgrossprofit as fp, tl3.estgrossprofit as igpm " +
                    "FROM " +
                    "transaction AS t " +
                    "INNER JOIN transactionline AS tl ON (tl.transaction = t.id) " +
                    "INNER JOIN transactionline AS tl2 ON (tl2.transaction = t.id) " +
                    "INNER JOIN transactionline AS tl3 ON (tl3.transaction = t.id) " +
                    "WHERE " +
                    "t.recordtype LIKE 'customsale_rsc_financiamento' AND " + //pegando apenas financiamento invoice
                    "t.custbody_rsc_projeto_obra_gasto_compra = " + id_projeto + " AND " + //referentes a um projeto
                    "t.custbody_rsc_tran_unidade IS NOT null AND " + //de uma unidade não nula
                    "t.custbody_lrc_fatura_principal = " + id_contrato + " AND " + //e de contrato especifico
                    "tl.linesequencenumber = 3 AND " + //Pegando os valores de incc
                    "tl2.linesequencenumber = 1 AND " + //fração do principal
                    "tl3.linesequencenumber = 4"; //igpm
                var resultIterator = query_1.default.runSuiteQL({
                    query: sql
                });
                var sqlresult = resultIterator.asMappedResults();
                //console.log(sqlresult);
                var A03_1 = 0;
                var A04_1 = 0;
                var A09_1 = 0;
                var A10_1 = 0;
                var A12_1 = 0;
                var A13_1 = 0;
                sqlresult.forEach(function (res) {
                    if (res.pago) {
                        A09_1 += res.pago;
                        A10_1 += (res.incc + res.pago);
                    }
                    else {
                        A03_1 += (res.incc + res.igpm);
                    }
                    if (datinha_1[0] === mes_atual && datinha_1[1] == ano_atual) { //se a data da parcela for igual a data atual
                        if (res.pago) {
                            A12_1 += res.pago;
                            A13_1 += (res.incc + res.igpm);
                        }
                        else {
                            A04_1 += res.nao_pago;
                        }
                    }
                });
                //----------------------------------------------------------------------------
                var infos = {
                    ano: ano_atual,
                    periodo: mes_atual,
                    subsidiaria: subsidiaria,
                    divisao: divisao,
                    data_venda: data_venda,
                    fator_aprovacao: fator_aprovacao,
                    fator_participacao: fator_participacao,
                    junix: junix,
                    torre: torre,
                    unidade: unidade,
                    venda_acumulada: venda_acumulada,
                    venda_do_mes: venda_do_mes,
                    A03: A03_1,
                    A04: A04_1,
                    A09: A09_1,
                    A10: A10_1,
                    A12: A12_1,
                    A13: A13_1
                };
                lista.push(infos);
            }
            return true;
        });
        return lista;
    }
    exports.procucarUnidades = procucarUnidades;
    function makelist(informacoes) {
        var form = currentRecord_1.default.get();
        //Removendo as linhas da sublista
        var total_linhas_detalhes = form.getLineCount({ sublistId: "custpage_lrc_sublist" });
        for (var i = 0; i < total_linhas_detalhes; i++) {
            form.removeLine({ sublistId: "custpage_lrc_sublist", line: 0 });
        }
        //subtotal
        var total_a01 = 0;
        var total_a02 = 0;
        var total_a03 = 0;
        var total_a04 = 0;
        var total_a09 = 0;
        var total_a10 = 0;
        var total_a12 = 0;
        var total_a13 = 0;
        //-----------------------------------------------------------------------------
        //Criando uma estrutura de dados para um CSV
        //Matriz
        var matriz = [];
        var primeira_linha = ["EMPRESA", "PROJETO", "ANO", "PERIODO", "DATA DO DOCUMENTO", "FATOR DE APROPRIAÇÃO", "FATOR DE PARTICIPAÇÃO",
            "A01 - VENDA ACUMULADA", "A02 - VENDA DO MÊS", "A03 - VENDA ACUMULADA DA CORREÇÃO MONETARIA", "A04 - VENDA DENTRO DO MÊS",
            "A09 - RECEBIMENTO ACUMULADO VALOR PRINCIPAL", "A10 - RECEBIMENTO ACUMULADO CM", "A12 - VALOR DE RECEBIMENTO DO VALOR PRINCIPAL",
            "A13 - VALOR DE RECEBIMENTO NO MÊS CM", "PROJETO FINANCEIRO", "TORRE", "UNIDADE"];
        matriz.push(primeira_linha);
        //-----------------------------------------------------------------------------
        for (var i = 0; i < informacoes.length; i++) {
            form.selectNewLine({ sublistId: "custpage_lrc_sublist" });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_subsidiaria', text: informacoes[i].subsidiaria });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_emp_projeto', text: informacoes[i].divisao });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_ano', text: informacoes[i].ano });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_mes', text: informacoes[i].periodo });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_data_doc', text: informacoes[i].data_venda });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_fator_apropriacao', text: informacoes[i].fator_aprovacao });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_fator_participacao', text: informacoes[i].fator_participacao });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_proj_financ', text: informacoes[i].junix });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_torre', text: informacoes[i].torre });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_unit', text: informacoes[i].unidade });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a01', text: informacoes[i].venda_acumulada.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }) });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a02', text: informacoes[i].venda_do_mes.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }) });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a03', text: informacoes[i].A03.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }) });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a04', text: informacoes[i].A04.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }) });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a09', text: informacoes[i].A09.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }) });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a10', text: informacoes[i].A10.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }) });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a12', text: informacoes[i].A12.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }) });
            form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a13', text: informacoes[i].A13.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }) });
            var linha = [informacoes[i].subsidiaria, informacoes[i].divisao, informacoes[i].ano, informacoes[i].periodo, informacoes[i].data_venda, informacoes[i].fator_aprovacao,
                informacoes[i].fator_participacao, informacoes[i].junix, informacoes[i].torre, informacoes[i].unidade,
                informacoes[i].venda_acumulada.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }),
                informacoes[i].venda_do_mes.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }),
                informacoes[i].A03.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }),
                informacoes[i].A04.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }),
                informacoes[i].A09.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }),
                informacoes[i].A10.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }),
                informacoes[i].A12.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }),
                informacoes[i].A13.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })];
            matriz.push(linha);
            total_a01 += Number(informacoes[i].venda_acumulada);
            total_a02 += Number(informacoes[i].venda_do_mes);
            total_a03 += Number(informacoes[i].A03);
            total_a04 += Number(informacoes[i].A04);
            total_a09 += Number(informacoes[i].A09);
            total_a10 += Number(informacoes[i].A10);
            total_a12 += Number(informacoes[i].A12);
            total_a13 += Number(informacoes[i].A13);
            form.commitLine({ sublistId: "custpage_lrc_sublist" });
        }
        //-----------------------------------------------------------------------------
        form.selectNewLine({ sublistId: "custpage_lrc_sublist" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_subsidiaria', text: "SUBTOTAL" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_emp_projeto', text: "-" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_ano', text: "-" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_mes', text: "-" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_data_doc', text: "-" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_fator_apropriacao', text: "-" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_fator_participacao', text: "-" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_proj_financ', text: "-" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_torre', text: "-" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_unit', text: "-" });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a01', text: String(total_a01.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })) });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a02', text: String(total_a02.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })) });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a03', text: String(total_a03.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })) });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a04', text: String(total_a04.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })) });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a09', text: String(total_a09.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })) });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a10', text: String(total_a10.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })) });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a12', text: String(total_a12.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })) });
        form.setCurrentSublistText({ sublistId: 'custpage_lrc_sublist', fieldId: 'custpage_lrc_a13', text: String(total_a13.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })) });
        var ultima_linha = ["SUBTOTAL", "-", "-", "-", "-", "-", "-", "-", "-", "-",
            String(total_a01.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })),
            String(total_a02.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })),
            String(total_a03.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })),
            String(total_a04.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })),
            String(total_a09.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })),
            String(total_a10.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })),
            String(total_a12.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' })),
            String(total_a13.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }))];
        matriz.push(ultima_linha);
        form.commitLine({ sublistId: "custpage_lrc_sublist" });
        //-----------------------------------------------------------------------------
        return matriz;
    }
    exports.makelist = makelist;
    function relatorio() {
        var id_projeto = "";
        var contador_total = 0;
        var contador_vendido = 0;
        var dias = 0;
        var form = currentRecord_1.default.get();
        var ordem = form.getValue({ fieldId: "cuspage_lrc_ordem" });
        var data_atual = form.getValue({ fieldId: "cuspage_lrc_data_atual" });
        var projeto = form.getText({ fieldId: "cuspage_lrc_selecao" });
        if (!data_atual) {
            alert("É necessário selecionar uma data");
            return false;
        }
        //---------------------------------------------------------------------
        //VERIFICANDO SE CONTEM 60% DAS UNIDADES VENDIDAS e SE PASSARAM OS 180 DIAS
        search_1.default.create({
            type: "job",
            filters: ["entityid", "IS", projeto],
            columns: ["startdate"]
        }).run().each(function (result) {
            var data_inicio = String(result.getValue("startdate"));
            var datai = data_inicio.slice(6) + "," + data_inicio.slice(3, 5) + "," + data_inicio.slice(0, 2);
            var DI = new Date(datai);
            var ini = Number(DI.valueOf());
            var end = Number(data_atual === null || data_atual === void 0 ? void 0 : data_atual.valueOf());
            //console.log(DI);
            //console.log(data_atual);
            dias = (end - ini) / (1000 * 60 * 60 * 24);
            //console.log(dias);
            id_projeto = result.id;
            return true;
        });
        search_1.default.create({
            type: "customrecord_rsc_unidades_empreendimento",
            filters: ["custrecord_rsc_un_emp_projeto", "IS", id_projeto],
            columns: ["custrecord_rsc_un_emp_nr_contrato"]
        }).run().each(function (resultado) {
            var id_contrato = resultado.getValue("custrecord_rsc_un_emp_nr_contrato");
            contador_total++;
            if (id_contrato)
                contador_vendido++;
            return true;
        });
        //---------------------------------------------------------------------
        var matriz = undefined;
        var porcentagem = contador_total / contador_total;
        if (porcentagem >= 0.6 || ordem || dias >= 180) {
            var informacoes = procucarUnidades();
            matriz = makelist(informacoes);
            //console.log(informacoes.length);
        }
        else {
            alert("Os critérios de aprovação para o relatório não estão sendo satisfeitos");
        }
        if (matriz) {
            var string = "";
            for (var i = 0; i < matriz.length; i++) {
                for (var j = 0; j < matriz[i].length; j++) {
                    string = string + matriz[i][j] + ";";
                }
                string = string.slice(0, string.length - 1) + "\n";
            }
            console.log(string);
            form.setValue({
                fieldId: "custpage_lrc_escondido",
                value: string
            });
        }
        return;
    }
    exports.relatorio = relatorio;
    function downloadCSV() {
        var form = currentRecord_1.default.get();
        var string = form.getValue({ fieldId: "custpage_lrc_escondido" });
        var blob = new Blob([String(string)], { type: 'text/plain;charset=utf-8;' });
        var link = window.document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = 'export.csv';
        link.click();
        window.URL.revokeObjectURL(link.href);
    }
    exports.downloadCSV = downloadCSV;
    function lerDataAtual(data) {
        if (data) {
            data = String(data);
            var dia = data.slice(9, 11);
            var mes = String(data.slice(4, 7));
            var ano = data.slice(11, 15);
            var mes_numero = tranformarMeses(mes);
            var retorno = [mes, ano, dia, mes_numero];
            return retorno;
        }
        else
            return ["mes não informado", "ano não informado"];
    }
    exports.lerDataAtual = lerDataAtual;
    function tranformarMeses(str) {
        var mes_num = "";
        switch (str) {
            case "Jan":
                mes_num = "01";
                break;
            case "Feb":
                mes_num = "02";
                break;
            case "Mar":
                mes_num = "03";
                break;
            case "Apr":
                mes_num = "04";
                break;
            case "May":
                mes_num = "05";
                break;
            case "Jun":
                mes_num = "06";
                break;
            case "Jul":
                mes_num = "07";
                break;
            case "Ago":
                mes_num = "08";
                break;
            case "Sep":
                mes_num = "09";
                break;
            case "Oct":
                mes_num = "10";
                break;
            case "Nov":
                mes_num = "11";
                break;
            case "Dec":
                mes_num = "12";
                break;
        }
        return mes_num;
    }
    exports.tranformarMeses = tranformarMeses;
});
