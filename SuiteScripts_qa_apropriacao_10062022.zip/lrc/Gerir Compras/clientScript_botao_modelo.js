/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript para definir as funções da criação de modelo de requisição das tarefas de modelo de projeto
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url"], function (require, exports, currentRecord_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.criarRequisicao = exports.abrirInterfaceCriacaoModeloRequisicao = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var abrirInterfaceCriacaoModeloRequisicao = function () {
        var currentRecord = currentRecord_1.default.get();
        var url = url_1.default.resolveScript({
            deploymentId: 'customdeploy_criacao_param_req',
            scriptId: 'customscript_lrc_suitelet_criac_par_req',
            params: {
                modeloDeProjetoId: String(currentRecord.getValue('id'))
            }
        });
        window.open(url, "_blank");
    };
    exports.abrirInterfaceCriacaoModeloRequisicao = abrirInterfaceCriacaoModeloRequisicao;
    var criarRequisicao = function () {
        var currentRecord = currentRecord_1.default.get();
        var url = url_1.default.resolveScript({
            deploymentId: 'customdeploy_lrc_cria_requisicao',
            scriptId: 'customscript_lrc_cria_requisicao',
            params: {
                projeto: String(currentRecord.getValue('id'))
            }
        });
        window.open(url, "_blank");
    };
    exports.criarRequisicao = criarRequisicao;
});
// export const validateLine: EntryPoints.Client.validateLine = (ctx: EntryPoints.Client.validateLineContext) =>{
//     const sublistIndex = ctx.currentRecord.getCurrentSublistIndex({sublistId: "custpage_lrc_sublista_requisicao"});
//     console.log('index', sublistIndex)
//     const sublistCount = ctx.currentRecord.getLineCount({sublistId: "custpage_lrc_sublista_requisicao"}); 
//     console.log('count', sublistCount)
//     if(ctx.sublistId = 'custpage_lrc_sublista_requisicao'){ 
//         if(sublistIndex == sublistCount){
//             alert("Você não pode adicionar nem remover linhas. Os critérios são definidos do botão criar modelo de requisição.");
//             return false;
//         }
//     }
//     return true
// }
// export const validateDelete: EntryPoints.Client.validateDelete = (ctx: EntryPoints.Client.validateDeleteContext) =>{
//     console.log('aqui')
//     if (ctx.sublistId == "custpage_lrc_sublista_requisicao"){
//         console.log('aqui2')
//         alert("Você não pode adicionar nem remover linhas. Os critérios são definidos do botão criar modelo de requisição.");
//         return false;
//     }
//     return true
// }
// export const validateInsert: EntryPoints.Client.validateInsert = (ctx: EntryPoints.Client.validateInsertContext) =>{
//     if (ctx.sublistId == "custpage_lrc_sublista_requisicao"){
//         alert("Você não pode inserir linhas. Os critérios são definidos a partir do modelo");
//         return false;
//     }
//     return true
// }
