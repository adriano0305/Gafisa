/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* userevent_gerir_compras.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        var form = ctx.form;
        var record = ctx.newRecord;
        var sublistas = record.getSublists();
        log_1.default.error("sublistas", sublistas);
        var sublistaAtividade = form.getSublist({
            id: "activities"
        });
        sublistaAtividade.addButton({
            label: "Novo Chamado",
            id: "custpage_lrc_novo_chamado"
        });
    };
    exports.beforeLoad = beforeLoad;
});
