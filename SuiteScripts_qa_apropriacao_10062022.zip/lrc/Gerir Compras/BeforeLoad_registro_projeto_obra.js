/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_processoDistrato.js
 *
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        if (ctx.request && ctx.request.parameters.projetoObra) {
            var form = ctx.form;
            log.debug('form', form)
            var parameters = ctx.request.parameters;
            var projetoObra = parameters.projetoObra;
            var setaValue = form.getField({
                id: 'class'
            }).defaultValue = projetoObra;
            log_1.default.error('setValue', setaValue);
        }
    };
    exports.beforeLoad = beforeLoad;
});
