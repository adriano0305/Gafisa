/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * beforeLoad.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE) {
            var avaliacaoRecord = ctx.newRecord;
            log_1.default.error("parameters", ctx.request.parameters);
            avaliacaoRecord.setValue({
                fieldId: "custrecord_lrc_campo_fornecedor",
                value: ctx.request.parameters["vendorId"]
            });
        }
    };
    exports.beforeLoad = beforeLoad;
});
