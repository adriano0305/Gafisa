/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * avaliacaoDeFornecedor.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url", "N/log"], function (require, exports, currentRecord_1, url_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.preencherCampo = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    log_1 = __importDefault(log_1);
    exports.pageInit = function () {
    };
    exports.preencherCampo = function () {
        var record = currentRecord_1.default.get();
        var createNewAvaliacaoURL = url_1.default.resolveRecord({
            isEditMode: false,
            recordType: "customrecord_lrc_avaliacao_fornecedores",
            params: {
                "vendorId": record.id
            }
        });
        log_1.default.error("createNewAvaliacaoURL", createNewAvaliacaoURL);
        window.location.replace(createNewAvaliacaoURL);
    };
});
