/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * ClienteScript_BloqueioFornecedor.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log"], function (require, exports, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = exports.pageInit = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var currentRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        var currentRecordType = currentRecord.type;
        log_1.default.error('type', currentRecordType);
        log_1.default.error('fieldId', fieldId);

        if (fieldId === 'entity' || fieldId == 'approvalstatus') {
            log_1.default.error('field = entity', 'done');
            try {
                var fornecedor = record_1.default.load({
                    type: 'vendor',
                    id: currentRecord.getValue('entity')
                });
                var status_aprovacao = currentRecord.getValue('approvalstatus');
                log_1.default.error('status_aprovacao', status_aprovacao);

                var statusSuspensao = fornecedor.getValue('custentity_lrc_status_suspensao');
                log_1.default.error('status', statusSuspensao);
                if (statusSuspensao != 1 && status_aprovacao == 2 ) {
                    // Contrato de compra = "purchasecontract"
                    // Pagamento = "vendorpayment"
                    // Requisição = "purchaserequisition"
                    // Pedido de compra = "purchaseorder"
                    // Cotação de compras = "customtransaction_rsc_cotacao_compras"
                    // Cotação de compra = "customtransaction_rsc_cotacao_compras"
                    if (statusSuspensao == 2) {
                        if (currentRecordType == 'purchasecontract' ||
                            currentRecordType == 'purchaserequisition' ||
                            currentRecordType == 'purchaseorder' ||
                            currentRecordType == 'vendorbill') {
                            currentRecord.setValue({
                                fieldId: 'entity',
                                value: ''
                            });
                            
                            alert('Fornecedor Suspenso');
                        }
                    }
                    else if (statusSuspensao == 3 || statusSuspensao == 4 || statusSuspensao == 5 || statusSuspensao == 6) {
                        if (currentRecordType == 'purchasecontract' ||
                            currentRecordType == 'purchaserequisition' ||
                            currentRecordType == 'purchaseorder' ||
                            currentRecordType == 'vendorpayment' ||
                            currentRecordType == 'customtransaction_rsc_cotacao_compras' ||
                            currentRecordType == 'vendorbill') {
                            currentRecord.setValue({
                                fieldId: 'entity',
                                value: ''
                            });
                            alert('Fornecedor Suspenso');
                        }
                        log_1.default.error('if', currentRecordType);
                    }
                }
            }
            catch (error) {
                log_1.default.error('main if', error);
            }
        }
    };
    exports.fieldChanged = fieldChanged;
});
