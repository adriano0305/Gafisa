/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * userEvent_removerBotao.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/record"], function (require, exports, log_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.VIEW) {
            var form = ctx.form;
            var newRecord = ctx.newRecord;
            log_1.default.error("form", form);
            log_1.default.error("NewRec", newRecord);
            var status_1 = newRecord.getText({
                fieldId: 'statusRef'
            });
            log_1.default.error("status", status_1);
            var statusStr = status_1.toLowerCase();
            log_1.default.error("StatusStr", statusStr);
            if (statusStr == 'pendingreceipt') {
                var idEntity = newRecord.getValue({
                    fieldId: 'entity'
                });
                log_1.default.error("entity", idEntity);
                var vendor = record_1.default.load({
                    type: 'vendor',
                    id: idEntity
                });
                log_1.default.error("vendor", vendor);
                var statusSuspenso = vendor.getValue({
                    fieldId: 'custentity_lrc_status_suspensao'
                });
                log_1.default.error("statusSuspenso", statusSuspenso);
                log_1.default.error("Entrou no if", "done");
                if (statusSuspenso && statusSuspenso != 1 && statusSuspenso != 2) {
                    form.removeButton({
                        id: "receive"
                    });
                }
            }
        }
    };
    exports.beforeLoad = beforeLoad;
});
