/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* 
* 
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record"], function (require, exports, search_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    var beforeSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var newAtiv = newRecord.getValue('custrecord_rsc_procurador_atividade');
        if (newAtiv) {
            search_1.default.create({
                type: 'customrecord_rsc_procurador',
                filters: [
                    ['custrecord_rsc_procurador_atividade', 'IS', 'T']
                ]
            }).run().each(function (result) {
                var recordProcurador = record_1.default.load({
                    type: 'customrecord_rsc_procurador',
                    id: result.id
                });
                recordProcurador.setValue({
                    fieldId: 'custrecord_rsc_procurador_atividade',
                    value: false
                });
                recordProcurador.save({
                    ignoreMandatoryFields: true
                });
                return true;
            });
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
