/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* TestClientSublist.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/currentRecord", "N/search", "N/log"], function (require, exports, record_1, currentRecord_1, search_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = exports.salvarConfig = exports.pageInit = void 0;
    record_1 = __importDefault(record_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var salvarConfig = function () {
        var currRecord = currentRecord_1.default.get();
        log_1.default.error('currRecord', currRecord);
        var qtLinhas = currRecord.getLineCount({
            sublistId: 'custpage_lrc_item'
        });
        var arredondamento = currRecord.getValue('custpage_lrc_arrend_parcela');
        var tipoDoc = currRecord.getValue('custpage_lrc_tipo_doc');
        log_1.default.error('tipoDoc', tipoDoc);
        if (tipoDoc) {
            var searchResult = search_1.default.create({
                type: 'customrecord_lrc_configuracao_de_parcela',
                filters: ['custrecord_lrc_campo_tipo_documento_fisc', 'IS', tipoDoc]
            }).run().getRange({
                start: 0,
                end: 1
            });
            log_1.default.error('searchResult', searchResult[0]);
            if (searchResult[0]) {
                var configRecord = record_1.default.load({
                    type: 'customrecord_lrc_configuracao_de_parcela',
                    id: searchResult[0].id
                });
                log_1.default.error('configRecord', configRecord);
                configRecord.setValue({
                    fieldId: 'custrecord_lrc_arredondamento_parcela',
                    value: arredondamento
                });
                configRecord.save({
                    ignoreMandatoryFields: true
                });
            }
            else {
                var configRecord = record_1.default.create({
                    type: 'customrecord_lrc_configuracao_de_parcela'
                });
                configRecord.setValue({
                    fieldId: 'custrecord_lrc_arredondamento_parcela',
                    value: arredondamento
                });
                configRecord.setValue({
                    fieldId: 'custrecord_lrc_campo_tipo_documento_fisc',
                    value: tipoDoc
                });
                log_1.default.error('tipoDoc', tipoDoc);
                configRecord.save({
                    ignoreMandatoryFields: true
                });
            }
        }
        for (var i = 0; i < qtLinhas; i++) {
            var itemSublista = currRecord.getSublistValue({
                sublistId: 'custpage_lrc_item',
                fieldId: 'custpage_lrc_camp_item',
                line: i
            });
            var unidadeSublista = currRecord.getSublistValue({
                sublistId: 'custpage_lrc_item',
                fieldId: 'custpage_lrc_unidade_correcao',
                line: i
            });
            log_1.default.error('itemSublista', itemSublista);
            log_1.default.error('unidadeSublista', unidadeSublista);
            if (itemSublista) {
                if (!unidadeSublista) {
                    alert('Preencha a unidade de correção desse item');
                    return false;
                }
            }
            if (unidadeSublista) {
                if (!itemSublista) {
                    alert('Preencha a unidade de correção desse item');
                    return false;
                }
            }
            var searchItem = search_1.default.create({
                type: 'customrecord_lrc_unidade_item',
                filters: [
                    ['custrecord_lrc_itens', 'IS', itemSublista]
                ]
            }).run().getRange({
                start: 0,
                end: 1
            });
            log_1.default.error('searchItem', searchItem[0]);
            if (searchItem[0]) {
                var unidadeRecord = record_1.default.load({
                    type: 'customrecord_lrc_unidade_item',
                    id: searchItem[0].id
                });
                unidadeRecord.setValue({
                    fieldId: 'custrecord_lrc_unidade_correcao',
                    value: unidadeSublista
                });
                unidadeRecord.save({
                    ignoreMandatoryFields: true
                });
            }
            else {
                var unidadeRecord = record_1.default.create({
                    type: 'customrecord_lrc_unidade_item',
                });
                unidadeRecord.setValue({
                    fieldId: 'custrecord_lrc_unidade_correcao',
                    value: unidadeSublista
                });
                unidadeRecord.setValue({
                    fieldId: 'custrecord_lrc_itens',
                    value: itemSublista
                });
                log_1.default.error('itemSublista', itemSublista);
                log_1.default.error('unidadeSublista', unidadeSublista);
                unidadeRecord.save({
                    ignoreMandatoryFields: true
                });
            }
        }
        alert('Configurações atualizadas.');
        currRecord.setValue({
            fieldId: 'custpage_lrc_tipo_doc',
            value: ''
        });
        currRecord.setValue({
            fieldId: 'custpage_lrc_arrend_parcela',
            value: false
        });
        for (var i = 0; i < qtLinhas; i++) {
            currRecord.removeLine({
                sublistId: 'custpage_lrc_item',
                line: i,
            });
        }
    };
    exports.salvarConfig = salvarConfig;
    var fieldChanged = function (ctx) {
        var currentRecord = ctx.currentRecord;
        var tipoDoc = currentRecord.getValue('custpage_lrc_tipo_doc');
        var fieldId = ctx.fieldId;
        if (fieldId == 'custpage_lrc_tipo_doc') {
            if (tipoDoc != '') {
                var searchResult = search_1.default.create({
                    type: 'customrecord_lrc_configuracao_de_parcela',
                    filters: ['custrecord_lrc_campo_tipo_documento_fisc', 'IS', tipoDoc]
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                if (searchResult[0]) {
                    var configRecord = record_1.default.load({
                        type: 'customrecord_lrc_configuracao_de_parcela',
                        id: searchResult[0].id,
                    });
                    currentRecord.setValue({
                        fieldId: 'custpage_lrc_arrend_parcela',
                        value: configRecord.getValue('custrecord_lrc_arredondamento_parcela')
                    });
                }
            }
        }
    };
    exports.fieldChanged = fieldChanged;
});
