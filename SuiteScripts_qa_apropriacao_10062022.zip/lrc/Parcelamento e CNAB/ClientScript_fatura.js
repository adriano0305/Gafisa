/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* TestClientSublist.ts
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = exports.pageInit = void 0;
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var fieldId = ctx.fieldId;
        var currRecord = ctx.currentRecord;
        if (fieldId == 'custbody_lrc_tipo_fatura') {
            if (currRecord.getValue('custbody_lrc_tipo_fatura') == 2) {
                currRecord.getField('custbody_lrc_fatura_principal').isVisible = true;
            }
            else {
                currRecord.getField('custbody_lrc_fatura_principal').isVisible = false;
            }
        }
    };
    exports.fieldChanged = fieldChanged;
});
