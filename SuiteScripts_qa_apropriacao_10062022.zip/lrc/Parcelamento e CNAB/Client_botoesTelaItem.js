/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * Client_botoesTelaItem.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/search", "N/url"], function (require, exports, currentRecord_1, search_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.editar = exports.adicionar = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    search_1 = __importDefault(search_1);
    url_1 = __importDefault(url_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var adicionar = function () {
        var currentRecord = currentRecord_1.default.get();
        var redirecionar = url_1.default.resolveRecord({
            recordType: 'customrecord_lrc_unidade_item',
            isEditMode: true,
            params: {
                itemId: currentRecord.id
            }
        });
        window.location.replace(redirecionar);
    };
    exports.adicionar = adicionar;
    var editar = function () {
        console.error('editar');
        var currentRecord = currentRecord_1.default.get();
        var itemId = currentRecord.id;
        var searchCorrecao = search_1.default.create({
            type: "customrecord_lrc_unidade_item",
            filters: ['custrecord_lrc_itens', 'IS', itemId],
        }).run().getRange({
            start: 0,
            end: 1
        });
        var redirecionar = url_1.default.resolveRecord({
            recordType: 'customrecord_lrc_unidade_item',
            recordId: searchCorrecao[0].id,
            isEditMode: true,
            params: {
                itemId: currentRecord.id
            }
        });
        window.location.replace(redirecionar);
    };
    exports.editar = editar;
});
