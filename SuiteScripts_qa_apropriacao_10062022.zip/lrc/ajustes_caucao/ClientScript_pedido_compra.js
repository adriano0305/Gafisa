/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search"], function (require, exports, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.saveRecord = void 0;
    search_1 = __importDefault(search_1);
    var saveRecord = function (ctx) {
        var record = ctx.currentRecord;
        var quantidadeItensSublist = record.getLineCount({
            sublistId: 'apply'
        });
        for (var i = 0; i < quantidadeItensSublist; i++) {
            console.log('linha', i);
            var valorDevido = record.getSublistValue({
                fieldId: 'due',
                line: i,
                sublistId: 'apply'
            });
            console.log('valordevido', valorDevido);
            var pagamento = record.getSublistValue({
                fieldId: 'amount',
                line: i,
                sublistId: 'apply'
            });
            console.log('pagamento', pagamento);
            if (pagamento) {
                var internalId = record.getSublistValue({
                    fieldId: 'internalid',
                    line: i,
                    sublistId: 'apply'
                });
                console.log('internalid', internalId);
                var retidoCaucao = search_1.default.lookupFields({
                    id: internalId,
                    type: 'vendorbill',
                    columns: 'custbody_rsc_retido_caucao'
                });
                console.log(retidoCaucao.custbody_rsc_retido_caucao);
                console.log(valorDevido - pagamento);
                if (valorDevido - pagamento < retidoCaucao.custbody_rsc_retido_caucao) {
                    console.log('entrou', 'if');
                    var dialog = confirm("O pagamento atual consumirá o saldo do valor retido para caução. Deseja continuar?");
                    if (dialog == true) {
                        return true;
                    }
                    else {
                        return false;
                    }
                    ;
                }
                ;
            }
            ;
        }
        ;
        return true;
    };
    exports.saveRecord = saveRecord;
});
