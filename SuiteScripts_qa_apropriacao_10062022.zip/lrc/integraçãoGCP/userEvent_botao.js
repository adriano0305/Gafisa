/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEventReturnAuth.ts
 *
 *
 *
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.EDIT) {
            var form = ctx.form;
            form.clientScriptModulePath = './clientScript_funcaoBotao.js';
            form.addButton({
                id: "custpage_lrc_criar_chamado",
                label: 'Criar Chamado',
                functionName: 'funcaoBotaoCriarChamado'
            });
        }
    };
    exports.beforeLoad = beforeLoad;
});
