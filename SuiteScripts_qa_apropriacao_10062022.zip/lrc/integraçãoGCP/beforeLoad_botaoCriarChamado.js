/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_processoDistrato.js
 *
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        if (ctx.request.parameters.informacoesGCP) {
            var form = ctx.form;
            var parameters = ctx.request.parameters;
            var informacoesGCP = parameters.informacoesGCP;
            var record = ctx.newRecord;
            log_1.default.error('parameters', parameters);
            log_1.default.error('parameters', informacoesGCP);
            // record.setValue({
            //     fieldId: 'custevent_lrc_informacoes_do_gcp',
            //     value: parameters
            // });
            form.getField({
                id: 'custevent_lrc_informacoes_do_gcp'
            }).defaultValue = informacoesGCP;
        }
    };
    exports.beforeLoad = beforeLoad;
});
