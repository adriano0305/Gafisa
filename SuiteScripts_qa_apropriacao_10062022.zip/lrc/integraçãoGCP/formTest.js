/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * SuiteLet para testes de interface
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
define(["require", "exports", "N/log", "N/ui/serverWidget"], function (require, exports, log_1, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    log_1 = __importDefault(log_1);
    UI = __importStar(UI);
    exports.onRequest = function (ctx) {
        log_1.default.debug('GET', 'done');
        var form = UI.createForm({
            title: 'GCP TESTE'
        });
        form.addTab({
            id: 'tab_teste',
            label: 'Tab Teste'
        });
        form.addTab({
            id: 'tab_teste2',
            label: 'Tab Teste 2'
        });
        ctx.response.writePage(form);
    };
});
