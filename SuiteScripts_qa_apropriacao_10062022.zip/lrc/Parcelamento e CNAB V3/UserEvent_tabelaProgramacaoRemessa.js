/**
* @NApiVersion 2.x
* @NScriptType UserEventScript
*
* UserEvent_tabelaProgramacaoRemessa.ts
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        //Se a opção "Gerar remessa automaticamente?" ('custpage_lrc_generate_auto') estiver marcada
        //insere o botão "Gerar remessa"
        //if(CurrentRecord.get().getValue('custpage_campo_gerar_auto')){
        ctx.form.addButton({
            id: "custpage_generate_button",
            label: "Gerar Remessa",
            functionName: "gerarAuto"
        });
        // }
    };
    exports.beforeLoad = beforeLoad;
});
