/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet para ajuste das parcelas selecionadas no passo anterior do processo
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget", "./utils/formFunctions"], function (require, exports, UI, FormFunctions) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    FormFunctions = __importStar(FormFunctions);
    var onRequest = function (ctx) {
        var params = ctx.request.parameters;
        var vendorBills = [];
        if (params.hasOwnProperty('vendorbills'))
            vendorBills = JSON.parse(params.vendorbills);
        if (ctx.request.method == 'GET') {
            var form = UI.createForm({
                title: 'Agendar modificação das parcelas'
            });
            // Field para armazenar dados do parâmetro da requisição
            form.addField({
                id: 'custpage_campo_array_ids',
                label: 'Parcelas Ids',
                type: UI.FieldType.LONGTEXT
            }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = JSON.stringify(vendorBills);
            // Botões
            form.addButton({
                id: 'custpage_btn_remover_att',
                label: 'Remover parcelas da atualização',
                functionName: 'removerParcelas'
            });
            form.addButton({
                id: 'custpage_btn_agendar_att',
                label: 'Agendar atualização',
                functionName: 'agendarAtt'
            });
            form.addButton({
                id: 'custpage_btn_voltar_tela',
                label: 'Voltar',
                functionName: 'voltarPasso'
            });
            // Fieldgroup
            form.addFieldGroup({
                id: 'custpage_fieldgroup_parameters',
                label: 'Parâmetros para Atualização em Massa',
            }).isCollapsed = true;
            // Campos de ajuste das parcelas
            form.addField({
                id: 'custpage_campo_data_pag',
                label: 'Data do pagamento',
                type: UI.FieldType.DATE,
                container: 'custpage_fieldgroup_parameters'
            });
            form.addField({
                id: 'custpage_campo_status_parcela',
                label: 'Status da parcela',
                type: UI.FieldType.SELECT,
                source: 'customlist_lrc_list_status_aprov',
                container: 'custpage_fieldgroup_parameters'
            });
            form.addField({
                id: 'custpage_campo_metodo_pag',
                label: 'Método de pagamento',
                type: UI.FieldType.SELECT,
                source: 'customlistlrc_metodos_pagamento',
                container: 'custpage_fieldgroup_parameters'
            });
            form.addField({
                id: 'custpage_campo_conta_pag',
                label: 'Conta do pagamento',
                type: UI.FieldType.SELECT,
                source: 'customrecord_lrc_reg_contas_bancarias',
                container: 'custpage_fieldgroup_parameters'
            });
            form = FormFunctions.createParcelasSublist(form);
            form.clientScriptModulePath = './Clientscript_ajusteParcela.js';
            ctx.response.writePage(form);
        }
        ;
    };
    exports.onRequest = onRequest;
});
