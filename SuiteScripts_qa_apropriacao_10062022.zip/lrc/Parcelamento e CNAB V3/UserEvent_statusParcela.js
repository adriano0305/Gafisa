/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_statusParcela.ts
 *
 */ 
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/runtime"], function (require, exports, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    runtime_1 = __importDefault(runtime_1);
    var beforeLoad = function (ctx) {
        var record = ctx.newRecord;
        var newRecordType = ctx.newRecord.getValue("type");
        var paramsPagamento = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_parcela_pagamento_apro' });
        var paramsRecebimento = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_parcela_recebimento_apro' });
        if (ctx.type == ctx.UserEventType.CREATE) {
            if (newRecordType == 'invoice' || paramsRecebimento == true) {
                record.setValue({
                    fieldId: 'approvalstatus',
                    value: 2
                });
            }
            else if (newRecordType == 'vendorbill' || paramsPagamento == true) {
                record.setValue({
                    fieldId: 'approvalstatus',
                    value: 2
                });
            }
            ;
        }
        ;
    };
    exports.beforeLoad = beforeLoad;
});
