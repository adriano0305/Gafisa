var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord"], function (require, exports, currentRecord_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.aproveAllSublistItens = exports.selectAllSublistItens = exports.clearSublist = exports.setSublistExecutarValues = exports.getSublistExecutarValues = exports.setSublistParcelaValues = exports.getSublistParcelaValues = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    var getSublistParcelaValues = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var quantidadeItensSublist = currentAjusteParcelaRecord.getLineCount({
            sublistId: 'custpage_sublist_parcelas'
        });
        var invoices = [];
        if (quantidadeItensSublist == 0) {
            alert('Nenhuma parcela selecionada');
            throw new Error('Nenhuma parcela Selecionada');
        }
        ;
        for (var i = 0; i < quantidadeItensSublist; i++) {
            var invoice = { internalid: '' };
            var isParcelaSelecionada = currentAjusteParcelaRecord.getSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_selecionar',
                line: i
            });
            if (isParcelaSelecionada) {
                var approvalStatus = currentAjusteParcelaRecord.getSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_campo_status_parcela',
                    line: i
                });
                invoice.approvalstatus = String(approvalStatus);
                // const contaPagamento = currentAjusteParcelaRecord.getSublistValue({
                //     sublistId: 'custpage_sublist_parcelas',
                //     fieldId: 'custpage_campo_contas_pagar',
                //     line: i
                // });
                // invoice.contaPagamento = String(contaPagamento);
                var internalId = currentAjusteParcelaRecord.getSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_campo_numero_parcela',
                    line: i
                });
                invoice.internalid = String(internalId);
                var entity = currentAjusteParcelaRecord.getSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_entidade_campo',
                    line: i
                });
                invoice.entity = String(entity);
                var total = currentAjusteParcelaRecord.getSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_campo_base_parcela',
                    line: i
                });
                invoice.total = String(total);
                var duedate = currentAjusteParcelaRecord.getSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_campo_data_vencimentos',
                    line: i
                });
                invoice.duedate = String(duedate);
                var enddate = currentAjusteParcelaRecord.getSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_campo_data_pgts',
                    line: i
                });
                invoice.enddate = String(enddate);
                var custbodyLrcInvoiceMetPagFatura = currentAjusteParcelaRecord.getSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_campo_metodo_pgts',
                    line: i
                });
                invoice.custbodyLrcInvoiceMetPagFatura = String(custbodyLrcInvoiceMetPagFatura);
                var custpageCampoContaPgts = currentAjusteParcelaRecord.getSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_campo_conta_pgts',
                    line: i
                });
                invoice.custpageCampoContaPgts = String(custpageCampoContaPgts);
                invoices.push(invoice);
            }
            ;
        }
        ;
        return invoices;
    };
    exports.getSublistParcelaValues = getSublistParcelaValues;
    var setSublistParcelaValues = function (invoices) {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        invoices.forEach(function (invoice) {
            console.log(invoice);
            currentAjusteParcelaRecord.selectNewLine({
                sublistId: 'custpage_sublist_parcelas',
            });
            currentAjusteParcelaRecord.setCurrentSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_status_parcela',
                value: String(invoice.approvalstatus) || ''
            });
            // currentAjusteParcelaRecord.setCurrentSublistValue({
            //     sublistId: 'custpage_sublist_parcelas',
            //     fieldId: 'custpage_campo_contas_pagar',
            //     value: String(invoice.contaPagamento) || ''
            // });
            currentAjusteParcelaRecord.setCurrentSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_numero_parcela',
                value: String(invoice.internalid) || ''
            });
            currentAjusteParcelaRecord.setCurrentSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_entidade_campo',
                value: String(invoice.entity) || ''
            });
            currentAjusteParcelaRecord.setCurrentSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_base_parcela',
                value: String(invoice.total) || ''
            });
            if (invoice.duedate) {
                invoice.duedate = invoice.duedate.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                currentAjusteParcelaRecord.setCurrentSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_campo_data_vencimentos',
                    value: new Date(invoice.duedate)
                });
            }
            if (invoice.enddate) {
                invoice.enddate = invoice.enddate.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                currentAjusteParcelaRecord.setCurrentSublistValue({
                    sublistId: 'custpage_sublist_parcelas',
                    fieldId: 'custpage_campo_data_pgts',
                    value: new Date(invoice.enddate)
                });
            }
            currentAjusteParcelaRecord.setCurrentSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_metodo_pgts',
                value: String(invoice.custbodyLrcInvoiceMetPagFatura) || ''
            });
            currentAjusteParcelaRecord.setCurrentSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_conta_pgts',
                value: String(invoice.custpageCampoContaPgts) || ''
            });
            currentAjusteParcelaRecord.commitLine({
                sublistId: 'custpage_sublist_parcelas'
            });
        });
        currentAjusteParcelaRecord.setValue({
            fieldId: 'custpage_campo_array_ids',
            value: currentAjusteParcelaRecord.getSublist({
                sublistId: 'custpage_sublist_parcelas'
            }).toString() || ''
        });
    };
    exports.setSublistParcelaValues = setSublistParcelaValues;
    var getSublistExecutarValues = function () {
        var currentExec = currentRecord_1.default.get();
        var quantidadeItensSublist = currentExec.getLineCount({
            sublistId: 'custpage_sublist_parcelas'
        });
        var gerarCnab = [];
        if (quantidadeItensSublist == 0) {
            alert('Nenhuma parcela selecionada');
            throw new Error('Nenhuma parcela Selecionada');
        }
        ;
        for (var i = 0; i < quantidadeItensSublist; i++) {
            var pagamento = {};
            var contaPagamento = currentExec.getSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_conta_pag',
                line: i
            });
            pagamento.contaPagamento = String(contaPagamento) || '';
            var total = currentExec.getSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_saldo',
                line: i
            });
            pagamento.total = String(total) || '';
            var duedate = currentExec.getSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_data_pag',
                line: i
            });
            pagamento.dataPagamento = String(duedate) || '';
            gerarCnab.push(pagamento);
        }
        ;
        return gerarCnab;
    };
    exports.getSublistExecutarValues = getSublistExecutarValues;
    var setSublistExecutarValues = function (invoices) {
        var currentExecutarGeracao = currentRecord_1.default.get();
        invoices.forEach(function (pagamento) {
            console.log(pagamento);
            try {
                currentExecutarGeracao.selectNewLine({
                    sublistId: 'custpage_sublist_parcelas_exec',
                });
                currentExecutarGeracao.setCurrentSublistValue({
                    sublistId: 'custpage_sublist_parcelas_exec',
                    fieldId: 'custpage_campo_conta_pag',
                    value: String(pagamento.custpageCampoContaPgts) || 'Vazio'
                });
                currentExecutarGeracao.setCurrentSublistValue({
                    sublistId: 'custpage_sublist_parcelas_exec',
                    fieldId: 'custpage_campo_saldo',
                    value: String(pagamento.total) || 'Vazio'
                });
                if (pagamento.duedate) {
                    pagamento.duedate = pagamento.duedate.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                    currentExecutarGeracao.setCurrentSublistValue({
                        sublistId: 'custpage_sublist_parcelas_exec',
                        fieldId: 'custpage_campo_data_pag',
                        value: new Date(pagamento.duedate)
                    });
                }
                currentExecutarGeracao.commitLine({
                    sublistId: 'custpage_sublist_parcelas_exec'
                });
            }
            catch (error) {
                console.log('executar error', error);
            }
        });
    };
    exports.setSublistExecutarValues = setSublistExecutarValues;
    var clearSublist = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var quantidadeItensSublist = currentAjusteParcelaRecord.getLineCount({
            sublistId: 'custpage_sublist_parcelas'
        });
        for (var i = quantidadeItensSublist; i >= 1; i--) {
            currentAjusteParcelaRecord.removeLine({
                sublistId: 'custpage_sublist_parcelas',
                line: i
            });
        }
    };
    exports.clearSublist = clearSublist;
    var selectAllSublistItens = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var quantidadeItensSublist = currentAjusteParcelaRecord.getLineCount({
            sublistId: 'custpage_sublist_parcelas'
        });
        for (var i = 0; i < quantidadeItensSublist; i++) {
            currentAjusteParcelaRecord.selectLine({
                sublistId: 'custpage_sublist_parcelas',
                line: i
            });
            currentAjusteParcelaRecord.setCurrentSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_selecionar',
                value: true
            });
            currentAjusteParcelaRecord.commitLine({
                sublistId: 'custpage_sublist_parcelas'
            });
        }
    };
    exports.selectAllSublistItens = selectAllSublistItens;
    var aproveAllSublistItens = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var quantidadeItensSublist = currentAjusteParcelaRecord.getLineCount({
            sublistId: 'custpage_sublist_parcelas'
        });
        for (var i = 0; i < quantidadeItensSublist; i++) {
            currentAjusteParcelaRecord.selectLine({
                sublistId: 'custpage_sublist_parcelas',
                line: i
            });
            currentAjusteParcelaRecord.setCurrentSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_status_parcela',
                value: 2
            });
            currentAjusteParcelaRecord.commitLine({
                sublistId: 'custpage_sublist_parcelas'
            });
        }
    };
    exports.aproveAllSublistItens = aproveAllSublistItens;
});
