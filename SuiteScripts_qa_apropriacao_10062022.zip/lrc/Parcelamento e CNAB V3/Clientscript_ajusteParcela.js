/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript para definir as funções dos processo da interface de Ajuste de Parcela
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/search", "N/log", "N/url", "N/record", "./utils/sublistFunctions"], function (require, exports, currentRecord_1, search_1, log_1, url_1, record_1, SublistFunctions) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.voltarPasso = exports.agendarAtt = exports.removerParcelas = exports.atualizarEmMassa = exports.buscarParcelas = exports.selecionarTudo = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    url_1 = __importDefault(url_1);
    record_1 = __importDefault(record_1);
    SublistFunctions = __importStar(SublistFunctions);
    var pageInit = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var invoices = currentAjusteParcelaRecord.getValue('custpage_campo_array_ids');
        if (invoices) {
            SublistFunctions.setSublistParcelaValues(JSON.parse(JSON.parse(JSON.stringify(invoices))));
            SublistFunctions.selectAllSublistItens();
        }
    };
    exports.pageInit = pageInit;
    var selecionarTudo = function () {
        SublistFunctions.selectAllSublistItens();
    };
    exports.selecionarTudo = selecionarTudo;
    var buscarParcelas = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var preFilters = [
            ['subsidiary', 'IS', 'custpage_campo_subsidiaria'],
            ['location', 'IS', 'custpage_campo_localidade'],
            ['approvalstatus', 'IS', 'custpage_campo_statusparcela'],
            ['custbody_lrc_vendor_prev_pagamento', 'IS', 'custpage_campo_contapgt'],
            ['custbody_lrc_vendor_metodo_pagamento', 'IS', 'custpage_campo_metodopgt'],
            ['startdate', 'ONORAFTER', 'custpage_campo_vencimentode'],
            ['enddate', 'BEFORE', 'custpage_campo_vencimentoate'],
            ['trandate', 'ONORAFTER', 'custpage_campo_pagamentode'],
            ['duedate', 'BEFORE', 'custpage_campo_pagamentoate'],
            ['department', 'IS', 'custpage_campo_departamento'],
            ['class', 'IS', 'custpage_campo_centrodecusto'],
            ['internalid', 'IS', 'custpage_campo_numerodoc'],
            ['entity', 'IS', 'custpage_campo_entidades'],
        ];
        var filters = [];
        preFilters.forEach(function (preFilter) {
            var fieldValue = String(currentAjusteParcelaRecord.getValue(preFilter[2]));
            if (fieldValue) {
                var filter = void 0;
                if (preFilter[1] === 'BEFORE' || preFilter[1] === 'ONORAFTER') {
                    filter = [preFilter[0], preFilter[1], dateToString(new Date(String(fieldValue)))];
                }
                else {
                    filter = [preFilter[0], preFilter[1], fieldValue];
                }
                filters.push(filter);
                filters.push('AND');
            }
        });
        filters.push(['mainline', 'IS', 'T']);
        console.log('filtros', filters);
        var pagedInvoice = search_1.default.create({
            type: 'vendorbill',
            filters: filters,
            columns: [
                'approvalstatus',
                'internalid',
                'entity',
                'total',
                'duedate',
                'enddate',
                'custbody_lrc_vendor_metodo_pagamento',
                'custbody_lrc_vendor_prev_pagamento'
            ]
        }).runPaged({
            pageSize: 50
        });
        var vendorBills = [];
        if (pagedInvoice.pageRanges.length) {
            for (var i = 0; i < pagedInvoice.pageRanges.length; i++) {
                var currentPage = pagedInvoice.fetch({
                    index: i
                });
                currentPage.data.forEach(function (result) {
                    var vendorBill = {
                        internalid: '',
                    };
                    vendorBill.approvalstatus = String(result.getValue('approvalstatus'));
                    vendorBill.internalid = String(result.getValue('internalid'));
                    vendorBill.entity = String(result.getValue('entity'));
                    vendorBill.total = String(result.getValue('total'));
                    vendorBill.duedate = String(result.getValue('duedate'));
                    vendorBill.enddate = String(result.getValue('enddate'));
                    vendorBill.custbodyLrcInvoiceMetPagFatura = String(result.getValue('custbody_lrc_vendor_metodo_pagamento'));
                    vendorBill.custpageCampoContaPgts = String(result.getValue('custbody_lrc_vendor_prev_pagamento'));
                    vendorBill.internalid && vendorBills.push(vendorBill);
                });
            }
            SublistFunctions.setSublistParcelaValues(vendorBills);
        }
        else {
            alert('Nenhum registro encontrado!');
        }
    };
    exports.buscarParcelas = buscarParcelas;
    var atualizarEmMassa = function () {
        var vendorBills = SublistFunctions.getSublistParcelaValues();
        var url = url_1.default.resolveScript({
            deploymentId: "customdeploy_lrc_imple_sessiontwo",
            scriptId: 'customscript_lrc_ajuste_parcela_twosessi',
            params: {
                vendorbills: JSON.stringify(vendorBills)
            }
        });
        window.location.replace(url);
    };
    exports.atualizarEmMassa = atualizarEmMassa;
    var removerParcelas = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var quantidadeItensSublist = currentAjusteParcelaRecord.getLineCount({
            sublistId: 'custpage_sublist_parcelas'
        });
        for (var i = 0; i < quantidadeItensSublist; i++) {
            var isParcelaSelecionada = currentAjusteParcelaRecord.getSublistValue({
                sublistId: 'custpage_sublist_parcelas',
                fieldId: 'custpage_campo_selecionar',
                line: i
            });
            if (isParcelaSelecionada) {
                currentAjusteParcelaRecord.removeLine({
                    sublistId: 'custpage_sublist_parcelas',
                    line: i
                });
            }
        }
    };
    exports.removerParcelas = removerParcelas;
    var agendarAtt = function () {
        var arrayParcelas = [];
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var statusParcelaId = currentAjusteParcelaRecord.getValue('custpage_campo_status_parcela');
        var metodoPagamentoId = currentAjusteParcelaRecord.getValue('custpage_campo_metodo_pag');
        var contaPagamentoId = currentAjusteParcelaRecord.getValue('custpage_campo_conta_pag');
        var dataPagamento = String(currentAjusteParcelaRecord.getValue('custpage_campo_data_pag'));
        var vendorBills = SublistFunctions.getSublistParcelaValues();
        try {
            var newAgendAjustParcelaRecord = record_1.default.create({
                type: 'customrecord_lrc_agend_ajuste_parcela',
            });
            if (dataPagamento) {
                dataPagamento = dataPagamento.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                newAgendAjustParcelaRecord.setValue({
                    fieldId: 'custrecord_lrc_agend_data_pag',
                    value: new Date(dataPagamento)
                });
            }
            newAgendAjustParcelaRecord.setValue({
                fieldId: 'custrecord_lrc_agend_status_parcela',
                value: statusParcelaId || ''
            });
            newAgendAjustParcelaRecord.setValue({
                fieldId: 'custrecord_lrc_agend_met_pagamento',
                value: metodoPagamentoId || ''
            });
            newAgendAjustParcelaRecord.setValue({
                fieldId: 'custrecord_lrc_agend_conta_pag',
                value: contaPagamentoId || ''
            });
            vendorBills.forEach(function (vendorBill) {
                arrayParcelas.push(vendorBill.internalid);
            });
            newAgendAjustParcelaRecord.setValue({
                fieldId: 'custrecord_lrc_agend_parc_att',
                value: JSON.stringify(arrayParcelas)
            });
            newAgendAjustParcelaRecord.save({ ignoreMandatoryFields: true });
            alert('Atualização agendada!');
        }
        catch (error) {
            log_1.default.error('agendarAtualizacaoError', error);
        }
    };
    exports.agendarAtt = agendarAtt;
    var voltarPasso = function () {
        var vendorBills = SublistFunctions.getSublistParcelaValues();
        var url = url_1.default.resolveScript({
            deploymentId: 'customdeploy_lrc_imple_ajuste_parcela',
            scriptId: 'customscript_lrc_script_ajuste_parcela',
            params: {
                vendorbills: JSON.stringify(vendorBills)
            }
        });
        window.location.replace(url);
    };
    exports.voltarPasso = voltarPasso;
    var dateToString = function (date) {
        return date.getDay() + "/" + date.getMonth() + "/" + date.getFullYear();
    };
});
