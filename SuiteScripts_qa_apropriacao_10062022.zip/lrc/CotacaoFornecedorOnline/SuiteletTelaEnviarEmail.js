/**
 *@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteletTelaEnviarEmail.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log", "N/ui/serverWidget", "N/email", "N/render", "N/file", "N/record", "N/url", "N/runtime"], function (require, exports, search_1, log_1, serverWidget_1, email_1, render_1, file_1, record_1, url_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getTransactionContacts = exports.onRequest = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    serverWidget_1 = __importDefault(serverWidget_1);
    email_1 = __importDefault(email_1);
    render_1 = __importDefault(render_1);
    file_1 = __importDefault(file_1);
    record_1 = __importDefault(record_1);
    url_1 = __importDefault(url_1);
    runtime_1 = __importDefault(runtime_1);
    var handle_rollback_delete_record_msg = function (msg) {
        record_1.default.delete({
            type: msg.recordType,
            id: msg.recordId
        });
    };
    var handle_rollback_delete_file_msg = function (msg) {
        file_1.default.delete({
            id: msg.fileId
        });
    };
    var ROLLBACK_MSGS = [];
    var ROLLBACK_F_DICT = {
        "DELETE_FILE": handle_rollback_delete_file_msg,
        "DELETE_RECORD": handle_rollback_delete_record_msg
    };
    var rollback = function () {
        ROLLBACK_MSGS.forEach(function (rollbackMsg) {
            var msgType = rollbackMsg.msgType.toString();
            var msg = rollbackMsg.msg;
            ROLLBACK_F_DICT[msgType](msg);
        });
    };
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var form = serverWidget_1.default.createForm({ title: "Enviar E-mail" });
            buildForm(ctx.request.parameters, form);
            ctx.response.writePage(form);
        }
        else { // Submit Button ENVIAR
            // Constroi email
            var email = void 0;
            try {
                email = buildEmail(ctx);
            }
            catch (e) {
                rollback();
                throw Error(e);
            }
            // Adiciona anexo na pasta de anexos
            var attachmentFile = ctx.request.files["custpage_lrc_anexo"];
            var folderId = runtime_1.default.getCurrentScript().getParameter({ name: "custscript_lrc_attachments_folder_id" });
            try {
                addFileToAttachmentsFolder(folderId, attachmentFile);
            }
            catch (e) {
                rollback();
                throw Error("Ocorreu um erro ao adicionar o arquivo na pasta de anexos: " + e);
            }
            // Cria registro "Mensagens da Requisição"
            var logRecord = void 0;
            try {
                var reqId = Number(ctx.request.parameters["custpage_lrc_reqid"]);
                logRecord = buildLogRecord(reqId, email);
            }
            catch (e) {
                rollback();
                throw Error("Ocorreu um erro ao construir o registro \"Mensagens da Requisi\u00E7\u00E3o\": " + e);
            }
            // Salva o registro "Mensagens da Requisição" e redireciona
            var id = void 0;
            try {
                id = logRecord.save();
            }
            catch (e) {
                rollback();
                throw Error("Ocorreu um erro ao salvar o registro \"Mensagens da Requisi\u00E7\u00E3o\": " + e);
            }
            // Adiciona uma mensagem de DELETE_RECORD em rollback (Caso ocorra algum erro -> rollback() deletando o registro da mensagem)
            var rollbackDeleteRecordMsg = {
                recordId: id.toString(),
                recordType: "customrecord_lrc_mensagens_requisicao"
            };
            var rollbackMsg = {
                msgType: "DELETE_RECORD",
                msg: rollbackDeleteRecordMsg
            };
            ROLLBACK_MSGS.push(rollbackMsg);
            log_1.default.error("id", id);
            // Captura o URL do registro de mensagem
            var logRecordURL = url_1.default.resolveRecord({
                recordType: "customrecord_lrc_mensagens_requisicao",
                recordId: id
            });
            log_1.default.error("logrrecorduirl", logRecordURL);
            // Captura o URL da Tela de Envio de email
            var scriptURL = url_1.default.resolveScript({
                scriptId: "customscript_lrc_enviar_email_st",
                deploymentId: "customdeploy_lrc_enviar_email_st",
                params: { reqId: Number(ctx.request.parameters["custpage_lrc_reqid"]) },
                returnExternalUrl: false
            });
            // Envia email
            try {
                email_1.default.sendBulk({
                    author: Number(runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_autor_email' })) || -5,
                    body: email.content,
                    subject: email.subject,
                    recipients: email.to,
                    cc: email.cc,
                    bcc: email.bcc,
                    attachments: email.attachments
                });
            }
            catch (e) {
                rollback();
                throw Error("Ocorreu um erro ao enviar o e-mail: " + e);
            }
            var html = "\n            <!DOCTYPE html>\n            <html>\n                <head>\n                    <title>Email enviado!</title>\n                    <style type=\"text/css\">\n                        a.button6{\n                            display:inline-block;\n                            padding:0.7em 1.4em;\n                            margin:0 0.3em 0.3em 0;\n                            border-radius:0.15em;\n                            box-sizing: border-box;\n                            text-decoration: none;\n                            border: 2px solid #125ab2;\n                            font-family:'Roboto',sans-serif;\n                            text-transform: none;\n                            font-weight:400;\n                            color:#FFFFFF;\n                            background-color: #358efa;\n                            text-align:center;\n                            position:relative;\n                        }\n                        a.button6:active{\n                            top:0.1em;\n                        }\n                        a.button6:hover{\n                            background-color: #1467cc\n                        }\n                        @media all and (max-width:30em){\n                            a.button6{\n                                display:block;\n                                margin:0.4em auto;\n                            }\n                        }\n                    </style>\n                </head>\n                <body>\n                    <div>\n                        <a href=\"" + scriptURL + "\" class=\"button6\"><b>Voltar</b></a>\n                    </div>\n                    <div>\n                        <a href=\"" + logRecordURL + "\" class=\"button6\"><b>Visualizar Registro de Mensagem</b></a>\n                    </div>\n                </body>\n            </html>\n        ";
            ctx.response.write({ output: html });
        }
    };
    var buildLogRecord = function (reqId, email) {
        var logRecord = record_1.default.create({
            type: "customrecord_lrc_mensagens_requisicao"
        });
        // Constroi string de emails de destinatarios
        var recipients = [];
        recipients = recipients.concat(email.to.map(function (email) { return "PARA: " + email; }));
        recipients = recipients.concat(email.cc.map(function (email) { return "CC: " + email; }));
        recipients = recipients.concat(email.bcc.map(function (email) { return "BCC: " + email; }));
        var recipientsStr = recipients.join("\n");
        var fieldsToFill = {
            custrecord_lrc_requisicao: reqId,
            custrecord_lrc_assunto: email.subject,
            custrecord_lrc_mensagem: email.content,
            custrecord_lrc_dest: recipientsStr,
            custrecord_lrc_req_data: new Date()
        };
        Object.keys(fieldsToFill).forEach(function (fieldId) {
            logRecord.setValue({
                fieldId: fieldId,
                value: fieldsToFill[fieldId]
            });
        });
        return logRecord;
    };
    var buildEmail = function (ctx) {
        log_1.default.error("ctx.request", ctx.request);
        log_1.default.error("parameters", Object.keys(ctx.request.parameters));
        // Get attachment(s)
        var attachments = [];
        var attachmentFile = ctx.request.files["custpage_lrc_anexo"];
        log_1.default.error("attachmentFile", attachmentFile);
        if (attachmentFile)
            attachments.push(attachmentFile);
        // Get templateId
        var templateId = Number(ctx.request.parameters["custpage_lrc_modelo_email"]);
        var reqId = Number(ctx.request.parameters["custpage_lrc_reqid"]);
        // Render email
        var renderedEmail;
        try {
            renderedEmail = renderEmail(templateId, reqId);
        }
        catch (e) {
            throw "Ocorreu um erro ao renderizar o e-mail: " + e;
        }
        var content = renderedEmail["content"];
        var subject = renderedEmail["subject"];
        // Captura informações da sublista
        var rowDelimiter = /\u0002/;
        var colDelimiter = /\u0001/;
        var to = [];
        var cc = [];
        var bcc = [];
        var dests_rows = ctx.request.parameters["custpage_lrc_sublist_destdata"].split(rowDelimiter);
        log_1.default.error("rows", dests_rows);
        dests_rows.forEach(function (row) {
            var cols = row.split(colDelimiter);
            log_1.default.error("cols", cols);
            var email = String(cols[0]);
            if (cols[1] == "T")
                to.push(email);
            if (cols[2] == "T")
                cc.push(email);
            if (cols[3] == "T")
                bcc.push(email);
        });
        log_1.default.error("cc", cc);
        log_1.default.error("to", to);
        log_1.default.error("bcc", bcc);
        var email = {
            to: to,
            cc: cc,
            bcc: bcc,
            attachments: attachments,
            content: content,
            subject: subject
        };
        return email;
    };
    var renderEmail = function (templateId, transactionId) {
        var mergeResult = render_1.default.mergeEmail({
            templateId: templateId,
            transactionId: transactionId
        });
        var emailSubject = mergeResult.subject;
        var emailBody = mergeResult.body;
        var responseBody = {
            content: emailBody,
            subject: emailSubject
        };
        return responseBody;
    };
    var addFileToAttachmentsFolder = function (folderId, file) {
        if (!file)
            return; // nada a fazer
        if (!folderId)
            throw "O par\u00E2metro ID DA PASTA DE ANEXOS (\"custscript_lrc_attachments_folder_id\") n\u00E3o est\u00E1 definido!";
        // Define o nome do arquivo
        // Caso o nome já exista, o nome é definido por file.name + " (2... e assim por diante)"
        var searchObj = search_1.default.create({
            type: search_1.default.Type.FOLDER,
            columns: [
                search_1.default.createColumn({
                    name: "name",
                    join: "file",
                    sort: search_1.default.Sort.DESC
                })
            ],
            filters: [
                ["internalid", "IS", folderId],
                "AND",
                ["file.folder", "IS", folderId],
                "AND",
                ["file.name", "CONTAINS", file.name]
            ]
        }).run().getRange({ start: 0, end: 1 });
        var fileCopyIndex = null;
        if (searchObj && searchObj[0]) {
            var searchFileName = String(searchObj[0].getValue({ name: "name", join: "file" }));
            fileCopyIndex = getFileCopyIndex(searchFileName, file.name);
        }
        if (fileCopyIndex) {
            file.name = file.name + (" (" + fileCopyIndex.toString() + ")");
        }
        log_1.default.error("file.name", file.name);
        // Define a pasta do arquivo
        file.folder = Number(folderId);
        // Salva o arquivo
        var fileId = file.save();
        log_1.default.error("fileId", fileId);
        // Adiciona uma mensagem de DELETE em rollback (Caso ocorra algum erro -> rollback() deletando o registro do arquivo)
        var rollbackDeleteFileMsg = { fileId: fileId.toString() };
        var rollbackMsg = {
            msgType: "DELETE_FILE",
            msg: rollbackDeleteFileMsg
        };
        ROLLBACK_MSGS.push(rollbackMsg);
    };
    var getFileCopyIndex = function (searchFileName, fileName) {
        var newString = searchFileName.replace(fileName, "").replace(/[ ()]+/g, "");
        log_1.default.error("newString", newString);
        return newString ? (Number(newString) + 1) : 2;
    };
    var buildForm = function (params, form) {
        // Define modulo do clientscript
        form.clientScriptModulePath = "./ClientScriptTelaEnviarEmail.js";
        // Captura o ID da requisição
        var reqId = params.reqId;
        // Encontra os contatos da requisição com o campo e-mail definido
        var contacts = exports.getTransactionContacts(reqId, "PurchReq", [
            ["email", "isnotempty", ""]
        ]);
        log_1.default.error("contacts", contacts);
        // Constroi tabs
        buildTabs(form);
        // Constroi bodyFields
        buildBodyFields(form, reqId.toString());
        // Adiciona os botoes necessarios
        buildButtons(form);
        // Controi sublista de contatos 
        buildDestSublist(form, contacts);
    };
    var buildTabs = function (form) {
        // form.addSubtab({
        //     id: "custpage_lrc_subtab_anexos",
        //     label: "Anexos"
        // });
        form.addSubtab({
            id: "custpage_lrc_subtab_dest",
            label: "Destinatários"
        });
    };
    var buildBodyFields = function (form, reqId) {
        form.addField({
            type: serverWidget_1.default.FieldType.INLINEHTML,
            label: "X",
            id: "custpage_lrc_inline_html"
        })
            .defaultValue =
            "\n        <style>\n            div.a {\n                font-size: 15px;\n                color: red;\n            }\n        </style>\n        <div class=\"a\">\n            Obs: Os contatos da requisi\u00E7\u00E3o que n\u00E3o possuem e-mail s\u00E3o ignorados!\n        </div>\n    ";
        form.addField({
            type: serverWidget_1.default.FieldType.SELECT,
            label: "Modelo",
            id: "custpage_lrc_modelo_email",
            source: "emailtemplate"
        });
        form.addField({
            type: serverWidget_1.default.FieldType.LONGTEXT,
            label: "Mensagem",
            id: "custpage_lrc_corpo"
        }).updateDisplayType({ displayType: serverWidget_1.default.FieldDisplayType.DISABLED });
        form.addField({
            type: serverWidget_1.default.FieldType.LONGTEXT,
            label: "Assunto",
            id: "custpage_lrc_assunto"
        }).updateDisplayType({ displayType: serverWidget_1.default.FieldDisplayType.DISABLED });
        form.addField({
            type: serverWidget_1.default.FieldType.FILE,
            label: "Anexo",
            id: "custpage_lrc_anexo"
        });
        // Campo escondido para armazenar id da requisição
        form.addField({
            type: serverWidget_1.default.FieldType.TEXT,
            label: "ID DA REQUISICAO",
            id: "custpage_lrc_reqid"
        }).updateDisplayType({ displayType: serverWidget_1.default.FieldDisplayType.HIDDEN })
            .defaultValue = reqId;
    };
    var buildButtons = function (form) {
        form.addSubmitButton({
            label: "Enviar"
        });
        form.addButton({
            label: "Cancelar",
            functionName: "cancelar",
            id: "custpage_lrc_cancelar"
        });
        form.addButton({
            label: "Pré-Visualizar",
            functionName: "preview",
            id: "custpage_lrc_preview"
        });
    };
    var buildDestSublist = function (form, contacts) {
        var sublist = form.addSublist({
            label: "Destinatários",
            id: "custpage_lrc_sublist_dest",
            type: serverWidget_1.default.SublistType.INLINEEDITOR,
            tab: "custpage_lrc_subtab_dest"
        });
        // Constroi campo "Destinatários adicionais"
        var destsField = sublist.addField({
            id: "custpage_lrc_dests",
            label: "Destinatários adicionais",
            type: serverWidget_1.default.FieldType.SELECT,
        });
        contacts.forEach(function (contact) {
            destsField.addSelectOption({
                text: contact.entityid,
                value: contact.email
            });
        });
        // Constroi demais campos da sublista
        sublist.addField({
            id: "custpage_lrc_is_to",
            label: "Para",
            type: serverWidget_1.default.FieldType.CHECKBOX,
        });
        sublist.addField({
            id: "custpage_lrc_is_cc",
            label: "CC",
            type: serverWidget_1.default.FieldType.CHECKBOX,
        });
        sublist.addField({
            id: "custpage_lrc_is_bcc",
            label: "BCC",
            type: serverWidget_1.default.FieldType.CHECKBOX,
        });
    };
    exports.getTransactionContacts = function (tranInternalId, dbstrantype, optionalFilters) {
        var contacts = [];
        var filters = [
            ["transaction.type", "anyof", dbstrantype],
            "AND",
            ["transaction.internalid", "is", tranInternalId]
        ];
        if (optionalFilters) {
            filters.push("AND");
            filters.push(optionalFilters);
        }
        search_1.default.create({
            type: search_1.default.Type.CONTACT,
            filters: filters,
            columns: [
                search_1.default.createColumn({
                    name: "internalid",
                    summary: search_1.default.Summary.GROUP
                }),
                search_1.default.createColumn({
                    name: "email",
                    summary: search_1.default.Summary.GROUP
                }),
                search_1.default.createColumn({
                    name: "entityid",
                    summary: search_1.default.Summary.GROUP
                })
            ]
        }).run().each(function (result) {
            contacts.push({
                "internalid": Number(result.getValue({ name: "internalid", summary: search_1.default.Summary.GROUP })),
                "email": String(result.getValue({ name: "email", summary: search_1.default.Summary.GROUP })),
                "entityid": String(result.getValue({ name: "entityid", summary: search_1.default.Summary.GROUP })),
            });
            return true;
        });
        return contacts;
    };
});
