/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * lrc_cancel_memo.ts
 *
 * Retornar valor de crédito do memorando de crédito.
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log", "N/search"], function (require, exports, record_1, log_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    function Criar_Nova_Data(record) {
        var novaDataModificacao = record_1.default.create({
            type: "customrecord_lrc_conta_data_modificacao",
        });
        var date = new Date(); //verificar se precisa de modificação
        novaDataModificacao.setValue({
            fieldId: 'custrecord_lrc_lastmodifieddate',
            value: date
        });
        novaDataModificacao.setValue({
            fieldId: 'custrecord_lrc_conta_bacaria',
            value: record.id
        });
        novaDataModificacao.save({
            ignoreMandatoryFields: true
        });
    }
    function Editar_Data_Modificacao(id) {
        var DataModificacao = record_1.default.load({
            type: 'customrecord_lrc_conta_data_modificacao',
            id: id,
            isDynamic: true
        });
        var date = new Date();
        DataModificacao.setValue({
            fieldId: 'custrecord_lrc_lastmodifieddate',
            value: date
        });
        DataModificacao.save({
            ignoreMandatoryFields: true
        });
    }
    var afterSubmit = function (ctx) {
        log_1.default.error("Entrou", ctx.newRecord);
        var record = ctx.newRecord;
        if (ctx.type == ctx.UserEventType.EDIT) { //caso conta bancária está sendo editada
            if (record.type == 'customrecord_enl_entity_bank_details') {
                var dataModificacao = search_1.default.create({
                    type: "customrecord_lrc_conta_data_modificacao",
                    filters: [
                        ["custrecord_lrc_conta_bacaria", "is", record.id],
                    ]
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                if (dataModificacao && dataModificacao[0]) { //existe registro para data de modificação
                    Editar_Data_Modificacao(dataModificacao[0].id);
                }
                else { //caso essa conta bancária não tenha um registro para data de modificação
                    Criar_Nova_Data(record);
                }
            }
        }
        else if (ctx.type == ctx.UserEventType.CREATE) { //caso nova conta
            //novo record de data de modificação deve ser criado
            if (record.type == 'customrecord_enl_entity_bank_details') {
                Criar_Nova_Data(record);
            }
        }
    };
    exports.afterSubmit = afterSubmit;
});
