/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* lrc_cancel_memo.ts
*
* Retornar valor de crédito do memorando de crédito.
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    var beforeSubmit = function (ctx) {
      
      
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT) {
            var newRecord = ctx.newRecord;
          	log.debug("-----","recordtype: "+newRecord.type);
          
            if (newRecord.type == 'customerpayment' || newRecord.type == 'vendorpayment' || newRecord.type == 'vendorpayment' || newRecord.type == 'invoice' || newRecord.type == 'vendorbill') {
                newRecord.setValue({
                    fieldId: 'custbody_rsc_gesplan_lastmodifdate_dt',
                    value: new Date()
                });
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
