/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = void 0;
    log_1 = __importDefault(log_1);
    exports.afterSubmit = function (ctx) {
        log_1.default.error("Simulação de um script userEvent", "sim");
    };
});
