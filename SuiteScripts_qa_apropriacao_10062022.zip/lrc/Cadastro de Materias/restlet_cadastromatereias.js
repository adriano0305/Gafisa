/**
* @NAPIVersion 2.0
* @NScriptType Restlet
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record"], function (require, exports, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.post = exports.delete = void 0;
    record_1 = __importDefault(record_1);
    var del = function (ctx) {
        var type = ctx.type;
        var id = ctx.id;
        return {
            success: true
        };
    };
    exports.delete = del;
    var post = function (ctx) {
        var items = ctx.items;
        var objRetorno = {};
        var objInventoryItem = {};
        var objNonInventoryItem = {};
        var objServiceItem = {};
        var arrayInventoryItem = [];
        var arrayNonInventoryItem = [];
        var arrayServiceItem = [];
        if (items) {
            try {
                Object.keys(items).forEach(function (itemType) {
                    items[itemType].forEach(function (item) {
                        if (itemType == 'inventoryitem') {
                            if (item.itemid) {
                                objInventoryItem['itemid'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['itemid'] = 'Status: Falta argumento "itemid".';
                            }
                            if (item.upccode) {
                                objInventoryItem['upccode'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['upccode'] = 'Status: Falta argumento "upccode".';
                            }
                            if (item.displayname) {
                                objInventoryItem['displayname'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['displayname'] = 'Status: Falta argumento "displayname".';
                            }
                            if (item.vendorname) {
                                objInventoryItem['vendorname'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['vendorname'] = 'Status: Falta argumento "vendorname".';
                            }
                            if (item.unitstype) {
                                objInventoryItem['unitstype'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['unitstype'] = 'Status: Falta argumento "unitstype".';
                            }
                            if (item.stockunit) {
                                objInventoryItem['stockunit'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['stockunit'] = 'Status: Falta argumento "stockunit".';
                            }
                            if (item.purchaseunit) {
                                objInventoryItem['purchaseunit'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['purchaseunit'] = 'Status: Falta argumento "purchaseunit".';
                            }
                            if (item.saleunit) {
                                objInventoryItem['saleunit'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['saleunit'] = 'Status: Falta argumento "saleunit".';
                            }
                            if (item.parent) {
                                objInventoryItem['parent'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['parent'] = 'Status: Falta argumento "parent".';
                            }
                            if (item.subsidiary) {
                                objInventoryItem['subsidiary'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['subsidiary'] = 'Status: Falta argumento "subsidiary".';
                            }
                            if (item.includechildren == false || item.includechildren == true) {
                                objInventoryItem['includechildren'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['includechildren'] = 'Status: Falta argumento "includechildren".';
                            }
                            if (item.department) {
                                objInventoryItem['department'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['department'] = 'Status: Falta argumento "department".';
                            }
                            if (item.class) {
                                objInventoryItem['class'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['class'] = 'Status: Falta argumento "class".';
                            }
                            if (item.location) {
                                objInventoryItem['location'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['location'] = 'Status: Falta argumento "location".';
                            }
                            if (item.cogsaccount) {
                                objInventoryItem['cogsaccount'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['cogsaccount'] = 'Status: Falta argumento "cogsaccount".';
                            }
                            if (item.intercocogsaccount) {
                                objInventoryItem['intercocogsaccount'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['intercocogsaccount'] = 'Status: Falta argumento "intercocogsaccount".';
                            }
                            if (item.assetaccount) {
                                objInventoryItem['assetaccount'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['assetaccount'] = 'Status: Falta argumento "assetaccount".';
                            }
                            if (item.incomeaccount) {
                                objInventoryItem['incomeaccount'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['incomeaccount'] = 'Status: Falta argumento "incomeaccount".';
                            }
                            if (item.intercoincomeaccount) {
                                objInventoryItem['intercoincomeaccount'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['intercoincomeaccount'] = 'Status: Falta argumento "intercoincomeaccount".';
                            }
                            if (item.gainlossaccount) {
                                objInventoryItem['gainlossaccount'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['gainlossaccount'] = 'Status: Falta argumento "gainlossaccount".';
                            }
                            if (item.billpricevarianceacct) {
                                objInventoryItem['billpricevarianceacct'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['billpricevarianceacct'] = 'Status: Falta argumento "billpricevarianceacct".';
                            }
                            if (item.billqtyvarianceacct) {
                                objInventoryItem['billqtyvarianceacct'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['billqtyvarianceacct'] = 'Status: Falta argumento "billqtyvarianceacct".';
                            }
                            if (item.billexchratevarianceacct) {
                                objInventoryItem['billexchratevarianceacct'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['billexchratevarianceacct'] = 'Status: Falta argumento "billexchratevarianceacct".';
                            }
                            if (item.custreturnvarianceaccount) {
                                objInventoryItem['custreturnvarianceaccount'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['custreturnvarianceaccount'] = 'Status: Falta argumento "custreturnvarianceaccount".';
                            }
                            if (item.vendreturnvarianceaccount) {
                                objInventoryItem['vendreturnvarianceaccount'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['vendreturnvarianceaccount'] = 'Status: Falta argumento "vendreturnvarianceaccount".';
                            }
                            if (item.dropshipexpenseaccount) {
                                objInventoryItem['dropshipexpenseaccount'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['dropshipexpenseaccount'] = 'Status: Falta argumento "dropshipexpenseaccount".';
                            }
                            if (item.taxschedule) {
                                objInventoryItem['taxschedule'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['taxschedule'] = 'Status: Falta argumento "taxschedule".';
                            }
                            if (item.custitem_enl_taxorigin) {
                                objInventoryItem['custitem_enl_taxorigin'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['custitem_enl_taxorigin'] = 'Status: Falta argumento "custitem_enl_taxorigin".';
                            }
                            if (item.custitem_enl_ncmitem) {
                                objInventoryItem['custitem_enl_ncmitem'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['custitem_enl_ncmitem'] = 'Status: Falta argumento "custitem_enl_ncmitem".';
                            }
                            if (item.custitem_enl_it_taxgroup) {
                                objInventoryItem['custitem_enl_it_taxgroup'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['custitem_enl_it_taxgroup'] = 'Status: Falta argumento "custitem_enl_it_taxgroup".';
                            }
                            if (item.billqtyvarianceacct) {
                                objInventoryItem['custitem_enl_cest'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['custitem_enl_cest'] = 'Status: Falta argumento "custitem_enl_cest".';
                            }
                            if (item.billqtyvarianceacct) {
                                objInventoryItem['custitem_enl_producttype'] = 'Status: Ok';
                            }
                            else {
                                objInventoryItem['custitem_enl_producttype'] = 'Status: Falta argumento "custitem_enl_producttype".';
                            }
                            arrayInventoryItem.push(objInventoryItem);
                        }
                        if (itemType == 'noninventoryitem') {
                            if (item.itemid) {
                                objNonInventoryItem['itemid'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['itemid'] = 'Status: Falta argumento "itemid".';
                            }
                            if (item.displayname) {
                                objNonInventoryItem['displayname'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['displayname'] = 'Status: Falta argumento "displayname".';
                            }
                            if (item.vendorname) {
                                objNonInventoryItem['vendorname'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['vendorname'] = 'Status: Falta argumento "vendorname".';
                            }
                            if (item.unitstype) {
                                objNonInventoryItem['unitstype'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['unitstype'] = 'Status: Falta argumento "unitstype".';
                            }
                            if (item.subsidiary) {
                                objNonInventoryItem['subsidiary'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['subsidiary'] = 'Status: Falta argumento "subsidiary".';
                            }
                            if (item.includechildren == false || item.includechildren == true) {
                                objNonInventoryItem['includechildren'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['includechildren'] = 'Status: Falta argumento "includechildren".';
                            }
                            if (item.department) {
                                objNonInventoryItem['department'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['department'] = 'Status: Falta argumento "department".';
                            }
                            if (item.class) {
                                objNonInventoryItem['class'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['class'] = 'Status: Falta argumento "class".';
                            }
                            if (item.location) {
                                objNonInventoryItem['location'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['location'] = 'Status: Falta argumento "location".';
                            }
                            if (item.expenseaccount) {
                                objNonInventoryItem['expenseaccount'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['expenseaccount'] = 'Status: Falta argumento "expenseaccount".';
                            }
                            if (item.currency) {
                                objNonInventoryItem['currency'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['currency'] = 'Status: Falta argumento "currency".';
                            }
                            if (item.billexchratevarianceacct) {
                                objNonInventoryItem['billexchratevarianceacct'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['billexchratevarianceacct'] = 'Status: Falta argumento "billexchratevarianceacct".';
                            }
                            if (item.billpricevarianceacct) {
                                objNonInventoryItem['billpricevarianceacct'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['billpricevarianceacct'] = 'Status: Falta argumento "billpricevarianceacct".';
                            }
                            if (item.billqtyvarianceacct) {
                                objNonInventoryItem['billqtyvarianceacct'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['billqtyvarianceacct'] = 'Status: Falta argumento "billqtyvarianceacct".';
                            }
                            if (item.taxschedule) {
                                objNonInventoryItem['taxschedule'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['taxschedule'] = 'Status: Falta argumento "taxschedule".';
                            }
                            if (item.custitem_enl_taxorigin) {
                                objNonInventoryItem['custitem_enl_taxorigin'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['custitem_enl_taxorigin'] = 'Status: Falta argumento "custitem_enl_taxorigin".';
                            }
                            if (item.custitem_enl_ncmitem) {
                                objNonInventoryItem['custitem_enl_ncmitem'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['custitem_enl_ncmitem'] = 'Status: Falta argumento "custitem_enl_ncmitem".';
                            }
                            if (item.custitem_enl_it_taxgroup) {
                                objNonInventoryItem['custitem_enl_it_taxgroup'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['custitem_enl_it_taxgroup'] = 'Status: Falta argumento "custitem_enl_it_taxgroup".';
                            }
                            if (item.custitem_enl_cest) {
                                objNonInventoryItem['custitem_enl_cest'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['custitem_enl_cest'] = 'Status: Falta argumento "custitem_enl_cest".';
                            }
                            if (item.custitem_enl_producttype) {
                                objNonInventoryItem['custitem_enl_cest'] = 'Status: Ok';
                            }
                            else {
                                objNonInventoryItem['custitem_enl_producttype'] = 'Status: Falta argumento "custitem_enl_producttype".';
                            }
                            arrayNonInventoryItem.push(objNonInventoryItem);
                        }
                        if (itemType == 'serviceitem') {
                            if (item.itemid) {
                                objServiceItem['itemid'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['itemid'] = 'Status: Falta argumento "itemid".';
                            }
                            if (item.displayname) {
                                objServiceItem['displayname'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['displayname'] = 'Status: Falta argumento "displayname".';
                            }
                            if (item.vendorname) {
                                objServiceItem['vendorname'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['vendorname'] = 'Status: Falta argumento "vendorname".';
                            }
                            if (item.unitstype) {
                                objServiceItem['unitstype'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['unitstype'] = 'Status: Falta argumento "unitstype".';
                            }
                            if (item.purchaseunit) {
                                objServiceItem['purchaseunit'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['purchaseunit'] = 'Status: Falta argumento "purchaseunit".';
                            }
                            if (item.itemid) {
                                objServiceItem['subsidiary'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['subsidiary'] = 'Status: Falta argumento "subsidiary".';
                            }
                            if (item.includechildren == false || item.includechildren == true) {
                                objServiceItem['includechildren'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['includechildren'] = 'Status: Falta argumento "includechildren".';
                            }
                            if (item.department) {
                                objServiceItem['department'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['department'] = 'Status: Falta argumento "department".';
                            }
                            if (item.class) {
                                objServiceItem['class'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['class'] = 'Status: Falta argumento "class".';
                            }
                            if (item.location) {
                                objServiceItem['location'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['location'] = 'Status: Falta argumento "location".';
                            }
                            if (item.expenseaccount) {
                                objServiceItem['expenseaccount'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['expenseaccount'] = 'Status: Falta argumento "expenseaccount".';
                            }
                            if (item.currency) {
                                objServiceItem['currency'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['currency'] = 'Status: Falta argumento "currency".';
                            }
                            if (item.billexchratevarianceacct) {
                                objServiceItem['billexchratevarianceacct'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['billexchratevarianceacct'] = 'Status: Falta argumento "billexchratevarianceacct".';
                            }
                            if (item.billpricevarianceacct) {
                                objServiceItem['billpricevarianceacct'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['billpricevarianceacct'] = 'Status: Falta argumento "billpricevarianceacct".';
                            }
                            if (item.billqtyvarianceacct) {
                                objServiceItem['billqtyvarianceacct'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['billqtyvarianceacct'] = 'Status: Falta argumento "billqtyvarianceacct".';
                            }
                            if (item.taxschedule) {
                                objServiceItem['taxschedule'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['taxschedule'] = 'Status: Falta argumento "taxschedule".';
                            }
                            if (item.custitem_enl_it_taxgroup) {
                                objServiceItem['custitem_enl_it_taxgroup'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['custitem_enl_it_taxgroup'] = 'Status: Falta argumento "custitem_enl_it_taxgroup".';
                            }
                            if (item.custitem_enl_codigodeservico) {
                                objServiceItem['custitem_enl_codigodeservico'] = 'Status: Ok';
                            }
                            else {
                                objServiceItem['custitem_enl_codigodeservico'] = 'Status: Falta argumento "custitem_enl_codigodeservico".';
                            }
                            arrayServiceItem.push(objServiceItem);
                        }
                        var json = JSON.stringify(item);
                        var logItem = record_1.default.create({
                            type: 'customrecord_lrc_log_item'
                        });
                        logItem.setValue({
                            fieldId: 'custrecord_lrc_json_item',
                            value: json
                        });
                        logItem.setValue({
                            fieldId: 'custrecord_lrc_tipo_item',
                            value: itemType
                        });
                        logItem.setValue({
                            fieldId: 'custrecord_lrc_processado_item',
                            value: false
                        });
                        logItem.save({
                            ignoreMandatoryFields: true
                        });
                    });
                });
                objRetorno['InventoryItem'] = arrayInventoryItem;
                objRetorno['NonInventoryItem'] = arrayNonInventoryItem;
                objRetorno['ServiceItem'] = arrayServiceItem;
            }
            catch (err) {
                throw Error("Erro ao criar o registro Log de Itens: " + err);
            }
            return objRetorno;
        }
        else {
            return "Não há nenhum item no json para ser cadastrado.";
        }
    };
    exports.post = post;
});
