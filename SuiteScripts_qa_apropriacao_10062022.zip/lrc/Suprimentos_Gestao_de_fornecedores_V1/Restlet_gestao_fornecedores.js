/**
* @NAPIVersion 2.0
* @NScriptType Restlet
* restlet_gestao_fornecedores.ts
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/record", "N/search"], function (require, exports, Log, record_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.post = void 0;
    Log = __importStar(Log);
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    var post = function (ctx) {
        var objRetorno = {};
        var fornecedores = [];
        if (ctx.hasOwnProperty('vendor')) {
            fornecedores = ctx.vendor;
            var i_1 = 0;
            var camposVazios_1 = [];
            fornecedores.forEach(function (fornecedor) {
                objRetorno['vendor' + i_1] = {};
                camposVazios_1 = [];
                Object.keys(fornecedor).forEach(function (fornecedorKey) {
                    if (fornecedorKey == 'Endereco') {
                        Object.keys(fornecedor['Endereco']).forEach(function (enderecoKey) {
                            var enderecoValue = fornecedor['Endereco'][enderecoKey];
                            if (!enderecoValue && enderecoValue != false && enderecoValue != 0) {
                                camposVazios_1.push(enderecoKey);
                            }
                        });
                    }
                    else if (!fornecedor[fornecedorKey] && fornecedor[fornecedorKey] !== false && fornecedor[fornecedorKey] !== 0) {
                        camposVazios_1.push(fornecedorKey);
                    }
                });
                Log.error('camposVazios', camposVazios_1);
                if (camposVazios_1.length > 0) {
                    objRetorno['vendor' + i_1].mensagem = 'Falta os argumentos ' + JSON.stringify(camposVazios_1) + '. Favor verifica-los e tentar novamente.';
                    i_1++;
                    return;
                    // throw objRetorno;
                }
                Log.error('teste', 'teste');
                var fornecedores = fornecedor.Fornecedor;
                var idFornecedor;
                Log.error('json', fornecedores);
                // Log.error('fornecedorId', fornecedores['Id']);
                var searchVendor = search_1.default.create({
                    type: 'vendor',
                    filters: [
                        ['entityid', 'IS', fornecedor['Fornecedor']]
                    ]
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                Log.error('searchVendor[0]', searchVendor[0]);
                if (searchVendor[0]) {
                    if (idFornecedor = String(searchVendor[0].id)) {
                        var vendorRecord = record_1.default.load({
                            type: 'vendor',
                            id: searchVendor[0].id
                        });
                        vendorRecord.setValue({
                            fieldId: 'altname',
                            value: fornecedor['Nome']
                        });
                        vendorRecord.setValue({
                            fieldId: 'isperson',
                            value: fornecedor['Tipo']
                        });
                        vendorRecord.setValue({
                            fieldId: 'companyname',
                            value: fornecedor['NomeEmpresa']
                        });
                        /* Nao atualizar subsidiaria. */
                        /*vendorRecord.setValue({
                            fieldId: 'subsidiary',
                            value: fornecedor['Subsidiaria']
                        });*/
                        vendorRecord.setValue({
                            fieldId: 'legalname',
                            value: fornecedor['RazaoSocial']
                        });
                        vendorRecord.setValue({
                            fieldId: 'currency',
                            value: fornecedor['Moeda']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_cnpjcpf',
                            value: fornecedor['CNPJ/CPF']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_ccmnum',
                            value: fornecedor['InscricaoMunicipal2']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_ienum',
                            value: fornecedor['InscricaoEstadual2']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_mei',
                            value: fornecedor['EmpreendedorIndividual']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_simplesnacional',
                            value: fornecedor['SimplesNacional']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_ent_operationtypeid',
                            value: fornecedor['TipoOperacao2']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_ent_documenttypeid',
                            value: fornecedor['TipoDocFical2']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_freighttype',
                            value: fornecedor['TipoFrete']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_statetaxpayer',
                            value: fornecedor['ContribuinteICMS']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_ent_activitysector',
                            value: fornecedores['SetorAtividade2']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_entitytype',
                            value: fornecedor['EntityType']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_enl_suframaid',
                            value: fornecedor['Suframa']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_avlr_pisfopag',
                            value: fornecedor['PisSobreFolhaPagamento']
                        });
                        vendorRecord.setValue({
                            fieldId: 'custentity_avlr_subjectpayrolltaxreliefg',
                            value: fornecedor['SujeitoDesoneracaoFolha']
                        });
                        try {
                            var idVendor = vendorRecord.save({
                                ignoreMandatoryFields: true
                            });
                            objRetorno['vendor' + i_1].mensagem = "Cadastro modificado com sucesso (" + idVendor + ")";
                          objRetorno['vendor' +i_1].idNetSuite = idVendor;
                        }
                        catch (err) {
                            objRetorno['vendor' + i_1].mensagem = 'Erro ao salvar registro. Verifique os campos obrigatórios.';
                          objRetorno['vendor' + i_1].details = err;
                            // throw objRetorno;
                        }
                    }
                }
                else {
                    Log.error("Fornecedor", fornecedor);
                    var novoFornecedor_1 = record_1.default.create({
                        type: record_1.default.Type.VENDOR,
                        isDynamic: true
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'entityid',
                        value: fornecedor['Fornecedor']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'altname',
                        value: fornecedor['Nome']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'isperson',
                        value: fornecedor['Tipo']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'companyname',
                        value: fornecedor['NomeEmpresa']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'subsidiary',
                        value: fornecedor['Subsidiaria']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'legalname',
                        value: fornecedor['RazaoSocial']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'currency',
                        value: fornecedor['Moeda']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_cnpjcpf',
                        value: fornecedor['CNPJ/CPF']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_ccmnum',
                        value: fornecedor['InscricaoMunicipal2']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_ienum',
                        value: fornecedor['InscricaoEstadual2']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_mei',
                        value: fornecedor['EmpreendedorIndividual']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_simplesnacional',
                        value: fornecedor['SimplesNacional']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_ent_operationtypeid',
                        value: fornecedor['TipoOperacao2']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_ent_documenttypeid',
                        value: fornecedor['TipoDocFical2']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_freighttype',
                        value: fornecedor['TipoFrete']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_statetaxpayer',
                        value: fornecedor['ContribuinteICMS']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_ent_activitysector',
                        value: fornecedor['SetorAtividade2']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_entitytype',
                        value: fornecedor['EntityType']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_enl_suframaid',
                        value: fornecedor['Suframa']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_avlr_pisfopag',
                        value: fornecedor['PisSobreFolhaPagamento']
                    });
                    novoFornecedor_1.setValue({
                        fieldId: 'custentity_avlr_subjectpayrolltaxreliefg',
                        value: fornecedor['SujeitoDesoneracaoFolha']
                    });
                    var Endereco = fornecedor.Endereco;
                    Log.error("Endereco", Endereco);
                    if (Endereco) {
                        Endereco.forEach(function (endereco) {
                            var AddressSubrecord = novoFornecedor_1.getCurrentSublistSubrecord({
                                sublistId: 'addressbook',
                                fieldId: 'addressbookaddress',
                            });
                            Log.error('AddressSubrecord', AddressSubrecord);
                            AddressSubrecord.setValue({
                                fieldId: 'country',
                                value: String(endereco['Pais'])
                            });
                            AddressSubrecord.setValue({
                                fieldId: 'addr1',
                                value: String(endereco['Endereco1'])
                            });
                            AddressSubrecord.setValue({
                                fieldId: 'addr2',
                                value: String(endereco['Endereco2'])
                            });
                            AddressSubrecord.setValue({
                                fieldId: 'city',
                                value: String(endereco['Cidade'])
                            });
                            AddressSubrecord.setValue({
                                fieldId: 'state',
                                value: String(endereco['Estado'])
                            });
                            AddressSubrecord.setValue({
                                fieldId: 'zip',
                                value: String(endereco['Zip'])
                            });
                            novoFornecedor_1.commitLine({
                                sublistId: 'addressbook'
                            });
                        });
                    }
                    try {
                        var idVendor = novoFornecedor_1.save({
                            ignoreMandatoryFields: true
                        });
                        objRetorno['vendor' + i_1].mensagem = "Cadastro efetuado com sucesso (" + idVendor + ")";
                      	objRetorno['vendor' +i_1].idNetSuite = idVendor;
                    }
                    catch (err) {
                      objRetorno['vendor' + i_1].mensagem = 'Erro ao salvar registro. Verifique os campos obrigatórios.';
                                                objRetorno['vendor' + i_1].details = err;
                    }
                }
                i_1++;
            });
            return objRetorno;
        }
        else {
            return 'Nenhum fornecedor encontrado.';
            // throw objRetorno;
        }
    };
    exports.post = post;
});
