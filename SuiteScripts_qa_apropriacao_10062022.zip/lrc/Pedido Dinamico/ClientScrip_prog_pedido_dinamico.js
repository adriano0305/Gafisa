/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* TestClientSublist.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/search"], function (require, exports, record_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = exports.pageInit = void 0;
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    var pageInit = function (ctx) {
        var currRecord = ctx.currentRecord;
        var item = currRecord.getValue('custrecord_lrc_item_prog_dinamic');
        var tipoPedido = currRecord.getValue('custrecord_lrc_tipo_pedido');
        var buscaSalvaId = currRecord.getValue('custrecord_lrc_buscasalva');
        var fator = currRecord.getValue('custrecord_lrc_fator_pedido');
        var descricao = currRecord.getValue('custrecord_lrc_descricao');
        if (buscaSalvaId) {
            var buscaSalva = search_1.default.load({
                id: String(buscaSalvaId)
            });
            var valorColName_1 = '';
            var valorColJoin_1 = '';
            var entidadeColName_1 = '';
            var entidadeColJoin_1 = '';
            var colunas = buscaSalva.columns;
            console.log(colunas);
            for (var i = 0; i < colunas.length; i++) {
                if (colunas[i].label.toLowerCase() == 'valor') {
                    valorColName_1 = colunas[i].name;
                    valorColJoin_1 = colunas[i].join;
                    console.log(valorColName_1);
                }
                if (colunas[i].label.toLowerCase() == 'entidade') {
                    entidadeColName_1 = colunas[i].name;
                    entidadeColJoin_1 = colunas[i].join;
                    console.log(entidadeColName_1);
                }
            }
            currRecord.selectLine({
                sublistId: 'custpage_lrc_item_sublist',
                line: 0
            });
            buscaSalva.run().each(function (result) {
                console.log('run entrou');
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_item',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: item
                });
                if (tipoPedido == 2) {
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_fornecedor',
                        sublistId: 'custpage_lrc_item_sublist',
                        value: result.getValue({ name: entidadeColName_1, join: entidadeColJoin_1 })
                    });
                }
                else {
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_cliente',
                        sublistId: 'custpage_lrc_item_sublist',
                        value: result.getValue({ name: entidadeColName_1, join: entidadeColJoin_1 })
                    });
                }
                console.log(result.getValue(entidadeColName_1));
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_quantidade',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: 1
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_descricao',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: descricao
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_valor',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: result.getValue({ name: valorColName_1, join: valorColJoin_1 })
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_fator',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: fator
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_valor_transacao',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: Number(fator) * Number(result.getValue({ name: valorColName_1, join: valorColJoin_1 }))
                });
                currRecord.commitLine({
                    sublistId: 'custpage_lrc_item_sublist'
                });
                return true;
            });
        }
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var fieldId = ctx.fieldId;
        var currRecord = ctx.currentRecord;
        var descricao = currRecord.getValue('custrecord_lrc_descricao');
        var cliente = currRecord.getValue('custrecord_lrc_cliente');
        var buscaSalvaId = currRecord.getValue('custrecord_lrc_buscasalva');
        var tipoPedido = currRecord.getValue('custrecord_lrc_tipo_pedido');
        var item = currRecord.getValue('custrecord_lrc_item_prog_dinamic');
        var fator = currRecord.getValue('custrecord_lrc_fator_pedido');
        var subsidiaria = currRecord.getValue('custrecord_lrc_subsidiaria');
        var localidade = currRecord.getValue('custrecord_lrc_localidade');
        var qtLinhas = currRecord.getLineCount({
            sublistId: 'custpage_lrc_item_sublist'
        });
        if (fieldId == 'custrecord_lrc_fator_pedido') {
            for (var i = 0; i < qtLinhas; i++) {
                currRecord.selectLine({
                    line: i,
                    sublistId: 'custpage_lrc_item_sublist'
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_fator',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: fator
                });
                var valor = currRecord.getCurrentSublistValue({
                    sublistId: 'custpage_lrc_item_sublist',
                    fieldId: 'custpage_lrc_valor'
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_valor_transacao',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: Number(fator) * Number(valor)
                });
            }
        }
        if (fieldId == 'custrecord_lrc_descricao') {
            for (var i = 0; i < qtLinhas; i++) {
                currRecord.selectLine({
                    line: i,
                    sublistId: 'custpage_lrc_item_sublist'
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_descricao',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: descricao
                });
            }
        }
        if (fieldId == 'custrecord_lrc_item_prog_dinamic') {
            for (var i = 0; i < qtLinhas; i++) {
                currRecord.selectLine({
                    line: i,
                    sublistId: 'custpage_lrc_item_sublist'
                });
                currRecord.setCurrentSublistValue({
                    fieldId: 'custpage_lrc_item',
                    sublistId: 'custpage_lrc_item_sublist',
                    value: item
                });
            }
        }
        if (fieldId == 'custrecord_lrc_subsidiaria') {
            if (!cliente) {
                alert('Selecione um cliente antes de selecionar uma subsidiaria');
                currRecord.setValue({
                    fieldId: 'custrecord_lrc_subsidiaria',
                    value: '',
                    ignoreFieldChange: true
                });
            }
            else {
                var searchCliente = search_1.default.create({
                    type: 'customer',
                    filters: ['internalid', 'IS', cliente]
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                var recordCliente = record_1.default.load({
                    type: 'customer',
                    id: searchCliente[0].id
                });
                var qtSubsdiary = recordCliente.getLineCount({
                    sublistId: 'submachine'
                });
                var verificaSub = 0;
                for (var i = 0; i < qtSubsdiary; i++) {
                    var subsidiaryLine = recordCliente.getSublistValue({
                        sublistId: 'submachine',
                        fieldId: 'subsidiary',
                        line: i
                    });
                    if (subsidiaryLine == subsidiaria) {
                        verificaSub++;
                    }
                }
                if (verificaSub == 0) {
                    alert('Essa subsidiaria não existe no cliente escolhido');
                    currRecord.setValue({
                        fieldId: 'custrecord_lrc_subsidiaria',
                        value: '',
                        ignoreFieldChange: true
                    });
                }
            }
        }
        if (fieldId == 'custrecord_lrc_localidade') {
            if (!subsidiaria) {
                alert('Selecione uma subsidiaria antes de selecionar uma localidade');
                currRecord.setValue({
                    fieldId: 'custrecord_lrc_localidade',
                    value: '',
                    ignoreFieldChange: true
                });
            }
            else {
                var searchLocation = search_1.default.create({
                    type: 'location',
                    filters: ['internalId', 'IS', localidade],
                }).run().getRange({
                    start: 0,
                    end: 1
                });
                var localidadeRecord = record_1.default.load({
                    type: 'location',
                    id: searchLocation[0].id
                });
                var subLocalidade = localidadeRecord.getValue('subsidiary');
                if (subLocalidade != subsidiaria) {
                    alert('Está localidade não pertence a subsidiaria selecionada');
                    currRecord.setValue({
                        fieldId: 'custrecord_lrc_localidade',
                        value: '',
                        ignoreFieldChange: true
                    });
                }
            }
        }
        if (fieldId == 'custrecord_lrc_buscasalva') {
            var buscaSalva = search_1.default.load({
                id: String(buscaSalvaId)
            });
            var valorColName_2 = '';
            var valorColJoin_2 = '';
            var entidadeColName_2 = '';
            var entidadeColJoin_2 = '';
            var colunas = buscaSalva.columns;
            var verificaValor = 0;
            var verificaEntidade = 0;
            console.log(colunas);
            if (colunas) {
                for (var i = 0; i < colunas.length; i++) {
                    if (colunas[i].label.toLowerCase() == 'valor') {
                        verificaValor++;
                        valorColName_2 = colunas[i].name;
                        valorColJoin_2 = colunas[i].join;
                        console.log(valorColName_2);
                    }
                    if (colunas[i].label.toLowerCase() == 'entidade') {
                        verificaEntidade++;
                        if (colunas[i].name) {
                            entidadeColName_2 = colunas[i].name;
                        }
                        if (colunas[i].join) {
                            entidadeColJoin_2 = colunas[i].join;
                        }
                        console.log(entidadeColName_2);
                    }
                }
                if (verificaValor == 0) {
                    alert('Não existe o label "Valor" nessa busca salva');
                    return false;
                }
                if (verificaEntidade == 0) {
                    alert('Não existe o label "Entidade" nessa busca salva');
                    return false;
                }
                buscaSalva.run().each(function (result) {
                    console.log('run entrou');
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_item',
                        sublistId: 'custpage_lrc_item_sublist',
                        value: item
                    });
                    if (tipoPedido == 2) {
                        currRecord.setCurrentSublistValue({
                            fieldId: 'custpage_lrc_fornecedor',
                            sublistId: 'custpage_lrc_item_sublist',
                            value: result.getValue({ name: entidadeColName_2, join: entidadeColJoin_2 })
                        });
                    }
                    else {
                        currRecord.setCurrentSublistValue({
                            fieldId: 'custpage_lrc_cliente',
                            sublistId: 'custpage_lrc_item_sublist',
                            value: result.getValue({ name: entidadeColName_2, join: entidadeColJoin_2 })
                        });
                    }
                    console.log(result.getValue(entidadeColName_2));
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_quantidade',
                        sublistId: 'custpage_lrc_item_sublist',
                        value: 1
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_descricao',
                        sublistId: 'custpage_lrc_item_sublist',
                        value: descricao
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_valor',
                        sublistId: 'custpage_lrc_item_sublist',
                        value: result.getValue({ name: valorColName_2, join: valorColJoin_2 })
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_fator',
                        sublistId: 'custpage_lrc_item_sublist',
                        value: fator
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: 'custpage_lrc_valor_transacao',
                        sublistId: 'custpage_lrc_item_sublist',
                        value: Number(fator) * Number(result.getValue({ name: valorColName_2, join: valorColJoin_2 }))
                    });
                    currRecord.commitLine({
                        sublistId: 'custpage_lrc_item_sublist'
                    });
                    return true;
                });
            }
            else {
                alert('Não existem colunas nessa busca salva');
            }
        }
    };
    exports.fieldChanged = fieldChanged;
});
