/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * SuiteLet_imprimir_pdf.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/search", "./SuiteletPreviewSegment", "N/https", "N/url"], function (require, exports, log_1, search_1, SuiteletPreviewSegment_1, https_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    https_1 = __importDefault(https_1);
    url_1 = __importDefault(url_1);
    var onRequest = function (ctx) {
        log_1.default.error("SUITELET", "Chegou");
        if (ctx.request.method == 'GET') {
            var parameters = ctx.request.parameters;
            log_1.default.error('parameters', parameters);
            var translatedSymbols = [];
            var registroId;
            var filters = [];
            var tranid = parameters.tranid;
            if (tranid) {
                filters.push(["custrecord_lrc_layout_form", "IS", parameters.form]);
                filters.push("AND");
            }
            else {
                filters.push(["custrecord_lrc_layout_entryform", "IS", parameters.form]);
                filters.push("AND");
            }
            filters.push(['custrecord_lrc_layout_id_tipo_registro', 'IS', parameters.recordtype]);
            var registroPdf = search_1.default.create({
                type: 'customrecord_lrc_reg_layout_pdf',
                filters: filters,
                columns: [
                    'custrecord_lrc_layout_form',
                    'custrecord_lrc_layout_entryform',
                    'internalid'
                ]
            }).run().getRange({
                start: 0,
                end: 1
            });
            log_1.default.error("registroPDF", registroPdf);
            if (!registroPdf[0]) {
                throw Error("Não foi encontrado nenhum registro de layout relacionado");
            }
            registroId = registroPdf[0].getValue('internalid');
            log_1.default.error("LayoutPDF", registroId);
            log_1.default.error("SuiteletElse", "Chegou");
            var layoutId, segmento = "";
            log_1.default.error("Olha", segmento);
            search_1.default.create({
                type: 'customrecord_lrc_segmentos',
                filters: [
                    ['custrecord_lrc_layout_pdf_seg', 'IS', registroId]
                ],
                columns: [
                    'custrecord_lrc_segmento_seg',
                    'custrecord_lrc_descricao_seg',
                    'custrecord_lrc_layout_pdf_seg',
                    search_1.default.createColumn({
                        name: 'custrecord_lrc_ordem_seg',
                        sort: search_1.default.Sort.ASC
                    })
                ]
            }).run().each(function (result) {
                layoutId = result.getValue('custrecord_lrc_layout_pdf_seg');
                segmento += result.getValue('custrecord_lrc_segmento_seg') + "<br><br>";
                // segmento.push(result.getValue('custrecord_lrc_segmento_seg'));
                // segmento += segmento.concat(result.getValue('custrecord_lrc_segmento_seg'));
                return true;
            });
            log_1.default.error("Parameters.id", parameters.recordId);
            log_1.default.error("LayoutId", layoutId);
            log_1.default.error("Segmento", segmento);
            var symbols = SuiteletPreviewSegment_1.getLayoutSymbols(layoutId);
            log_1.default.error("SYmbols", symbols);
            log_1.default.error("SuiteletImprimir", "AntesFinalSymbols");
            var finalSymbols = SuiteletPreviewSegment_1.removeNotUsedSymbols(symbols, segmento);
            log_1.default.error("FinalsSymbols", finalSymbols);
            log_1.default.error("SuiteletImprimir", "AposFinalSymbols");
            var symbolsLength = finalSymbols.length;
            var nextIndex = 0;
            do {
                log_1.default.error("Repetição", "Chegou");
                log_1.default.error("RepetLayoutId", layoutId);
                log_1.default.error("ParametersLayoutId", parameters.layoutId);
                var url = url_1.default.resolveScript({
                    scriptId: "customscript_lrc_st_translate_symbols",
                    deploymentId: "customdeploy_lrc_st_translate_symbols",
                    params: {
                        symbols: JSON.stringify(finalSymbols.slice(nextIndex)),
                        layoutId: layoutId,
                        recordId: parameters.recordId,
                        allSymbols: '[]'
                    },
                    returnExternalUrl: true
                });
                log_1.default.error('url', url);
                var response = https_1.default.get({
                    url: url,
                });
                log_1.default.error("response", response.body);
                log_1.default.error("responsetype", typeof (response));
                log_1.default.error("response.code", response.code);
                if (response.code.toString().substring(0, 1) != "2") {
                    throw Error(response.body);
                }
                var bodyObj = JSON.parse(response.body);
                log_1.default.error('bodyJson', bodyObj);
                translatedSymbols = translatedSymbols.concat(JSON.parse(bodyObj.symbols));
                nextIndex = bodyObj.nextIndex;
            } while (nextIndex < symbolsLength);
            log_1.default.error("TranslatedSymbols", translatedSymbols);
            log_1.default.error("segmento", segmento);
            // var output = JSON.stringify(translateSegment(segmento, translatedSymbols));
            ctx.response.write({
                output: SuiteletPreviewSegment_1.translateSegment(segmento, translatedSymbols)
            });
        }
    };
    exports.onRequest = onRequest;
});
