/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * RestletTranslateSymbols.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/https", "N/url", "N/log", "N/search"], function (require, exports, https_1, url_1, log_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = exports.translateSegment = exports.removeNotUsedSymbols = exports.getLayoutSymbols = void 0;
    https_1 = __importDefault(https_1);
    url_1 = __importDefault(url_1);
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    function getLayoutSymbols(layout) {
        // var ordem;
        // let segmento = Search.create({
        //     type: 'customrecord_lrc_segmentos',
        //     filters:[
        //         ['custrecord_lrc_layout_pdf_seg', 'IS', layoutId]
        //     ],
        //     columns:[
        //         'custrecord_lrc_ordem_seg'
        //     ]
        // }).run().getRange({
        //     start: 0,
        //     end: 1
        // });
        // ordem = Number(segmento[0].getValue('custrecord_lrc_ordem_seg'));
        // Log.error("OrdemSegmento -->", ordem);
        // Log.error("TypeOfOrdem", typeof(ordem));
        /*
                Retorna um objeto do tipo:
            
                [
                    {
                        "symbol": String que representa o simbolo,
                        "type": recordType do simbolo,
                        "id": ID interno do simbolo no netsuite
                    },
                    {
                        "symbol": String que representa o simbolo,
                        "type": recordType do simbolo,
                        "id": ID interno do simbolo no netsuite
                    }
                
                ]
            
        */
        var finalSymbol = [];
        // Capturar simbolos do tipo "LRC @ Simbolo Formulario"
        log_1.default.error("LayoutId", layout);
        search_1.default.create({
            type: 'customrecord_lrc_simbolo_formulario',
            filters: [
                ['custrecord_lrc_simbolo_form_layout', 'IS', layout]
            ],
            columns: [
                'custrecord_lrc_simbolo_form'
            ]
        }).run().each(function (result) {
            var obj = {
                "symbol": result.getValue('custrecord_lrc_simbolo_form'),
                "type": "customrecord_lrc_simbolo_formulario",
                "id": result.id
            };
            log_1.default.error("obj1", obj);
            finalSymbol.push(obj);
            return true;
        });
        // Capturar simbolos do tipo "LRC @ Simbolo Campo"
        search_1.default.create({
            type: 'customrecord_lrc_simbolo_campo',
            filters: [
                ['custrecord_lrc_simbolo_campo_layout', 'IS', layout]
            ],
            columns: [
                'custrecord_lrc_simbolo_campo'
            ]
        }).run().each(function (result) {
            var obj = {
                "symbol": result.getValue('custrecord_lrc_simbolo_campo'),
                "type": "customrecord_lrc_simbolo_campo",
                "id": result.id
            };
            log_1.default.error("obj2", obj);
            finalSymbol.push(obj);
            return true;
        });
        // Capturar simbolos do tipo "LRC @ Simbolo Sublista"
        search_1.default.create({
            type: 'customrecord_lrc_simbolo_sublista',
            filters: [
                ['custrecord_lrc_layout', 'IS', layout]
            ],
            columns: [
                'custrecord_lrc_simbolo'
            ]
        }).run().each(function (result) {
            var obj = {
                "symbol": result.getValue('custrecord_lrc_simbolo'),
                "type": "customrecord_lrc_simbolo_sublista",
                "id": result.id
            };
            finalSymbol.push(obj);
            return true;
        });
        // Capturar simbolos do tipo "LRC @ Simbolo SuiteScript"
        search_1.default.create({
            type: 'customrecord_lrc_simbolo_suitescript',
            filters: [
                ['custrecord_lrc_simbolo_script_layout', 'IS', layout]
            ],
            columns: [
                'custrecord_lrc_script_simbolo'
            ]
        }).run().each(function (result) {
            var obj = {
                "symbol": result.getValue('custrecord_lrc_script_simbolo'),
                "type": "customrecord_lrc_simbolo_suitescript",
                "id": result.id
            };
            finalSymbol.push(obj);
            return true;
        });
        log_1.default.error("Preview", finalSymbol);
        return finalSymbol;
    }
    exports.getLayoutSymbols = getLayoutSymbols;
    function removeNotUsedSymbols(symbols, segment) {
        var newSymbols = [];
        if (segment) {
            symbols.forEach(function (symbol) {
                if (segment.indexOf(symbol.symbol) >= 0)
                    newSymbols.push(symbol);
            });
        }
        return newSymbols;
    }
    exports.removeNotUsedSymbols = removeNotUsedSymbols;
    function translateSegment(segment, translatedSymbols) {
        var newSegment = segment;
        log_1.default.error("translated", translatedSymbols);
        translatedSymbols.forEach(function (translatedSymbol) {
            log_1.default.error("translatedSymbol", translatedSymbol.symbol);
            log_1.default.error("translatedValue", translatedSymbol.value);
            var symbol = translatedSymbol.symbol;
            var value = translatedSymbol.value;
            if (typeof value == "object") {
                value = JSON.stringify(value);
            }
            newSegment = newSegment.split(symbol).join(value); // Troca todas as instancias do simbolo para o valor do simbolo
        });
        log_1.default.error("NewSegment", newSegment);
        return newSegment;
    }
    exports.translateSegment = translateSegment;
    var onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            /*
                Recebe um objeto da seguinte maneira:
                {
                    "segment": String que representa o segmento a ser traduzido
                    "layoutId": ID da instância do registro 'LRC @ Layout do PDF do Registro',
                    "recordId": ID do registro cuja impressão do segmento será visualizada,
                 
                }
            */
            /*
                Retorna uma string que representa o segmento com os símbolos traduzidos
            */
            var parameters = ctx.request.parameters;
            log_1.default.error('parameters', parameters);
            // Capture todos os simbolos disponiveis para o layout
            var symbols = removeNotUsedSymbols(getLayoutSymbols(parameters.layout), parameters.segment);
            log_1.default.error("symbols", symbols);
            var symbolsLength = symbols.length;
            var nextIndex = 0;
            var translatedSymbols = [];
            log_1.default.error("Preview_allSymbols", JSON.stringify(getLayoutSymbols(parameters.layout)));
            do {
                var url = url_1.default.resolveScript({
                    scriptId: "customscript_lrc_st_translate_symbols",
                    deploymentId: "customdeploy_lrc_st_translate_symbols",
                    params: {
                        symbols: JSON.stringify(symbols.slice(nextIndex)),
                        allSymbols: JSON.stringify(getLayoutSymbols(parameters.layout)),
                        layoutId: parameters.layout,
                        recordId: parameters.recordId
                    },
                    returnExternalUrl: true
                });
                log_1.default.error('url', url);
                var response = https_1.default.get({
                    url: url,
                });
                log_1.default.error("response", response);
                if (response.code.toString().substring(0, 1) != '2') {
                    throw Error(response.body);
                }
                var bodyObj = JSON.parse(response.body);
                log_1.default.error('bodyObj', bodyObj);
                translatedSymbols = translatedSymbols.concat(JSON.parse(bodyObj.symbols));
                nextIndex = bodyObj.nextIndex;
            } while (nextIndex < symbolsLength);
            log_1.default.error("translatedSymbols", translatedSymbols);
            log_1.default.error("Segment", parameters.segment);
            log_1.default.error("finalTranslate", translateSegment(parameters.segment, translatedSymbols));
            var valor = translateSegment(parameters.segment, translatedSymbols);
            log_1.default.error("obj", valor);
            log_1.default.error("typeofValor", typeof valor);
            JSON.stringify(valor);
            // JSON.parse(valor);
            log_1.default.error("obj", valor);
            ctx.response.write({
                output: translateSegment(parameters.segment, translatedSymbols)
            });
        }
    };
    exports.onRequest = onRequest;
});
