/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* Client_botoesTelaItem.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url"], function (require, exports, currentRecord_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.importar = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var importar = function () {
        var currentRecord = currentRecord_1.default.get();
        var doc = currentRecord.getValue('custpage_lrc_doc');
        if (doc) {
            var url = url_1.default.resolveScript({
                scriptId: 'customscript_lrc_criar_cobranca',
                deploymentId: 'customdeploy_lrc_criar_cobranca',
                params: {
                    doc: doc,
                }
            });
            console.log("doc:" + doc + "");
            window.location.replace(url);
        }
        else {
            alert('Não há documento para ser enviado.');
            return false;
        }
    };
    exports.importar = importar;
});
