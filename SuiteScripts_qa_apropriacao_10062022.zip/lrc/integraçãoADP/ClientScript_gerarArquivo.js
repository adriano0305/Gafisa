/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* Client_botoesTelaItem.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/log", "N/search", "N/url"], function (require, exports, currentRecord_1, log_1, search_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.exportar = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    url_1 = __importDefault(url_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var exportar = function () {
        var currentRecord = currentRecord_1.default.get();
        log_1.default.error('currentRecord', currentRecord);
        var lockupVendor = search_1.default.lookupFields({
            type: 'vendorbill',
            id: currentRecord.id,
            columns: [
                'entity',
                'transactionnumber',
                'account',
                'duedate'
            ]
        });
        var empresa = lockupVendor.entity[0].text;
        console.log(empresa);
        log_1.default.error('ClienteEmpresa', empresa);
        var nDocto = lockupVendor['transactionnumber'];
        var conta = lockupVendor.account[0].value;
        var entregar = lockupVendor['duedate'];
        var content = "{\n'vendorbill':[\n{\n'empresa': '" + empresa + "',\n'Nº Docto': '" + nDocto + "',\n'Centro/Divisão': '" + conta + "',\n'Nº Fornecedor': ' ',\n'Forma de Pagamento': ' ',\n'Vencto': '" + entregar + "'\n},\n]\n}";
        var url = url_1.default.resolveScript({
            scriptId: 'customscript_lrc_gerar_arquivo',
            deploymentId: 'customdeploy_lrc_gerar_arquivo',
            params: {
                content: content,
                nDocto: nDocto,
                id: currentRecord.id
            }
        });
        window.location.replace(url);
        alert('Arquivo exportado com sucesso.');
    };
    exports.exportar = exportar;
});
