/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_mudaCliente.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "./lib/parser", "N/log", "N/redirect", "N/runtime"], function (require, exports, record_1, parser_1, log_1, redirect_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    parser_1 = __importDefault(parser_1);
    log_1 = __importDefault(log_1);
    redirect_1 = __importDefault(redirect_1);
    runtime_1 = __importDefault(runtime_1);
    var onRequest = function (ctx) {
        if (ctx.request.method == 'GET') {
            var parameters = ctx.request.parameters;
            var doc = parameters.content;
            var parsedContent = parser_1.default.parseCSV(doc, ";");
            if (parsedContent.error) {
                throw Error(parsedContent.error);
            }
            var data = parsedContent.data;
            var tipoDocumentoFiscal_1 = runtime_1.default.getCurrentScript().getParameter({
                name: 'custscript_lrc_tipo_documento_fiscal'
            });
            var tipoOperação_1 = runtime_1.default.getCurrentScript().getParameter({
                name: 'custscript_lrc_tipo_oprecao'
            });
            var localidade_1 = runtime_1.default.getCurrentScript().getParameter({
                name: 'custscript_lrc_localidade'
            });
            var conta_1 = runtime_1.default.getCurrentScript().getParameter({
                name: 'custscript_lrc_conta'
            });
            var codigoImposto_1 = runtime_1.default.getCurrentScript().getParameter({
                name: 'custscript_lrc_codigo_de_imposto'
            });
            data.forEach(function (row) {
                var vendorbillRecord = record_1.default.create({
                    type: 'vendorbill'
                });
                vendorbillRecord.setValue({
                    fieldId: 'entity',
                    value: row.matrícula
                });
                log_1.default.error('entity', row['matrícula']);
                log_1.default.error('row', row);
                vendorbillRecord.setValue({
                    fieldId: 'account',
                    value: row.código,
                });
                log_1.default.error('account', row['código']);
                vendorbillRecord.setValue({
                    fieldId: 'subsidiary',
                    value: row.estabelecimento
                });
                log_1.default.error('subsidiaria', row['estabelecimento']);
                vendorbillRecord.setValue({
                    fieldId: 'custbody_rsc_projeto_obra_gasto_compra',
                    value: row.cr
                });
                vendorbillRecord.setSublistValue({
                    sublistId: 'expense',
                    fieldId: 'account',
                    line: 0,
                    value: conta_1
                });
                log_1.default.error('sublista account', conta_1);
                vendorbillRecord.setSublistValue({
                    sublistId: 'expense',
                    fieldId: 'taxcode',
                    line: 0,
                    value: codigoImposto_1
                });
                log_1.default.error('codigoImposto', codigoImposto_1);
                vendorbillRecord.setSublistValue({
                    sublistId: 'expense',
                    fieldId: 'amount',
                    value: row.valor,
                    line: 0
                });
                log_1.default.error('sublista amount', row['valor']);
                vendorbillRecord.setValue({
                    fieldId: 'custbody2',
                    value: row.descricao
                });
                vendorbillRecord.setValue({
                    fieldId: 'memo',
                    value: row.clas
                });
                vendorbillRecord.setValue({
                    fieldId: 'custbody_gaf_processtype',
                    value: row.processo
                });
                if (row.hora == 0) {
                    var newHora = new Date();
                    vendorbillRecord.setValue({
                        fieldId: 'trandate',
                        value: newHora
                    });
                }
                else {
                    var horaSeparada = row.hora.split('/');
                    var horaData = "" + horaSeparada[1] + '/' + horaSeparada[0] + '/' + horaSeparada[2];
                    log_1.default.error('horaData', horaData);
                    var hora = new Date(horaData);
                    vendorbillRecord.setValue({
                        fieldId: 'trandate',
                        value: hora
                    });
                    log_1.default.error('data', hora);
                }
                vendorbillRecord.setValue({
                    fieldId: 'custbody_enl_order_documenttype',
                    value: tipoDocumentoFiscal_1
                });
                log_1.default.error('tipoDocumentoFiscal', tipoDocumentoFiscal_1);
                vendorbillRecord.setValue({
                    fieldId: 'custbody_enl_operationtypeid',
                    value: tipoOperação_1
                });
                log_1.default.error('tipoOperação', tipoOperação_1);
                vendorbillRecord.setSublistValue({
                    sublistId: 'expense',
                    fieldId: 'location_display',
                    line: 0,
                    value: localidade_1
                });
                var vendorId = vendorbillRecord.save({
                    ignoreMandatoryFields: true
                });
                redirect_1.default.toRecord({
                    type: 'vendorbill',
                    id: vendorId
                });
            });
        }
    };
    exports.onRequest = onRequest;
});
