/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * SubmitContratoCompra.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord"], function (require, exports, currentRecord_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    currentRecord_1 = __importDefault(currentRecord_1);
    exports.pageInit = function () {
        var purchaseContractId = getUrlParameter('purchase_contract');
        if (purchaseContractId) {
            var currentRecord = currentRecord_1.default.get();
            currentRecord.setValue({
                fieldId: 'purchasecontract',
                value: purchaseContractId
            });
        }
    };
    var getUrlParameter = function getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1), sURLVariables = sPageURL.split('&'), sParameterName, i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return typeof sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
        return false;
    };
});
