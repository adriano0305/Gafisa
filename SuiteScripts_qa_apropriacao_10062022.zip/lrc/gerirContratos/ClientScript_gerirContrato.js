/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * SubmitContratoCompra.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/search", "N/currentRecord", "N/url", "N/runtime"], function (require, exports, record_1, search_1, currentRecord_1, url_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    runtime_1 = __importDefault(runtime_1);
    exports.fieldChanged = function (ctx) {
        var contratoRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        var statusContratoJuridico = contratoRecord.getField({
            fieldId: 'custbody_lrc_status'
        });
        // Modificação no campo "Status DOCUSIGN" 
        if (fieldId === 'custbody_lrc_status_docusign') {
            var statusParametrizado = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_status_aprovado' });
            var contratoJuridicoId = contratoRecord.getValue('custbody_lrc_contrato_juridico');
            var statusEnvelope = '';
            if (contratoJuridicoId)
                statusEnvelope = exports.getStatusEnvelope(String(contratoJuridicoId));
            if (statusEnvelope === statusParametrizado) {
                statusContratoJuridico.isDisabled = false;
            }
            else if (!statusEnvelope) {
                contratoRecord.setValue({
                    fieldId: 'custbody_lrc_status',
                    value: 1
                });
                statusContratoJuridico.isDisabled = true;
            }
        }
        // Modificação no campo "Contrato Jurídico"
        else if (fieldId === 'custbody_lrc_contrato_juridico') {
            var contratoJuridicoId = contratoRecord.getValue('custbody_lrc_contrato_juridico');
            if (contratoJuridicoId) {
                contratoRecord.setValue({
                    fieldId: 'custbody_lrc_status_docusign',
                    value: exports.getStatusEnvelope(String(contratoJuridicoId))
                });
            }
            else { // Caso remova o Contrato Jurídico
                contratoRecord.setValue({
                    fieldId: 'custbody_lrc_status_docusign',
                    value: ''
                });
            }
        }
    };
    exports.getStatusEnvelope = function (contratoJuridicoId) {
        var contratoJuridico = search_1.default.create({
            type: 'customrecord_lrc_contrato_juridico',
            filters: [
                ['internalid', 'anyof', contratoJuridicoId]
            ],
            columns: [
                'custrecord_lrc_contract_envelope.custrecord_lrc_env_status'
            ]
        }).run().getRange({
            start: 0,
            end: 1
        })[0];
        return contratoJuridico.getValue({
            join: 'custrecord_lrc_contract_envelope',
            name: 'custrecord_lrc_env_status'
        });
    };
    exports.openEndeavorSalesOrder = function () {
        var currentRecord = currentRecord_1.default.get();
        var contratoEmpreitadaId = currentRecord.getValue({
            fieldId: "id"
        });
        var purchaseOrder = record_1.default.create({
            type: record_1.default.Type.SALES_ORDER,
        });
        window.location.href = url_1.default.resolveRecord({
            recordId: purchaseOrder.id,
            recordType: record_1.default.Type.PURCHASE_ORDER.toString(),
            params: {
                endeavor_contract: contratoEmpreitadaId
            }
        });
    };
    exports.openSalesOrder = function () {
        var currentRecord = currentRecord_1.default.get();
        var contratoId = currentRecord.getValue({
            fieldId: "id"
        });
        var contratoFornecedor = currentRecord.getValue({
            fieldId: "entity"
        });
        var contratoSubsidiaria = currentRecord.getValue({
            fieldId: "subsidiary"
        });
        var purchaseOrder = record_1.default.create({
            type: record_1.default.Type.SALES_ORDER,
        });
        console.log(contratoFornecedor);
        window.location.href = url_1.default.resolveRecord({
            recordId: purchaseOrder.id,
            recordType: record_1.default.Type.PURCHASE_ORDER.toString(),
            params: {
                entity: contratoFornecedor,
                subsidiary: contratoSubsidiaria,
                purchase_contract: contratoId
            }
        });
    };
});
