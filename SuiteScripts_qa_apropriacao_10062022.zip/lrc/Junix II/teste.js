/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_mudaCliente.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record"], function (require, exports, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    var onRequest = function (ctx) {
        var cobrancaRecord = record_1.default.create({
            type: 'vendorbill',
        });
        cobrancaRecord.setValue({
            fieldId: 'entity',
            value: 15
        });
        cobrancaRecord.setValue({
            fieldId: 'account',
            value: 239
        });
        cobrancaRecord.setValue({
            fieldId: 'trandate',
            value: new Date()
        });
        cobrancaRecord.setValue({
            fieldId: 'subsidiary',
            value: 1
        });
        cobrancaRecord.setValue({
            fieldId: 'custbody_enl_operationtypeid',
            value: 15
        });
        cobrancaRecord.setValue({
            fieldId: 'custbody_enl_order_documenttype',
            value: 13
        });
        cobrancaRecord.setSublistValue({
            fieldId: 'account',
            line: 0,
            sublistId: 'expense',
            value: 220
        });
        cobrancaRecord.setSublistValue({
            fieldId: 'amount',
            sublistId: 'expense',
            line: 0,
            value: 1000
        });
        cobrancaRecord.setSublistValue({
            fieldId: 'taxcode',
            sublistId: 'expense',
            line: 0,
            value: 5
        });
        cobrancaRecord.save({
            ignoreMandatoryFields: true
        });
    };
    exports.onRequest = onRequest;
});
