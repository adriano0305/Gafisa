/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
*
*
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log", "N/record", "./envioApi.js"], function (require, exports, search_1, log_1, record_1, envioApi_js_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    envioApi_js_1 = __importDefault(envioApi_js_1);
    var getInputData = function () {
        return search_1.default.create({
            type: 'invoice',
            filters: [
                ['custbody_rsc_status_contrato', 'IS', '2'],
                'AND',
                ['custbody_lrc_fatura_principal', 'ANYOF', '@NONE@'],
                'AND',
                ['internalid', 'IS', ''],
                'AND',
                ['custbody_lrc_enviado_para_junix', 'IS', 'F']
            ],
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var req = JSON.parse(ctx.value);
        var invoiceRecord = record_1.default.load({
            type: 'invoice',
            id: req.id
        });
        var clienteFatura = record_1.default.load({
            type: 'customer',
            id: invoiceRecord.getValue('entity'),
        });
        var objInvoice = {};
        var objCliente = {};
        var arrayParcelas = [];
        var objParcelas = {};
        search_1.default.create({
            type: 'invoice',
            filters: ['custbody_lrc_fatura_principal', 'IS', req.id]
        }).run().each(function (result) {
            var recordParcela = record_1.default.load({
                type: 'invoice',
                id: result.id
            });
            var objSaldoDevedor = {};
            objParcelas['numeroParcela'] = recordParcela.getValue('internalid');
            objParcelas['tipoParcela'] = recordParcela.getValue('custbodyrsc_tpparc');
            objParcelas['data'] = recordParcela.getValue('custbodyrsc_tpparc');
            objParcelas['dataPagamento'] = recordParcela.getValue('duedate');
            objParcelas['valorParcela'] = recordParcela.getValue('total');
            objParcelas['valorPago'] = recordParcela.getValue('amountpaid');
            objParcelas['valorEmAberto'] = recordParcela.getValue('amountremaining');
            objParcelas['valorParcelaPrincipal'] = recordParcela.getValue('total');
            objParcelas['valorDesconto'] = recordParcela.getValue('discounttotal');
            objParcelas['juros'] = recordParcela.getValue('custrecord_gst_instal_interestrate');
            objSaldoDevedor['numeroContrato'] = recordParcela.getValue('custbody_rsc_nrdocboleto');
            objSaldoDevedor['dataSaldo'] = new Date();
            objSaldoDevedor['valorSaldoAtualizado'] = invoiceRecord.getValue('total');
            objSaldoDevedor['valorVendaAtualizado'] = invoiceRecord.getValue('total');
            objSaldoDevedor['valorPago'] = '';
            objParcelas['SaldoDevedor'] = objSaldoDevedor;
            arrayParcelas.push(objParcelas);
            return true;
        });
        objCliente['Nome'] = clienteFatura.getValue('glommedname') || clienteFatura.getValue('companyname');
        objCliente['CPF_CNPJ'] = clienteFatura.getValue('custentity_enl_cnpjcpf');
        objCliente['Email'] = clienteFatura.getValue('email');
        objCliente['DataNascimento'] = clienteFatura.getValue('custentity_lrc_data_nascimento');
        objCliente['Endereco'] = clienteFatura.getValue('defaultaddress');
        objCliente['nacionalidade'] = clienteFatura.getValue('custentity_lrc_nacionalidade');
        objCliente['naturalidadev'] = clienteFatura.getValue('custentity_lrc_naturalidade');
        objCliente['EstadoCivil'] = clienteFatura.getValue('custentity_lrc_estado_civil');
        objCliente['rg'] = clienteFatura.getValue('custentity_lrc_rg');
        objCliente['OrgaoExpeditor'] = clienteFatura.getValue('custentity_lrc_orgao_expedidor');
        objCliente['Profissao'] = clienteFatura.getValue('custentityprof');
        objCliente['TelefoneComercial'] = clienteFatura.getValue('phone');
        objCliente['celular'] = clienteFatura.getValue('mobilephone');
        objCliente['TelefoneResidencial'] = clienteFatura.getValue('mobilephone');
        objCliente['Tipo'] = clienteFatura.getText('isperson');
        objCliente['Sexo'] = clienteFatura.getText('custentity_rsc_sexo');
        objInvoice['CodigoEmpreendimento'] = invoiceRecord.getValue('custbody_rsc_projeto_obra_gasto_compra');
        objInvoice['CodigoBloco'] = invoiceRecord.getValue('custbody_rsc_ebu');
        objInvoice['Unidade'] = invoiceRecord.getValue('custbody_rsc_ebu');
        objInvoice['NumeroProposta'] = invoiceRecord.getValue('custbody_rsc_nr_proposta');
        objInvoice['NumeroContrato'] = invoiceRecord.getValue('tranid');
        objInvoice['DataVenda'] = invoiceRecord.getValue('custbody_rsc_data_venda');
        objInvoice['ValorVenda'] = invoiceRecord.getValue('custbody_rsc_vlr_venda');
        objInvoice['DataEntregaChaves'] = invoiceRecord.getValue('custbody_lrc_data_chave');
        objInvoice['Ativo'] = invoiceRecord.getValue('custbody_rsc_ativo');
        objInvoice['TipoContrato'] = invoiceRecord.getValue('custbody_lrc_tipo_contrato');
        objInvoice['DataPrevisaoEntrega'] = invoiceRecord.getValue('custbody_lrc_data_previsao_entrega');
        objInvoice['ITBIGratis'] = invoiceRecord.getValue('custbody_lrc_itbi_gratis');
        objInvoice['RegistroGratis'] = invoiceRecord.getValue('custbody_lrc_registro_gratis');
        objInvoice['DataEmissao'] = invoiceRecord.getValue('trandate');
        objInvoice['ValorVendaAtualizada'] = invoiceRecord.getValue('custbody_lrc_vlr_venda_att');
        objInvoice['ValorSaldoDevedor'] = invoiceRecord.getValue('custbody_lrc_vlr_devedor');
        objInvoice['Banco'] = invoiceRecord.getValue('custrecord_enl_bankid');
        objInvoice['TipoOperacao'] = invoiceRecord.getValue('custbody_rsc_tipo_op');
        objInvoice['DataRepasseFuturo'] = invoiceRecord.getValue('custbody_lrc_data_repasse_futuro');
        objInvoice['ModalidadeFinanciamento'] = invoiceRecord.getValue('custbody_rsc_mod_financ');
        objInvoice['SistemaAmortizacao'] = invoiceRecord.getValue('custbody_rsc_sist_amort');
        objInvoice['ValorFGTS'] = invoiceRecord.getValue('custbody_lrc_valor_fgts');
        objInvoice['ValorSubsidio'] = invoiceRecord.getValue('custbody_lrc_vlr_subsidio');
        objInvoice['ValorInterveniencia'] = invoiceRecord.getValue('custbody_lrc_vlr_interveniencia');
        objInvoice['ValorRecursosProprios'] = invoiceRecord.getValue('custbody_lrc_recursos_proprios');
        objInvoice['TaxaJuros'] = invoiceRecord.getValue('custrecord_gst_instal_interestrate');
        objInvoice['AssessoriaCNPJ'] = invoiceRecord.getValue('custbody_lrc_assessoria');
        objInvoice['DataLiberacaoChave'] = invoiceRecord.getValue('custbody_lrc_data_liberacao_chave');
        objInvoice['Cliente'] = objCliente;
        objInvoice['Lista-Parcelas'] = arrayParcelas;
        var body = {
            spe: objInvoice,
            name: 'TESTE'
        };
        var retorno = envioApi_js_1.default.sendRequest(body, 'Contrato/Salvar');
        log_1.default.error('Retorno', retorno);
        invoiceRecord.setValue({
            fieldId: 'custbody_lrc_enviado_para_junix',
            value: true
        });
        invoiceRecord.save({
            ignoreMandatoryFields: true
        });
    };
    exports.map = map;
});
