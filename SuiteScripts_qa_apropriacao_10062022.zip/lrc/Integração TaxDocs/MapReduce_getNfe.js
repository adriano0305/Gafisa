/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* MapReduce_getNfe.js
*
* MapReduce reponsável por obter as NFE's da api da Avalara
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/https", "N/record", "N/log", "N/runtime"], function (require, exports, https_1, record_1, log_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    https_1 = __importDefault(https_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    runtime_1 = __importDefault(runtime_1);
    var getInputData = function () {
        //credenciais para obtenção do token
        var jsoncrend = {
            "grant_type": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptgrant_type_1'
            }),
            "client_id": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptclient_id_1'
            }),
            "username": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptusername_1'
            }),
            "password": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptpassword_1'
            }),
            "client_secret": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptclient_secret_1'
            })
        };
        //chamada para obtenção do token
        var response = https_1.default.post({
            body: JSON.stringify(jsoncrend),
            url: 'https://api-gateway.avalarabrasil.com.br/oauth/token',
            headers: { "Content-Type": "application/json" }
        });
        var objResponse = JSON.parse(response.body);
        var bearer_resp = objResponse.access_token;
        var date = new Date();
        //Data de inicio e fim para a query
        var datestart = "".concat(date.getFullYear(), "-").concat(date.getMonth() - 1, "-").concat(date.getDate());
        var dateend = "".concat(date.getFullYear(), "-").concat(date.getMonth(), "-").concat(date.getDate());
        //url api
        var urlget = 'https://api-taxdocs-external.avalarabrasil.com.br/api/v1/CTE?startEntryDate='
            + datestart
            + '&endEntryDate='
            + dateend + '&$top=1000';
        //autorização
        var headerObj = { Authorization: "Bearer " + bearer_resp + "" };
        //get nfe
        var response2 = https_1.default.get({
            headers: headerObj,
            url: urlget,
        });
        var objResponse2 = JSON.parse(response2.body);
        return objResponse2;
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var list_nfe = JSON.parse(ctx.value);
        //Persistencia dos dados
        list_nfe.forEach(function (obj) {
            log_1.default.error("list_nfe.forEach((obj", obj);
            var new_nfe = record_1.default.create({
                type: 'customrecord_lrc_nf',
            });
            new_nfe.setValue({
                fieldId: 'custrecord_lrc_num_nfe',
                value: obj.invoiceNumber
            });
            new_nfe.setValue({
                fieldId: 'custrecord_lrc_chave_acesso',
                value: obj.invoiceKey
            });
            new_nfe.setValue({
                fieldId: 'custrecord_lrc_json_nfe',
                value: JSON.stringify(obj)
            });
            new_nfe.save({ ignoreMandatoryFields: true });
        });
    };
    exports.map = map;
});
