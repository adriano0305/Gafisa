/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* Suitelet para criação dos parâmetros de modelo de requisição
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget","N/search"], function (require, exports, UI,search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    search_1 = __importStar(search_1);
    var onRequest = function (ctx) {
        if (ctx.request.method == 'GET') {
            var newForm = UI.createForm({
                title: 'Criação de Modelo de Requisição'
            });
            var params = ctx.request.parameters;
            newForm = createFields(newForm, params.modeloDeProjetoId);
            newForm = createSublist(newForm, params.modeloDeProjetoId);
            newForm.clientScriptModulePath = './Clientscript_criacaoModeloRequisicao.js';
            newForm.addButton({
                id: 'custpage_btn_salvar',
                label: 'Salvar',
                functionName: 'salvarParamsReq' //função criada no ClientScript_criacaoModeloRequisicao
            });
            newForm.addButton({
                id: 'custpage_btn_cancelar',
                label: 'Cancelar',
                functionName: 'cancelarParamsReq' //função criada no ClientScript_criacaoModeloRequisicao
            });
            ctx.response.writePage(newForm);
        }
    };
    exports.onRequest = onRequest;
    // Lista do registro
    var createFields = function (form, modeloDeProjetoId) {
        form.addTab({
            id: 'custpage_subtab_itens',
            label: 'Itens'
        });
        form.addField({
            id: 'custpage_lrc_nome',
            label: 'Nome do Modelo',
            type: UI.FieldType.TEXT
        })
        form.addField({
            id: 'custpage_lrc_solicitante',
            label: 'Solicitante',
            type: UI.FieldType.SELECT,
            source: 'employee'
        });
        form.addField({
            id: 'custpage_lrc_subsidiaria',
            label: 'Subsidiaria',
            type: UI.FieldType.SELECT,
            source: 'subsidiary'
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        form.addField({
            id: 'custpage_lrc_data',
            label: 'Data',
            type: UI.FieldType.DATE,
        });
        form.addField({
            id: 'custpage_lrc_data_entrega',
            label: 'Data Entrega',
            type: UI.FieldType.DATE,
        });
        form.addField({
            id: 'custpage_lrc_modelo_relacionado',
            label: 'Projeto Relacionado',
            type: UI.FieldType.SELECT,
            source: 'job'
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        }).defaultValue = modeloDeProjetoId;
        return form;
    };
    //sublista dos itens de registro
    var createSublist = function (form, modeloId) {
        var itensSublist = form.addSublist({
            id: 'custpage_itens',
            label: 'Itens',
            type: UI.SublistType.INLINEEDITOR,
            tab: 'custpage_subtab_itens'
        });
        itensSublist.addField({
            id: 'custpage_item',
            label: 'Item',
            type: UI.FieldType.SELECT,
            source: 'item'
        });
        var campoTarefa = itensSublist.addField({
            id: 'custpage_lrc_mod_proj_taf_relacionada',
            label: 'Tarefa de Projeto Relacionada',
            type: UI.FieldType.SELECT,
        })
        campoTarefa.addSelectOption({
            text: '',
            value: ''
        });
        search_1.default.create({
            type: 'projecttask',
            filters: [
                ['company', 'IS', modeloId]
            ],
            columns: [
                'title'
            ]
        }).run().each(function (tarefaProjeto) {
            campoTarefa.addSelectOption({
                value: String(tarefaProjeto.id),
                text: String(tarefaProjeto.getValue('title'))
            });
            return true;
        });
        itensSublist.addField({
            id: 'custpage_quantidade',
            label: 'Quantidade',
            type: UI.FieldType.FLOAT,
        });   
        itensSublist.addField({
            id: 'custpage_unidades',
            label: 'Unidades',
            type: UI.FieldType.SELECT,
            source: 'unitstype'
        });
        itensSublist.addField({
            id: 'custpage_descricao',
            label: 'Descrição',
            type: UI.FieldType.TEXTAREA,
        });
        itensSublist.addField({
            id: 'custpage_taxa_estimada',
            label: 'Taxa Estimada',
            type: UI.FieldType.FLOAT,
        });
        itensSublist.addField({
            id: 'custpage_valor_estimado',
            label: 'Valor Estimado',
            type: UI.FieldType.CURRENCY,
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        return form;
    };
});
