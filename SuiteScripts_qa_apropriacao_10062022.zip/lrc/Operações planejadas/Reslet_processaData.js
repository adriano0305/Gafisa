/**
* @NAPIVersion 2.0
* @NScriptType Restlet
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/search"], function (require, exports, Log, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.post = void 0;
    Log = __importStar(Log);
    search_1 = __importDefault(search_1);
    var post = function (ctx) {
        var dataInicio = ctx.dataInicio;
        var dataFinal = ctx.dataFinal;
        Log.error('dataInicio', dataInicio);
        Log.error('dataFinal', dataFinal);
        Log.error('nada', ctx);
        var arrayProcessaPu = [];
        var arrayProcessaLa = [];
        var arrayProcessaIn = [];
        var arrayProcessaSa = [];
        var arrayProcessaVe = [];
        var jsonObjPu = {};
        var jsonObjLa = {};
        var jsonObjIn = {};
        var jsonObjSa = {};
        var jsonObjVe = {};
        try {
            var purchaseorderSearchObj = search_1.default.create({
                type: "purchaseorder",
                filters: [
                    ['trandate', search_1.default.Operator.ONORAFTER, dataInicio],
                    "AND",
                    ['trandate', search_1.default.Operator.ONORBEFORE, dataFinal],
                    "AND",
                    ['mainline', 'is', 'T']
                ],
                columns: ['trandate', 'tranid', 'duedate', 'account', 'class', 'class', 'currency', 'total', 'entity']
            });
            purchaseorderSearchObj.run().each(function (result) {
                Log.error("passou por aqui compra", "done");
                jsonObjPu['trandate'] = result.getValue("trandate");
                jsonObjPu['tranid'] = result.getValue("tranid");
                jsonObjPu['duedate'] = result.getValue("duedate");
                jsonObjPu['accont'] = result.getValue("account");
                jsonObjPu['class'] = result.getValue("total");
                jsonObjPu['currency'] = result.getValue("currency");
                jsonObjPu['total'] = result.getValue("total");
                jsonObjPu['entity'] = result.getValue("entity");
                arrayProcessaPu.push(jsonObjPu);
                return true;
            });
        }
        catch (e) {
            Log.error("Error", e);
        }
        search_1.default.create({
            type: "journalentry",
            filters: [
                ['trandate', search_1.default.Operator.ONORAFTER, dataInicio],
                "AND",
                ['trandate', search_1.default.Operator.ONORBEFORE, dataFinal],
                "AND",
                ['mainline', 'is', 'T']
            ],
            columns: ['trandate', 'tranid', 'duedate', 'account', 'class', 'class', 'currency', 'total', 'entity']
        }).run().each(function (result) {
            Log.error("lancamento", result.getValue("trandate"));
            jsonObjLa['trandate'] = result.getValue("trandate");
            jsonObjLa['tranid'] = result.getValue("tranid");
            jsonObjLa['duedate'] = result.getValue("duedate");
            jsonObjLa['accont'] = result.getValue("account");
            jsonObjLa['class'] = result.getValue("total");
            jsonObjLa['currency'] = result.getValue("currency");
            jsonObjLa['total'] = result.getValue("total");
            jsonObjLa['entity'] = result.getValue("entity");
            arrayProcessaLa.push(jsonObjLa);
            //ctx.response.write({output: stringLancamento})
            return true;
        });
        search_1.default.create({
            type: "invoice",
            filters: [
                ['trandate', search_1.default.Operator.ONORAFTER, dataInicio],
                "AND",
                ['trandate', search_1.default.Operator.ONORBEFORE, dataFinal],
                "AND",
                ['mainline', 'is', 'T']
            ],
            columns: ['trandate', 'tranid', 'duedate', 'account', 'class', 'class', 'currency', 'total', 'entity']
        }).run().each(function (result) {
            Log.error("passou por aqui invoice", "done");
            jsonObjIn['trandate'] = result.getValue("trandate");
            jsonObjIn['tranid'] = result.getValue("tranid");
            jsonObjIn['duedate'] = result.getValue("duedate");
            jsonObjIn['accont'] = result.getValue("account");
            jsonObjIn['class'] = result.getValue("total");
            jsonObjIn['currency'] = result.getValue("currency");
            jsonObjIn['total'] = result.getValue("total");
            jsonObjIn['entity'] = result.getValue("entity");
            arrayProcessaIn.push(jsonObjIn);
            //ctx.response.write({output: stringFatura})
            return true;
        });
        search_1.default.create({
            type: "salesorder",
            filters: [
                ['trandate', search_1.default.Operator.ONORAFTER, dataInicio],
                "AND",
                ['trandate', search_1.default.Operator.ONORBEFORE, dataFinal],
                "AND",
                ['mainline', 'is', 'T']
            ],
            columns: ['trandate', 'tranid', 'duedate', 'account', 'class', 'class', 'currency', 'total', 'entity']
        }).run().each(function (result) {
            Log.error("passou por aqui venda", "done");
            jsonObjSa['trandate'] = result.getValue("trandate");
            jsonObjSa['tranid'] = result.getValue("tranid");
            jsonObjSa['duedate'] = result.getValue("duedate");
            jsonObjSa['accont'] = result.getValue("account");
            jsonObjSa['class'] = result.getValue("total");
            jsonObjSa['currency'] = result.getValue("currency");
            jsonObjSa['total'] = result.getValue("total");
            jsonObjSa['entity'] = result.getValue("entity");
            arrayProcessaSa.push(jsonObjSa);
            //ctx.response.write({output: stringVenda})
            return true;
        });
        search_1.default.create({
            type: "vendorbill",
            filters: [
                ['trandate', search_1.default.Operator.ONORAFTER, dataInicio],
                "AND",
                ['trandate', search_1.default.Operator.ONORBEFORE, dataFinal],
                "AND",
                ['mainline', 'is', 'T']
            ],
            columns: ['trandate', 'tranid', 'duedate', 'account', 'class', 'class', 'currency', 'total', 'entity']
        }).run().each(function (result) {
            Log.error("passou por aqui vendorbill", "done");
            jsonObjVe['trandate'] = result.getValue("trandate");
            jsonObjVe['tranid'] = result.getValue("tranid");
            jsonObjVe['duedate'] = result.getValue("duedate");
            jsonObjVe['accont'] = result.getValue("account");
            jsonObjVe['class'] = result.getValue("total");
            jsonObjVe['currency'] = result.getValue("currency");
            jsonObjVe['total'] = result.getValue("total");
            jsonObjVe['entity'] = result.getValue("entity");
            arrayProcessaVe.push(jsonObjVe);
            //ctx.response.write({output: stringCobranca})
            return true;
        });
        var objFinal = {};
        objFinal['purchaseOrder'] = arrayProcessaPu;
        objFinal['journalentry'] = arrayProcessaLa;
        objFinal['invoice'] = arrayProcessaIn;
        objFinal['salesOrder'] = arrayProcessaSa;
        objFinal['vendorBill'] = arrayProcessaVe;
        Log.error("qualquercoisa", objFinal);
        Log.error("arrayProcessaPu", arrayProcessaPu);
        return objFinal;
    };
    exports.post = post;
});
