/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/record", "N/search", "N/runtime"], function (require, exports, currentRecord_1, record_1, search_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.trocarClient = exports.fieldChanged = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    runtime_1 = __importDefault(runtime_1);
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var currentRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        if (fieldId == 'custpage_lrc_cliente_antigo') {
            console.log('entrou no if');
            var clienteAntigo = currentRecord.getValue({
                fieldId: 'custpage_lrc_cliente_antigo'
            });
            var campoFatura_1 = currentRecord.getField({
                fieldId: 'custpage_lrc_fatura_referente'
            });
            campoFatura_1.removeSelectOption({
                value: null
            });
            search_1.default.create({
                type: "invoice",
                filters: [
                    ['custbody_lrc_fatura_principal', 'ANYOF', '@NONE@'],
                    'AND',
                    ['entity', 'IS', clienteAntigo],
                    'AND',
                    ['mainline', 'IS', 'T'],
                ],
                columns: [
                    'tranid'
                ]
            }).run().each(function (result) {
                var invoiceRecord = search_1.default.lookupFields({
                    type: 'invoice',
                    id: result.id,
                    columns: [
                        'tranid'
                    ]
                });
                console.log('result', result);
                campoFatura_1.insertSelectOption({
                    text: "Fatura #" + invoiceRecord['tranid'],
                    value: result.id
                });
                console.log('lookup', invoiceRecord);
                return true;
            });
        }
        if (fieldId == 'custpage_lrc_novo_cliente') {
            var clienteNovo = currentRecord.getValue({
                fieldId: 'custpage_lrc_novo_cliente'
            });
            var campoSubisidiaria = currentRecord.getField({
                fieldId: 'custpage_lrc_subsidiaria'
            });
            var record = record_1.default.load({
                type: 'customer',
                id: clienteNovo,
            });
            var linhaSublista = record.getLineCount({
                sublistId: 'submachine'
            });
            campoSubisidiaria.removeSelectOption({
                value: null
            });
            for (var i = 0; i < linhaSublista; i++) {
                var valorSublistaText = void 0;
                var valorSublistValue = void 0;
                valorSublistaText = record.getSublistText({
                    fieldId: 'subsidiary',
                    line: i,
                    sublistId: 'submachine'
                }),
                    valorSublistValue = record.getSublistValue({
                        fieldId: 'subsidiary',
                        line: i,
                        sublistId: 'submachine'
                    });
                var ePrincipal = record.getSublistValue({
                    fieldId: 'isprimesub',
                    line: i,
                    sublistId: 'submachine'
                });
                if (ePrincipal == true) {
                    campoSubisidiaria.insertSelectOption({
                        text: valorSublistaText,
                        value: valorSublistValue,
                        isSelected: true
                    });
                }
                else {
                    campoSubisidiaria.insertSelectOption({
                        text: valorSublistaText,
                        value: valorSublistValue,
                        isSelected: false
                    });
                }
            }
            var valueSubisidiaria = currentRecord.getValue({
                fieldId: 'custpage_lrc_subsidiaria'
            });
            var localidade_1 = currentRecord.getField({
                fieldId: 'custpage_lrc_location'
            });
            localidade_1.removeSelectOption({
                value: null
            });
            search_1.default.create({
                type: 'location',
                filters: [
                    ['subsidiary', 'IS', valueSubisidiaria]
                ],
                columns: ['name']
            }).run().each(function (result) {
                var name = result.getValue({
                    name: 'name'
                });
                console.log(result.id, name);
                localidade_1.insertSelectOption({
                    text: name,
                    value: result.id
                });
                return true;
            });
        }
        if (fieldId == 'custpage_lrc_subsidiaria') {
            var valueSubisidiaria = currentRecord.getValue({
                fieldId: 'custpage_lrc_subsidiaria'
            });
            var localidade_2 = currentRecord.getField({
                fieldId: 'custpage_lrc_location'
            });
            localidade_2.removeSelectOption({
                value: null
            });
            search_1.default.create({
                type: 'location',
                filters: [
                    ['subsidiary', 'IS', valueSubisidiaria]
                ],
                columns: ['name']
            }).run().each(function (result) {
                var name = result.getValue({
                    name: 'name'
                });
                console.log(result.id, name);
                localidade_2.insertSelectOption({
                    text: name,
                    value: result.id
                });
                return true;
            });
        }
    };
    exports.fieldChanged = fieldChanged;
    var trocarClient = function () {
        console.log('entrou aqui no começo');
        var record = currentRecord_1.default.get();
        console.log('entrou aqui no começo record');
        var clienteNovo = record.getValue({
            fieldId: 'custpage_lrc_novo_cliente'
        });
        var campoSubisidiaria = record.getValue({
            fieldId: 'custpage_lrc_subsidiaria'
        });
        console.log(clienteNovo, 'pegou valor do cliente novo');
        var campoFatura = record.getValue({
            fieldId: 'custpage_lrc_fatura_referente'
        });
        var taxa = record.getValue({
            fieldId: 'custpage_lrc_taxa_adicional'
        });
        console.log(campoFatura, 'pegou valor da fatura');
        var localidade = record.getValue({
            fieldId: 'custpage_lrc_location'
        });
        search_1.default.create({
            type: "invoice",
            filters: [
                ['custbody_lrc_fatura_principal', 'IS', campoFatura],
                'OR',
                ['internalid', 'IS', campoFatura],
                'AND',
                ['mainline', 'IS', 'T'],
            ],
            columns: ['entity', 'subsidiary']
        }).run().each(function (result) {
            console.log('entrou na search');
            var recordLoad = record_1.default.load({
                id: result.id,
                type: 'invoice',
            });
            console.log('result', result);
            recordLoad.setValue({
                fieldId: 'location',
                value: localidade
            });
            recordLoad.setValue({
                fieldId: 'entity',
                value: clienteNovo
            });
            recordLoad.setValue({
                fieldId: 'subsidiary',
                value: campoSubisidiaria
            });
            var item = runtime_1.default.getCurrentScript().getParameter({
                name: 'custscript_lrc_taxa_adicional'
            });
            console.log(item);
            var line = recordLoad.getLineCount({
                sublistId: 'item'
            });
            recordLoad.setSublistValue({
                fieldId: 'item',
                line: line,
                sublistId: 'item',
                value: item
            });
            recordLoad.setSublistValue({
                fieldId: 'amount',
                line: line,
                sublistId: 'item',
                value: taxa
            });
            recordLoad.save();
            return true;
        });
        alert('Transferência realizada');
    };
    exports.trocarClient = trocarClient;
});
