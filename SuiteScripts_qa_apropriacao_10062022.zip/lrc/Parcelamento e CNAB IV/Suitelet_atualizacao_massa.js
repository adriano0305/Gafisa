/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
*Suitelet_ataualizacao_massa.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/log"], function (require, exports, UI, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    log_1 = __importDefault(log_1);
    var onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var parameters = ctx.request.parameters;
            log_1.default.debug('Parameters', parameters.parcelas);
            var form = UI.createForm({
                title: 'Atualização em Massa'
            });
            if (parameters.hasOwnProperty("parcelas")) {
                form.addField({
                    id: 'custpage_lrc_array_parcelas',
                    type: UI.FieldType.LONGTEXT,
                    label: 'Array parcelas',
                }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = parameters.parcelas;
            }
            // const jsonObj = {} as any
            // jsonObj['parcelas'] = JSON.parse(arrayParcelas);
            var formId = form.addField({
                id: 'custpage_lrc_cliente',
                type: UI.FieldType.SELECT,
                source: 'customer',
                label: 'Cliente'
            });
            form.addField({
                id: 'custpage_lrc_data',
                type: UI.FieldType.DATE,
                label: 'Data',
            });
            var sublist = form.addSublist({
                id: 'custpage_lrc_faturas_sublist',
                type: UI.SublistType.INLINEEDITOR,
                label: 'Faturas'
            });
            sublist.addField({
                id: 'custpage_lrc_fatura_sublist',
                type: UI.FieldType.SELECT,
                source: 'invoice',
                label: 'Fatura'
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist.addField({
                id: 'custpage_lrc_cliente_sublist',
                type: UI.FieldType.SELECT,
                source: 'customer',
                label: 'Cliente'
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist.addField({
                id: 'custpage_lrc_data_sublist',
                type: UI.FieldType.TEXT,
                label: 'Data',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist.addField({
                id: 'custpage_lrc_valor',
                type: UI.FieldType.TEXT,
                label: 'Valor ',
            }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
            sublist.addField({
                id: 'custpage_lrc_selecionar',
                type: UI.FieldType.CHECKBOX,
                label: 'Selecionar',
            });
            sublist.addButton({
                id: 'button_lrc_atualizar',
                label: 'Atualizar',
                functionName: 'atualizarEmMassa',
            });
            form.clientScriptModulePath = "./ClientScript_atualizacao_massa.js";
            ctx.response.writePage(form);
        }
    };
    exports.onRequest = onRequest;
});
