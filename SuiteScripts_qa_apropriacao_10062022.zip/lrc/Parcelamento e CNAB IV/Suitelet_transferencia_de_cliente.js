/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 *  Suitelet_transferencia_de_cliente
 *
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget"], function (require, exports, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    var onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var form = UI.createForm({
                title: 'Transferência de Cliente'
            });
            form.clientScriptModulePath = "./ClientScript_tela_transferencia_de_cliente.js";
            var formId = form.addField({
                id: 'custpage_lrc_cliente_antigo',
                type: UI.FieldType.SELECT,
                source: "customer",
                label: 'Cliente Antigo'
            });
            form.addField({
                id: 'custpage_lrc_novo_cliente',
                type: UI.FieldType.SELECT,
                source: "customer",
                label: 'Novo cliente'
            });
            form.addField({
                id: 'custpage_lrc_subsidiaria',
                type: UI.FieldType.SELECT,
                label: 'Subsidiaria'
            });
            form.addField({
                id: 'custpage_lrc_location',
                type: UI.FieldType.SELECT,
                label: 'Localidade'
            });
            form.addField({
                id: 'custpage_lrc_taxa_adicional',
                type: UI.FieldType.CURRENCY,
                label: 'Taxa Adicional'
            });
            form.addField({
                id: 'custpage_lrc_fatura_referente',
                type: UI.FieldType.SELECT,
                label: 'Fatura refertente',
            });
            form.addButton({
                id: "custpage_lrc_button",
                label: "Realizar transferência",
                functionName: "trocarClient"
            });
            ctx.response.writePage(form);
        }
    };
    exports.onRequest = onRequest;
});
