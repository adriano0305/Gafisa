/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript_atualizacao_massa.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url", "N/log", "N/search", "N/record"], function (require, exports, currentRecord_1, url_1, log_1, search_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.atualizarEmMassa = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    var pageInit = function (ctx) {
        var record = currentRecord_1.default.get();
        console.log('array parcela', String(record.getValue('custpage_lrc_array_parcelas')));
        if (record.getValue('custpage_lrc_array_parcelas')) {
            var arrayParcelas = JSON.parse(String(record.getValue('custpage_lrc_array_parcelas')));
            arrayParcelas.forEach(function (parcela) {
                var searchedInvoice = search_1.default.lookupFields({
                    type: 'invoice',
                    id: String(parcela),
                    columns: [
                        'entity',
                        'duedate',
                        'total'
                    ]
                });
                record.selectNewLine({
                    sublistId: 'custpage_lrc_faturas_sublist',
                });
                record.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_faturas_sublist',
                    fieldId: 'custpage_lrc_cliente_sublist',
                    value: searchedInvoice.entity[0].value
                });
                console.log('searchedInvoice', searchedInvoice);
                record.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_faturas_sublist',
                    fieldId: 'custpage_lrc_data_sublist',
                    value: searchedInvoice.duedate || ''
                });
                record.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_faturas_sublist',
                    fieldId: 'custpage_lrc_fatura_sublist',
                    value: String(parcela)
                });
                console.log('searchedInvoice', searchedInvoice);
                record.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_faturas_sublist',
                    fieldId: 'custpage_lrc_valor',
                    value: searchedInvoice.total || ''
                });
                record.setCurrentSublistValue({
                    sublistId: 'custpage_lrc_faturas_sublist',
                    fieldId: 'custpage_lrc_selecionar',
                    value: true
                });
                record.commitLine({
                    sublistId: 'custpage_lrc_faturas_sublist'
                });
            });
        }
    };
    exports.pageInit = pageInit;
    var atualizarEmMassa = function () {
        var record = currentRecord_1.default.get();
        alert("Aguarde enquanto as parcelas estão atualizando, pode levar alguns minutos.");
        var quantidadeItensSublist = record.getLineCount({
            sublistId: 'custpage_lrc_faturas_sublist'
        });
        if (quantidadeItensSublist == 0) {
            alert('Nenhuma parcela selecionada');
            throw new Error('Nenhuma parcela Selecionada');
        }
        ;
        for (var i = 0; i < quantidadeItensSublist; i++) {
            console.log('quantidade sibulista', quantidadeItensSublist);
            var isParcelaSelecionada = record.getSublistValue({
                sublistId: 'custpage_lrc_faturas_sublist',
                fieldId: 'custpage_lrc_selecionar',
                line: i
            });
            if (isParcelaSelecionada) {
                console.log('Parcela', isParcelaSelecionada);
                var parcelaId = record.getSublistValue({
                    sublistId: 'custpage_lrc_faturas_sublist',
                    fieldId: 'custpage_lrc_fatura_sublist',
                    line: i
                });
                var faturaRecord = record_1.default.load({
                    id: String(parcelaId),
                    type: record_1.default.Type.INVOICE
                });
                faturaRecord.setValue({
                    fieldId: 'entity',
                    value: record.getValue('custpage_lrc_cliente')
                });
                faturaRecord.setValue({
                    fieldId: 'duedate',
                    value: record.getValue('custpage_lrc_data')
                });
                faturaRecord.save({ ignoreMandatoryFields: true });
            }
        }
        var atualizar = url_1.default.resolveScript({
            scriptId: 'customscript_irc_ajuste_de_parcelas',
            deploymentId: 'customdeploy_irc_ajuste_de_parcelas',
        });
        log_1.default.error("Atualizar", atualizar);
        alert('Atualização realizada com sucesso.');
        window.location.replace(atualizar);
    };
    exports.atualizarEmMassa = atualizarEmMassa;
});
