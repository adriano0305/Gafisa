/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 *
 *  ClienteScript_ajuste_de_parcela.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/currentRecord", "N/url"], function (require, exports, search_1, currentRecord_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.atualizar = exports.buscar = exports.pageInit = void 0;
    search_1 = __importDefault(search_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var buscar = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        console.log("Entrei no botão");
        var preFilters = [
            ['subsidiary', 'IS', 'custpage_lrc_subsidiaria'],
            ['entity', 'IS', 'custpage_lrc_cliente'],
            ['duedate', 'ONORBEFORE', 'custpage_lrc_data'], // Data
        ];
        var filters = [];
        preFilters.forEach(function (preFilter) {
            console.log("Entrei no preFilter");
            var fieldValue = String(currentAjusteParcelaRecord.getValue(preFilter[2]));
            if (fieldValue) {
                if (preFilter[2] === 'custpage_lrc_data') {
                    fieldValue = dateToString(new Date(fieldValue));
                }
            }
            else {
                if (preFilter[2] === '') {
                    fieldValue = dateToString(new Date(fieldValue));
                }
            }
            if (fieldValue) {
                var filter = [preFilter[0], preFilter[1], fieldValue];
                filters.push(filter);
                filters.push('AND');
            }
        });
        console.log("Sai do prefilter");
        filters.push(['mainline', 'IS', 'T']);
        filters.push('AND');
        filters.push(['custbody_lrc_fatura_principal', 'ISNOTEMPTY', ' ']);
        console.log("Filters", filters);
        var pagedInvoice = search_1.default.create({
            type: search_1.default.Type.INVOICE,
            filters: filters,
            columns: [
                "subsidiary",
                "entity",
                "duedate",
                "total"
            ]
        }).runPaged({
            pageSize: 50
        });
        if (pagedInvoice.pageRanges.length) {
            for (var i = 0; i < pagedInvoice.pageRanges.length; i++) {
                var currentPage = pagedInvoice.fetch({
                    index: i
                });
                currentPage.data.forEach(function (result) {
                    console.log("Dentro da result", result);
                    currentAjusteParcelaRecord.selectNewLine({
                        sublistId: 'custpage_lrc_faturas',
                    });
                    currentAjusteParcelaRecord.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_fatura',
                        fieldId: 'custpage_lrc_faturas',
                        value: String(result.id)
                    });
                    currentAjusteParcelaRecord.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_fatura',
                        fieldId: 'custpage_lrc_cliente',
                        value: String(result.getValue('entity'))
                    });
                    if (result.getValue('duedate')) {
                        var data = String(result.getValue('duedate')).replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                        currentAjusteParcelaRecord.setCurrentSublistValue({
                            sublistId: 'custpage_lrc_fatura',
                            fieldId: 'custpage_lrc_data',
                            value: new Date(data)
                        });
                    }
                    currentAjusteParcelaRecord.setCurrentSublistValue({
                        sublistId: 'custpage_lrc_fatura',
                        fieldId: 'custpage_lrc_moeda',
                        value: String(result.getValue('total'))
                    });
                    currentAjusteParcelaRecord.commitLine({
                        sublistId: 'custpage_lrc_fatura'
                    });
                });
            }
        }
    };
    exports.buscar = buscar;
    var dateToString = function (date) {
        return date.getDate() + "/" + date.getMonth() + "/" + date.getFullYear();
    };
    var atualizar = function () {
        var currentAjusteParcelaRecord = currentRecord_1.default.get();
        var quantidadeItensSublist = currentAjusteParcelaRecord.getLineCount({
            sublistId: 'custpage_lrc_fatura'
        });
        if (quantidadeItensSublist == 0) {
            alert('Nenhuma parcela selecionada');
            throw new Error('Nenhuma parcela Selecionada');
        }
        ;
        var parcelas = [];
        for (var i = 0; i < quantidadeItensSublist; i++) {
            var isParcelaSelecionada = currentAjusteParcelaRecord.getSublistValue({
                sublistId: 'custpage_lrc_fatura',
                fieldId: 'custpage_lrc_selecionar',
                line: i
            });
            if (isParcelaSelecionada) {
                var parcelaId = currentAjusteParcelaRecord.getSublistValue({
                    sublistId: 'custpage_lrc_fatura',
                    fieldId: 'custpage_lrc_faturas',
                    line: i
                });
                parcelas.push(parcelaId);
            }
        }
        var url = url_1.default.resolveScript({
            scriptId: 'customscript_lrc_atualizacao_em_massa',
            deploymentId: 'customdeploy_lrc_atualizacao_em_massa',
            params: {
                parcelas: JSON.stringify(parcelas)
            }
        });
        window.location.replace(url);
    };
    exports.atualizar = atualizar;
});
