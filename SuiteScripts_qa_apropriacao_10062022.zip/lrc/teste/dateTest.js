/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log"], function (require, exports, search_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var searchHoraDataStatusAnterior = function (controleEscrituracaoId) {
                // Buscar o Status anterior do Controle de Escrituracao
                var tabelaAndamentoSearchResult = search_1.default.create({
                    type: "customrecord_lrc_tab_andamento_status",
                    filters: [
                        [
                            "custrecord_lrc_controle_escrituracao",
                            "IS",
                            controleEscrituracaoId,
                        ],
                    ],
                    columns: [
                        search_1.default.createColumn({
                            name: "custrecord_lrc_hora_data_status_final",
                            summary: search_1.default.Summary.MAX,
                        }),
                    ],
                })
                    .run()
                    .getRange({
                    start: 0,
                    end: 1,
                })[0];
                var horaDataStatusAnterior = tabelaAndamentoSearchResult.getAllValues()["MAX(custrecord_lrc_hora_data_status_final)"];
                var _a = horaDataStatusAnterior.split(" "), data = _a[0], hora = _a[1];
                log_1.default.error("data hora", data + " " + hora);
                data = data.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                log_1.default.error("data", data);
                var dataObj = new Date(data + " " + hora);
                dataObj.setTime(dataObj.getTime() - dataObj.getTimezoneOffset() * 60 * 1000);
                return dataObj;
            };
            var date = searchHoraDataStatusAnterior(ctx.request.parameters.id);
            log_1.default.error("date", date);
        }
    };
    function getCompanyDate(date) {
        var timeZoneOffSet = -3;
        var UTC = date.getutc;
        var companyDateTime = UTC + (timeZoneOffSet * 60 * 60 * 1000);
        return new Date(companyDateTime);
    }
});
