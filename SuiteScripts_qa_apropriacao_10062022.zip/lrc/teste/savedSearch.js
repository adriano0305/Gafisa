/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log"], function (require, exports, search_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var params = ctx.request.parameters;
            var searchId = params.searchId;
            log_1.default.error("search", search_1.default.load({
                id: searchId
            }).columns);
        }
    };
});
