/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * SuiteLet para testes de interface
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
define(["require", "exports", "N/log", "N/ui/serverWidget"], function (require, exports, log_1, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    log_1 = __importDefault(log_1);
    UI = __importStar(UI);
    exports.onRequest = function (ctx) {
        log_1.default.debug('GET', 'done');
        var form = UI.createForm({
            title: 'SuiteLet Test'
        });
        form.addTab({
            id: 'tab_test',
            label: 'Tab Test'
        });
        var tab1 = form.addTab({
            id: 'tabid1',
            label: 'Tab'
        });
        var tab2 = form.addTab({
            id: 'tabid2',
            label: 'Tab'
        });
        form.insertTab({
            tab: tab1,
            nexttab: 'tabid2'
        });
        form.insertTab({
            tab: tab2,
            nexttab: 'tabid1'
        });
        form.addSubtab({
            id: 'subtab_test',
            label: 'Teste',
            tab: 'tab1'
        });
        form.addField({
            id: 'teste',
            label: 'teste',
            type: UI.FieldType.SELECT,
            source: 'entity'
        });
        form.addSublist({
            id: 'sublist_teste',
            label: 'sublista teste',
            tab: 'tab1',
            type: UI.SublistType.LIST
        });
        ctx.response.writePage(form);
    };
});
