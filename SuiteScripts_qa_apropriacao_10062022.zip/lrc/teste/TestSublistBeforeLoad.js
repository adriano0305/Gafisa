/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * TestSublistBeforeLoad.ts
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/log"], function (require, exports, serverWidget_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = exports.beforeLoad = void 0;
    serverWidget_1 = __importStar(serverWidget_1);
    log_1 = __importDefault(log_1);
    exports.beforeLoad = function (ctx) {
        var form = ctx.form;
        form.addField({
            id: "custpage_lrc_check_validate",
            label: "CHECK VALIDATE",
            type: serverWidget_1.default.FieldType.CHECKBOX
        }).updateDisplayType({ displayType: serverWidget_1.default.FieldDisplayType.HIDDEN }).defaultValue = "T";
        if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.VIEW) {
            form.addField({
                id: "custpage_lrc_dynamic_field",
                label: "DYNAMIC FIELD",
                type: serverWidget_1.default.FieldType.INTEGER
            }).updateDisplayType({ displayType: serverWidget_1.default.FieldDisplayType.DISABLED }).defaultValue = parseInt(ctx.newRecord.getValue("custrecord1410")) || 0;
        }
        if (ctx.type == ctx.UserEventType.CREATE) {
            var sublist = form.addSublist({
                type: serverWidget_1.SublistType.INLINEEDITOR,
                id: "custpage_lrc_test",
                label: "TESTE CRITERIO"
            });
            sublist.addField({
                id: "custpage_lrc_criterio",
                type: serverWidget_1.default.FieldType.SELECT,
                label: "Critério",
                source: "customrecord_lrc_teste2"
            }).updateDisplayType({ displayType: serverWidget_1.default.FieldDisplayType.DISABLED });
            sublist.addField({
                id: "custpage_lrc_criterio_description",
                type: serverWidget_1.default.FieldType.TEXT,
                label: "Detalhe do Critério",
            }).updateDisplayType({ displayType: serverWidget_1.default.FieldDisplayType.DISABLED });
            sublist.addField({
                id: "custpage_lrc_criterio_peso",
                type: serverWidget_1.default.FieldType.INTEGER,
                label: "Peso do Critério"
            }).updateDisplayType({ displayType: serverWidget_1.default.FieldDisplayType.DISABLED });
            sublist.addField({
                id: "custpage_lrc_pontos",
                type: serverWidget_1.default.FieldType.FLOAT,
                label: "Pontos"
            }).updateDisplayType({ displayType: serverWidget_1.default.FieldDisplayType.DISABLED });
            sublist.addField({
                id: "custpage_lrc_avaliacao",
                type: serverWidget_1.default.FieldType.INTEGER,
                label: "Avaliação"
            });
            sublist.addField({
                id: "custpage_lrc_url",
                type: serverWidget_1.default.FieldType.URL,
                label: "URL"
            }).linkText = "Clique aqui";
        }
    };
    exports.beforeSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var sublistCount = newRecord.getLineCount({
            sublistId: "custpage_lrc_test"
        });
        log_1.default.error("sublistCount", sublistCount);
        var fields = [
            "custpage_lrc_criterio",
            "custpage_lrc_criterio_description",
            "custpage_lrc_pontos",
            "custpage_lrc_criterio_avaliacao",
            "custpage_lrc_criterio_peso"
        ];
        var _loop_1 = function (line) {
            fields.forEach(function (field) {
                var value = newRecord.getSublistValue({
                    sublistId: "custpage_lrc_test",
                    fieldId: field,
                    line: line
                });
                log_1.default.error("[field key, field value]", [field, value]);
            });
        };
        for (var line = 0; line < sublistCount; line++) {
            _loop_1(line);
        }
    };
});
