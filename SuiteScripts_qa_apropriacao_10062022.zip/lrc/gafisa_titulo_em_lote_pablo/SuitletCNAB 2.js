/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * SuitletCNAB.ts
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/search"], function (require, exports, UI, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SepararPorSub = exports.SearchInstallments = exports.onRequest = void 0;
    UI = __importStar(UI);
    search_1 = __importDefault(search_1);
    //import CurrentRecord from "N/currentRecord";
    var onRequest = function (ctx) {
        var form = UI.createForm({
            title: "LRC @ CNAB"
        });
        form.clientScriptModulePath = "./DetalhesCNAB.js";
        //CABEÇALHO
        var selection_field = form.addField({ id: "custpage_lrc_sub_field", label: "Selecione a subsidiaria para detalhamento", type: UI.FieldType.SELECT }); //Selecao de subsidiaria
        form.addField({ id: "custpage_lrc_idate", label: "Select Inicial Date", source: "IDate", type: UI.FieldType.DATE }); //Selecao de data inicial
        form.addField({ id: "custpage_lrc_fdate", label: "Select Final Date", source: "FDate", type: UI.FieldType.DATE }); //Selecao de data final
        form.addField({ id: "custpage_lrc_checkbox", label: "Selecionar Todos (Detalhes CNAB)", type: UI.FieldType.CHECKBOX }); //Checkbox de selecionar todos
        form.addField({ id: "custpage_lrc_aprovador1", label: "Aprovador 1", type: UI.FieldType.TEXT });
        form.addField({ id: "custpage_lrc_aprovador2", label: "Aprovador 2", type: UI.FieldType.TEXT });
        form.addButton({ id: "custpage_lrc_buscacnabs", label: "Atualizar Detalhes CNAB", functionName: "buscaCNABs" }); //Botao Buscar CNAB
        form.addButton({ id: "custpage_lrc_aprovarcnabs", label: "Aprovar CNABs", functionName: "Aprovar" });
        //SELEÇÃO A APROVAR
        var sublist = form.addSublist({ id: "custpage_lrc_sublist", label: "Prestações por subsidiarias", type: UI.SublistType.INLINEEDITOR });
        sublist.addField({ id: "custpage_lrc_sublist_subsidiaria", type: UI.FieldType.TEXT, label: "Subsidiaria" });
        sublist.addField({ id: "custpage_lrc_sublist_banco", type: UI.FieldType.TEXT, label: "Banco" });
        sublist.addField({ id: "custpage_lrc_sublist_valor_total", type: UI.FieldType.TEXT, label: "Valor Total" });
        sublist.addField({ id: "custpage_lrc_sublist_quantidade", type: UI.FieldType.TEXT, label: "Numero de CNABs" });
        //DETALHES DOs CNABs
        var detalhe = form.addSublist({ id: "custpage_lrc_detalhes", label: "Detalhes do CNAB", type: UI.SublistType.INLINEEDITOR });
        detalhe.addField({ id: "custpage_lrc_detalhes_checkbox", type: UI.FieldType.CHECKBOX, label: "Seleção de CNABs" });
        detalhe.addField({ id: "custpage_lrc_detalhes_subsidiaria", type: UI.FieldType.TEXT, label: "Subsidiaria Selecionada" });
        detalhe.addField({ id: "custpage_lrc_detalhes_id", type: UI.FieldType.TEXT, label: "Id Título" });
        detalhe.addField({ id: "custpage_lrc_detalhes_fornecedor", type: UI.FieldType.TEXT, label: "Fornecedor" });
        detalhe.addField({ id: "custpage_lrc_detalhes_vencimento", type: UI.FieldType.TEXT, label: "Vencimento" });
        detalhe.addField({ id: "custpage_lrc_detalhes_valor", type: UI.FieldType.TEXT, label: "Valor" });
        //Pegar todas as informações necessarias dos installments
        var subs = SearchInstallments();
        subs = SepararPorSub(subs);
        //Colocar as opções no SELECT subsidiaria
        selection_field.addSelectOption({ value: "TODAS", text: "TODAS" });
        for (var i = 0; i < subs.length; i++) {
            //Setar os valores da sublista -> subsidiarias que possuem installments
            selection_field.addSelectOption({ value: subs[i]["subsidiaria"], text: subs[i]["subsidiaria"] });
            sublist.setSublistValue({ id: "custpage_lrc_sublist_subsidiaria", line: i, value: subs[i]["subsidiaria"] });
            if (subs[i]["banco"] == "")
                subs[i]["banco"] = "Não Informado";
            sublist.setSublistValue({ id: "custpage_lrc_sublist_banco", line: i, value: subs[i]["banco"] });
            sublist.setSublistValue({ id: "custpage_lrc_sublist_valor_total", line: i, value: Number(subs[i]["valor_total"]).toFixed(2) });
            sublist.setSublistValue({ id: "custpage_lrc_sublist_quantidade", line: i, value: Number(subs[i]["quantidade"]).toFixed() });
        }
        //------------------------------------
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
    function SearchInstallments() {
        var consulta = []; //Consulta será o resultado final das search retornadas em uma lista de objetos    
        search_1.default.create({
            type: "installment",
            filters: [["custrecord_rsc_cnab_inst_status_ls", "IS", "2"]],
            columns: [
                "duedate",
                "custrecord_rsc_cnab_inst_bank_ls",
                "amount",
                search_1.default.createColumn({ name: "entity", join: "transaction" }),
                search_1.default.createColumn({ name: "subsidiary", join: "transaction" }),
                search_1.default.createColumn({ name: "internalid", join: "transaction" }) //id do vendorbill
            ]
        }).run().each(function (result) {
            //Log.error("resultado da busca", result);
            var data_vencimento = String(result.getValue("duedate"));
            var banco = result.getText("custrecord_rsc_cnab_inst_bank_ls");
            var valor_total = Number(result.getValue("amount"));
            var fornecedor = result.getText({ name: "entity", join: "transaction" });
            var subsidiaria = result.getText({ name: "subsidiary", join: "transaction" });
            var id_titulo = result.id;
            var obj = {
                "data_vencimento": data_vencimento,
                "banco": banco,
                "valor_total": valor_total,
                "fornecedor": fornecedor,
                "subsidiaria": subsidiaria,
                "id_titulo": id_titulo
            };
            consulta.push(obj);
            return true;
        });
        return consulta;
    }
    exports.SearchInstallments = SearchInstallments;
    function SepararPorSub(lista) {
        var new_list = [];
        new_list.push({ "subsidiaria": lista[0]["subsidiaria"], "banco": lista[0]["banco"], "valor_total": lista[0]["valor_total"], "quantidade": 0 });
        var j;
        for (var i = 1; i < lista.length; i++) {
            j = 0;
            while (j < new_list.length && lista[i]["subsidiaria"] != new_list[j]["subsidiaria"]) {
                j++;
            }
            if (j >= new_list.length)
                new_list.push({ "subsidiaria": lista[i]["subsidiaria"], "banco": lista[i]["banco"], "valor_total": lista[i]["valor_total"], "quantidade": 0 });
            else {
                new_list[j]["valor_total"] += lista[i]["valor_total"];
                new_list[j]["quantidade"]++;
            }
        }
        return new_list;
    }
    exports.SepararPorSub = SepararPorSub;
});
