/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 *
 * Client_enviar.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/currentRecord", "N/record", "N/url"], function (require, exports, search_1, currentRecord_1, record_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.TrasformarStringEmData = exports.Aprovar = exports.buscaCNABs = exports.PegarCnabsParaDetalhamento = exports.SepararPorSub = exports.SearchInstallments = exports.fieldChanged = exports.pageInit = void 0;
    search_1 = __importDefault(search_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    record_1 = __importDefault(record_1);
    url_1 = __importDefault(url_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var form = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        if (fieldId == "custpage_lrc_checkbox1") {
            var checkBox = form.getValue({ fieldId: "custpage_lrc_checkbox1" });
            var total_linhas_sublista = form.getLineCount({ sublistId: "custpage_lrc_detalhes" });
            for (var i = 0; i < total_linhas_sublista; i++) {
                form.selectLine({ line: i, sublistId: "custpage_lrc_detalhes" });
                if (checkBox)
                    form.setCurrentSublistValue({ fieldId: "custpage_lrc_detalhes_checkbox", sublistId: "custpage_lrc_detalhes", value: true });
                else
                    form.setCurrentSublistValue({ fieldId: "custpage_lrc_detalhes_checkbox", sublistId: "custpage_lrc_detalhes", value: false });
                form.commitLine({ sublistId: "custpage_lrc_detalhes" });
            }
        }
        if (fieldId == "custpage_lrc_checkbox2") {
            var checkBox = form.getValue({ fieldId: "custpage_lrc_checkbox2" });
            var total_linhas_sublista = form.getLineCount({ sublistId: "custpage_lrc_sublist" });
            for (var i = 0; i < total_linhas_sublista; i++) {
                form.selectLine({ line: i, sublistId: "custpage_lrc_sublist" });
                if (checkBox)
                    form.setCurrentSublistValue({ fieldId: "custpage_lrc_sublist_checkbox", sublistId: "custpage_lrc_sublist", value: true });
                else
                    form.setCurrentSublistValue({ fieldId: "custpage_lrc_sublist_checkbox", sublistId: "custpage_lrc_sublist", value: false });
                form.commitLine({ sublistId: "custpage_lrc_sublist" });
            }
        }
    };
    exports.fieldChanged = fieldChanged;
    function SearchInstallments() {
        var consulta = []; //Consulta será o resultado final das search retornadas em uma lista de objetos    
        search_1.default.create({
            type: "installment",
            filters: [["custrecord_rsc_cnab_inst_status_ls", "IS", "2"]],
            columns: [
                "duedate",
                "custrecord_rsc_cnab_inst_bank_ls",
                "amount",
                search_1.default.createColumn({ name: "entity", join: "transaction" }),
                search_1.default.createColumn({ name: "subsidiary", join: "transaction" }),
                search_1.default.createColumn({ name: "internalid", join: "transaction" }) //id do vendorbill
            ]
        }).run().each(function (result) {
            //Log.error("resultado da busca", result);
            var data_vencimento = String(result.getValue("duedate"));
            var banco = result.getText("custrecord_rsc_cnab_inst_bank_ls");
            var valor_total = Number(result.getValue("amount"));
            var fornecedor = result.getText({ name: "entity", join: "transaction" });
            var subsidiaria = result.getText({ name: "subsidiary", join: "transaction" });
            var id_titulo = result.id;
            var obj = {
                "data_vencimento": data_vencimento,
                "banco": banco,
                "valor_total": valor_total,
                "fornecedor": fornecedor,
                "subsidiaria": subsidiaria,
                "id_titulo": id_titulo
            };
            consulta.push(obj);
            return true;
        });
        return consulta;
    }
    exports.SearchInstallments = SearchInstallments;
    function SepararPorSub(lista) {
        var new_list = [];
        new_list.push({ "subsidiaria": lista[0]["subsidiaria"], "banco": lista[0]["banco"], "valor_total": Number(lista[0]["valor_total"]) });
        var j;
        for (var i = 1; i < lista.length; i++) {
            j = 0;
            while (j < new_list.length && lista[i]["subsidiaria"] != new_list[j]["subsidiaria"]) {
                j++;
            }
            if (j >= new_list.length)
                new_list.push({ "subsidiaria": lista[i]["subsidiaria"], "banco": lista[i]["banco"], "valor_total": Number(lista[i]["valor_total"]) });
            else
                new_list[j]["valor_total"] += Number(lista[i]["valor_total"]);
        }
        return new_list;
    }
    exports.SepararPorSub = SepararPorSub;
    function PegarCnabsParaDetalhamento(lista, sub) {
        var show_list = [];
        for (var i = 0; i < lista.length; i++) {
            if (sub == lista[i]["subsidiaria"]) {
                //console.log("subsidiarias pareadas");
                show_list.push({
                    "subsidiaria": lista[i]["subsidiaria"],
                    "id_titulo": lista[i]["id_titulo"],
                    "fornecedor": lista[i]["fornecedor"],
                    "vencimento": lista[i]["data_vencimento"],
                    "valor_total": lista[i]["valor_total"]
                });
            }
        }
        return show_list;
    }
    exports.PegarCnabsParaDetalhamento = PegarCnabsParaDetalhamento;
    function buscaCNABs() {
        var form = currentRecord_1.default.get();
        //Removendo as linhas da sublista
        var total_linhas_detalhes = form.getLineCount({ sublistId: "custpage_lrc_detalhes" });
        for (var i = 0; i < total_linhas_detalhes; i++) {
            form.removeLine({ sublistId: "custpage_lrc_detalhes", line: 0 });
        }
        var sub_selecionada;
        //puxa a info do SELECT BOX (selecione a subsidiaria para detalhamento)
        //Validação do filto de datas
        var inicial_date = form.getValue({ fieldId: "custpage_lrc_idate" });
        var final_date = form.getValue({ fieldId: "custpage_lrc_fdate" });
        var vid = inicial_date === null || inicial_date === void 0 ? void 0 : inicial_date.valueOf();
        var vfd = final_date === null || final_date === void 0 ? void 0 : final_date.valueOf();
        //Pexando as subsidiarias selecionadas
        var total_linhas_sublist = form.getLineCount({ sublistId: "custpage_lrc_sublist" });
        for (var i = 0; i < total_linhas_sublist; i++) {
            form.selectLine({ sublistId: "custpage_lrc_sublist", line: i });
            var check = form.getCurrentSublistValue({ sublistId: "custpage_lrc_sublist", fieldId: "custpage_lrc_sublist_checkbox" });
            if (check)
                sub_selecionada = form.getCurrentSublistText({ sublistId: "custpage_lrc_sublist", fieldId: "custpage_lrc_sublist_subsidiaria" });
            else
                sub_selecionada = undefined;
            console.log(sub_selecionada);
            var lista_detalhes = PegarCnabsParaDetalhamento(SearchInstallments(), sub_selecionada);
            //Carregamento da informações para o formulario
            if (vid && vfd) { //Se o usuario colocou a data de filtro
                for (var j = 0; j < lista_detalhes.length; j++) {
                    var data_vencimento = TrasformarStringEmData(String(lista_detalhes[j]["vencimento"])); //passando string para DATE
                    if (data_vencimento.valueOf() > vid && data_vencimento.valueOf() < vfd) { //comparando as datas
                        form.selectNewLine({ sublistId: "custpage_lrc_detalhes" });
                        form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_subsidiaria", value: lista_detalhes[j]["subsidiaria"] });
                        form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_id", value: Number(lista_detalhes[j]["id_titulo"]) });
                        form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_fornecedor", value: lista_detalhes[j]["fornecedor"] });
                        form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_vencimento", value: lista_detalhes[j]["vencimento"] });
                        form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_valor", value: lista_detalhes[j]["valor_total"] });
                        form.commitLine({ sublistId: "custpage_lrc_detalhes" });
                    }
                }
            }
            else { //se o usuario n colocou a data de filtro
                for (var j = 0; j < lista_detalhes.length; j++) {
                    form.selectNewLine({ sublistId: "custpage_lrc_detalhes" });
                    form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_subsidiaria", value: lista_detalhes[j]["subsidiaria"] });
                    form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_id", value: Number(lista_detalhes[j]["id_titulo"]) });
                    form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_fornecedor", value: lista_detalhes[j]["fornecedor"] });
                    form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_vencimento", value: lista_detalhes[j]["vencimento"] });
                    form.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_valor", value: lista_detalhes[j]["valor_total"] });
                    form.commitLine({ sublistId: "custpage_lrc_detalhes" });
                }
            }
            lista_detalhes.splice(0, lista_detalhes.length);
        }
    }
    exports.buscaCNABs = buscaCNABs;
    function Aprovar() {
        var form = currentRecord_1.default.get();
        var lista_de_ids = [];
        //if(form.getValue({fieldId: "custpage_lrc_aprovador1"}) && form.getValue({fieldId: "custpage_lrc_aprovador2"})){
        var total_linhas_sublista = form.getLineCount({ sublistId: "custpage_lrc_detalhes" });
        //verifica quais linhas da sublista tem a checkbox selecionada (valor true)
        for (var i = 0; i < total_linhas_sublista; i++) {
            form.selectLine({ line: i, sublistId: "custpage_lrc_detalhes" });
            var checkBox = form.getCurrentSublistValue({ fieldId: "custpage_lrc_detalhes_checkbox", sublistId: "custpage_lrc_detalhes" });
            if (checkBox) {
                lista_de_ids.push(form.getCurrentSublistValue({ fieldId: "custpage_lrc_detalhes_id", sublistId: "custpage_lrc_detalhes" }));
            }
        }
        console.log(lista_de_ids);
        var lista_controllers = [];
        search_1.default.create({
            type: "customrecord_rsc_cnab_controller",
            columns: ["custrecord_rsc_cnab_cont_installments_ds", "custrecord_rsc_cnab_cont_file_ls"]
        }).run().each(function (result) {
            var id_parcelas = String(result.getValue("custrecord_rsc_cnab_cont_installments_ds"));
            var array_ids = id_parcelas.split(",");
            for (var i = 0; i < array_ids.length; i++) {
                if (lista_de_ids.indexOf(array_ids[i]) != -1 && lista_controllers.indexOf(result.id) == -1) {
                    console.log("Id controller: ", result.id, "Array: ", array_ids);
                    lista_controllers.push(result.id);
                }
            }
            return true;
        });
        var registro_personalizado = record_1.default.load({
            type: "customrecord_lrc_confirm_aprov_cnab",
            id: "1"
        });
        console.log(registro_personalizado.getValue({ fieldId: "name" }));
        registro_personalizado.setValue({ fieldId: "custrecord_lrc_lista_id_file", value: lista_controllers });
        registro_personalizado.save();
        var myUrl = url_1.default.resolveScript({
            scriptId: "customscript_lrc_suitlet2cnab_pablo",
            deploymentId: "customdeploy_lrc_suitlet2cnab_pablo"
        });
        console.log(myUrl);
        window.location.replace(myUrl);
        //}
        return;
    }
    exports.Aprovar = Aprovar;
    function TrasformarStringEmData(data) {
        var dia = data.slice(0, 2);
        var mes = data.slice(3, 5);
        var ano = data.slice(6);
        var str = ano + '-' + mes + '-' + dia;
        var date = new Date(str);
        return date;
    }
    exports.TrasformarStringEmData = TrasformarStringEmData;
});
