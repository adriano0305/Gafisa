/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */

const custPage = 'custpage_rsc_';

define(['N/file', 'N/log', 'N/query', 'N/record', 'N/search', 'N/ui/serverWidget'], (file, log, query, record, search, serverWidget) => {
const remold = (array) => {
    var arrayLancamentos = [];

    for (var prop in array) {
        if (arrayLancamentos.length > 0) {
            const result = arrayLancamentos.find(lancamento => lancamento.id === array[prop].id && lancamento.expenseaccount === array[prop].expenseaccount);

            if (result) {
                log.audit('Finded!', result);
            } else {
                arrayLancamentos.push({
                    id: array[prop].id,
                    tranid: array[prop].tranid,
                    trandate: array[prop].trandate,
                    custbody_ref_parcela: array[prop].custbody_ref_parcela,
                    expenseaccount: array[prop].expenseaccount,
                    memo: array[prop].memo,
                    debitforeignamount: array[prop].debitforeignamount,
                    creditforeignamount: array[prop].creditforeignamount,
                    location: array[prop].location
                });
            }
        } else {
            arrayLancamentos.push({
                id: array[prop].id,
                tranid: array[prop].tranid,
                trandate: array[prop].trandate,
                custbody_ref_parcela: array[prop].custbody_ref_parcela,
                expenseaccount: array[prop].expenseaccount,
                memo: array[prop].memo,
                debitforeignamount: array[prop].debitforeignamount,
                creditforeignamount: array[prop].creditforeignamount,
                location: array[prop].location
            });
        }
    }

    return arrayLancamentos;
}

const localizarLancamentos = (idFI) => {
    log.audit('localizarLancamentos', {idFI: idFI});

    var arrayLancamentos = [];

    var sql = "SELECT t.id, t.tranid, t.trandate, t.custbody_ref_parcela, "+
    "tl.expenseaccount, tl.memo, tl.debitforeignamount, tl.creditforeignamount, tl.location "+
    "FROM transaction as t "+
    "INNER JOIN transactionline AS tl ON (tl.transaction = t.id) "+
    "WHERE t.custbody_ref_parcela = ? ";

    var consulta = query.runSuiteQL({
        query: sql,
        params: [idFI]
    });

    var sqlResults = consulta.asMappedResults();  

    var fileObj = file.create({
        name: 'arrayLancamentos.txt',
        fileType: file.Type.PLAINTEXT,
        folder: 704, // SuiteScripts > teste > Arquivos
        contents: JSON.stringify(sqlResults)
    });

    var fileObjId = fileObj.save();

    if (sqlResults.length > 0) {
        log.audit('sqlResults', sqlResults);

        for (i=0; i<sqlResults.length; i++) {
            arrayLancamentos.push({
                id: sqlResults[i].id,
                tranid: sqlResults[i].tranid,
                trandate: sqlResults[i].trandate,
                custbody_ref_parcela: sqlResults[i].custbody_ref_parcela,
                expenseaccount: sqlResults[i].expenseaccount,
                memo: sqlResults[i].memo,
                debitforeignamount: sqlResults[i].debitforeignamount,
                creditforeignamount: sqlResults[i].creditforeignamount,
                location: sqlResults[i].location
            });
        }
    }

    arrayLancamentos = arrayLancamentos.filter(function (dados) {
        return !this[JSON.stringify(dados)] && (this[JSON.stringify(dados)] = true);
    }, Object.create(null));

    arrayLancamentos = [...new Set(arrayLancamentos)];
    
    // var fileObj = file.create({
    //     name: 'arrayLancamentos.txt',
    //     fileType: file.Type.PLAINTEXT,
    //     folder: 704, // SuiteScripts > teste > Arquivos
    //     contents: JSON.stringify(arrayLancamentos)
    // });

    // var fileObjId = fileObj.save();
    // log.audit('fileObjId: '+fileObjId, {arrayParcelas: arrayParcelas});
    arrayLancamentos = remold(arrayLancamentos);
    log.audit('arrayLancamentos', arrayLancamentos);

    return arrayLancamentos;
}

const sublistaLancamentos = (form, idFI) => {
    log.audit('sublistaLancamentos', {form: form, idFI: idFI});

    // Guia Lançamentos
    const guia_fluxo_lancamentos = form.addTab({
        id: custPage+'guia_fluxo_lancamentos',
        label: 'Contabilidade'
    });

    // Sublista Lançamentos
    const listaLancamentos = form.addSublist({
        id: custPage+'lancamentos',
        type: 'list',
        label: 'Lançamentos',
        tab: custPage+'guia_fluxo_lancamentos'
    });

    var linhaLancamento = listaLancamentos.addField({
        id: custPage+'linha_lancamento',
        type: 'integer',
        label: '#'
    });

    var tranid = listaLancamentos.addField({
        id: custPage+'tranid',
        type: 'text',
        label: 'Tranid'
    });

    var data = listaLancamentos.addField({
        id: custPage+'data',
        type: 'date',
        label: 'Data'
    });

    var conta = listaLancamentos.addField({
        id: custPage+'conta',
        type: 'select',
        label: 'Conta',
        source: 'account'
    });

    conta.updateDisplayType({
        displayType: serverWidget.FieldDisplayType.INLINE
    });

    var debito = listaLancamentos.addField({
        id: custPage+'debito',
        type: 'currency',
        label: 'Débito'
    });

    var credito = listaLancamentos.addField({
        id: custPage+'credito',
        type: 'currency',
        label: 'Crédito'
    });
    
    var memorando = listaLancamentos.addField({
        id: custPage+'memorando',
        type: 'text',
        label: 'Memorando'
    });

    var localidade = listaLancamentos.addField({
        id: custPage+'localidade',
        type: 'select',
        label: 'Localidade',
        source: 'location'
    });

    localidade.updateDisplayType({
        displayType: serverWidget.FieldDisplayType.INLINE
    });

    var lancamentos = localizarLancamentos(idFI);

    if (lancamentos.length > 0) {
        for (i=0; i<lancamentos.length; i++) {
            listaLancamentos.setSublistValue({
                id: linhaLancamento.id,
                line: i,
                value: i+1
            });

            listaLancamentos.setSublistValue({
                id: tranid.id,
                line: i,
                value: lancamentos[i].tranid
            });

            listaLancamentos.setSublistValue({
                id: data.id,
                line: i,
                value: lancamentos[i].trandate
            });

            listaLancamentos.setSublistValue({
                id: conta.id,
                line: i,
                value: lancamentos[i].expenseaccount
            });

            listaLancamentos.setSublistValue({
                id: debito.id,
                line: i,
                value: lancamentos[i].debitforeignamount
            });

            listaLancamentos.setSublistValue({
                id: credito.id,
                line: i,
                value: lancamentos[i].creditforeignamount
            });

            listaLancamentos.setSublistValue({
                id: memorando.id,
                line: i,
                value: lancamentos[i].memo
            });

            listaLancamentos.setSublistValue({
                id: localidade.id,
                line: i,
                value: lancamentos[i].location
            });
        }
    }
}

const gerarPagamentoCliente = (dados) => {
    log.audit('gerarPagamentoCliente', dados);

    const fi = dados.newRecord;

    const objPagtoCliente = record.transform({
        fromType: 'customsale_rsc_financiamento',
        fromId: dados.newRecord.id,
        toType: 'customerpayment',
        isDynamic: true
    });

    if (objPagtoCliente) {
        log.audit('objPagtoCliente', objPagtoCliente);

        // Informações Principais
        objPagtoCliente.setValue('aracct', 122)
        .setValue('account', 19672)
        .setValue('memo', fi.getValue('memo'));

        // Classificação
        objPagtoCliente.setValue('location', fi.getValue('location'))
        .setValue('class', fi.getValue('class'));

        // Dados dos Contratos
        objPagtoCliente.setValue('custbodyrsc_tpparc', fi.getValue('custbodyrsc_tpparc'));

        var linhasFaturas = objPagtoCliente.getLineCount('apply');

        if (linhasFaturas > 0) {
            for (var line = 0; line < linhasFaturas; line++) {
                objPagtoCliente.selectLine('apply', line);

                var doc = objPagtoCliente.getCurrentSublistValue('apply', 'doc');

                if (doc == fi.id) {
                    log.audit('Iguais!', {doc: doc, fiId: fi.id});
                    objPagtoCliente.setCurrentSublistValue('apply', 'apply', true);
                }
            }            
        }

        var idPagtoCliente = objPagtoCliente.save({'enableSourcing': true, 'ignoreMandatoryFields': true});7
        log.audit('fi: '+fi.id, 'idPagtoCliente: '+idPagtoCliente);
    }
}

const afterSubmit = (context) => {
    log.audit('afterSubmit', context);

    const registroAtual = context.newRecord;

    const memo = registroAtual.getValue('memo');

    const tipoParcela = registroAtual.getValue('custbodyrsc_tpparc');

    // if (tipoParcela == 1 || memo == 'Ato') {
    //     log.audit('memo: '+memo, 'tipoParcela: '+tipoParcela);

    //     var pagtosAplicados = 0;

    //     search.create({type: "customerpayment",
    //         filters: [
    //            ["type","anyof","CustPymt"], "AND", 
    //            ["appliedtotransaction.internalid","anyof",registroAtual.id]
    //         ],
    //         columns: [
    //             "tranid","total",
    //             search.createColumn({name: "datecreated", sort: search.Sort.ASC, label: "Data da criação"})
    //         ]
    //     }).run().each(function (result) {
    //         log.audit('result', result);
    //         pagtosAplicados += Number(result.getValue('total'));
    //     });         
    //     log.audit('pagtosAplicados', pagtosAplicados);

    //     if (pagtosAplicados == 0 || pagtosAplicados < registroAtual.getValue('total')) {
    //         // gerarPagamentoCliente(context);
    //     }       
    // }
}

const beforeLoad = (context) => {
    log.audit('afterSubmit', context);

    const novoRegistro = context.newRecord;

    const form = context.form;

    if (novoRegistro.id) {
        sublistaLancamentos(form, novoRegistro.id);
    }
}

return {
    beforeLoad: beforeLoad,
    afterSubmit: afterSubmit,
}
})