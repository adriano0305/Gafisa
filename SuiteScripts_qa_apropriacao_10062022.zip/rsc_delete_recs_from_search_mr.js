/**
 *@NApiVersion 2.x
 *@NScriptType MapReduceScript
 */
define(["N/search", "N/runtime","N/record"], function (search, runtime,record) {

      function getSavedSearchId() {
            // Obtain an object that represents the current script
            var myScript = runtime.getCurrentScript();
            // Obtain the value of the Check Box Required script parameter
            var scriptParameterValue = myScript.getParameter({
                  name: 'custscript_rsc_deleterecs_savedsearch_ls'
            });
            // return 'customsearch800';
            log.audit("Carregando saved search id:", scriptParameterValue);
            return scriptParameterValue;
      }
      function loadSavedSearch() {
            var savedSearchId = getSavedSearchId();
            var ss = search.load({
                  id: savedSearchId
            });

            return ss;
      }
      function executeSavedSearch(_search) {
            var searchResultCount = _search.runPaged().count;
            log.debug("Quantidade de registros encontrados: ", searchResultCount);
            return _search;
      }

      function getInputData() {
            var ss = loadSavedSearch();
            return executeSavedSearch(ss);
      }

      function map(context) {
            const srcResult = JSON.parse(context.value);
            //log.debug('map to remove _old', "recordtype : "+srcResult.recordType+"  "+srcResult.id);
            //log.audit("Deletando registro", srcResult.recordType + ' ' + srcResult.id + ' excluido com sucesso.');
 
            var deletedId = record.delete(
                   {
                         type: srcResult.recordType,
                         id: srcResult.id
                   });
            log.audit('Registro deletado com sucesso', "recordtype : " + srcResult.recordType + "  id: " + srcResult.id);
            //log.audit('registro excluido ', deletedId);


      }

      function reduce(context) {

      }

      function summarize(summary) {
            var type = summary.toString();
            log.audit(type,
                  '"Uso Consumido:" ' + summary.usage +
                  ', "Número de Filas:" ' + summary.concurrency +
                  ', "Quantidade de Saídas:" ' + summary.yields
            );
            var contents = '';
            summary.output.iterator().each(function (key, value) {
                  contents += (key + ' ' + value + '\n');
                  return true;
            });
            log.audit(' contents', contents);

      }

      return {
            getInputData: getInputData,
            map: map,
            summarize: summarize
      }
});
