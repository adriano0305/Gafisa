/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */




define(["N/file", "N/record", "N/runtime", "N/search", "N/query"],

    (file, record, runtime, search, query,) => {

    /**
     * Function to format date and return new date object.
     * @param {String} date
     * @returns {Date} Return formated date
     * @since 2015.2
     */
    function formatDate(date) {
            var dateToFormat = date.split('T');
            var arrayDateToFormat = dateToFormat[0].split('-');
            var dateStringToFormat = arrayDateToFormat[2] + '/' + arrayDateToFormat[1] + '/' + arrayDateToFormat[0];
            dateStringToFormat = dateStringToFormat.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            var returnDate = new Date(dateStringToFormat);
            return returnDate;
    }

    /**
     * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
     * @param {Object} inputContext
     * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
     *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
     * @param {Object} inputContext.ObjectRef - Object that references the input data
     * @typedef {Object} ObjectRef
     * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
     * @property {string} ObjectRef.type - Type of the record instance that contains the input data
     * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
     * @since 2015.2
     */
    const getInputData = (inputContext) => {
        return search.create({
            type:'customrecord_rsc_bl_emp',
            filters:[
                ['custrecord_rsc_bl_emp_int_junix', 'IS', 'T']

            ]
        })
    }
    const map = (mapContext) => {
        var req = JSON.parse(mapContext.value);
        var unidadeRecord = record.load({
            type:'customrecord_rsc_bl_emp',
            id: req.id
        })
        unidadeRecord.setValue({
            fieldId: 'custrecord_rsc_bl_emp_int_junix',
            value: false
        })
        unidadeRecord.save({
            ignoreMandatoryFields:true
        })
    }
    return {getInputData, map}
})