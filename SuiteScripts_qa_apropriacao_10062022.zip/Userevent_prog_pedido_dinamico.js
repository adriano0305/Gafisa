var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget"], function (require, exports, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    UI = __importStar(UI);
    var beforeLoad = function (ctx) {
        var form = ctx.form;
        var tab = form.addSubtab({
            id: 'custpage_lrc_itens',
            label: 'Itens'
        });
        var sublistItens = form.addSublist({
            type: UI.SublistType.INLINEEDITOR,
            id: 'custpage_lrc_item_sublist',
            label: 'Item'
        });
        sublistItens.addField({
            id: 'custpage_lrc_item',
            label: 'Item',
            type: UI.FieldType.SELECT,
            source: 'item'
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublistItens.addField({
            id: 'custpage_lrc_fornecedor',
            label: 'Fornecedor',
            type: UI.FieldType.SELECT,
            source: 'vendor'
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublistItens.addField({
            id: 'custpage_lrc_cliente',
            label: 'Cliente',
            type: UI.FieldType.SELECT,
            source: 'customer'
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublistItens.addField({
            id: 'custpage_lrc_quantidade',
            label: 'Quantidade',
            type: UI.FieldType.INTEGER,
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublistItens.addField({
            id: 'custpage_lrc_descricao',
            label: 'Descrição',
            type: UI.FieldType.TEXT,
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublistItens.addField({
            id: 'custpage_lrc_fator',
            label: 'Fator',
            type: UI.FieldType.FLOAT,
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublistItens.addField({
            id: 'custpage_lrc_valor',
            label: 'Valor',
            type: UI.FieldType.FLOAT,
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
        sublistItens.addField({
            id: 'custpage_lrc_valor_transacao',
            label: 'Valor da Transação',
            type: UI.FieldType.FLOAT,
        }).updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
    };
    exports.beforeLoad = beforeLoad;
});
