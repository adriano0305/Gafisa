/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define([], function() {      

    function beforeLoad(context) {
        var Record = context.newRecord;
        // log.debug("record", Record);

        var fieldCheck = Record.getValue({
            fieldId: 'custevent_rsc_tarefa_workflow'
        });

        var status = Record.getValue({
            fieldId: 'status'
        })

        if(context.type == context.UserEventType.VIEW && fieldCheck == true && status != 'COMPLETE'){
            var Form = context.form;    

            Form.clientScriptFileId = 13585
            var bt1 = Form.addButton({
                id: 'custpage_bt_teste',
                label: 'Aprovar PDC (Script)',
                functionName: 'updateApproveStaus(' + Record.id + ')'
            });
            log.debug('button', bt1);
        }         

    }

    function beforeSubmit(context) {
    }

    function afterSubmit(context) {
    }

    return {
        beforeLoad: beforeLoad,
        // beforeSubmit: beforeSubmit
        // afterSubmit: afterSubmit
    }
});
