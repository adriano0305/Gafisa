/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript para definir as funções da criação de modelo de requisição das tarefas de modelo de projeto
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.pageInit = void 0;
    var pageInit = function (ctx) {
        var currentRecord = ctx.currentRecord;
        currentRecord.setValue({
            fieldId: 'duedate',
            value: new Date()
        });
    };
    exports.pageInit = pageInit;
});
