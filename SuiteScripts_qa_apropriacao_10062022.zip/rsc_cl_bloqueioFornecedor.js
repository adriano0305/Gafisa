/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
define(['N/record', "N/search"], function(record, search) {

    function pageInit() {
        alert("testing")
    }

    function saveRecord(context) {
        
    }

    function validateField(ctx) {
        var currentRecord = ctx.currentRecord;
        var currentRecordType = currentRecord.type;
        var sublistId = "";
        var fieldId = "";

        log.debug('ctx'), currentRecord
        log.debug('ctx-type'), currentRecord

        if (currentRecordType == "orderpurchaserequisitions") {
            sublistId = "itens";
            fieldId = "itemvendor_display";
            alert("error caique")
        }
        else {
            alert("error caique")
        }
    }

    function fieldChanged(context) {
        
    }

    function postSourcing(context) {
        
    }

    function lineInit(context) {
        
    }

    function validateDelete(context) {
        
    }

    function validateInsert(context) {
        
    }

    function validateLine(context) {
        
    }

    function sublistChanged(context) {
        
    }

    return {
        pageInit: pageInit,
        validateField: validateField,
    }
});
