/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define(["N/record"], function(record) {
    function beforeSubmit(ctx) {
        try {
            var rec = ctx.newRecord;
            var bloco = rec.getValue('custrecord_rsc_un_emp_bloco');
            var unidade = rec.getValue('custrecord_rsc_un_emp_unidade');
            var nome = rec.getValue('name');

            if (bloco && unidade || bloco && unidade && nome){
                var get_rec = record.load({
                    type: 'customrecord_rsc_bl_emp',
                    id: bloco
                });
                var blocoString = get_rec.getValue('name');

                rec.setValue({
                    fieldId: 'name',
                    value: blocoString + ' - ' + unidade + ' / ' + nome
                });
            };

            if (bloco && !unidade){
                var get_rec = record.load({
                    type: 'customrecord_rsc_bl_emp',
                    id: bloco
                });
                var blocoString = get_rec.getValue('name');

                rec.setValue({
                    fieldId: 'name',
                    value: blocoString + ' - ' + nome
                });
            } else if (!bloco && unidade){
                rec.setValue({
                    fieldId: 'name',
                    value: unidade + ' / ' + nome
                });
            };
        }
        catch (e) {
            throw new Error('Erro inesperado, contate o desenvolvimento.')
        }
    }

    return {
        beforeSubmit: beforeSubmit
    }
});
