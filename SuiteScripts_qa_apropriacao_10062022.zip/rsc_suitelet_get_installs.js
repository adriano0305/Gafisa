/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 @author Wilson
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log"], function (require, exports, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    var onRequest = function (ctx) {
        var InvoceVedor = record_1.default.load({
            type: 'vendorbill',
            id: 73770
        });
        var installmentSub = InvoceVedor.getSublistValue({
            sublistId: 'installment',
            fieldId: 'duedate',
            line: 0
        });
        log_1.default.debug('Instala', installmentSub);
    };
    exports.onRequest = onRequest;
});
