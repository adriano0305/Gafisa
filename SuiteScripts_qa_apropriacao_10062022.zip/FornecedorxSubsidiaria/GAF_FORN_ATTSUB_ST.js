// /**
//  * @NScriptType suitelet
//  * @NApiVersion 2.0
//  * @scriptName rsc-cnab-batch-st
//  */
// define([ 'N/ui/serverWidget', 'N/task' ],

//     function( ui, task )
//     {
//         function onRequest(context)
//         {
//             var params = context.request.parameters;
//             var fornId = params.fornId
//             task.create({
//                 taskType: task.TaskType.MAP_REDUCE,
//                 scriptId: 'customscript_rsc_mr_atualsubsid',
//                 deploymentId: 'customdeploy_rsc_subsidiaria_fornecedor',
//                 params: { custscript_rsc_id_fornecedor: idfornecedor }
//             }).submit();
//         }
//     return{
//         onRequest:onRequest
//     }
// })
/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
*
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/search", "N/redirect", "N/task", "N/runtime", "N/https", "N/log"], function (require, exports, record_1, search_1, redirect_1, task_1, runtime_1, https_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    redirect_1 = __importDefault(redirect_1);
    task_1 = __importDefault(task_1);
    runtime_1 = __importDefault(runtime_1);
    https_1 = __importDefault(https_1);
    log_1 = __importDefault(log_1);
    var onRequest = function (ctx) {
        var params = ctx.request.parameters;
        var fornId = params.fornId
        task_1.default.create({
            taskType: task_1.default.TaskType.MAP_REDUCE,
            scriptId: 'customscript_rsc_mr_atualsubsid',
            //deploymentId: 'customdeploy_rsc_subsidiaria_fornecedor',
            params: { custscript_rsc_id_fornecedor: fornId }
        }).submit();
        redirect_1.default.toRecord({
            type:'vendor',
            id: fornId
        })
    };
    exports.onRequest = onRequest;
});