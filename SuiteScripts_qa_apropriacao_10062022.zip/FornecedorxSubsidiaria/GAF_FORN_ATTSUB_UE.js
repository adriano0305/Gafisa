/**
 *@NApiVersion 2.1
*@NScriptType UserEventScript
*/
define(['N/record', 'N/error'], function(record, error) {

    function beforeLoad(context) {
        var form = context.form;
        
        form.addButton({
            id: 'custpage_attSubsidiarias',
            label:'Atualizar Subsidiarias',
            functionName:'attSub'
        })
        form.clientScriptModulePath = './GAF_FORN_ATTSUB_CL.js';
    }

    return{
        beforeLoad: beforeLoad,
    }
})
