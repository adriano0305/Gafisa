/**
 *@NApiVersion 2.1
 *@NScriptType MapReduceScript
 */
define(["N/query", "N/runtime","N/record"], function (query, runtime,record) {
      

      const SCRIPTPARAMETER = 'custscript_rsc_updt_extids_mr';
      class CustomRecordQuery {
            constructor() {
                  this.scriptName = SCRIPTPARAMETER;
            }
            getSql() {
                  let ids = this.getRecordTypeIds();
                  let sql = "";
                  if (ids.length > 0) {
                        for (let i = 0; i < ids.length; i++) {
                              let id = ids[i];
                              log.debug("id["+i+"]", id);
                              sql += `SELECT '${id}' AS type, id, name, externalid `;
                              sql += `FROM ${id} `;
                              sql += `WHERE externalid IS NULL `;
                              if (parseInt(i) != parseInt((ids.length - 1))) {
                                   sql += `UNION `;
                              }
                              
                        }
                  }
                  log.debug({
                        title: "SQL",
                        details: sql
                  })
                  return sql;


            }
            getRecordTypeIds() {
                  let script = runtime.getCurrentScript().getParameter({ name: this.scriptName });
                  if (script) {
                        log.audit("scriptparameter : ", script);
                        log.audit("scriptparameter.length : ", script.length);

                        let aScripts = script.split(' ');
                        log.audit("aScript : ", aScripts);
                        log.audit("aScript.length : ", aScripts.length);

                        let scripts = script.split('\r\n');
                        log.audit("scriptparameter splits : ", scripts);
                        log.audit("scriptparameter splits length : ", scripts.length);

                        return scripts;
                  }
            }
            runSql(sql) {

                  return query.runSuiteQL({ query: sql }).asMappedResults();
            }

      }


      function getInputData() {

            let crQuery = new CustomRecordQuery();
            let sql = crQuery.getSql();
            log.audit({ title: 'getInputData', details: "running query: " + sql });
            try {
                let  data = crQuery.runSql(sql);
                log.audit({ title: 'getInputData', details: "qtde de registros "+data.length });
                return data;
            
            
            }catch(e){
                  log.error({ title: 'getInputData', details: e.message });
                  return [];
            }
            

      }

      function map(context) {
            log.audit({ title: '--- map ---- ', details: "********** map **********" });
            //let key = JSON.parse(context.key);
            let value = JSON.parse(context.value);

            //log.audit({ title: 'map keys: ', details: JSON.stringify(key)});
            
            //log.audit({ title: 'map values: ', details: JSON.stringify(value) });
            //var keyNames = Object.keys(value);
            let recordType = value.type;
            let id = value.id;
            let name = value.name;
            let updatedId = record.submitFields({
                  type: recordType,
                  id: id,
                  values: {
                        externalid: name
                  },
                  options: {
                        enableSourcing: false,
                        ignoreMandatoryFields : true
                  }
            });
            log.audit({ title: 'update record ', details: "recordType: " + recordType + " id: " + id + " name: " + name + " updatedId: " + updatedId });
            
      }

      function reduce(context) {
            log.audit({ title: '--- reduce ---- ', details: "********** reduce **********" });

      }

      function summarize(summary) {
            log.audit({ title: '--- summarize ---- ', details: "********** summarize **********" });
            let type = summary.toString();
            log.audit(type,
               '"Uso Consumido:" ' + summary.usage +
                ', "Número de Filas:" ' + summary.concurrency +
                ', "Quantidade de Saídas:" ' + summary.yields
             );

      }

      return {
            getInputData: getInputData,
            map: map,
            reduce: reduce,
            summarize: summarize
      }
});
