/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
*
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.VIEW) {
            var form = ctx.form;
            var record = ctx.newRecord;
            var liberado = record.getValue('custentity_rsc_liberado');
            if (!liberado) {
                form.addButton({
                    id: 'custpage_btt_habitesse',
                    label: "Habite-se",
                    functionName: "habite"
                });
            }
            form.clientScriptModulePath = './rsc_funcionalidade_btt_habite.js';
        }
    };
    exports.beforeLoad = beforeLoad;
});
