/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/search', 'N/query', 'N/format'],
    /**
     * @param {search} search
     * @param {query} query
     */
    (search, query, format) => {

        const get = (requestParams) => {
            log.debug({title:'Params', details:requestParams})
            const operation = requestParams.operation;
            log.debug({title: 'Resultado', details: operation})
            var data =  doAction(operation, requestParams.periodo);
            // log.debug('Data', data)
            return data
        }

        function doAction(operation, periodo){
            var retorno = []
            try {
                var lista = ["empresa", "projeto", "conta", "classtran", "saldocontabil", "unidadeeconomica", "contrato", "distrato",
                    "parcela", "pagamento", "avancoprojeto"];

                log.debug({title: 'Lista', details: lista.indexOf(operation)})
                switch (lista.indexOf(operation)) {
                    case 0:
                        log.debug({title:'Empresa Processar', details:retorno})
                        retorno = getEmpresa();
                        log.debug({title:'Retorno', details:retorno})
                        break;
                    case 1:
                        retorno = getProjeto();
                        break;
                    case 2:
                        retorno = getConta();
                        break;
                    case 3:
                        retorno = getClassTran();
                        break;
                    case 4:
                        retorno = getSaldoContabil(periodo);
                        break;
                    case 5:
                        retorno = getUnidadeEconomica();
                        break;
                    case 6:
                        retorno = getContrato();
                        break;
                    case 7:
                        retorno = getDistrato();
                        break;
                    case 8:
                        retorno = getParcela();
                        break;
                    case 9:
                        retorno = getFluxo();
                        break;
                    case 10:
                        retorno = getAvancoProjeto();
                        break;
                    default:
                        retorno = null;
                        break;
                }
            } catch (e) {
                retorno = JSON.stringify({erro: e});
            }


            return retorno;
        }

        function getEmpresa() {
            log.debug({title:'Select', details:'Entrou no processo'})
            var sql = 'subsidiary'
            var queryParams = []
            const result = selectAllRows(sql,queryParams)
            const len = result.length
            log.debug('Tamanho quem vem de subsidara', len)

            const json_result = []

            for (var i = 0; i < len; i++) {
                // log.debug('name', result[i].name)
                json_result.push({
                    cd_empresa: result[i].id,
                    ds_empresa: result[i].name

                })
            }

            // var subsidiarySearchObj = search.create({
            //     type: "subsidiary",
            //     filters:
            //         [
            //         ],
            //     columns:
            //         [
            //             search.createColumn({
            //                 name: "name",
            //                 sort: search.Sort.ASC,
            //                 label: "Name"
            //             }),
            //             search.createColumn({name: "namenohierarchy", label: "Name (no hierarchy)"})
            //         ]
            // });
            // var searchResultCount = subsidiarySearchObj.runPaged().count;
            // log.debug("subsidiarySearchObj result count",searchResultCount);

            // log.debug({title:'Select', details:'Montou select'})
            // var pagedData = subsidiarySearchObj.runPaged({
            //     pageSize: 1000
            // });
            // log.debug({title:'Select', details:'Rodou a query'})
            // var tb_stage_empresa = [];
            // // iterate the pages
            // for( var i=0; i < pagedData.pageRanges.length; i++ ) {

            //     // fetch the current page data
            //     var currentPage = pagedData.fetch(i);

            //     // and forEach() thru all results
            //     currentPage.data.forEach( function(result) {

            //         const empresa = {
            //             'cd_empresa' : result.id,
            //             'ds_empresa' : result.getValue('namenohierarchy')
            //         }

            //         tb_stage_empresa.push(empresa);

            //     });

            // }
            // log.debug({title:'Dados', details:tb_stage_empresa})



            return JSON.stringify(json_result) ;
        }

        function getProjeto() {
            log.debug({title:'Select', details:'Entrou no processo'})

            const sql = 'job'
            const queryParams = []
            const query_result = selectAllRows(sql, queryParams)
            const len = query_result.length
            log.debug('Tamanho que vem da busca', len)

            const res_json = []

            for (var  i = 0; i < len; i++) {
                res_json.push({
                    cd_projeto: query_result[i].id,
                    ds_projeto: query_result[i].altname
                })
            }


            // var jobSearchObj = search.create({
            //     type: "job",
            //     filters:
            //         [
            //             /*["custentity_rsc_spe_projeto","noneof","@NONE@"]*/
            //         ],
            //     columns:
            //         [
            //             search.createColumn({
            //                 name: "namenohierarchy",
            //                 join: "CUSTENTITY_RSC_SPE_PROJETO",
            //                 label: "Name (no hierarchy)"
            //             }),
            //             search.createColumn({name: "companyname", label: "Name (no hierarchy)"})
            //         ]
            // });
            // var searchResultCount = jobSearchObj.runPaged().count;
            // log.debug("subsidiarySearchObj result count",searchResultCount);

            // log.debug({title:'Select', details:'Montou select'})
            // var pagedData = jobSearchObj.runPaged({
            //     pageSize: 1000
            // });
            // log.debug({title:'Select', details:'Rodou a query'})
            // var tb_stage_empresa = [];
            // // iterate the pages
            // for( var i=0; i < pagedData.pageRanges.length; i++ ) {

            //     // fetch the current page data
            //     var currentPage = pagedData.fetch(i);

            //     // and forEach() thru all results
            //     currentPage.data.forEach( function(result) {

            //         const empresa = {
            //             'cd_projeto' : result.id,
            //             'ds_projeto' : result.getValue('companyname')
            //         }

            //         tb_stage_empresa.push(empresa);

            //     });

            // }
            // log.debug({title:'Dados', details:tb_stage_empresa})
            return JSON.stringify(res_json);
        }

        function getConta() {
            log.debug({title:'Select', details:'Entrou no processo'})
            var sql =  'account'
            var queryParams = []
            const query_result = selectAllRows(sql, queryParams)
            const len = query_result.length
            const res_json = []

            for (var i = 0; i < len; i++) {
                res_json.push({
                    cd_conta_contabil: query_result[i].acctnumber,
                    ds_conta_contabil: query_result[i].accountsearchdisplayname,
                    cd_conta_sintetica: query_result[i].id

                })
            }


            // var searchObj = search.create({
            //     type: "account",
            //     filters:
            //         [
            //         ],
            //     columns:
            //         [
            //             search.createColumn({
            //                 name: "name",
            //                 sort: search.Sort.ASC,
            //                 label: "Name"
            //             }),
            //             search.createColumn({name: "displayname", label: "Display Name"}),
            //             search.createColumn({name: "number", label: "Number"})
            //         ]
            // });

            // var searchResultCount = searchObj.runPaged().count;
            // log.debug("subsidiarySearchObj result count",searchResultCount);

            // log.debug({title:'Select', details:'Montou select'})
            // var pagedData = searchObj.runPaged({
            //     pageSize: 1000
            // });
            // log.debug({title:'Select', details:'Rodou a query'})
            // var tb_stage_empresa = [];
            // // iterate the pages
            // for( var i=0; i < pagedData.pageRanges.length; i++ ) {

            //     // fetch the current page data
            //     var currentPage = pagedData.fetch(i);

            //     // and forEach() thru all results
            //     currentPage.data.forEach( function(result) {

            //         const empresa = {
            //             'cd_conta_contabil' : result.getValue('number'),
            //             'ds_conta_contabil' : result.getValue('displayname'),
            //             'cd_conta_sintetica' :result.id
            //         }

            //         tb_stage_empresa.push(empresa);

            //     });

            // }
            // log.debug({title:'Dados', details:tb_stage_empresa})
            return JSON.stringify(res_json);
        }

        function getClassTran(){
            log.debug({title:'Select', details:'Entrou no processo'})
            const sql = 'SELECT  projecttask.id, fullname FROM projecttask INNER JOIN job ON (projectTask.project = job.id) WHERE job.custentity_rsc_spe_projeto IS NOT NULL'
            const queryParams = []
            const query_result = selectAllRows(sql, queryParams)
            const len = query_result.length
            log.debug('Tamanho da Busca do Query', len)
            const res_json = []
            for (var i = 0; i < len; i++) {
                res_json.push({
                    cd_centro_custo: query_result[i].id,
                    ds_centro_custo: query_result[i].fullname
                })
            }



            // var jobSearchObj = search.create({
            //     type: "projecttask",
            //     filters:
            //         [
            //             ["job.custentity_rsc_spe_projeto","noneof","@NONE@"]
            //         ],
            //     columns:
            //         [
            //             search.createColumn({
            //                 name: "id",
            //                 sort: search.Sort.ASC,
            //                 label: "ID"
            //             }),
            //             search.createColumn({name: "title", label: "Name"})
            //         ]
            // });
            // var searchResultCount = jobSearchObj.runPaged().count;
            // log.debug("subsidiarySearchObj result count",searchResultCount);

            // log.debug({title:'Select', details:'Montou select'})
            // var pagedData = jobSearchObj.runPaged({
            //     pageSize: 1000
            // });
            // log.debug({title:'Select', details:'Rodou a query'})
            // var fields = [];
            // // iterate the pages
            // for( var i=0; i < pagedData.pageRanges.length; i++ ) {

            //     // fetch the current page data
            //     var currentPage = pagedData.fetch(i);

            //     // and forEach() thru all results
            //     currentPage.data.forEach( function(result) {

            //         const centro_custo = {
            //             cd_centro_custo: result.id,
            //             ds_centro_custo: result.getValue('title')
            //         }

            //         fields.push(centro_custo);

            //     });

            // }
            // log.debug({title:'Dados', details:fields})
            return JSON.stringify(res_json);

        }

        function getSaldoContabil(periodo){
            var periodosplited = periodo.split('');
            var ano = ''
            var mes = ''
            for(var i = 0; i < 4; i++){
                ano += periodosplited[i]
            }
            for(var i = 4; i < periodosplited.length; i++){
                mes += periodosplited[i]
            }
            var data = new Date(ano, mes-1, 1)
            data = format.format({ value: data, type: format.Type.DATE });
            log.debug('data]', data)
            var idperiodo = 0;
            var periodoSearch = search.create({
                type:'accountingperiod',
                filters:[
                    ['isquarter','IS', 'F']
                ],
                columns:[
                    'startdate'
                ]
            }).run().each(function (result){
                var startdate = result.getValue('startdate');
                if(startdate == data){
                    idperiodo = result.id
                }
                log.debug('startdate',startdate)
                return true
            })
            // log.debug('periodoSearch[0]', periodoSearch[0])
            log.debug('idperiodo',idperiodo)
            if(idperiodo != 0){ 
                var sql = 'select transactionline.subsidiary cd_empresa,\n' +
                    '\ttransaction.custbody_rsc_projeto_obra_gasto_compra cd_projeto,\n' +
                    '\taccount.acctnumber cd_conta_contabil, \n' +
                    '\t\'01\' cd_livro, \n' +
                    '\ttransactionline.class cd_centro_custo,\n' +
                    '\tsum(transactionanterior.vl_saldo_inicial) vl_saldo_inicial, \n' +
                    '\tsum(transactionaccountingline.debit) vl_debito,\n' +
                    '\tsum(transactionaccountingline.credit) vl_credito,\n' +
                    '\tsum(transactionaccountingline.amount) vl_saldo_final, \n' +
                    '\tBUILTIN.DF(transaction.postingperiod)  periodoanterior\n' +
                    'from transactionaccountingline\n' +
                    'join transaction on  transaction.id = transactionaccountingline.transaction \n' +
                    'join transactionline on transaction.id = transactionline.transaction \n' +
                    'join account on account.id = transactionaccountingline.account\n' +
                    'left join (select \tc.subsidiary cd_empresa,\n' +
                    '\t\t\t\tb.custbody_rsc_projeto_obra_gasto_compra cd_projeto,\n' +
                    '\t\t\t\td.acctnumber cd_conta_contabil, \n' +
                    '\t\t\t\tc.class cd_centro_custo,\n' +
                    '\t\t\t\tb.postingperiod,\t\n' +
                    '\t\t\t\tsum(a.amount) vl_saldo_inicial\n' +
                    '\t\tfrom \ttransactionaccountingline a, transaction b, transactionline c, account d\n' +
                    '\t\twhere \tb.id = a.transaction \n' +
                    '\t\t\tand b.id = c.transaction \n' +
                    '\t\t\tand d.id = a.account \n' +
                    '\t\t\tand c.mainline = \'T\' \n' +
                    '\t\tgroup by \n' +
                    '\t\t\t\td.acctnumber, \n' +
                    '\t\t\t\tb.postingperiod, \n' +
                    '\t\t\t\tc.subsidiary,\n' +
                    '\t\t\t\tb.custbody_rsc_projeto_obra_gasto_compra,\n' +
                    '\t\t\t\tc.class ) \n' +
                    '\t\ttransactionanterior on transactionanterior.cd_empresa = transactionline.subsidiary\n' +
                    '\t\t\t\t\t\tand transactionanterior.cd_projeto = transaction.custbody_rsc_projeto_obra_gasto_compra\n' +
                    '\t\t\t\t\t\tand transactionanterior.cd_conta_contabil = account.acctnumber \n' +
                    '\t\t\t\t\t\tand transactionanterior.cd_centro_custo = transactionline.class\n' +
                    '\t\t\t\t\t\tand transactionanterior.postingperiod < transaction.postingperiod \n' +
                    'where transactionline.mainline = \'T\' \n' +
                    'and transaction.postingperiod = ' + idperiodo +'\n'+
                    'group by \n' +
                    '\taccount.acctnumber, \n' +
                    '\tBUILTIN.DF(transaction.postingperiod), \n' +
                    '\ttransactionline.subsidiary,\n' +
                    '\ttransaction.custbody_rsc_projeto_obra_gasto_compra,\n' +
                    'transactionline.class';
                log.debug('sql', sql)

                var queryParams = [];

                var queryResults = selectAllRows(sql, queryParams);
                log.debug('Query Reuslt', queryResults)
                var retorno = [];
                var records = queryResults;
                // If records were returned...
                if ( records.length > 0 ) {

                    // Add the records to the sublist...
                    for (r = 0; r < records.length; r++) {
                        // Get the record.
                        var record = records[r];
                        var estrutura = {
                            cd_empresa: record['cd_empresa'],
                            cd_projeto: record['cd_projeto'],
                            cd_conta_contabil: record['cd_conta_contabil'],
                            cd_livro: record['cd_livro'],
                            cd_centro_custo: record['cd_centro_custo'],
                            vl_saldo_inicial: record['vl_saldo_inicial'],
                            vl_debito: record['vl_debito'],
                            vl_credito: record['vl_credito'],
                            vl_saldo_final: record['vl_saldo_final'],
                            periodo: record['periodoanterior']
                        }
                        retorno.push(estrutura);
                    }
                }
                return JSON.stringify(retorno);
            }else{
                return "Periodo Contábel Inválido"
            }
        }

        function getUnidadeEconomica(){
            var sql = 'select * from customrecord_rsc_unidades_empreendimento'
            var queryParams = [];
            var queryResult = selectAllRows(sql, queryParams);
            const len = queryResult.length
            log.debug('Tamanho da query', len)

            var retorno = [];

            for (var i = 0; i < len; i++) {
                retorno.push({
                    cd_projeto: queryResult[i].id,
                    cd_obra_bloco: queryResult[i].custrecord_rsc_un_emp_bloco,
                    ds_obra_bloco: null,
                    nr_unidade: queryResult[i].custrecord_rsc_un_emp_unidade,
                    vl_area_comum_coberta: null,
                    vl_area_privativa_coberta: null,
                    vl_area_comum_descoberta: null,
                    vl_fracao_ideal: queryResult[i].custrecord_rsc_un_emp_fracao,
                    ds_status: queryResult[i].custrecord_rsc_un_emp_status,
                    ds_tipo: null,
                    nr_contrato: queryResult[i].custrecord_rsc_un_emp_nr_contrato,
                    dt_venda: null,
                    ds_tipologia: null,
                    vl_estoque: queryResult[i].custrecord_rsc_un_emp_vl_estoque,
                    vl_coef_aprop: queryResult[i].custrecord_rsc_un_emp_coef_aprop
                })

            }

            // var retorno = [];
            // var estrutura = {
            //     cd_projeto: 'modelo',
            //     cd_obra_bloco: 'Descrição Teste',
            //     ds_obra_bloco: 'Descrição Teste',
            //     nr_unidade: 'Descrição Teste',
            //     vl_area_comum_coberta: 'Descrição Teste',
            //     vl_area_privativa_coberta: 'Descrição Teste',
            //     vl_area_comum_descoberta: 'Descrição Teste',
            //     vl_fracao_ideal: 'Descrição Teste',
            //     ds_status: 'Descrição Teste',
            //     ds_tipo: 'Descrição Teste',
            //     nr_contrato: 'Descrição Teste',
            //     dt_venda: 'Descrição Teste',
            //     vl_venda: 'Descrição Teste',
            //     ds_tipologia: 'Descrição Teste',
            //     vl_estoque: 'Descrição Teste',
            //     vl_coef_aprop: 'Descrição Teste'
            // }
            // retorno.push(estrutura);

            return JSON.stringify(retorno);
        }

        function getContrato(){
            log.debug({title:'Select', details:'Entrou no processo'})

            const sql = "select custrecord_rsc_un_emp_projeto cd_projeto, custrecord_rsc_un_emp_bloco cd_obra_bloco, custrecord_rsc_un_emp_unidade nr_unidade, custbody_rsc_vlr_venda vl_venda, custbody_rsc_data_venda dt_venda, custbody_lrc_numero_contrato  nr_contrato from customrecord_rsc_unidades_empreendimento a\n" +
                "join transaction b on a.custrecord_rsc_un_emp_nr_contrato = b.id\n" +
                "where custbody_rsc_status_contrato = 2\n"
            const queryParams = []
            const query_result = selectAllRows(sql, queryParams)
            log.debug('Query', query_result)
            const len = query_result.length
            log.debug('Tamaho que vem do Query', len)

            const res_json = []

            for (var i=0; i < len; i++) {
                res_json.push({
                    cd_projeto: query_result[i].cd_projeto,
                    cd_obra_bloco: query_result[i].cd_obra_bloco,
                    nr_unidade: query_result[i].nr_unidade,
                    dt_venda: query_result[i].dt_venda,
                    vl_venda: query_result[i].vl_venda,
                    nr_contrato: query_result[i].nr_contrato
                })
            }

            return JSON.stringify(res_json);

        }

        function getDistrato(){
            log.debug({title:'Select', details:'Entrou no processo'})

            const sql = "select custrecord_rsc_un_emp_projeto cd_projeto, custrecord_rsc_un_emp_bloco cd_obra_bloco, " +
                "custrecord_rsc_un_emp_unidade nr_unidade, custbody_rsc_vlr_venda vl_venda, custbody_rsc_data_venda dt_venda," +
                " custbody_lrc_numero_contrato  nr_contrato from customrecord_rsc_unidades_empreendimento a\n" +
                "join transaction b on a.custrecord_rsc_un_emp_nr_contrato = b.id\n" +
                "where custbody_rsc_status_contrato = 3\n"
            const queryParams = []

            const query_result = selectAllRows(sql, queryParams)
            const len = query_result.length
            log.debug('Tamanho da query', len)

            const res_json = []

            for (var i = 0; i < len; i++) {
                res_json.push({
                    cd_projeto: query_result[i].cd_projeto,
                    cd_obra_bloco: query_result[i].cd_obra_bloco,
                    nr_unidade: query_result[i].nr_unidade,
                    dt_venda: query_result[i].dt_venda,
                    vl_venda: query_result[i].vl_venda,
                    nr_contrato: query_result[i].nr_contrato
                })
            }
            return JSON.stringify(res_json);
        }

        function getParcela(){

            var sql = 'select custrecord_rsc_un_emp_projeto cd_projeto, custrecord_rsc_un_emp_bloco cd_obra_bloco, ' +
                'custrecord_rsc_un_emp_unidade nr_unidade, b.custbody_lrc_numero_contrato  nr_contrato , ' +
                'c.custbody_lrc_tipo_parcela ds_tipo_parcela, c.duedate dt_vencimento, c.foreigntotal vl_parcela, ' +
                'c.custbody_lrc_vendor_parcela_data_pag dt_pagamento\n' +
                'from customrecord_rsc_unidades_empreendimento a \n' +
                'join transaction b on a.custrecord_rsc_un_emp_nr_contrato = b.id \n' +
                'join transaction c on b.id = c.custbody_lrc_fatura_principal\n' +
                'where b.custbody_rsc_status_contrato = 2';
            var queryParams = []
            const query_result = selectAllRows(sql, queryParams)
            const len = query_result.length
            log.debug('Tamanho que vem da Query', len)
            const res_json = []
            for (var i = 0; i < len; i++) {
                res_json.push({
                    cd_projeto:  query_result[i].cd_projeto,
                    cd_obra_bloco_bloco: query_result[i].cd_obra_bloco_bloco,
                    nr_unidade: query_result[i].nr_unidade,
                    nr_contrato: query_result[i].nr_contrato,
                    ds_tipo_parcela: query_result[i].ds_tipo_parcela,
                    dt_vencimento: query_result[i].dt_vencimento,
                    vl_parcela: query_result[i].vl_parcela,
                    dt_pagamento: query_result[i].dt_pagamento
                });

            };


            return JSON.stringify(res_json);
        }

        function getFluxo(){
            var retorno = [];
            var estrutura = {
                cd_empresa: 'modelo',
                cd_projeto: 'modelo',
                cd_centro_custo: 'Descrição Teste',
                cd_classe_financeira: 'Descrição Teste',
                dt_titulo: 'Descrição Teste',
                dt_vencimento: 'Descrição Teste',
                vl_entrada: 'Descrição Teste',
                vl_saida: 'Descrição Teste',
                dt_pagamento: 'Descrição Teste',
                ds_fluxo: 'Descrição Teste',
                ds_agente: 'Descrição Teste'
            }
            retorno.push(estrutura);

            return JSON.stringify(retorno);

        }

        function getAvancoProjeto(){
            //var retorno = [];

            //retorno.push(estrutura);
            log.debug({title:'Select', details:'Entrou no processo'})

            const sql = 'SELECT id , custentity_porcent_avanco_fisico, custentity_porcent_avanco_acumulado FROM job WHERE custentity_rsc_spe_projeto IS NOT NULL'
            const queryParams = []
            const query_result = selectAllRows(sql, queryParams)

            const len = query_result.length
            log.debug('Tamanho do query', len)

            const res_json = []

            for (var i = 0; i < len; i++) {
                res_json.push({
                    cd_projeto: query_result[i].id,
                    pc_avanco_fisico_mes: query_result[i].custentity_porcent_avanco_fisico,
                    pc_avanco_fisico_acm: query_result[i].custentity_porcent_avanco_acumulado

                })
            }


            // var jobSearchObj = search.create({
            //     type: "job",
            //     filters:
            //         [
            //             ["custentity_rsc_spe_projeto","noneof","@NONE@"]
            //         ],
            //     columns:
            //         [
            //             search.createColumn({
            //                 name: "namenohierarchy",
            //                 join: "CUSTENTITY_RSC_SPE_PROJETO",
            //                 label: "Name (no hierarchy)"
            //             }), search.createColumn({name: "custentity_porcent_avanco_fisico"}),
            //             search.createColumn({name: "custentity_porcent_avanco_acumulado"})
            //         ]
            // });
            // var searchResultCount = jobSearchObj.runPaged().count;
            // log.debug("subsidiarySearchObj result count",searchResultCount);

            // log.debug({title:'Select', details:'Montou select'})
            // var pagedData = jobSearchObj.runPaged({
            //     pageSize: 1000
            // });
            // log.debug({title:'Select', details:'Rodou a query'})
            // var tb_stage_empresa = [];
            // // iterate the pages
            // for( var i=0; i < pagedData.pageRanges.length; i++ ) {

            //     // fetch the current page data
            //     var currentPage = pagedData.fetch(i);

            //     // and forEach() thru all results
            //     currentPage.data.forEach( function(result) {

            //         const estrutura = {
            //             cd_projeto: result.id,
            //             pc_avanco_fisico_mes: result.getValue('custentity_porcent_avanco_fisico'),
            //             pc_avanco_fisico_acm: result.getValue('custentity_porcent_avanco_acumulado'),
            //         }

            //         tb_stage_empresa.push(estrutura);

            //     });

            // }
            // log.debug({title:'Dados', details:tb_stage_empresa})
            return JSON.stringify(res_json);
        }

        function selectAllRows( sql, queryParams = new Array() ) {
            try {
                var moreRows = true;
                var rows = new Array();
                var paginatedRowBegin = 1;
                var paginatedRowEnd = 5000;

                do {
                    var paginatedSQL = 'SELECT * FROM ( SELECT ROWNUM AS ROWNUMBER, * FROM (' + sql + ' ) ) WHERE ( ROWNUMBER BETWEEN ' + paginatedRowBegin + ' AND ' + paginatedRowEnd + ')';
                    var queryResults = query.runSuiteQL( { query: paginatedSQL, params: queryParams } ).asMappedResults();
                    rows = rows.concat( queryResults );
                    if ( queryResults.length < 5000 ) { moreRows = false; }
                    paginatedRowBegin = paginatedRowBegin + 5000;
                } while ( moreRows );
            } catch( e ) {
                log.error( { title: 'selectAllRows - error', details: { 'sql': sql, 'queryParams': queryParams, 'error': e } } );
            }
            return rows;
        }

        return {get}

    });
