/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define(["N/ui/serverWidget", "N/record"], function(serverWidget, record) {

    function beforeLoad(ctx) {
        var form = ctx.form
        var newRecordType = ctx.newRecord.type;

        if(newRecordType == 'projecttask' ){
            var newRecord = ctx.newRecord;
            log.debug('newRecord', newRecord);

            var get_etapa = newRecord.getValue({
                fieldId: 'custevent_rsc_etapa_projeto'
            })
            form.addField({
                id: 'custpage_rsc_etapa',
                label: 'Etapa De Projeto (temporário)',
                type: serverWidget.FieldType.TEXT
            }).updateDisplayType({
                displayType : serverWidget.FieldDisplayType.HIDDEN 
            });

            newRecord.setValue({
                fieldId: 'custpage_rsc_etapa',
                value: get_etapa
            });
        }
    }

    return {
        beforeLoad: beforeLoad
    }
});
