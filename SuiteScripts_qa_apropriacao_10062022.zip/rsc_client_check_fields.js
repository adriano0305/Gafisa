/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @author Wilson
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log", "N/query", "N/ui/dialog"], function (require, exports, record_1, log_1, query_1, dialog_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.saveRecord = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    query_1 = __importDefault(query_1);
    dialog_1 = __importDefault(dialog_1);
    var saveRecord = function (ctx) {
        var current = ctx.currentRecord;
        var recordType = current.type;
        var recordId = current.id ? current.id : null;
        // const recordId = null
        if (recordId) {
            var tableRecord = record_1.default.load({
                type: recordType,
                id: recordId
            });
            var params_1 = [{
                    transaction_type: tableRecord.getValue('custrecord_rsc_transacoes_aprovacao') ? tableRecord.getValue('custrecord_rsc_transacoes_aprovacao') : null,
                    approver: tableRecord.getValue('custrecord_rsc_aprovador_n1') ? tableRecord.getValue('custrecord_rsc_aprovador_n1') : null,
                    lvl_approver: tableRecord.getValue('custrecord_nivel_aprovador') ? tableRecord.getValue('custrecord_nivel_aprovador') : null,
                    department: tableRecord.getValue('custrecord_rsc_departamento') ? tableRecord.getValue('custrecord_rsc_departamento') : null,
                    project_name: tableRecord.getValue('custrecord_rsc_nome_projeto') ? tableRecord.getValue('custrecord_rsc_nome_projeto') : null,
                    stage_of_project: tableRecord.getValue('custrecord_rsc_etapa_projeto') ? tableRecord.getValue('custrecord_rsc_etapa_projeto') : null,
                    min_value: tableRecord.getValue('custrecord_rsc_valor_minimo') ? tableRecord.getValue('custrecord_rsc_valor_minimo') : null,
                    max_value: tableRecord.getValue('custrecord_rsc_valor_maximo') ? tableRecord.getValue('custrecord_rsc_valor_maximo') : null
                }];
            var filters_1 = Array();
            params_1.forEach(function (value) {
                if (value.transaction_type) {
                    filters_1.push("custrecord_rsc_transacoes_aprovacao=" + value.transaction_type + " AND ");
                }
                else {
                    filters_1.push("custrecord_rsc_transacoes_aprovacao IS " + value.transaction_type + " AND ");
                }
                if (value.approver) {
                    filters_1.push("custrecord_rsc_aprovador_n1=" + value.approver + " AND ");
                }
                else {
                    filters_1.push("custrecord_rsc_aprovador_n1 IS " + value.approver + " AND ");
                }
                if (value.lvl_approver) {
                    filters_1.push("custrecord_nivel_aprovador=" + value.lvl_approver + " AND ");
                }
                else {
                    filters_1.push("custrecord_nivel_aprovador IS " + value.lvl_approver + " AND ");
                }
                if (value.department) {
                    filters_1.push("custrecord_rsc_departamento=" + value.department + " AND ");
                }
                else {
                    filters_1.push("custrecord_rsc_departamento IS " + value.department + " AND ");
                }
                if (value.project_name) {
                    filters_1.push("custrecord_rsc_nome_projeto=" + value.project_name + " AND ");
                }
                else {
                    filters_1.push("custrecord_rsc_nome_projeto IS " + value.project_name + " AND ");
                }
                if (value.stage_of_project) {
                    filters_1.push("custrecord_rsc_etapa_projeto=" + value.stage_of_project + " AND ");
                }
                else {
                    filters_1.push("custrecord_rsc_etapa_projeto IS " + value.stage_of_project + " AND ");
                }
                if (value.min_value) {
                    filters_1.push("custrecord_rsc_valor_minimo=" + value.min_value + " AND ");
                }
                else {
                    filters_1.push("custrecord_rsc_valor_minimo IS " + value.min_value + " AND ");
                }
                if (value.max_value) {
                    filters_1.push("custrecord_rsc_valor_maximo=" + value.max_value);
                }
                else {
                    filters_1.push("custrecord_rsc_valor_maximo IS " + value.max_value);
                }
            });
            log_1.default.debug('Filters', filters_1);
            var sql_1 = "SELECT * FROM customrecord_rsc_aprovadores_workflow WHERE ";
            for (var i = 0; i < filters_1.length; i++) {
                sql_1 += filters_1[i];
            }
            var queryResults_1 = query_1.default.runSuiteQL({
                query: sql_1
            }).asMappedResults();
            log_1.default.debug('Qeury Result', queryResults_1);
            if (queryResults_1.length > 0) {
                if (queryResults_1[0].id != recordId) {
                    dialog_1.default.alert({
                        title: 'Erro na Edição',
                        message: 'Existem registro Iguais'
                    });
                    return false;
                }
            }
            return true;
        }
        var params = [{
                transaction_type: current.getValue('custrecord_rsc_transacoes_aprovacao') ? current.getValue('custrecord_rsc_transacoes_aprovacao') : null,
                approver: current.getValue('custrecord_rsc_aprovador_n1') ? current.getValue('custrecord_rsc_aprovador_n1') : null,
                lvl_approver: current.getValue('custrecord_nivel_aprovador') ? current.getValue('custrecord_nivel_aprovador') : null,
                department: current.getValue('custrecord_rsc_departamento') ? current.getValue('custrecord_rsc_departamento') : null,
                project_name: current.getValue('custrecord_rsc_nome_projeto') ? current.getValue('custrecord_rsc_nome_projeto') : null,
                stage_of_project: current.getValue('custrecord_rsc_etapa_projeto') ? current.getValue('custrecord_rsc_etapa_projeto') : null,
                min_value: current.getValue('custrecord_rsc_valor_minimo') ? current.getValue('custrecord_rsc_valor_minimo') : null,
                max_value: current.getValue('custrecord_rsc_valor_maximo') ? current.getValue('custrecord_rsc_valor_maximo') : null
            }];
        var filters = Array();
        params.forEach(function (value) {
            if (value.transaction_type) {
                filters.push("custrecord_rsc_transacoes_aprovacao=" + value.transaction_type + " AND ");
            }
            else {
                filters.push("custrecord_rsc_transacoes_aprovacao IS " + value.transaction_type + " AND ");
            }
            if (value.approver) {
                filters.push("custrecord_rsc_aprovador_n1=" + value.approver + " AND ");
            }
            else {
                filters.push("custrecord_rsc_aprovador_n1 IS " + value.approver + " AND ");
            }
            if (value.lvl_approver) {
                filters.push("custrecord_nivel_aprovador=" + value.lvl_approver + " AND ");
            }
            else {
                filters.push("custrecord_nivel_aprovador IS " + value.lvl_approver + " AND ");
            }
            if (value.department) {
                filters.push("custrecord_rsc_departamento=" + value.department + " AND ");
            }
            else {
                filters.push("custrecord_rsc_departamento IS " + value.department + " AND ");
            }
            if (value.project_name) {
                filters.push("custrecord_rsc_nome_projeto=" + value.project_name + " AND ");
            }
            else {
                filters.push("custrecord_rsc_nome_projeto IS " + value.project_name + " AND ");
            }
            if (value.stage_of_project) {
                filters.push("custrecord_rsc_etapa_projeto=" + value.stage_of_project + " AND ");
            }
            else {
                filters.push("custrecord_rsc_etapa_projeto IS " + value.stage_of_project + " AND ");
            }
            if (value.min_value) {
                filters.push("custrecord_rsc_valor_minimo=" + value.min_value + " AND ");
            }
            else {
                filters.push("custrecord_rsc_valor_minimo IS " + value.min_value + " AND ");
            }
            if (value.max_value) {
                filters.push("custrecord_rsc_valor_maximo=" + value.max_value);
            }
            else {
                filters.push("custrecord_rsc_valor_maximo IS " + value.max_value);
            }
        });
        log_1.default.debug('Filters else', filters);
        var sql = "SELECT * FROM customrecord_rsc_aprovadores_workflow WHERE ";
        for (var i = 0; i < filters.length; i++) {
            sql += filters[i];
        }
        var queryResults = query_1.default.runSuiteQL({
            query: sql
        }).asMappedResults();
        log_1.default.debug('Query Reuslt', queryResults.length);
        if (queryResults.length > 0) {
            var id_record_duplicate = queryResults[0].id;
            // const approver_record_duplicate = queryResults[0].custrecord_rsc_aprovador_n1
            var msg = "Esse registro j\u00E1 existe.\n\t\t\tId: " + id_record_duplicate + "\n\t\t\t";
            dialog_1.default.alert({
                title: 'Error na Criação',
                message: msg
            });
            return false;
        }
        return true;
    };
    exports.saveRecord = saveRecord;
});
