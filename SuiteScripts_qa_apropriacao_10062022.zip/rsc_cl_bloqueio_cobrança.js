/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 @Autor Caique Rocha - Runsmart
 */
define(["N/currentRecord", "N/record"], function(currentRecord, record) {


    function fieldChanged(context) {
        var currentRecord = context.currentRecord;
        var fieldId = context.fieldId

        if(fieldId == 'approvalstatus' || fieldId == 'entity'){
            var status_aprovacao = currentRecord.getValue({
                fieldId: 'approvalstatus'
            });

            var fornecedor = record.load({
                type: 'vendor',
                id: currentRecord.getValue('entity')
            });

            var status_bloqueio_fornecedor = fornecedor.getValue({
                fieldId: 'custentity_lrc_status_suspensao'
            });

            if(status_aprovacao == 2) {
                if(status_bloqueio_fornecedor == 2 || status_bloqueio_fornecedor == 3 ||
                    status_bloqueio_fornecedor == 4 || status_bloqueio_fornecedor == 5 ||
                    status_bloqueio_fornecedor == 6){
                    currentRecord.setValue({
                        fieldId: 'approvalstatus',
                        value: 1
                    });
                
                    alert("Fornecedor Suspenso")
                }   
            }
        }
    }

    return {
        fieldChanged: fieldChanged
    }
});
