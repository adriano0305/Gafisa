/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
 var retorno = [];
 define(['N/record', 'N/query', 'N/runtime', 'N/search'],
     
     (record, query, runtime, search) => {
 
         /**
          * Defines the function that is executed when a POST request is sent to a RESTlet.
          * @param {string | Object} requestBody - The HTTP request body; request body is passed as a string when request
          *     Content-Type is 'text/plain' or parsed into an Object when request Content-Type is 'application/json' (in which case
          *     the body must be a valid JSON)
          * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
          *     Object when request Content-Type is 'application/json' or 'application/xml'
          * @since 2015.2
          */
         const _post = (requestBody) => {
                 //log.debug("requestBody", requestBody);
                 //return requestBody;
                 log.debug({title:'RequestBody', details:requestBody})
                 return doAction(requestBody);
         }; 
 
         function doAction(body){
                 /**
                  * "sysCode": "1236",
            "memo": "2",
            "subsidiary": "1",
            "trandate": "08/06/2021",
            "lines": [
                {
                    "account": "121",
                    "debit": "100"
                },
                {
                    "account": "218",
                    "credit": "100"
                }
            ]
        }
                  */

                 let bd = body[0];
                 log.debug('body[0]', body[0]);
                 let bodyDetails = {
                        sysCode : bd.sysCode,
                        memo : bd.memo,
                        subsidiary : bd.subsidiary,
                        trandate : bd.trandate,
                        lines : bd.lines
                 }

             log.debug({title: 'RequestBodyDetails', details: JSON.stringify(bodyDetails)  });
        
             var retorna = []
             try {
                         body[0].data.forEach(createContabil);
                         //body.forEach(createContabil);

                         retorna = JSON.stringify({dados: retorno});
             } catch (e) {
                         retorna = JSON.stringify({erro: e.toString()});
             }
             return retorna;
         }
 
         function tratarData(data) {
                 var dataCadastro = data.split('T');
                 var dateCadastro = dataCadastro[0].split('/');
                 var cadastroData = dateCadastro[2] + '/' + dateCadastro[1] + '/' + dateCadastro[0];
                 cadastroData = cadastroData.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                 cadastroData = new Date(cadastroData);
                 return cadastroData;
         }
 
         function createContabil(element, index, array) {
                 try {
                         log.audit({title: "Lista Keys", details: Object.keys(element)});
                         var lanctoContabil = null;
                         var subsidiary = element.subsidiary;
                         if (element.erpDocument === undefined || element.erpDocument == 0) {
                                 lanctoContabil = record.create({type: "journalentry", isDynamic: false});
 
                                 Object.keys(element).forEach(function (key) {
                                         if (key != "lines"){
                                                 log.debug({title: 'Key', details: key});
                                                 log.debug({title:'Valor', details: element[key]});
                                                 var field = lanctoContabil.getField({fieldId: key});
                                                 log.debug({title: 'field', details: field});
                                                 var valor = null;
                                                 if (field.type === 'date'){
 
                                                         valor = tratarData(element[key]);
                                                 } else
                                                 {
                                                                 valor = element[key];
                                                 }
                                                 lanctoContabil.setValue({
                                                         fieldId: key,
                                                         value: valor
                                                 });
                                         }
                                 });
 
                                 var i_1 = 0;
                                 element.lines.forEach(function (line) {
                                         Object.keys(line).forEach(function (key) {
                                                 if (key != "lines"){
                                                         var field = lanctoContabil.getSublistField({sublistId: 'line', fieldId: key, line: i_1});
 
                                                         var valor = null;
                                                         if (field.type === 'date'){
                                                                 valor = new Date(line[key]);
                                                         } else
                                                         {
                                                                 log.debug({title: 'Key', details: key});
                                                                 if (key === 'account'){
                                                                         log.debug({title: 'Key Account', details: key});
                                                                         var queryResults = query.runSuiteQL({
                                                                                 query: 'select id from account where acctnumber =  ? ',
                                                                                 params: [line[key]]
                                                                         });
                                                                         var account = queryResults.asMappedResults();
                                                                         if (account.length > 0){
                                                                                 valor = account[0].id;
                                                                         }
                                                                 } else {
                                                                         valor = line[key];
                                                                 }
                                                         }
                                                         lanctoContabil.setSublistValue({
                                                                 sublistId: 'line',
                                                                 fieldId: key,
                                                                 value: valor,
                                                                 line: i_1
                                                         });
                                                         log.debug('job', element['custbody_rsc_projeto_obra_gasto_compra'])
                                                         lanctoContabil.setSublistValue({
                                                                sublistId: 'line',
                                                                fieldId: 'custcol_rsc_fieldcliente',
                                                                value: element['custbody_rsc_projeto_obra_gasto_compra'],
                                                                line: i_1
                                                        });
                                                 }
 
                                         });
                                         i_1++;
                                 });
                         } else {
                                 lanctoContabil = record.load({
                                         type: "journalentry",
                                         id: element.erpDocument,
                                         isDynamic: false
                                 })
                                 var reversalDate = element["reversaldate"].replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
 
                                 reversalDate = new Date(reversalDate);
                                 lanctoContabil.setValue({
                                         fieldId: "reversaldate",
                                         value: reversalDate
                                 });
                                 lanctoContabil.setValue({
                                         fieldId: "memo",
                                         value: element["memo"]
                                 });
 
                                 subsidiary = lanctoContabil.getValue('subsidiary');
                         }
 
                         var idNovo = lanctoContabil.save({ignoreMandatoryFields: true});
 
                         if (element.erpDocument === undefined || element.erpDocument == 0) {
                                 retorno.push({
                                         "custbody_rsc_gesplan_syscode": element.custbody_rsc_gesplan_syscode,
                                         "mensagemErro": '',
                                         "erpDocument": idNovo,
                                         "erpCompany": subsidiary
                                 });
                         }
                         else {
                                 var queryResults = query.runSuiteQL(
                                     { query:'select transaction.reversal  from transaction where type = \'Journal\' and id = ?',
                                  params: [idNovo]});
                                 var records = queryResults.asMappedResults();
                                 var idReversao = 0;
                                 // If records were returned...
                                 if ( records.length > 0 ) {
                                         // Add the records to the sublist...
                                         for (r = 0; r < records.length; r++) {
                                                 // Get the record.
                                                 var recordReversal = records[r];
                                                 idReversao = recordReversal['reversal'];
                                         }
                                 }
 
                                 retorno.push({
                                         "custbody_rsc_gesplan_syscode": element.custbody_rsc_gesplan_syscode,
                                         "mensagemErro": '',
                                         "erpDocument": idNovo,
                                         "erpCompany": subsidiary,
                                         "reversionNumber": idReversao,
                                 });
                         }
 
 
                 } catch (e) {
                         retorno.push({
                                 "custbody_rsc_gesplan_syscode": element.custbody_rsc_gesplan_syscode,
                                 "mensagemErro": e.message,
                                 "erpDocument": "",
                                 "erpCompany": element.subsidiary
                         });
 
                 }
                 var scriptObj = runtime.getCurrentScript();
                 log.debug('Remaining governance units: ' + scriptObj.getRemainingUsage());
 
         }
 
         return {
                 post : _post
                }
 
     });
 