/**
 *@NApiVersion 2.1
*@NScriptType Suitelet
*/
define(['N/error', 'N/https', 'N/log', 'N/record', 'N/redirect', 'N/search', 'N/ui/serverWidget', 'N/url'], function(error, https, log, record, redirect, search, serverWidget, url) {
function onRequest(context) {
    log.audit('onRequest', context);

    /* ******************* FIELD TYPES ****************** *
    * ■ CHECKBOX ■ CURRENCY ■ DATE ■ DATETIMETZ ■ EMAIL   *
    * ■ FILE ■ FLOAT ■ HELP ■ INLINEHTML ■ INTEGER        *
    * ■ IMAGE ■ LABEL ■ LONGTEXT ■ MULTISELECT ■ PASSPORT *
    * ■ PERCENT ■ PHONE ■ SELECT ■ RADIO ■ RICHTEXT       *
    * ■ TEXT ■ TEXTAREA ■ TIMEOFDAY ■ URL                 *
    * *************************************************** */ 

    /* ****************** SUBLIST TYPES ***************** *
    * ■ INLINEEDITOR ■ EDITOR ■ LIST ■ STATICLIST         *
    * *************************************************** */ 

    const request = context.request;
    const response = context.response;
    var parameters;
    // const parameters = JSON.parse(request.parameters.json);
    // log.audit('parameters', parameters);

    const custPage = 'custpage_rsc_';

    const form = serverWidget.createForm({
        title: 'Resumo Reparcelamento 2'
    });

    if (request.method == 'GET') {
        parameters = JSON.parse(request.parameters.json);
        log.audit('parameters', parameters);        

        var jsonReparcelamento = form.addField({
            id: custPage+'json_reparcelamento',
            type: serverWidget.FieldType.TEXTAREA,
            label: 'JSON Reparcelamento'
        });

        jsonReparcelamento.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        jsonReparcelamento.defaultValue = JSON.stringify(parameters);

        // Grupo: Dados do Reparcelamento
        var dadosReparcelamento = form.addFieldGroup({
            id: custPage+'dados_reparcelamento',
            label: 'Dados do Reparcelamento'
        });

        var totalFinanciado = form.addField({
            id: custPage+'total_financiado',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Total Financiado',
            container: custPage+'dados_reparcelamento'
        });

        totalFinanciado.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        totalFinanciado.defaultValue = parameters.saldoFinanciado;

        var totalParcelasMarcadas = form.addField({
            id: custPage+'total_parcelas_marcadas',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Total das Parcelas Marcadas',
            container: custPage+'dados_reparcelamento'
        });

        totalParcelasMarcadas.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        totalParcelasMarcadas.defaultValue = parameters.totalParcelasMarcadas;

        var custoTotal = form.addField({
            id: custPage+'custo_total',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Custo Total',
            container: custPage+'dados_reparcelamento'
        });

        custoTotal.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        custoTotal.defaultValue = parameters.custoTotal;

        var valorEntrada = form.addField({
            id: custPage+'valor_entrada',
            label: 'Valor da Entrada',
            type: serverWidget.FieldType.CURRENCY,
            container: custPage+'dados_reparcelamento'
        });

        valorEntrada.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        valorEntrada.defaultValue = parameters.valorEntrada;

        var vencimentoEntrada = form.addField({
            id: custPage+'vencimento_entrada',
            label: 'Vencimento Entrada',
            type: serverWidget.FieldType.DATE,
            container: custPage+'dados_reparcelamento'
        });

        vencimentoEntrada.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        vencimentoEntrada.defaultValue = parameters.vencimentoEntrada;

        var observacao = form.addField({
            id: custPage+'observacao',
            label: 'Observação',
            type: serverWidget.FieldType.TEXT,
            container: custPage+'dados_reparcelamento'
        });

        var efetivarApos1Pagamento = form.addField({
            id: custPage+'efetivar_apos_1_pagamento',
            label: 'Efetivar após o 1º pagamento',
            type: serverWidget.FieldType.CHECKBOX,
            container: custPage+'dados_reparcelamento'
        });

        efetivarApos1Pagamento.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.NORMAL
        });

        efetivarApos1Pagamento.defaultValue = 'F';

        var idReparcelamento2 = form.addField({
            id: custPage+'id_reparcelamento_2',
            type: serverWidget.FieldType.INTEGER,
            label: 'ID Reparcelamento 2',
            container: custPage+'dados_reparcelamento'
        });

        idReparcelamento2.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.HIDDEN
        });

        var linkReparcelamento2 = form.addField({
            id: custPage+'link_reparcelamento_2',
            type: serverWidget.FieldType.URL,
            label: 'Link Reparcelamento 2',
            container: custPage+'dados_reparcelamento'
        });

        linkReparcelamento2.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        var idTabelaEfetivacaoReparcelamento = form.addField({
            id: custPage+'id_tabela_efetivacao_reparcelamento',
            type: serverWidget.FieldType.INTEGER,
            label: 'ID Tabela Efetivação Reparcelamento',
            container: custPage+'dados_reparcelamento'
        });

        idTabelaEfetivacaoReparcelamento.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.HIDDEN
        });

        var linkTabelaEfetivacaoReparcelamento = form.addField({
            id: custPage+'link_tabela_efetivacao_reparcelamento',
            type: serverWidget.FieldType.URL,
            label: 'Link Tabela Efetivação Reparcelamento',
            container: custPage+'dados_reparcelamento'
        });

        linkTabelaEfetivacaoReparcelamento.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        var sumario = form.addField({
            id: custPage+'sumario',
            type: serverWidget.FieldType.LONGTEXT,
            label: 'sumario',
            container: custPage+'dados_reparcelamento'
        });

        sumario.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.HIDDEN
        });

        var sublistaResumoReparcelamento = form.addSublist({
            id : custPage+'sublista_resumo_reparcelamento',
            type : serverWidget.SublistType.LIST,
            label : 'Resumo do Reparcelamento'
        });

        var ano = sublistaResumoReparcelamento.addField({
            id: custPage+'ano',
            type: serverWidget.FieldType.TEXT,
            label: 'Ano'
        });

        var parcela = sublistaResumoReparcelamento.addField({
            id: custPage+'parcela',
            type: serverWidget.FieldType.DATE,
            label: 'Parcela'
        });

        var prestacao = sublistaResumoReparcelamento.addField({
            id: custPage+'prestacao',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Prestação'
        });

        var atualizarParcelas = calcularJuros(
            parameters.dataInicio.newDate,
            parameters.parcelasLiquidacao,
            parameters.valores_parcelas_recalculadas,
            parameters.unidadeCorrecao
        );

        sumario.defaultValue = JSON.stringify(atualizarParcelas);

        for (i=0; i<atualizarParcelas.length; i++) {
            sublistaResumoReparcelamento.setSublistValue({
                id: ano.id,
                line: i,
                value: parseInt(atualizarParcelas[i].ano)
            });

            sublistaResumoReparcelamento.setSublistValue({
                id: parcela.id,
                line: i,
                value: atualizarParcelas[i].parcela
            });

            sublistaResumoReparcelamento.setSublistValue({
                id: prestacao.id,
                line: i,
                value: atualizarParcelas[i].prestacao
            });
        }

        form.addSubmitButton({
            label: 'Gravar Tabela de Efetivação'
            // label: 'Gerar Reparcelamento'
        });

        form.addButton({
            id: custPage+'voltar',
            label: 'Voltar',
            functionName: 'voltar'
        });

        form.clientScriptModulePath = "./reparcelamento_cnab/rsc_resumo_reparcelamento_2_ct.js";
        
        response.writePage({
            pageObject: form
        });
    } else {
        log.audit('context POST', context);

        parameters = request.parameters;
        log.audit('parameters', parameters);

        var jsonReparcelamento = form.addField({
            id: custPage+'json_reparcelamento',
            type: serverWidget.FieldType.TEXTAREA,
            label: 'JSON Reparcelamento'
        });

        jsonReparcelamento.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.HIDDEN
        });

        jsonReparcelamento.defaultValue = JSON.stringify(parameters.custpage_rsc_json_reparcelamento);

        // Grupo: Dados do Reparcelamento
        var dadosReparcelamento = form.addFieldGroup({
            id: custPage+'dados_reparcelamento',
            label: 'Dados do Reparcelamento'
        });

        var totalFinanciado = form.addField({
            id: custPage+'total_financiado',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Total Financiado',
            container: custPage+'dados_reparcelamento'
        });

        totalFinanciado.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        totalFinanciado.defaultValue = parameters.custpage_rsc_total_financiado;

        var totalParcelasMarcadas = form.addField({
            id: custPage+'total_parcelas_marcadas',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Total das Parcelas Marcadas',
            container: custPage+'dados_reparcelamento'
        });

        totalParcelasMarcadas.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        totalParcelasMarcadas.defaultValue = parameters.custpage_rsc_total_parcelas_marcadas;

        var custoTotal = form.addField({
            id: custPage+'custo_total',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Custo Total',
            container: custPage+'dados_reparcelamento'
        });

        custoTotal.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        custoTotal.defaultValue = parameters.custpage_rsc_custo_total;

        var valorEntrada = form.addField({
            id: custPage+'valor_entrada',
            label: 'Valor da Entrada',
            type: serverWidget.FieldType.CURRENCY,
            container: custPage+'dados_reparcelamento'
        });

        valorEntrada.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        valorEntrada.defaultValue = parameters.custpage_rsc_valor_entrada;

        var vencimentoEntrada = form.addField({
            id: custPage+'vencimento_entrada',
            label: 'Vencimento Entrada',
            type: serverWidget.FieldType.DATE,
            container: custPage+'dados_reparcelamento'
        });

        vencimentoEntrada.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        vencimentoEntrada.defaultValue = parameters.custpage_rsc_vencimento_entrada;

        var efetivarApos1Pagamento = form.addField({
            id: custPage+'efetivar_apos_1_pagamento',
            label: 'Efetivar após o 1º pagamento',
            type: serverWidget.FieldType.CHECKBOX,
            container: custPage+'dados_reparcelamento'
        });

        efetivarApos1Pagamento.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        efetivarApos1Pagamento.defaultValue = parameters.custpage_rsc_efetivar_apos_1_pagamento;

        var idReparcelamento2 = form.addField({
            id: custPage+'id_reparcelamento_2',
            type: serverWidget.FieldType.INTEGER,
            label: 'ID Reparcelamento 2',
            container: custPage+'dados_reparcelamento'
        });

        idReparcelamento2.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.HIDDEN
        });

        var linkReparcelamento2 = form.addField({
            id: custPage+'link_reparcelamento_2',
            type: serverWidget.FieldType.URL,
            label: 'Link Reparcelamento 2',
            container: custPage+'dados_reparcelamento'
        });

        linkReparcelamento2.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        var enviado = form.addField({
            id: custPage+'enviado',
            type: serverWidget.FieldType.CHECKBOX,
            label: 'Enviado',
            container: custPage+'dados_reparcelamento'
        });

        enviado.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.HIDDEN
        });

        var tarefa = form.addField({
            id: custPage+'tarefa',
            type: serverWidget.FieldType.TEXT,
            label: 'Tarefa',
            container: custPage+'dados_reparcelamento'
        });

        tarefa.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.HIDDEN
        });

        var sumario = form.addField({
            id: custPage+'sumario',
            type: serverWidget.FieldType.LONGTEXT,
            label: 'sumario',
            container: custPage+'dados_reparcelamento'
        });

        sumario.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.HIDDEN
        });

        var sublistaResumoReparcelamento = form.addSublist({
            id : custPage+'sublista_resumo_reparcelamento',
            type : serverWidget.SublistType.LIST,
            label : 'Resumo do Reparcelamento'
        });

        var ano = sublistaResumoReparcelamento.addField({
            id: custPage+'ano',
            type: serverWidget.FieldType.TEXT,
            label: 'Ano'
        });

        var parcela = sublistaResumoReparcelamento.addField({
            id: custPage+'parcela',
            type: serverWidget.FieldType.DATE,
            label: 'Parcela'
        });

        var prestacao = sublistaResumoReparcelamento.addField({
            id: custPage+'prestacao',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Prestação'
        });

        parameters = JSON.parse(parameters.custpage_rsc_json_reparcelamento);
        log.audit('parameters JSON.parse', parameters);

        var atualizarParcelas = calcularJuros(
            parameters.dataInicio.newDate,
            parameters.parcelasLiquidacao,
            parameters.valores_parcelas_recalculadas,
            parameters.unidadeCorrecao
        );

        sumario.defaultValue = JSON.stringify(atualizarParcelas);

        for (i=0; i<atualizarParcelas.length; i++) {
            sublistaResumoReparcelamento.setSublistValue({
                id: ano.id,
                line: i,
                value: parseInt(atualizarParcelas[i].ano)
            });

            sublistaResumoReparcelamento.setSublistValue({
                id: parcela.id,
                line: i,
                value: atualizarParcelas[i].parcela
            });

            sublistaResumoReparcelamento.setSublistValue({
                id: prestacao.id,
                line: i,
                value: atualizarParcelas[i].prestacao
            });
        }

        form.addButton({
            id: custPage+'voltar',
            label: 'Voltar',
            functionName: 'voltar'
        });

        form.clientScriptModulePath = "./reparcelamento_cnab/rsc_resumo_reparcelamento_2_ct.js";

        response.writePage({
            pageObject: form
        });

        var reparcelamento = request.parameters.custpage_rsc_json_reparcelamento;
        reparcelamento = JSON.parse(reparcelamento);
        log.audit('reparcelamento', reparcelamento);

        const novasParcelas = request.parameters.custpage_rsc_sumario;
        log.audit('novasParcelas', novasParcelas);

        const arrayParcelas = reparcelamento.arrayParcelas;
        log.audit('arrayParcelas', arrayParcelas);

        var observacao = request.parameters.custpage_rsc_observacao;

        var gerarTabelaEfetivacao = criarTabelaEfetivacaoReparcelamento({
            reparcelamento: reparcelamento,
            novasParcelas: JSON.parse(novasParcelas),
            observacao: observacao
        });
        log.audit('gerarTabelaEfetivacao', gerarTabelaEfetivacao);

        if (gerarTabelaEfetivacao.status == 'Sucesso') {
            var idTabelaEfetivacaoReparcelamento = form.addField({
                id: custPage+'id_tabela_efetivacao_reparcelamento',
                type: serverWidget.FieldType.INTEGER,
                label: 'ID Tabela Efetivação Reparcelamento',
                container: custPage+'dados_reparcelamento'
            });

            idTabelaEfetivacaoReparcelamento.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.HIDDEN
            });

            var linkTabelaEfetivacaoReparcelamento = form.addField({
                id: custPage+'link_tabela_efetivacao_reparcelamento',
                type: serverWidget.FieldType.URL,
                label: 'Link Tabela Efetivação Reparcelamento',
                container: custPage+'dados_reparcelamento'
            });

            linkTabelaEfetivacaoReparcelamento.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            idTabelaEfetivacaoReparcelamento.defaultValue = gerarTabelaEfetivacao.idTabelaEfetivacao;

            linkTabelaEfetivacaoReparcelamento.linkText = 'Tabela de Efetivação Nº '+gerarTabelaEfetivacao.idTabelaEfetivacao;

            linkTabelaEfetivacaoReparcelamento.defaultValue = gerarTabelaEfetivacao.urlTabelaEfetivacao;

            form.addButton({
                id: custPage+'checar_status',
                label: 'Checar Status',
                functionName: 'checarStatus'
            });
        } else {
            gerarTabelaEfetivacao.msg;
        }

        // var efetivarApos1Pagamento = request.parameters.custpage_rsc_efetivar_apos_1_pagamento;
        // log.audit('efetivarApos1Pagamento', efetivarApos1Pagamento);
        
        // if (efetivarApos1Pagamento == 'T') {
        //     var idTabelaEfetivacaoReparcelamento = form.addField({
        //         id: custPage+'id_tabela_efetivacao_reparcelamento',
        //         type: serverWidget.FieldType.INTEGER,
        //         label: 'ID Tabela Efetivação Reparcelamento',
        //         container: custPage+'dados_reparcelamento'
        //     });
    
        //     idTabelaEfetivacaoReparcelamento.updateDisplayType({
        //         displayType: serverWidget.FieldDisplayType.HIDDEN
        //     });
    
        //     var linkTabelaEfetivacaoReparcelamento = form.addField({
        //         id: custPage+'link_tabela_efetivacao_reparcelamento',
        //         type: serverWidget.FieldType.URL,
        //         label: 'Link Tabela Efetivação Reparcelamento',
        //         container: custPage+'dados_reparcelamento'
        //     });

        //     linkTabelaEfetivacaoReparcelamento.updateDisplayType({
        //         displayType: serverWidget.FieldDisplayType.INLINE
        //     });

        //     var gerarTabelaEfetivacao = criarTabelaEfetivacaoReparcelamento({
        //         reparcelamento: reparcelamento,
        //         novasParcelas: JSON.parse(novasParcelas),
        //         efetivarApos1Pagamento: efetivarApos1Pagamento
        //     });

        //     if (gerarTabelaEfetivacao.status == 'Sucesso') {
        //         idTabelaEfetivacaoReparcelamento.defaultValue = gerarTabelaEfetivacao.idTabelaEfetivacao;

        //         linkTabelaEfetivacaoReparcelamento.linkText = 'Tabela de Efetivação Nº '+gerarTabelaEfetivacao.idTabelaEfetivacao;

        //         linkTabelaEfetivacaoReparcelamento.defaultValue = gerarTabelaEfetivacao.urlTabelaEfetivacao;

        //         form.addButton({
        //             id: custPage+'checar_status',
        //             label: 'Checar Status',
        //             functionName: 'checarStatus'
        //         });
        //     } else {
        //         gerarTabelaEfetivacao.msg;
        //     }
        // } else {
        //     const reparcelamento2 = record.create({
        //         type: 'customrecord_rsc_reparcelamento_2',
        //         isDynamic: true
        //     });

        //     reparcelamento2.setValue({
        //         fieldId: 'custrecord_rsc_total_financiado',
        //         value: reparcelamento.saldoFinanciado
        //     });

        //     reparcelamento2.setValue({
        //         fieldId: 'custrecord_rsc_total_parcelas_marcadas',
        //         value: reparcelamento.totalParcelasMarcadas
        //     });

        //     reparcelamento2.setValue({
        //         fieldId: 'custrecord_custo_total',
        //         value: reparcelamento.custoTotal
        //     });

        //     reparcelamento2.setValue({
        //         fieldId: 'custrecord_rsc_valor_entrada',
        //         value: reparcelamento.valorEntrada
        //     });

        //     reparcelamento2.setValue({
        //         fieldId: 'custrecord_rsc_vencimento_entrada',
        //         value: formatData(reparcelamento.vencimentoEntrada)
        //     });

        //     reparcelamento2.setValue({
        //         fieldId: 'custrecord_rsc_fatura_principal',
        //         value: reparcelamento.id_fatura_principal
        //     })

        //     reparcelamento2.setValue({
        //         fieldId: 'custrecord_rsc_enviado',
        //         value: true
        //     });

        //     reparcelamento2.setValue({
        //         fieldId: 'custrecord_rsc_status',
        //         value: 1
        //     });

        //     const reparcelamento2Id = reparcelamento2.save();
        //     log.audit('reparcelamento2Id', reparcelamento2Id);

        //     var urlReparcelamento2;

        //     if (reparcelamento2Id) {
        //         arrayParcelas.forEach(function (parcela) {
        //             const loadFinanciamentoInvoice = record.load({
        //                 type: 'customsale_rsc_financiamento',
        //                 id: parcela.id_financiamento_invoice
        //             });
        //             log.audit('Parcela Nº: '+loadFinanciamentoInvoice.getValue('tranid'), 'Atualizando reparcelamento destino...');

        //             loadFinanciamentoInvoice.setValue({
        //                 fieldId: 'custbody_rsc_reparcelamento_destino',
        //                 value: reparcelamento2Id
        //             });

        //             loadFinanciamentoInvoice.save({ignoreMandatoryFields: true});
        //         });

        //         urlReparcelamento2 = url.resolveRecord({
        //             recordType: 'customrecord_rsc_reparcelamento_2',
        //             recordId: reparcelamento2Id
        //         });

        //         idReparcelamento2.defaultValue = reparcelamento2Id;

        //         linkReparcelamento2.linkText = 'Reparcelamento Nº '+reparcelamento2Id;

        //         linkReparcelamento2.defaultValue = urlReparcelamento2;

        //         form.addButton({
        //             id: custPage+'checar_status',
        //             label: 'Checar Status',
        //             functionName: 'checarStatus'
        //         });
        //     }

        //     const json = {
        //         reparcelamento2Id: reparcelamento2Id,
        //         reparcelamento: request.parameters.custpage_rsc_json_reparcelamento,
        //         novasParcelas: novasParcelas
        //     }
        //     log.audit('json', json);

        //     // Suitelet: RSC Fatura Novas Parcelas 2 ST
        //     const responseR2 = https.post({
        //         url: 'https://5843489-sb1.extforms.netsuite.com/app/site/hosting/scriptlet.nl?script=995&deploy=1&compid=5843489_SB1&h=fc3cbe0ae05453aaef22',
        //         body: json
        //     });
        //     log.audit('code: '+responseR2.code, 'body: '+responseR2.body);

        //     if (responseR2.code == 200) {
        //         tarefa.defaultValue = responseR2.body;

        //         const loadReparcelamento2 = record.load({
        //             type: 'customrecord_rsc_reparcelamento_2',
        //             id: reparcelamento2Id,
        //             isDynamic: true
        //         });

        //         loadReparcelamento2.setValue({
        //             fieldId: 'custrecord_rsc_tarefa',
        //             value: responseR2.body
        //         });

        //         loadReparcelamento2.save();

        //         // redirect.toRecord({
        //         //     type: 'customrecord_rsc_reparcelamento_2',
        //         //     id: reparcelamento2Id
        //         // });
        //     } else {
        //         log.error('Erro', 'code: '+responseR2.code+', body: '+responseR2.body);
        //     }
        // }
    }
}

function criarTabelaEfetivacaoReparcelamento(dados) {
    log.audit('dados', dados);

    const tabelaEfetivacao = record.create({
        type: 'customrecord_rsc_tab_efetiva_reparcela',
        isDynamic: true
    });
    log.audit('tabelaEfetivacao', tabelaEfetivacao);

    // Dados Gerais
    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_contrato_fatura_principal',
        value: dados.reparcelamento.id_fatura_principal
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_cliente',
        value: dados.reparcelamento.cliente
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_unidade',
        value: dados.reparcelamento.unidade
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_total_fatura_principal',
        value: dados.reparcelamento.total_fatura_principal
    });

    // Dados para Efetivação (Reparcelamento)
    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_valor_financiado',
        value: dados.reparcelamento.saldoFinanciado
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_total_prestacoes_marcadas',
        value: dados.reparcelamento.totalParcelasMarcadas
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_valor_total',
        value: dados.reparcelamento.custoTotal
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_valor_da_entrada',
        value: dados.reparcelamento.valorEntrada
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_reparcelar_em',
        value: dados.reparcelamento.parcelasLiquidacao+'x'
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_vencimento_da_entrada',
        value: formatData(dados.reparcelamento.vencimentoEntrada)
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_primeiro_vencimento',
        value: formatData(dados.reparcelamento.dataInicio.text)
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_juros_de_mora',
        value: dados.reparcelamento.jurosMora
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_observacao_memo',
        value: dados.observacao
    });

    tabelaEfetivacao.setValue({
        fieldId: 'custrecord_rsc_status_ter',
        value: 1
    });

    // Sublista Parcelas
    for (i=0; i<dados.novasParcelas.length; i++) {
        tabelaEfetivacao.selectNewLine({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento'
        });

        tabelaEfetivacao.setCurrentSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento',
            fieldId: 'custrecord_rsc_ano',
            value: dados.novasParcelas[i].ano
        });

        tabelaEfetivacao.setCurrentSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento',
            fieldId: 'custrecord_rsc_parcela',
            value: formatData(dados.novasParcelas[i].parcela)
        });

        tabelaEfetivacao.setCurrentSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento',
            fieldId: 'custrecord_rsc_prestacao',
            value: Number(dados.novasParcelas[i].prestacao)
        });

        tabelaEfetivacao.commitLine({
            sublistId: 'recmachcustrecord_rsc_resumo_reparcelamento',
        });
    }

    // Sublista Resumo
    for (i=0; i<dados.reparcelamento.arrayParcelas.length; i++) {
        tabelaEfetivacao.selectNewLine({
            sublistId: 'recmachcustrecord_rsc_resumo'
        });

        tabelaEfetivacao.setCurrentSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo',
            fieldId: 'custrecord_rsc_parcela_contrato',
            value: dados.reparcelamento.arrayParcelas[i].id_financiamento_invoice
        });

        tabelaEfetivacao.setCurrentSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo',
            fieldId: 'custrecord_rsc_vencimento_parcela',
            value: formatData(dados.reparcelamento.arrayParcelas[i].vencimento)
        });

        tabelaEfetivacao.setCurrentSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo',
            fieldId: 'custrecord_rsc_valor_parcela',
            value: Number(dados.reparcelamento.arrayParcelas[i].valor)
        });

        tabelaEfetivacao.setCurrentSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo',
            fieldId: 'custrecord_rsc_multa_parcela',
            value: Number(dados.reparcelamento.arrayParcelas[i].multa) || 0
        });

        tabelaEfetivacao.setCurrentSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo',
            fieldId: 'custrecord_rsc_juros_parcela',
            value: Number(dados.reparcelamento.arrayParcelas[i].juros) || 0
        });

        tabelaEfetivacao.setCurrentSublistValue({
            sublistId: 'recmachcustrecord_rsc_resumo',
            fieldId: 'custrecord_rsc_valor_atualizado_parcela',
            value: dados.reparcelamento.arrayParcelas[i].valorAtualizado
        });

        tabelaEfetivacao.commitLine({
            sublistId: 'recmachcustrecord_rsc_resumo'
        });
    }

    var idTabelaEfetivacao, erro;
    
    try {
        idTabelaEfetivacao = tabelaEfetivacao.save({ignoreMandatoryFields: true});
        log.audit('idTabelaEfetivacao', idTabelaEfetivacao);
    } catch (e) {
        log.error('Erro Tabela Efetivação', e);
        erro = e;
    }

    if (idTabelaEfetivacao) {
        const loadTabelaEfetivacao = record.load({
            type: 'customrecord_rsc_tab_efetiva_reparcela',
            id: idTabelaEfetivacao,
            isDynamic: true
        });        
        
        loadTabelaEfetivacao.setValue({
            fieldId: 'custrecord_rsc_status_ter',
            value: 3
        });

        loadTabelaEfetivacao.save();

        var urlTabelaEfetivacao = url.resolveRecord({
            recordType: 'customrecord_rsc_tab_efetiva_reparcela',
            recordId: idTabelaEfetivacao
        });
        log.audit('urlTabelaEfetivacao', urlTabelaEfetivacao);

        return {
            status: 'Sucesso',
            idTabelaEfetivacao: idTabelaEfetivacao,
            urlTabelaEfetivacao: urlTabelaEfetivacao
        }
    } else {
        return {
            status: 'Erro',
            msg: error.create({
                name: 'Erro ao gravar tabela de efetivação.',
                message: erro.message
            })
        }
    }
}

function formatData(data) {
    log.audit('formatData', data);

    var partesData = data.split("/");

    var novaData = new Date(partesData[2], partesData[1] - 1, partesData[0]);

    return novaData;
}

function calcularJuros(dataInicio, parcelasLiquidacao, valores_parcelas_recalculadas, unidadeCorrecao) {
    log.audit('calcularJuros', {
        dataInicio: dataInicio, 
        parcelasLiquidacao: parcelasLiquidacao,
        valores_parcelas_recalculadas: valores_parcelas_recalculadas,
        unidadeCorrecao: unidadeCorrecao
    });

    var parcela = new Date(dataInicio);
    var juros = valores_parcelas_recalculadas;
    
    var arrayJuros = [];

    for (i=0; i<parcelasLiquidacao; i++) {
        parcela.setMonth(parcela.getMonth()+1);
        if (parcela.getMonth() == 0) {
            parcela.setMonth(1);
        }
        var dataInicio = (parcela.getDate()+1)+'/'+parcela.getMonth()+'/'+parcela.getFullYear();
        dataInicio = String(dataInicio);
        
        var ano = parcela.getFullYear();
        log.audit('ano: '+ano, 'dataInicio: '+dataInicio);

        juros = unidadeCorrecao ? ((juros * Number(unidadeCorrecao.fatorMensal)) / 100) + juros : 0;
        // juros = ((juros * Number(unidadeCorrecao.fatorMensal)) / 100) + juros;
        
        arrayJuros.push({
            ano: ano,
            parcela: dataInicio,
            prestacao: valores_parcelas_recalculadas / parcelasLiquidacao,
            juros: juros.toFixed(2)
        });
    }

    log.audit('arrayJuros', arrayJuros);
    return arrayJuros;
}

return {
    onRequest: onRequest
}
});
