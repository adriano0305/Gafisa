/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/query', 'N/search', 'N/record'],
    /**
 * @param{query} query
 * @param{search} search
 * @param{record} record
 */
    (query, search, Record) => {


        /**
         * Defines the function that is executed when a POST request is sent to a RESTlet.
         * @param {string | Object} requestBody - The HTTP request body; request body is passed as a string when request
         *     Content-Type is 'text/plain' or parsed into an Object when request Content-Type is 'application/json' (in which case
         *     the body must be a valid JSON)
         * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
         *     Object when request Content-Type is 'application/json' or 'application/xml'
         * @since 2015.2
         */
        const post = (requestBody) => {
            log.debug({ title: 'Params', details: requestBody });

            const operation = requestBody.tipoRegistro;
            log.debug({ title: 'Resultado', details: operation })
            return doAction(requestBody);
        }

        function doAction(body) {
            var retorno = []
            try {
                retorno = getPrevisto(body);
            } catch (e) {
                retorno = JSON.stringify({ erro: e.toString() });
            }
            return retorno;
        }

        function getPrevisto(body) {
            // log.debug({title:'Select', details:'Entrou no processo'});
            var dataIni = new Date(body.dataInicio);
            var dataFim = new Date(body.dataFinal);
            //let startTime = new Date().getMinutes()+':'+new Date().getSeconds();
            let startTime = new Date().getTime();
            var tb_stage_empresa = [];

            log.audit({ title: 'Iniciando consulta de previsões para gesplan', details: 'start time: ' + startTime });

            log.debug({ title: 'RequestBody', details: JSON.stringify(body) });

            log.audit({
                title: 'Data Inicial',
                details: body.dataInicio
            })
            log.audit({
                title: 'Data Final',
                details: body.dataFinal
            })


            //colocar log como audit inicio da execução.Mostrar data e hora e segundos

            // Run the query.

            try {
                arrResults = [];
                var sql = 'select BUILTIN.DF(a.status) statustitulo, TO_CHAR(a.lastModifiedDate,\'DD/MM/YYYY HH24:MI:SS\') lastModifiedDate , b.subsidiary, a.id, a.trandate, a.duedate, a.memo, custbody_rsc_installments,  ' +
                    'a.custbody4, a.transactionNumber, c1.acctnumber account, b.class, a.CUSTBODY_ENL_VENDORPAYMENTACCOUNT, ' +
                    'd.symbol currency, b.foreignamount total, c.amount, a.exchangerate, b.department departament, a.entity, a.type, e.tipo, ' +
                    'b.item as itemid, ' +
                    'b.linesequencenumber as itemsequence, ' +
                    'a.custbody_lrc_invoice_met_pag_fatura from transaction a ' +
                    'join transactionline b on a.id = b.transaction ' +
                    'join transactionaccountingline c on a.id = c.transaction and b.id = c.transactionline ' +
                    'join currency d on a.currency = d.id ' +
                    'join account c1 on c.account = c1.id ' +
                    'join (select e1.id, externalCode, e2.altname, e1.tipo, e1.custentity_enl_cnpjcpf, dataupdate from (select id, entityid externalCode, custentity_enl_cnpjcpf, \'1\' tipo, custentity_lrc_data_modifica_cliente dataupdate from customer\n' +
                    '            union\n' +
                    '            select id, entityid externalCode, custentity_enl_cnpjcpf, \'2\' tipo, custentity_lrc_data_modifica_fornec dataupdate from employee \n' +
                    '            union\n' +
                    '            select id, entityid externalCode, custentity_enl_cnpjcpf, \'3\' tipo, custentity_lrc_data_modifica_fornec dataupdate from vendor ) e1\n' +
                    '            join entity e2 on e1.externalCode = e2.entityid) e on e.id = a.entity ' +
                    'where  ' +
                    'type in (\'PurchOrd\', \'SalesOrd\', \'VendBill\', \'CuTrSale\')' +
                    ' and void != \'T\' ' +
                    ' and (status in  (\'2\', \'A\') or approvalStatus in (\'2\')) ' +
                    ' and b.mainline != \'T\' ' +
                    ' and b.foreignamount != 0 ' +
                    ' and ((itemtype in (\'Service\', \'NonInvtPart\', \'InvtPart\')) or (category > 0)) ' +
                    ' and a.lastModifiedDate between TO_TIMESTAMP (\' ' + body.dataInicio + '\', \'DD/MM/YYYY HH24:MI:SS\') and TO_TIMESTAMP (\'' + body.dataFinal + '\', \'DD/MM/YYYY HH24:MI:SS\')';

                log.debug({ title: 'query:', details: sql })
                var queryParams = new Array();
                var arrResults = selectAllRows(sql, queryParams);
                //log.debug( { title: 'getInputData - number of rows selected', details: JSON.stringify(arrResults) } );

                const records = arrResults;

                // If records were returned...
                log.audit(
                    {
                        title: "Qtde registros encontrados na consulta",
                        details: records.length
                    });

                let vendBillIdCount = [];
                let salesOrdIdCount = [];
                let purchOrdIdCount = [];
                let cuTrSaleCount = [];


                let transactionList = [];

                //faz o loop por transacao.parcela.item
                if (records.length > 0) {


                    //seleciona o id das transacoes que estao no objeto records

                    transactionList = selectTransactionIds(records);

                    log.debug("buscando instalaments para transacoes", transactionList.join(','));

                    //busca todas as instalments dessas transacacoes.
                    const allInstalmentsResultSet = searchInstalmentsByTransactionIdList(transactionList);
                    log.debug("allInstalmentsResultSet", JSON.stringify(allInstalmentsResultSet));
                    let logMsg = "";
                    //busca todas as parcelas dessas transacacoes.
                    for (let x = 0; x < records.length; x++) {
                        let record = records[x];
                        log.debug("records[x].id", records[x].id);    
                        const instalmentList = searchInstalmentsOnResultSetByTranId(record.id, allInstalmentsResultSet);
                       
                        if (instalmentList.length > 0) {
                            log.debug("instalmentList obj ", JSON.stringify(instalmentList));
                            log.debug("instalmentList lenght ", instalmentList.length );
                            
                            for (let y = 0; x < instalmentList.length; y++) {
                                log.debug("loop",y);    
                                const instalment = instalmentList[y];
                                logMsg += "instalment.transactionId : "+instalment.transactionId;
                                logMsg += "instalment.transactionType : "+instalment.transactionType;
                                logMsg += "instalment.dueDate : "+instalment.dueDate;
                                logMsg += "instalment.amount : "+instalment.amount;
                                logMsg += "instalment.amountPaid : "+instalment.amountPaid;
                                logMsg += "instalment.status : "+instalment.status;
                                logMsg += "instalment.number : "+instalment.number;

                                log.debug("instalments logMsg", logMsg);
                                
                                
                                //log.debug("instalment.transactionType", instalment.transactionType);

                                
                                //log.debug("instalmentList.transactionId", instalmentList[y].transactionId);


                            }
                        }
                    }
                    return logMsg;

                }




                //percorre as transacoes e monta um array com todos os ids das transacoes.
                if (records.length > 0) {

                    //seleciona o id das transacoes que estao no objeto records
                    const transactionIds = selectTransactionIds(records);

                    //busca todas as instalments dessas transacacoes.
                    const allInstalmentsResultSet = searchInstalmentsByTransactionIdList(transactionIds);

                    //log.debug("allInstallmentsResultSet", allInstallmentsResultSet);

                    // Add the records to the sublist...
                    for (r = 0; r < records.length; r++) {
                        // Get the record.
                        var record = records[r];
                        //log.debug('record', record)
                        var originSystem = '';
                        var eventType = '';
                        var inverterSinal = false;
                        //log.debug("Registro nr:  " + r, 'tipo: ' + record.type);


                        var zerarValor = false;
                        switch (record['statustitulo']) {
                            case 'Purchase Order : Fully Billed':
                                zerarValor = true;
                                break;
                            case 'Bill : Paid In Full':
                                zerarValor = true;
                                break;
                            default: break;
                        }

                        switch (record['type']) {

                            case 'PurchOrd':
                                originSystem = 'PO';
                                inverterSinal = false;
                                eventType = 'S'
                                //log.debug("buscando instalments para PurchOrd", record.id);

                                //let msg = "Ja existe o id " + record.id + " de " + record['type'] + "  na lista? " + purchOrdIdCount.includes(record.id);
                                //log.debug("---checking transactions ids for instalment search----", msg);

                                if (purchOrdIdCount.includes(record.id)) {
                                    //log.debug("id encontrado", "nao adiciona denovo");
                                    break;
                                }
                                purchOrdIdCount.push(record.id);

                                break;
                            case 'SalesOrd':
                                originSystem = 'SO';
                                inverterSinal = true;
                                eventType = 'E';

                                //let msg = "Ja existe o id " + record.id + " de " + record['type'] + "  na lista? " + salesOrdIdCount.includes(record.id);
                                //log.debug("---checking transactions ids for instalment search----", msg);

                                if (salesOrdIdCount.includes(record.id)) {
                                    //log.debug("id encontrado", "nao adiciona denovo");
                                    break;
                                }
                                salesOrdIdCount.push(record.id);
                                break;

                            case 'CuTrSale':
                                originSystem = 'CR';
                                inverterSinal = true;
                                eventType = 'E';

                                //let msg = "Ja existe o id " + record.id + " de " + record['type'] + "  na lista? " + cuTrSaleCount.includes(record.id);
                                //log.debug("---checking transactions ids for instalment search----", msg);


                                if (cuTrSaleCount.includes(record.id)) {
                                    //log.debug("id encontrado", "nao adiciona denovo");
                                    break;
                                }
                                cuTrSaleCount.push(record.id);
                                break;

                            case 'VendBill':
                                originSystem = 'CP';
                                inverterSinal = false;
                                eventType = 'S'
                                //log.debug("Adicionando id vendorbill:",record.id);
                                //log.debug("Verificando se vendorbill ja esta no array de filtro  ", "vendorbillid: "+record.id);

                                //let msg = "Ja existe o id " + record.id + " de " + record['type'] + "  na lista? " + vendBillIdCount.includes(record.id);
                                //log.debug("---checking transactions ids for instalment search----", msg);

                                if (vendBillIdCount.includes(record.id)) {
                                    //log.debug("id encontrado", "nao adiciona denovo");
                                    break;
                                }
                                vendBillIdCount.push(record.id);
                                break;
                            //const VendoBillRecord = Record.load({
                            //type: 'vendorbill',
                            //id: record.id
                            //})

                            //'vendorbill'

                            // search.lookupFields({
                            //     type: record.Type.VENDOR_BILL,
                            //     id: record.id,
                            //     columns: []
                            // })

                            //const Lines_installment = VendoBillRecord.getLineCount('installment')


                            //log.debug('qtde parcelas da vendorbill ( CP )', Lines_installment);
                            //if (Lines_installment > 0) {

                            //for (var x = 0; x < Lines_installment; x++) {
                            //const date = new Date( VendoBillRecord.getSublistValue({sublistId: 'installment', fieldId: 'duedate', line: x}))
                            //var day = date.getDate()
                            //var month = date.getMonth() + 1
                            //var year = date.getFullYear()
                            //if (day < 10) {
                            //day = '0'+String(day)
                            //}

                            //if(month < 10) {
                            //month = '0'+String(month)
                            //}
                            //log.debug("VendorBillInternalId: "+record.id,"parcela nr:  "+x+'  data da parcela: '+day+'/'+month+'/'+year);



                            //tb_stage_empresa.push({
                            //'dataAtualizacao': record['r'],
                            //'integrationType': '',
                            //'scenario': '01',
                            //'businessUnit': record['subsidiary'],
                            //'originSystem': originSystem,
                            //'externalCode': record['transactionnumber'],
                            //'dateOfIssue': record['trandate'],
                            //'dueDate': String(day + "/" + month + "/" + year),
                            //'payday': '',
                            //'description': record['transactionnumber'] + ' - ' + (record['memo'] == null ? '' : record['memo']),
                            //'observation': '',
                            //'documentType': record['type'],
                            //'documentNumber': record['transactionnumber'],
                            //'accountingAccountPlan': '01',
                            //'accountingAccount': record['account'],
                            //'costCenterPlan': '01',
                            //'costCenter': (record['departament']== null? 0: record['departament']),
                            //'currentAccount': record['custbody_enl_vendorpaymentaccount'],
                            //'paymentNumber': '',
                            //'currency': record['currency'],
                            //'eventType': eventType,
                            //'value': VendoBillRecord.getSublistValue({sublistId: 'installment', fieldId: 'amount', line: x}),
                            //'valueBusiness': '',
                            //'conversionBusiness': '',
                            //'fixedRateBusiness': '',
                            //'valueAccount': '',
                            //'conversionAccount': '',
                            //'fixedRateAccount': '',
                            //'beneficiaryOrigin': originSystem,
                            //'beneficiary': record['entity'],
                            //'beneficiaryType': record['tipo'],
                            //'motionWay': (record['custbody_lrc_invoice_met_pag_fatura'] == null? 2: record['custbody_lrc_invoice_met_pag_fatura']),
                            //'flexField001': (record['class'] == null? 0: record['class']),
                            //'teste': 'Wilson Riverl Guzman'
                            //})
                            //}
                            //}

                            default: break;
                        }



                        //buscar instalments da transacao.
                        //log.debug("transactionIdsArray", transactionIdsArray);
                        const instalmentList = searchInstalmentsOnResultSetByTranId(record.id, allInstalmentsResultSet);
                        //log.debug("instalmentList", instalmentList);
                        //log.audit("qtde de id para realizar a busca de vendobill", vendBillIdCount.length);
                        //log.audit("allVendorBillsIds", vendBillIdCount.toString());
                        for (let l of instalmentList) {

                            //transacao com 1 parcela e 2 itens
                            //type.id.instalment.itemsequence
                            // 1 - PurchOrd255.1.1
                            // 2 - PurchOrd255.1.2

                            //transacao com  2 pacelas e 3 itens
                            //type.id.instalment.itemsequence
                            // 1 - PurchOrd256.1.1
                            // 2 - PurchOrd256.1.2
                            // 3 - PurchOrd256.1.3
                            // 3 - PurchOrd256.2.1
                            // 4 - PurchOrd256.2.2
                            // 5 - PurchOrd256.2.3




                            //record.id
                        }
                        const registros = {
                            'dataAtualizacao': record['lastmodifieddate'],
                            'integrationType': '',
                            'scenario': '01',
                            'businessUnit': record['subsidiary'],
                            'originSystem': 'CP',
                            'externalCode': `${record['transactionnumber']}`,
                            'dateOfIssue': record['trandate'],
                            'dueDate': (record['duedate'] == null ? record['trandate'] : record['duedate']),
                            'payday': '',
                            'description': record['transactionnumber'] + ' - ' + (record['memo'] == null ? '' : record['memo']),
                            'observation': '',
                            'documentType': record['type'],
                            'documentNumber': record['transactionnumber'],
                            'accountingAccountPlan': '01',
                            'accountingAccount': record['account'],
                            'costCenterPlan': '01',
                            'costCenter': (record['departament'] == null ? 0 : record['departament']),
                            'currentAccount': record['custbody_enl_vendorpaymentaccount'],
                            'paymentNumber': '',
                            'currency': record['currency'],
                            'eventType': eventType,
                            'value': (zerarValor ? 0 : (inverterSinal ? record['total'] * -1 : record['total'])),
                            'valueBusiness': '',
                            'conversionBusiness': '',
                            'fixedRateBusiness': '',
                            'valueAccount': '',
                            'conversionAccount': '',
                            'fixedRateAccount': '',
                            'beneficiaryOrigin': originSystem,
                            'beneficiary': record['entity'],
                            'beneficiaryType': record['tipo'],
                            'motionWay': (record['custbody_lrc_invoice_met_pag_fatura'] == null ? 2 : record['custbody_lrc_invoice_met_pag_fatura']),
                            'flexField001': (record['class'] == null ? 0 : record['class']),
                            'transaction_id': record.id,
                            'itemid': record['itemid'],
                            'itemsequence': record['itemsequence']
                        }

                        tb_stage_empresa.push(registros);
                    }

                    //monta filtro de id de transacao para buscar instalments
                    //var instalmentSearchResultSet = JSON.parse(JSON.stringify(searchInstalmentsByTransactionIdList(vendBillIdCount)));

                    //mostra o conteudo da lista de parcelas encontradas.
                    //instalmentSearchResultSet.each(function (record) {
                    //log.debug('instalmentSearchResultSet data ', JSON.stringify(record));
                    //log.debug("instalments", "trannum: "+record.getValue({name: "transactionnumber"})+"  instalmentNumber: "+record.getValue({name:"installmentnumber"}) );
                    //});



                    //log.error('Dados', instalmentSearchResultSet)

                    //log.debug('vendorbill instalment  ',instalmentSearchResultSet.toString());

                    /*
                   
                    tb_stage_empresa.forEach(function (value, index) {
                        
                        log.debug('transaction data', "transactionid: " + value['transaction_id'] + " itemseq: " + value['itemsequence']);
                        //let transactionInstalments   = searchInstalmentsOnResultSetByTranId(value['transaction_id'], instalmentSearchResultSet);
                        //log.debug('transaction instalments', JSON.stringify(transactionInstalments));


                        if (value['documentType'] == 'VendBill') {

                            let countOfInstallments = 0
                            for (var j = 0; j < instalmentSearchResultSet.length; j++) {
                                const data = instalmentSearchResultSet[j]
                                const transaction_id = data['id']
                                //log.error('data duedate', data['values']['installment.duedate'])
                                /*

                                //busca as parcelas por vendobill.
                                if (value['transaction_id'] == transaction_id && data['values']['installment.duedate'] != '') {
                                    countOfInstallments++;
                                    log.debug('contador de intalments', countOfInstallments);
                                    //let field_code = `externalCode`
                                    //log.debug('data', data)
                                    //tb_stage_empresa.splice(index + 1, 0, {


                                    tb_stage_empresa.splice(index, 1, {
                                        'dataAtualizacao': value['dataAtualizacao'],
                                        'integrationType': '',
                                        'scenario': '01',
                                        'businessUnit': value['businessUnit'],
                                        'originSystem': 'CP',
                                        //'externalCode': `${value['externalCode']}.${data['values']['installment.installmentnumber']}.${value['itemsequence']}`,
                                        'externalCode': `${value['externalCode']}.${countOfInstallments}.${value['itemsequence']}`,
                                        'dateOfIssue': value['dateOfIssue'],
                                        'dueDate': data['values']['installment.duedate'],
                                        'payday': '',
                                        'description': value['description'],
                                        'observation': '',
                                        'documentType': value['documentType'],
                                        'documentNumber': value['documentNumber'],
                                        'accountingAccountPlan': '01',
                                        'accountingAccount': value['accountingAccount'],
                                        'costCenterPlan': '01',
                                        'costCenter': value['costCenter'],
                                        'currentAccount': value['currentAccount'],
                                        'paymentNumber': '',
                                        'currency': value['currency'],
                                        'eventType': value['eventType'],
                                        'value': Number(data['values']['installment.amount']),
                                        'valueBusiness': '',
                                        'conversionBusiness': '',
                                        'fixedRateBusiness': '',
                                        'valueAccount': '',
                                        'conversionAccount': '',
                                        'fixedRateAccount': '',
                                        'beneficiaryOrigin': value['beneficiaryOrigin'],
                                        'beneficiary': value['beneficiary'],
                                        'beneficiaryType': value['beneficiaryType'],
                                        'motionWay': value['motionWay'],
                                        'flexField001': value['flexField001'],
                                        'transaction_id': record.id,
                                        'itemid': value['itemid'],
                                        'itemsequence': value['itemsequence']
                                        //'teste': 'Wilson Rivero Guzman ' + countOfInstallments
                                    })
                                    
                                }
                             

                            }
                        }
                    })
                    */



                } else {
                    log.debug('Nenhum registro encontrado para a query', sql);
                }

            } catch (e) {
                log.error({ title: 'Error Recuperar informações', details: e.toString() })
                throw e;
            }
            log.debug('retorno', JSON.stringify({ registros: tb_stage_empresa }))
            let endTime = new Date().getTime();
            let executionDuration = (endTime - startTime) / 1000;
            log.audit('Fim da execução', executionDuration + "seconds");

            return JSON.stringify({ registros: tb_stage_empresa });
        }

        /*
        aqui o result set contem todos os instalments de todas as transacoes.
        o papel dessa funcao é filtrar os instalments de acordo com o id da transacao.
        e retornar apenas os instalments que pertencem a transacao.
        */
        function searchInstalmentsOnResultSetByTranId(transactionInternalId, arrayToSearchIn) {
            let result = new Array();
            //log.debug("arrayToSearchIn", JSON.stringify(arrayToSearchIn));

            if (!transactionInternalId || transactionInternalId == "") {
                return result
            }
            if (!arrayToSearchIn || arrayToSearchIn.length == 0) {
                throw new Error("Array of instalments to search in is empty, null or undefined or has length equals 0");
            }
            result = arrayToSearchIn.filter( (instalment) => {
                log.debug("buscandos cached instalments",transactionInternalId  +" is equal to "+ instalment.transactionId+" : "+ (instalment.transactionId == transactionInternalId));
                return instalment.transactionId == transactionInternalId;
            });
            


            log.debug("instalments encontrados para transactionid : " + transactionInternalId, result.length);
            /*
            result.forEach(function (record) {
                log.debug(' searchInstalmentsOnResultSetByTranId', JSON.stringify(record));
            });
            */

            return result;


            /*
            for (let i = 0; i < arrayToSearchIn.length; i++) {
              const data = arrayToSearchIn[i]
              const transaction_id = data['id']
              if (transactionInternalId == transaction_id) {
                  result.push(data)
              }
            }
            */

        }
        /**
         * Busca o id de todos os registros de um tipo de documento
         * @param {*} queryResult 
         * @returns 
         */
        const selectTransactionIds = (queryResult) => {
            const result = [];
            const records = queryResult;
            if (records.length > 0) {
                // Add the records to the sublist...
                for (let r = 0; r < records.length; r++) {
                    let record = records[r];
                    //let msg = "id " + record.id + " - " + record['type'] + (result.includes(record.id) ? " ja existe na lista" : " adicionado na lista");
                    //log.debug("---checking transactions ids for instalment search----", msg);
                    if (!result.includes(record.id)) {
                        result.push(record.id);
                    }
                }
            }
            //log.debug("selectedTransactionIds ", result.join(","));
            return result;

        }

        /**
         * Recebe um array contendo os ids das transacoes e retorna todos os instalments dessas transacoes.
         * 
         * @param {Array} transactionIdList lista de ids das transacoes.
         * @returns {search.ResultSet} lista de instalments dessas transacoes.
         */
        function searchInstalmentsByTransactionIdList(transactionIdList) {
            log.debug("id das transacoes: ", transactionIdList.join(","));
            //monta filtro de id de transacao para buscar instalments
            let filtersOfInstallment = [
                ['mainline', 'IS', 'T'],
                'AND',
                //["internalid","anyof","16462","50792"]
                ["internalid", "anyof", transactionIdList]
            ]

            //Faz a busca de todas as instalments de todas as transacoes
            //por id de transacao
            let transactionSearchObj = search.create({
                type: "transaction",
                filters: filtersOfInstallment,
                columns: [
                    search.createColumn({ name: "internalid", label: "Internal ID" }),
                    search.createColumn({ name: "type", label: "Type" }),
                    search.createColumn({ name: "amount", label: "Amount" }),
                    search.createColumn({ name: "tranid", label: "Document Number" }),
                    search.createColumn({
                        name: "transactionnumber",
                        sort: search.Sort.ASC,
                        label: "Transaction Number"
                    }),
                    search.createColumn({
                        name: "installmentnumber",
                        join: "installment",
                        sort: search.Sort.ASC,
                        label: "Installment Number"
                    }),
                    search.createColumn({
                        name: "duedate",
                        join: "installment",
                        sort: search.Sort.ASC,
                        label: "Due Date"
                    }),
                    search.createColumn({
                        name: "amount",
                        join: "installment",
                        label: "Amount"
                    }),
                    search.createColumn({
                        name: "amountpaid",
                        join: "installment",
                        label: "Amount Paid"
                    }),
                    search.createColumn({
                        name: "status",
                        join: "installment",
                        label: "Status"
                    })
                ]
            })


            const instalmentList = [];
            const instalmentSearchResultSet = transactionSearchObj.run();

            instalmentSearchResultSet.each((results) => {
                //log.debug("resultado da busca de instalments", JSON.stringify(results));
                const instalment = {
                    transactionType: results.getValue({ name: "type" }),
                    transactionId: results.id,
                    dueDate: results.getValue({ name: "duedate" }),
                    amount: results.getValue({ name: "amount" }),
                    amountPaid: results.getValue({ name: "amountpaid" }),
                    status: results.getValue({ name: "status" }),
                    number: results.getValue({ name: "installmentnumber" })
                }
                instalmentList.push(instalment);


                //log.debug("lista de instalments ", "transaction_id: "+results.id + "transactiontype: " + results.getValue({ name: "type" }) + "  "+results.getValue({ name: "transactionnumber" }) + " data vcto parcela: " + results.getValue({ name: "installment.duedate" }));
                //log.debug("lista de instalments ", JSON.stringify(instalment));
                return true
            })
            //log.debug("lista de instalments tamanho: ", instalmentList.length);
            return instalmentList;
        }


        function selectAllRows(sql, queryParams = new Array()) {
            var rows = new Array();
            try {
                var moreRows = true;
                var paginatedRowBegin = 1;
                var paginatedRowEnd = 5000;

                do {

                    var paginatedSQL = 'SELECT * FROM ( SELECT ROWNUM AS ROWNUMBER, * FROM (' + sql + ' ) ) WHERE ( ROWNUMBER BETWEEN ' + paginatedRowBegin + ' AND ' + paginatedRowEnd + ')';
                    log.debug('selectAllRows - executando sql paginado', paginatedSQL);
                    var queryResults = query.runSuiteQL({ query: paginatedSQL, params: queryParams }).asMappedResults();
                    queryResults.length
                    log.debug('selectAllRows - records returned:', (queryResults.length || 0));
                    log.debug('selectAllRows - results:', JSON.stringify(queryResults));
                    rows = rows.concat(queryResults);
                    if (queryResults.length < 5000) {
                        moreRows = false;
                    }
                    paginatedRowBegin = paginatedRowBegin + 5000;
                } while (moreRows);

            } catch (e) {
                log.error({ title: 'selectAllRows - error', details: { 'sql': sql, 'queryParams': queryParams, 'error': e } });
                throw e;
            }
            log.debug('selectAllRows - rows:', JSON.stringify(rows));
            return rows;
        }

        return { post }

    });

