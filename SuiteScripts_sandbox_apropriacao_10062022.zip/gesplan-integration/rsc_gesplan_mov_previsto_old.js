/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/query', 'N/search', 'N/record'],
    /**
 * @param{query} query
 * @param{search} search
 * @param{record} record
 */
    (query, search, Record) => {


        /**
         * Defines the function that is executed when a POST request is sent to a RESTlet.
         * @param {string | Object} requestBody - The HTTP request body; request body is passed as a string when request
         *     Content-Type is 'text/plain' or parsed into an Object when request Content-Type is 'application/json' (in which case
         *     the body must be a valid JSON)
         * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
         *     Object when request Content-Type is 'application/json' or 'application/xml'
         * @since 2015.2
         */
        const post = (requestBody) => {
             log.debug({title:'Params', details:requestBody});

            const operation = requestBody.tipoRegistro;
             log.debug({title: 'Resultado', details: operation})
            return doAction(requestBody);
        }

        function doAction(body){
            var retorno = []
            try {
                retorno = getPrevisto(body);
            } catch (e) {
                retorno = JSON.stringify({erro: e.toString()});
            }
            return retorno;
        }

        function getPrevisto(body){
            // log.debug({title:'Select', details:'Entrou no processo'});
            var dataIni = new Date(body.dataInicio);
            var dataFim = new Date(body.dataFinal);
            // Run the query.
            try {
                arrResults = [];
                var sql = 'select BUILTIN.DF(a.status) statustitulo, TO_CHAR(a.lastModifiedDate,\'DD/MM/YYYY HH24:MI:SS\') lastModifiedDate , b.subsidiary, a.id, a.trandate, a.duedate, a.memo, custbody_rsc_installments,  ' +
                    'a.custbody4, a.transactionNumber, c1.acctnumber account, b.class, a.CUSTBODY_ENL_VENDORPAYMENTACCOUNT, ' +
                    'd.symbol currency, b.foreignamount total, c.amount, a.exchangerate, b.department departament, a.entity, a.type, e.tipo, ' +
                    'a.custbody_lrc_invoice_met_pag_fatura from transaction a ' +
                    'join transactionline b on a.id = b.transaction ' +
                    'join transactionaccountingline c on a.id = c.transaction and b.id = c.transactionline ' +
                    'join currency d on a.currency = d.id ' +
                    'join account c1 on c.account = c1.id ' +
                    'join (select e1.id, externalCode, e2.altname, e1.tipo, e1.custentity_enl_cnpjcpf, dataupdate from (select id, entityid externalCode, custentity_enl_cnpjcpf, \'1\' tipo, custentity_lrc_data_modifica_cliente dataupdate from customer\n' +
                    '            union\n' +
                    '            select id, entityid externalCode, custentity_enl_cnpjcpf, \'2\' tipo, custentity_lrc_data_modifica_fornec dataupdate from employee \n' +
                    '            union\n' +
                    '            select id, entityid externalCode, custentity_enl_cnpjcpf, \'3\' tipo, custentity_lrc_data_modifica_fornec dataupdate from vendor ) e1\n' +
                    '            join entity e2 on e1.externalCode = e2.entityid) e on e.id = a.entity ' +
                    'where  ' +
                    'type in (\'PurchOrd\', \'SalesOrd\', \'VendBill\', \'CuTrSale\')' +
                    ' and void != \'T\' ' +
                    ' and (status in  (\'2\', \'A\') or approvalStatus in (\'2\')) ' +
                    ' and b.mainline != \'T\' ' +
                    ' and b.foreignamount != 0 ' +
                    ' and ((itemtype in (\'Service\', \'NonInvtPart\', \'InvtPart\')) or (category > 0)) ' +
                    ' and a.lastModifiedDate between TO_TIMESTAMP (\' '+ body.dataInicio + '\', \'DD/MM/YYYY HH24:MI:SS\') and TO_TIMESTAMP (\''+ body.dataFinal + '\', \'DD/MM/YYYY HH24:MI:SS\')' ;
                
                log.debug({title:'Sql', details: sql})
                var queryParams = new Array();
                var arrResults = selectAllRows( sql, queryParams );
                log.debug( { title: 'getInputData - number of rows selected', details: JSON.stringify(arrResults) } );

                var tb_stage_empresa = [];
                var records = arrResults;
                
                // If records were returned...
                if ( records.length > 0 ) {

                    // Add the records to the sublist...
                    for (r = 0; r < records.length; r++) {
                        // Get the record.
                        var record = records[r];
                        //log.debug('record', record)
                        var originSystem = '';
                        var eventType = '';
                        var inverterSinal = false;

                        
                        var zerarValor = false;
                        switch (record['statustitulo']) {
                            case 'Purchase Order : Fully Billed':
                                zerarValor = true;
                                break;
                            case 'Bill : Paid In Full':
                                zerarValor = true;
                                break;
                            default: break;
                        }

                        switch (record['type']) {
                            case 'PurchOrd':
                                originSystem = 'PO';
                                inverterSinal = false;
                                eventType = 'S'
                                break;
                            case 'SalesOrd':
                                originSystem = 'SO';
                                inverterSinal = true;
                                eventType = 'E'
                                break;
                            case 'CuTrSale':
                                originSystem = 'CR';
                                inverterSinal = true;
                                eventType = 'E'
                                break;
                            case 'VendBill':
                                originSystem = 'CP';
                                inverterSinal = false;
                                eventType = 'S'
                                
                                const VendoBillRecord = Record.load({
                                    type: 'vendorbill',
                                    id: record.id
                                })
                                const Lines_installment = VendoBillRecord.getLineCount('installment')
                                //log.debug(Lines_installment)
                                if (Lines_installment > 0) {
                                    
                                    for (var x = 0; x < Lines_installment; x++) {
                                        const date = new Date( VendoBillRecord.getSublistValue({sublistId: 'installment', fieldId: 'duedate', line: x}))
                                        var day = date.getDate()
                                        var month = date.getMonth() + 1
                                        var year = date.getFullYear()
                                        if (day < 10) {
                                            day = '0'+String(day)
                                        }

                                        if(month < 10) {
                                            month = '0'+String(month)
                                        }


                                        
                                        tb_stage_empresa.push({
                                            'dataAtualizacao': record['lastmodifieddate'],
                                            'integrationType': '',
                                            'scenario': '01',
                                            'businessUnit': record['subsidiary'],
                                            'originSystem': originSystem,
                                            'externalCode': record['transactionnumber'],
                                            'dateOfIssue': record['trandate'],
                                            'dueDate': String(day + "/" + month + "/" + year),
                                            'payday': '',
                                            'description': record['transactionnumber'] + ' - ' + (record['memo'] == null ? '' : record['memo']),
                                            'observation': '',
                                            'documentType': record['type'],
                                            'documentNumber': record['transactionnumber'],
                                            'accountingAccountPlan': '01',
                                            'accountingAccount': record['account'],
                                            'costCenterPlan': '01',
                                            'costCenter': (record['departament']== null? 0: record['departament']),
                                            'currentAccount': record['custbody_enl_vendorpaymentaccount'],
                                            'paymentNumber': '',
                                            'currency': record['currency'],
                                            'eventType': eventType,
                                            'value': VendoBillRecord.getSublistValue({sublistId: 'installment', fieldId: 'amount', line: x}),
                                            'valueBusiness': '',
                                            'conversionBusiness': '',
                                            'fixedRateBusiness': '',
                                            'valueAccount': '',
                                            'conversionAccount': '',
                                            'fixedRateAccount': '',
                                            'beneficiaryOrigin': originSystem,
                                            'beneficiary': record['entity'],
                                            'beneficiaryType': record['tipo'],
                                            'motionWay': (record['custbody_lrc_invoice_met_pag_fatura'] == null? 2: record['custbody_lrc_invoice_met_pag_fatura']),
                                            'flexField001': (record['class'] == null? 0: record['class']),
                                            //'teste': 'Wilson Riverl Guzman'
                                        })
                                    }
                                }
                                break;
                            default: break;
                        }


                        const registros = {
                            'dataAtualizacao': record['lastmodifieddate'],
                            'integrationType': '',
                            'scenario': '01',
                            'businessUnit': record['subsidiary'],
                            'originSystem': originSystem,
                            'externalCode': record['transactionnumber'],
                            'dateOfIssue': record['trandate'],
                            'dueDate': (record['duedate'] == null ? record['trandate']:record['duedate']) ,
                            'payday': '',
                            'description': record['transactionnumber'] + ' - ' + (record['memo'] == null ? '' : record['memo']),
                            'observation': '',
                            'documentType': record['type'],
                            'documentNumber': record['transactionnumber'],
                            'accountingAccountPlan': '01',
                            'accountingAccount': record['account'],
                            'costCenterPlan': '01',
                            'costCenter': (record['departament']== null? 0: record['departament']),
                            'currentAccount': record['custbody_enl_vendorpaymentaccount'],
                            'paymentNumber': '',
                            'currency': record['currency'],
                            'eventType': eventType,
                            'value': (zerarValor ? 0 : (inverterSinal ? record['total'] *-1: record['total'])),
                            'valueBusiness': '',
                            'conversionBusiness': '',
                            'fixedRateBusiness': '',
                            'valueAccount': '',
                            'conversionAccount': '',
                            'fixedRateAccount': '',
                            'beneficiaryOrigin': originSystem,
                            'beneficiary': record['entity'],
                            'beneficiaryType': record['tipo'],
                            'motionWay': (record['custbody_lrc_invoice_met_pag_fatura'] == null? 2: record['custbody_lrc_invoice_met_pag_fatura']),
                            'flexField001': (record['class'] == null? 0: record['class'])
                        }

                        tb_stage_empresa.push(registros);
                    }
                }else {
                    log.debug('rsc_gesplan_mov_previsto', 'Não foi encontrado registro para a query: ' + sql);
                }

            } catch (e){
                log.debug({title: 'Error Recuperar informações', details: e.toString()})
            }
            return JSON.stringify({registros: tb_stage_empresa});
        }

        function selectAllRows( sql, queryParams = new Array() ) {
            try {
                var moreRows = true;
                var rows = new Array();
                var paginatedRowBegin = 1;
                var paginatedRowEnd = 5000;

                do {
                    var paginatedSQL = 'SELECT * FROM ( SELECT ROWNUM AS ROWNUMBER, * FROM (' + sql + ' ) ) WHERE ( ROWNUMBER BETWEEN ' + paginatedRowBegin + ' AND ' + paginatedRowEnd + ')';
                    var queryResults = query.runSuiteQL( { query: paginatedSQL, params: queryParams } ).asMappedResults();
                    rows = rows.concat( queryResults );
                    if ( queryResults.length < 5000 ) { moreRows = false; }
                    paginatedRowBegin = paginatedRowBegin + 5000;
                } while ( moreRows );
            } catch( e ) {
                log.error( { title: 'selectAllRows - error', details: { 'sql': sql, 'queryParams': queryParams, 'error': e } } );
            }
            return rows;
        }

        return {post}

    });

