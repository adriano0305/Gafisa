/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @author Wilson
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/https", "N/record"], function (require, exports, currentRecord_1, https_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.export_csv = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    https_1 = __importDefault(https_1);
    record_1 = __importDefault(record_1);
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var export_csv = function () {
        var current = currentRecord_1.default.get();
        var vendor_bill_id = current.id;
        var Record_Vendor_Bill = record_1.default.load({
            type: 'vendorbill',
            id: vendor_bill_id
        });
        var entity = Record_Vendor_Bill.getValue('entity');
        var type_operation = Record_Vendor_Bill.getValue('custbody_enl_operationtypeid');
        var method_pag = Record_Vendor_Bill.getValue('custbody_enl_instal_instalmentway');
        var res_method_pag = '';
        if (method_pag == 2) {
            res_method_pag = '0';
        }
        else if (method_pag == 5) {
            res_method_pag = '1';
        }
        else if (method_pag == '') {
            res_method_pag = '9';
        }
        else {
            res_method_pag = '2';
        }
        var id_local_iss = Record_Vendor_Bill.getValue('custbody_enl_transportorigin');
        var local_destionation = Record_Vendor_Bill.getValue('custbody_enl_transportdestination');
        var number_fiscal = Record_Vendor_Bill.getValue('custbody_enl_fiscaldocnumber');
        var doc_serie = Record_Vendor_Bill.getValue('custbody_enl_fiscaldocumentserie');
        var date_fiscal_doc = Record_Vendor_Bill.getValue('custbody_enl_fiscaldocdate');
        var id_situation = Record_Vendor_Bill.getValue('custbody_alvr_codigo_situacao');
        var id_subsidiary = Record_Vendor_Bill.getValue('subsidiary');
        var date_emissao = new Date(date_fiscal_doc);
        var month = date_emissao.getMonth();
        //if (entity == '' || type_operation == '' || method_pag == '') {
          //  alert('Falta de dados para gerar o CSV');
            //return;
        //}
        var month_format = '';
        if (month < 10) {
            month_format = "0" + (month + 1);
        }
        var date_format = date_emissao.getDate() + "/" + month_format + "/" + date_emissao.getFullYear();
        var Sub_Record = record_1.default.load({
            type: 'subsidiary',
            id: id_subsidiary
        });
        var info_tax_code = Sub_Record.getValue('custrecord_avlr_tco_companycode');
        var situation = record_1.default.load({
            type: 'customrecord_avlr_cod_sit_document',
            id: id_situation
        });
        var cod_situation = situation.getValue('custrecord_avlr_codigo_situacao_document');
        var Region = record_1.default.load({
            type: 'customrecord_enl_cities',
            id: id_local_iss
        });
        var ibge_code = Region.getValue('custrecord_enl_ibgecode');
        var body = {
            id: vendor_bill_id,
            type_register: 'CAPA',
            entity: "F" + entity,
            type_operation: type_operation == 3 ? '0' : '1',
            method_pag: res_method_pag,
            iss_code_ibge: ibge_code,
            number_fiscal: number_fiscal,
            doc_serie: doc_serie,
            date_fiscal_doc: date_format,
            situation: cod_situation,
            incricao_mnicipal: info_tax_code,
            pediodo_escritura: "" + month_format + date_emissao.getFullYear()
        };
        console.log(body);
        // ID SEACRJ SAVE = 1056
        try {
            var dat = https_1.default.post({
                url: '/app/site/hosting/scriptlet.nl?script=1207&deploy=1',
                body: JSON.stringify(body)
            });
            // window.location.replace(`https://5843489-sb1.app.netsuite.com${dat.body}`)
            window.location.replace(dat.body);
        }
        catch (e) {
            console.log(e);
        }
    };
    exports.export_csv = export_csv;
});
