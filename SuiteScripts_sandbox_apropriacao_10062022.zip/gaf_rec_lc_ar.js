/**
 *@NApiVersion 2.1
*@NScriptType MapReduceScript
*/
define(['N/log', 'N/query', 'N/record', 'N/search', 'N/transaction'], (log, query, record, search, transaction) => {
const anularLancamentos = (id) => {
    log.audit('anularLancamentos', id);

    var sql = "SELECT t.id, t.recordtype, t.tranid "+
    "FROM transaction as t "+
    "WHERE t.custbody_ref_parcela = ? ";

    var consulta = query.runSuiteQL({
        query: sql,
        params: [id]
    });

    var sqlResults = consulta.asMappedResults();
    log.audit('sqlResults', sqlResults);

    if (sqlResults.length > 0) {
        for (i=0; i<sqlResults.length; i++) {
            log.audit({ref: id}, {id: sqlResults[i].id, recordType: sqlResults[i].recordtype});
            voidTransaction = transaction.void({type: sqlResults[i].recordtype, id: sqlResults[i].id});
            log.audit('voidTransaction', voidTransaction);
        }        
    }
}

const getInputData =  (context) => {
    log.audit('getInputData', context);

    return search.create({type: "invoice",
        filters: [
           ["shipping","is","F"], "AND", 
           ["taxline","is","F"], "AND", 
           ["mainline","is","T"], "AND", 
           ["type","anyof","CustInvc"], "AND", 
           ["status","anyof","CustInvc:V"], "AND", 
           ["internalid","anyof","217357"]
        ],
        columns: [
            "datecreated","internalid","tranid"
        ]
    });
}

const map = (context) => {
    log.audit('map', context);

    const src = JSON.parse(context.value);
    log.audit('src', src);

    anularLancamentos(src.id);
}

const reduce = (context) => {
    log.audit('reduce', context);
}

const summarize = (summary) => {
    var type = summary.toString();
    log.audit(type, 
        '"Uso Consumido:" '+summary.usage+
        ', "Número de Filas:" '+summary.concurrency+
        ', "Quantidade de Saídas:" '+summary.yields
    );
    var contents = '';
    summary.output.iterator().each(function (key, value) {
        contents += (key + ' ' + value + '\n');
        return true;
    });
}

return {
    getInputData: getInputData,
    map: map,
    reduce: reduce,
    summarize: summarize
}
});
