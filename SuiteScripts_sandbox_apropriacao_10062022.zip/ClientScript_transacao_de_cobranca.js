/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 *
 * ClientScript_transacao_de_cobranca.js
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url"], function (require, exports, currentRecord_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.selecionaNfe = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    var pageInit = function (ctx) {
        var nfes;
        var currentTrRecord = currentRecord_1.default.get();
        Log.error("lisst nfe", String(currentTrRecord.getValue('custpage_campo_array_nfes')));
        if (String(currentTrRecord.getValue('custpage_campo_array_nfes')) != "undefined") {
            nfes = JSON.parse(String(currentTrRecord.getValue('custpage_campo_array_nfes')));
            setListValues(nfes);
        }
    };
    exports.pageInit = pageInit;
    var setListValues = function (list) {
        var current = currentRecord_1.default.get();
        list.forEach(function (item) {
            console.log(item);
            current.selectNewLine({
                sublistId: 'custpage_lrc_nf',
            });
            current.setCurrentSublistValue({
                sublistId: 'custpage_lrc_nf',
                fieldId: 'customrecord_lrc_nf',
                value: item.customrecord_lrc_nf || ''
            });
            current.setCurrentSublistValue({
                sublistId: 'custpage_lrc_nf',
                fieldId: 'custpage_lrc_xped',
                value: item.custpage_lrc_xped || ''
            });
            current.setCurrentSublistValue({
                sublistId: 'custpage_lrc_nf',
                fieldId: 'custpage_lrc_chave_acesso',
                value: item.custpage_lrc_chave_acesso || ''
            });
            current.setCurrentSublistValue({
                sublistId: 'custpage_lrc_nf',
                fieldId: 'custpage_lrc_check',
                value: false || ''
            });
            current.commitLine({
                sublistId: 'custpage_lrc_nf'
            });
        });
    };
    var selecionaNfe = function () {
        var currRecord = currentRecord_1.default.get();
        var idCobranca = String(currRecord.getValue('internalid'));
        console.log("ID:", idCobranca);
        var num_lines = currRecord.getLineCount({ sublistId: "custpage_lrc_nf" });
        console.log("Num_line: ", num_lines);
        for (var i = 0; i < num_lines; i++) {
            currRecord.selectLine({
                line: i,
                sublistId: "custpage_lrc_nf"
            });
            var currCheckBoxValue = currRecord.getCurrentSublistValue({
                fieldId: 'custpage_lrc_check',
                sublistId: 'custpage_lrc_nf'
            });
            console.log("currCheckBoxValue 01", currCheckBoxValue);
            if (currCheckBoxValue) {
                var chaveDeacesso = currRecord.getSublistValue({
                    sublistId: 'custpage_lrc_nf',
                    line: i,
                    fieldId: 'custpage_lrc_chave_acesso'
                });
                console.log("currCheckBoxValue 02", currCheckBoxValue);
                console.log("chaveDeAcesso: ", chaveDeacesso);
                var url = url_1.default.resolveRecord({
                    recordId: idCobranca,
                    isEditMode: true,
                    recordType: 'vendorbill',
                    params: {
                        chaveDeacesso: chaveDeacesso
                    }
                });
                window.open(url, "_blank");
            }
        }
    };
    exports.selecionaNfe = selecionaNfe;
});
