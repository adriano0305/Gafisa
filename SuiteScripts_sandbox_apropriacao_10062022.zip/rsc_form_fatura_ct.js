/**
 *@NApiVersion 2.1
*@NScriptType ClientScript
*/
define(['N/log', 'N/currentRecord', 'N/search', 'N/ui/dialog', 'N/url'], (log, currentRecord, search, dialog, url) => {
const pageInit = (context) => {}

const saveRecord = (context) => {}

const validateField = (context) => {}

const fieldChanged = (context) => {}

const postSourcing = (context) => {}

const lineInit = (context) => {}

const validateDelete = (context) => {}

const validateInsert = (context) => {}

const validateLine = (context) => {}

const sublistChanged = (context) => {}

const distrato = () => {
    dialog.alert({
        title: 'Aviso!',
        message: 'Este menu fará a Distrato.'
    });
}

const cessaoDireito = () => {
    dialog.alert({
        title: 'Aviso!',
        message: 'Este menu fará o Cessão de Direito.'
    });
}

return {
    cessaoDireito: cessaoDireito,
    distrato: distrato,
    pageInit: pageInit,
    // saveRecord: saveRecord,
    // validateField: validateField,
    // fieldChanged: fieldChanged,
    // postSourcing: postSourcing,
    // lineInit: lineInit,
    // validateDelete: validateDelete,
    // validateInsert: validateInsert,
    // validateLine: validateLine,
    // sublistChanged: sublistChanged
}
});
