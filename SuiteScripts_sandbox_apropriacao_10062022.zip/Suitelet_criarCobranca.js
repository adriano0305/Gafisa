/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_mudaCliente.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "./lib/parser", "N/log", "N/redirect"], function (require, exports, record_1, parser_1, log_1, redirect_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    parser_1 = __importDefault(parser_1);
    log_1 = __importDefault(log_1);
    redirect_1 = __importDefault(redirect_1);
    var onRequest = function (ctx) {
        if (ctx.request.method == 'GET') {
            var parameters = ctx.request.parameters;
            var doc = parameters.content;
            //const fileName = parameters.fileName;
            var parsedContent = parser_1.default.parseCSV(doc, "\t");
            if (parsedContent.error) {
                throw Error(parsedContent.error);
            }
            var parsedDoc = JSON.parse(doc);
            var data = parsedContent.data;
            data.forEach(function (row) {
                var vendorbillRecord = record_1.default.create({
                    type: 'vendorbill'
                });
                vendorbillRecord.setValue({
                    fieldId: 'entity',
                    value: row['matrícula']
                });
                log_1.default.error('Matricula', row['matrícula']);
                vendorbillRecord.setValue({
                    fieldId: 'subsidiary',
                    value: row['estabelecimento']
                });
                vendorbillRecord.setValue({
                    fieldId: 'custbody_rsc_projeto_obra_gasto_compra',
                    value: row['C.R.']
                });
                vendorbillRecord.setValue({
                    fieldId: 'class',
                    value: row['códigodocentrodecustocontabilidade']
                });
                vendorbillRecord.setValue({
                    fieldId: 'custbody_rsc_tarefa_proj_empreendiment',
                    value: row['clas.']
                });
                vendorbillRecord.setSublistValue({
                    sublistId: 'expense',
                    fieldId: 'account',
                    value: vendorbill.codigo,
                    line: 0
                });
                vendorbillRecord.setSublistValue({
                    sublistId: 'expense',
                    fieldId: 'amount',
                    value: vendorbill.valor,
                    line: 0
                });
                vendorbillRecord.setValue({
                    fieldId: 'custbody2',
                    value: vendorbill.descricao
                });
                vendorbillRecord.setValue({
                    fieldId: 'custbody_enl_order_documenttype',
                    value: vendorbill.classe
                });
                vendorbillRecord.setValue({
                    fieldId: 'custbody_enl_operationtypeid',
                    value: vendorbill.processo
                });
                var horaSeparada = vendorbill.hora.split('/');
                var horaData = "" + horaSeparada[1] + '/' + horaSeparada[0] + '/' + horaSeparada[2];
                log_1.default.error('horaData', horaData);
                var hora = new Date(horaData);
                vendorbillRecord.setValue({
                    fieldId: 'trandate',
                    value: hora
                });
                log_1.default.error('data', hora);
                var entregarSeparado = vendorbill.dtPgto.split('/');
                var entragarData = "" + entregarSeparado[1] + '/' + entregarSeparado[0] + '/' + entregarSeparado[2];
                var entregar = new Date(entragarData);
                vendorbillRecord.setValue({
                    fieldId: 'duedate',
                    value: entregar
                });
                var vendorId = vendorbillRecord.save({
                    ignoreMandatoryFields: true
                });
                redirect_1.default.toRecord({
                    type: 'vendorbill',
                    id: vendorId
                });
            });
        }
    };
    exports.onRequest = onRequest;
});
