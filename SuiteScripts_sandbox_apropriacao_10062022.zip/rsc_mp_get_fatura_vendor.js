/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* R├®gua Cobran├ºa
* MapReduce
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/query", "N/log"], function (require, exports, query_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    query_1 = __importDefault(query_1);
    log_1 = __importDefault(log_1);
    var getInputData = function () {
        var sql = "SELECT \n\t\tentity, \n\t\tcustbody_enl_operationtypeid, \n\t\tcustbody_enl_instal_instalmentway, \n\t\tcustbody_enl_transportorigin, \n\t\tcustbody_enl_transportdestination, \n\t\tcustbody_enl_fiscaldocnumber,\n\t\tcustbody_enl_fiscaldocumentserie,\n\t\tcustbody_enl_fiscaldocdate,\n\t\tcustbody_alvr_codigo_situacao,\n\n\tFROM transaction WHERE type='VendBill'";
        var query_result = query_1.default.runSuiteQL({
            query: sql
        }).asMappedResults();
        return query_result;
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var data = JSON.parse(ctx.value);
        log_1.default.debug('Data', data);
    };
    exports.map = map;
});
