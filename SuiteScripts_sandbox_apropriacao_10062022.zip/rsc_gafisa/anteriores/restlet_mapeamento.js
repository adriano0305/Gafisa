/**
 * @NAPIVersion 2.0
 * @NScriptType Restlet
 * restlet_mapeamento.ts
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/runtime"], function (require, exports, record_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.post = void 0;
    record_1 = __importDefault(record_1);
    runtime_1 = __importDefault(runtime_1);
    var post = function (ctx) {
        var arrayObj = [];
        var arrayErro = [];
        var objErro = {
            valorInvalido: 'o valor adicionado ao campo é invalido ou está vazio!',
            jsonInvalido: 'o json está incorreto',
            faturaErro: 'Erro ao criar o registro, verificar o json e os valores preenchidos'
        };
        ctx.forEach(function (cobranca) {
            var sequencial, situacao, data_fatura, tipo_doc, cod_empresa, data_lancamento, referencia, texto_cabecalho, cod_forn, valor, divisao, cond_pgto, data_base, atribuicao, texto_item, conta_deb, divisao_deb, centro_custo, id, nr_processo, autor_recla;
            try {
                sequencial = cobranca.sequencial;
                situacao = cobranca.situacao;
                data_fatura = cobranca.data_fatura;
                tipo_doc = cobranca.tipo_doc;
                cod_empresa = cobranca.cod_empresa;
                data_lancamento = cobranca.data_lancamento;
                referencia = cobranca.referencia;
                texto_cabecalho = cobranca.texto_cabecalho;
                cod_forn = cobranca.cod_forn;
                valor = cobranca.valor;
                divisao = cobranca.divisao;
                cond_pgto = cobranca.cond_pgto;
                data_base = cobranca.data_base;
                atribuicao = cobranca.atribuicao;
                texto_item = cobranca.texto_item;
                conta_deb = cobranca.conta_deb;
                divisao_deb = cobranca.divisao_deb;
                centro_custo = cobranca.centro_custo;
                id = cobranca.id;
                nr_processo = cobranca.nr_processo;
                autor_recla = cobranca.autor_recla;
            }
            catch (_a) {
                return objErro.jsonInvalido;
            }
            data_base = data_base.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            data_base = new Date(data_base);
            var contaSublista = runtime_1.default.getCurrentScript().getParameter({
                name: 'custscript_lrc_despesa_conta'
            });
            var tipoOperacao = runtime_1.default.getCurrentScript().getParameter({
                name: 'custscript_lrc_tipo_de_operacao'
            });
            var record = record_1.default.create({
                type: 'vendorbill',
            });
            var status = record.getValue({
                fieldId: 'approvalstatus'
            });
            try {
                record.setValue({
                    fieldId: 'custbody_lrc_status',
                    value: situacao
                });
                record.setValue({
                    fieldId: 'custbody_lrc_data_fatura',
                    value: data_fatura
                });
                record.setValue({
                    fieldId: 'custbody_enl_order_documenttype',
                    value: tipo_doc
                });
                record.setValue({
                    fieldId: 'custbody_lrc_numero_fornecedor',
                    value: cod_empresa
                });
                record.setValue({
                    fieldId: 'custbody_lrc_data_lancamento',
                    value: data_lancamento
                });
                record.setValue({
                    fieldId: 'custbody_lrc_referencia',
                    value: referencia
                });
                record.setValue({
                    fieldId: 'memo',
                    value: texto_cabecalho
                });
                record.setValue({
                    fieldId: 'entity',
                    value: cod_forn
                });
                record.setValue({
                    fieldId: 'usertotal',
                    value: valor
                });
                record.setValue({
                    fieldId: 'custbody_lrc_divisao',
                    value: divisao
                });
                record.setValue({
                    fieldId: 'terms',
                    value: cond_pgto
                });
                record.setValue({
                    fieldId: 'duedate',
                    value: data_base
                });
                record.setValue({
                    fieldId: 'custbody_lrc_atribuicao',
                    value: atribuicao
                });
                var line = record.getLineCount({
                    sublistId: 'expense'
                });
                record.setValue({
                    fieldId: 'custbody_lrc_texto_item',
                    value: texto_item
                });
                record.setSublistValue({
                    line: line,
                    sublistId: 'expense',
                    fieldId: 'account',
                    value: contaSublista
                });
                record.setSublistValue({
                    line: line,
                    sublistId: 'expense',
                    fieldId: 'grossamt',
                    value: valor
                });
                record.setValue({
                    fieldId: 'custbody_lrc_conta_deb',
                    value: conta_deb
                });
                record.setValue({
                    fieldId: 'custbody_lrc_div_deb',
                    value: divisao_deb
                });
                record.setValue({
                    fieldId: 'account',
                    value: centro_custo
                });
                //verificar
                record.setValue({
                    fieldId: 'tranid',
                    value: id
                });
                record.setValue({
                    fieldId: 'custbody_lrc_numero_processo',
                    value: nr_processo
                });
                record.setValue({
                    fieldId: 'custbody_lrc_proprietario',
                    value: autor_recla
                });
                record.setValue({
                    fieldId: 'custbody_enl_operationtypeid',
                    value: tipoOperacao
                });
            }
            catch (e) {
                arrayErro.push(e);
                return;
            }
            var recordId;
            try {
                recordId = record.save({
                    ignoreMandatoryFields: true
                });
            }
            catch (_b) {
                arrayErro.push(objErro.faturaErro);
                return;
            }
            var obj = {
                id_interno: id,
                n_do_documento: recordId,
                status: status
            };
            arrayObj.push(obj);
        });
        var objFinal = {
            erros: arrayErro,
            objs: arrayObj
        };
        return objFinal;
    };
    exports.post = post;
});
