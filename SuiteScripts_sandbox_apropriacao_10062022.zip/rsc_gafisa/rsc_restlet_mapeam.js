/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/record', 'N/runtime'],
    /**
     * @param{record} Record
     * @param{runtime} runtime
     */
    (Record, runtime) => {
        /**
         * Defines the function that is executed when a GET request is sent to a RESTlet.
         * @param {Object} requestParams - Parameters from HTTP request URL; parameters passed as an Object (for all supported
         *     content types)
         * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
         *     Object when request Content-Type is 'application/json' or 'application/xml'
         * @since 2015.2
         */
        const get = (requestParams) => {
            try{
                //requestParams retorna array com os dados do link
                var dados = []
                dados.push(requestParams)

                //Array para pegar os dados do requestParams
                var idNetSuite = dados[0]["idNetSuite"]

                var registro = Record.load({
                    type:"vendorbill",
                    id:idNetSuite
                })

            }catch (e) {
                log.debug("erro",e)
            }
            return registro
        }

        /**
         * Defines the function that is executed when a PUT request is sent to a RESTlet.
         * @param {string | Object} requestBody - The HTTP request body; request body are passed as a string when request
         *     Content-Type is 'text/plain' or parsed into an Object when request Content-Type is 'application/json' (in which case
         *     the body must be a valid JSON)
         * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
         *     Object when request Content-Type is 'application/json' or 'application/xml'
         * @since 2015.2
         */
        const put = (requestBody) => {

        }

        /**
         * Defines the function that is executed when a POST request is sent to a RESTlet.
         * @param {string | Object} ctx - The HTTP request body; request body is passed as a string when request
         *     Content-Type is 'text/plain' or parsed into an Object when request Content-Type is 'application/json' (in which case
         *     the body must be a valid JSON)
         * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
         *     Object when request Content-Type is 'application/json' or 'application/xml'
         * @since 2015.2
         */
        var post = (ctx) => {
            var dados = [];
            var mensagem = [];
            var objErro = {
                valorInvalido: 'o valor adicionado ao campo é inválido ou está vazio!',
                jsonInvalido: 'o json está incorreto',
                faturaErro: 'Erro ao criar o registro, verificar o json e os valores preenchidos'
            };

            ctx.forEach(function (cobranca, index) {
                var sequencial, situacao, data_fatura, tipo_doc, cod_empresa, data_lancamento, referencia, texto_cabecalho, cod_forn, valor, divisao, cond_pgto, data_base, atribuicao, texto_item, conta_deb, divisao_deb, centro_custo, id, nr_processo, autor_recla, documentos;
                try {
                    sequencial = cobranca.sequencial;
                    situacao = cobranca.situacao;
                    data_fatura = cobranca.data_fatura;
                    tipo_doc = cobranca.tipo_doc;
                    cod_empresa = cobranca.cod_empresa;
                    data_lancamento = cobranca.data_lancamento;
                    referencia = cobranca.referencia;
                    texto_cabecalho = cobranca.texto_cabecalho;
                    cod_forn = cobranca.cod_forn;
                    valor = cobranca.valor;
                    divisao = cobranca.divisao;
                    cond_pgto = cobranca.cond_pgto;
                    data_base = cobranca.data_base;
                    atribuicao = cobranca.atribuicao;
                    texto_item = cobranca.texto_item;
                    conta_deb = cobranca.conta_deb;
                    divisao_deb = cobranca.divisao_deb;
                    centro_custo = cobranca.centro_custo;
                    id = cobranca.id;
                    nr_processo = cobranca.nr_processo;
                    autor_recla = cobranca.autor_recla;
                    documentos = cobranca.documentos;
                }
                catch (_a) {
                    return objErro.jsonInvalido;
                }
                data_base = data_base.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                data_base = new Date(data_base);
                var contaSublista = runtime.getCurrentScript().getParameter({
                    name: 'custscript_lrc_despesa_conta'
                });

                log.debug("contaSublista", contaSublista)

                var tipoOperacao = runtime.getCurrentScript().getParameter({
                    name: 'custscript_lrc_tipo_de_operacao'
                });
                log.debug("tipoOperação", tipoOperacao)

                var record = Record.create({
                    type: 'vendorbill',
                    isDynamic: true,
                });

                var status = record.getValue({
                    fieldId: 'approvalstatus'
                });

                try {
                    record.setValue({
                        fieldId: 'custbody_lrc_status',
                        value: situacao
                    });

                    record.setValue({
                        fieldId: 'custbody_lrc_data_fatura',
                        value: data_fatura
                    });

                    record.setValue({
                        fieldId: 'custbody_enl_order_documenttype',
                        value: tipo_doc
                    });
                    record.setValue({
                        fieldId: 'custbody_lrc_numero_fornecedor',
                        value: cod_empresa
                    });
                    record.setValue({
                        fieldId: 'custbody_lrc_data_lancamento',
                        value: data_lancamento
                    });
                    record.setValue({
                        fieldId: 'custbody_lrc_referencia',
                        value: referencia
                    });
                    record.setValue({
                        fieldId: 'memo',
                        value: texto_cabecalho
                    });
                    record.setValue({
                        fieldId: 'entity',
                        value: cod_forn
                    });
                    record.setValue({
                        fieldId: 'usertotal',
                        value: valor
                    });
                    record.setValue({
                        fieldId: 'custbody_lrc_divisao',
                        value: divisao
                    });
                    record.setValue({
                        fieldId: 'terms',
                        value: cond_pgto
                    });
                    record.setValue({
                        fieldId: 'duedate',
                        value: data_base
                    });
                    record.setValue({
                        fieldId: 'custbody_lrc_atribuicao',
                        value: atribuicao
                    });
                    var line = record.getLineCount({
                        sublistId: 'expense'
                    });

                    log.debug("line", line)

                    record.setValue({
                        fieldId: 'custbody_lrc_texto_item',
                        value: texto_item
                    });

                    // record.setCurrentSublistValue({
                    //     line: line,
                    //     sublistId: 'expense',
                    //     fieldId: 'account',
                    //     value: contaSublista
                    // });

                    record.setValue({
                        fieldId: 'account',
                        value: 114
                    })

                    record.setCurrentSublistValue({
                        line: line,
                        sublistId: 'expense',
                        fieldId: 'grossamt',
                        value: valor
                    });
                    record.setValue({
                        fieldId: 'custbody_lrc_conta_deb',
                        value: conta_deb
                    });
                    record.setValue({
                        fieldId: 'custbody_lrc_div_deb',
                        value: divisao_deb
                    });
                    record.setValue({
                        fieldId: 'account',
                        value: centro_custo
                    });
                    //verificar
                    record.setValue({
                        fieldId: 'tranid',
                        value: id
                    });

                    record.setValue({
                        fieldId: 'custbody_lrc_numero_processo',
                        value: nr_processo
                    });
                    record.setValue({
                        fieldId: 'custbody_lrc_proprietario',
                        value: autor_recla
                    });
                    record.setValue({
                        fieldId: 'custbody_enl_operationtypeid',
                        value: tipoOperacao
                    });
                }
                catch (e) {
                    log.debug("e", e)
                    mensagem.push(e);
                    // return;
                }

                try {
                    var recordId;
                    recordId = record.save({
                        ignoreMandatoryFields: true
                    });
                    log.debug("recordId",recordId)
                }
                catch (_b) {
                    log.debug("_b", _b)
                    mensagem.push(objErro.faturaErro);
                    // return;
                }
                log.debug('mensagem', mensagem)

                var obj = {
                    "id_interno": id,
                    "n_do_documento": recordId || "erro na criação do registro no Netsuite",
                    "status": status,
                    "msg": mensagem[index]
                };
                dados.push(obj);
            });

            log.debug("dados", dados)

            var objFinal = {
                    dados
            };
            return objFinal;
            // return ctx;

        }

        /**
         * Defines the function that is executed when a DELETE request is sent to a RESTlet.
         * @param {Object} requestParams - Parameters from HTTP request URL; parameters are passed as an Object (for all supported
         *     content types)
         * @returns {string | Object} HTTP response body; returns a string when request Content-Type is 'text/plain'; returns an
         *     Object when request Content-Type is 'application/json' or 'application/xml'
         * @since 2015.2
         */
        const doDelete = (requestParams) => {

        }

        return {get, put, post, delete: doDelete}

    });
