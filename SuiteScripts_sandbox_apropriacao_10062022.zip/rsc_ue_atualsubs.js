/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define(['N/query'], function(query) {

    function beforeLoad(ctx) {

        resultQuery = query.runSuiteQL({
        query: "SELECT "+ "name, "+"custrecord_rsc_pen_atual_fornecedores "+"id, "
        "FROM " + "subsidiary "+
        "WHERE " + "custrecord_rsc_pen_atual_fornecedores is null"
        }).asMappedResults();

        if(ctx.type == ctx.UserEventType.CREATE)
        var subRecord = record.load({
            type: 'subsidiary',
            id: resultQuery['id'],
            isDynamic: true
        });
        subRecord.setValue({ fieldId: "custrecord_rsc_pen_atual_fornecedores", value: true });

        var subRecordsave = subRecord.save({
            enableSourcing: false,
            ignoreMandatoryFields: true
        
    }

    function beforeSubmit(context) {
        
    }

    function afterSubmit(context) {
        
    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    }
});
