/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
define(["N/currentRecord", "N/record", "N/query"], function(currentRecord, record, query) {

    function pageInit(ctx) {
        var currRecord = ctx.currentRecord;
        var rec_type = currRecord.type;

        var field_cliente = currRecord.getValue({
            fieldId: 'custbody_rsc_projeto_obra_gasto_compra'
        });

        if(rec_type == 'purchaserequisition' && field_cliente != '') {
            var field_etapa = currRecord.getValue({ // Buscando o valor de Etapa do Projeto
                fieldId: 'custpage_rsc_etapa'
            });

            currRecord.setValue({ // Configurando o valor de Etapa no corpo do form.
                //sublistId: 'item',
                fieldId: 'class',
                value: field_etapa
            });
        }
    }

    function postSourcing(ctx) {
        var currRecord = currentRecord.get();
        var fieldId = ctx.fieldId;
        var sublistId = ctx.sublistId;
        var rec_type = currRecord.type;

        var field_cliente = currRecord.getValue({
            fieldId: 'custbody_rsc_projeto_obra_gasto_compra'
        });

        if(rec_type == 'purchaserequisition') {
            if (fieldId == 'item' && sublistId == 'item' && field_cliente != '') {
                var item = currRecord.getCurrentSublistValue({
                    fieldId: 'item',
                    sublistId: 'item',
                });
                console.log('item :', item);

                var field_projecttask = currRecord.getValue({ // Buscando o valor de projecttask
                    fieldId: 'custpage_rsc_projecttask',
                });
                console.log('projecttask :', field_projecttask)

                var field_etapa = currRecord.getValue({ // Buscando o valor de Etapa do Projeto
                    fieldId: 'custpage_rsc_etapa'
                });

                var field_class = currRecord.getValue({ // Buscando o valor de Etapa do Projeto
                    fieldId: 'class'
                });
                console.log('etapa: ', field_etapa);

                var field_cliente = currRecord.getValue({ // Buscando o valor de Cliente: Tarefa
                    fieldId: 'custbody_rsc_projeto_obra_gasto_compra'
                });
                console.log('cliente: ', field_cliente);

                var field_tarefa = currRecord.getValue({ // Buscando o valor de Tarefa de Projeto
                    fieldId: 'custpage_rsc_tarefa',
                });
                console.log('tarefa: ', field_tarefa);

                if (item){
                    currRecord.setCurrentSublistValue({ // Configurando o valor de Etapa do Projeto
                        sublistId: 'item',
                        fieldId: 'custcol_rsc_fieldetapa',
                        value: field_etapa
                    });
                    currRecord.setCurrentSublistValue({ // Configurando o valor de Cliente: Tarefa
                        sublistId: 'item',
                        fieldId: 'custcol_rsc_fieldcliente',
                        value: field_cliente
                    });
                    currRecord.setCurrentSublistValue({ // Configurando o valor de Tarefa de Projeto
                        sublistId: 'item',
                        fieldId: 'custcol_rsc_fieldtarefa',
                        value: field_tarefa
                    });

                    currRecord.setCurrentSublistValue({ // Configurando o valor de Etapa do Projeto Nativo
                        sublistId: 'item',
                        fieldId: 'class',
                        value: field_class
                    });
                    currRecord.setCurrentSublistValue({ // Configurando o valor de Cliente: Tarefa Nativo
                        sublistId: 'item',
                        fieldId: 'customer',
                        value: field_cliente
                    });
                }
            }

            if (fieldId == 'customer' && sublistId == 'item' && field_cliente != '') {
                var item = currRecord.getCurrentSublistValue({
                    fieldId: 'item',
                    sublistId: 'item',
                });
                log.audit({title: 'field_projecttask', details: field_projecttask});

                var field_projecttask = currRecord.getValue({ // Buscando o valor de projecttask
                    fieldId: 'custpage_rsc_projecttask',
                });

                log.audit({title: 'field_projecttask', details: field_projecttask});

                currRecord.setCurrentSublistValue({ // Configurando o valor de Tarefa de Projeto Nativo
                    sublistId: 'item',
                    fieldId: 'projecttask',
                    value: field_projecttask
                });
            }
        }

        if(rec_type == 'purchaseorder' || rec_type == 'vendorbill'){
            if (fieldId == 'item' && sublistId == 'item' && field_cliente != '') {
                var item = currRecord.getCurrentSublistValue({
                    fieldId: 'item',
                    sublistId: 'item',
                });
                //console.log('item :', item);

                var lines = currRecord.getLineCount({
                    sublistId: 'item'
                });
                //console.log('Linhas :', lines);

                if(lines > 0){
                    var field_etapa = currRecord.getSublistValue({ // Buscando o valor de Etapa do Projeto
                        sublistId: 'item',
                        fieldId: 'custcol_rsc_fieldetapa',
                        line: 0
                    });
                    //console.log('etapa: ', field_etapa);

                    var field_cliente = currRecord.getValue({ // Buscando o valor de Cliente: Tarefa
                        fieldId: 'custbody_rsc_projeto_obra_gasto_compra'
                    });
                    //console.log('cliente: ', field_cliente);

                    var field_tarefa = currRecord.getSublistValue({ // Buscando o valor de Tarefa de Projeto
                        sublistId: 'item',
                        fieldId: 'custcol_rsc_fieldtarefa',
                        line: 0
                    });
                    //console.log('tarefa: ', field_tarefa);

                    if (item){
                        currRecord.setCurrentSublistValue({ // Configurando o valor de Etapa do Projeto
                            sublistId: 'item',
                            fieldId: 'custcol_rsc_fieldetapa',
                            value: field_etapa
                        });
                        currRecord.setCurrentSublistValue({ // Configurando o valor de Cliente: Tarefa
                            sublistId: 'item',
                            fieldId: 'custcol_rsc_fieldcliente',
                            value: field_cliente
                        });
                        currRecord.setCurrentSublistValue({ // Configurando o valor de Tarefa de Projeto
                            sublistId: 'item',
                            fieldId: 'custcol_rsc_fieldtarefa',
                            value: field_tarefa
                        });
                    }
                }
            }

        }
    }

    function fieldChanged(ctx) {
        var currRecord = currentRecord.get();
        var fieldId = ctx.fieldId;
        var sublistId = ctx.sublistId;
        var rec_type = currRecord.type;

        var field_cliente = currRecord.getValue({
            fieldId: 'custbody_rsc_projeto_obra_gasto_compra'
        });
        if (rec_type == 'purchaserequisition') {
            if (fieldId == 'projecttask' && sublistId == 'item' && field_cliente != '') {
                var projectTask = currRecord.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'projecttask'
                });
                if (projectTask>0){
                    
                log.audit({
                    title: 'Project Task', details: projectTask
                });

                var queryResults
                queryResults = query.runSuiteQL(
                    {
                        query: 'select custevent_rsc_etapa_projeto from projecttask where id = ?' ,
                        params: [projectTask]
                    }
                );

                var records = queryResults.asMappedResults();
                log.audit({title:'Registros selecionados', details: records.length});
                if ( records.length > 0 ) {
                    var record = records[0];
                    currRecord.setCurrentSublistValue({ // Configurando o valor de Etapa do Projeto Nativo
                        sublistId: 'item',
                        fieldId: 'class',
                        value: record['custevent_rsc_etapa_projeto']
                    });
                }

                }

            }

        }
    }
        return {
            pageInit: pageInit,
            postSourcing: postSourcing,
            fieldChanged: fieldChanged
        }
    });

