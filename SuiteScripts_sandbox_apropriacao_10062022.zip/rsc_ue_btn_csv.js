/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @author Wilson
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.VIEW || ctx.type == ctx.UserEventType.EDIT) {
            var form = ctx.form;
            form.addButton({
                label: 'Export CSV',
                id: 'custpage_export_btn',
                functionName: 'export_csv'
            });
            form.clientScriptModulePath = './rsc_client_btn_export_csv.js';
        }
    };
    exports.beforeLoad = beforeLoad;
});
