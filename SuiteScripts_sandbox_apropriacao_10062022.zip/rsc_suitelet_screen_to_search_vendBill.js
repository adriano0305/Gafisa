/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 @author Wilson
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/log", "N/query"], function (require, exports, UI, log_1, query_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    log_1 = __importDefault(log_1);
    query_1 = __importDefault(query_1);
    var onRequest = function (ctx) {
        var form = FormContent(ctx);
        if (ctx.request.method == 'POST') {
            var params = ctx.request.parameters;
            var periodo = params['custpage_listdate'];
            log_1.default.debug('Periodo', periodo);
            var format = '';
            if (periodo < 10) {
                format = "0" + periodo;
            }
            else {
                format = periodo;
            }
            form.addButton({
                label: 'Export CSV',
                id: 'custpage_btn',
                functionName: 'export'
            });
            var sql = "SELECT \n    id,\n    custbody_enl_fiscaldocnumber, \n    custbody_enl_operationtypeid, \n    custbody_enl_transportorigin,\n    custbody_enl_transportdestination,\n    entity,\n    custbody_alvr_codigo_situacao,\n    custbody_enl_instal_instalmentway,\n    custbody_enl_fiscaldocumentserie,\n    trandate,\n    custbody_enl_fiscaldocdate,\n    FROM \n    transaction WHERE type='VendBill' AND custbody_enl_statusrecebimento=2 AND custbody_enl_fiscaldocnumber IS NOT NULL AND trandate BETWEEN '01/" + String(format) + "/2021' AND '31/" + String(format) + "/2021'\n    ";
            var queryResult = query_1.default.runSuiteQL({
                query: sql
            }).asMappedResults();
            log_1.default.debug('Tamanho', queryResult.length);
            var len = queryResult.length;
            var sublist = form.addSublist({
                id: 'custpage_sublist_result',
                type: UI.SublistType.LIST,
                label: 'Resultados'
            });
            sublist.addField({
                id: 'custpage_doc_fiscal',
                label: 'Documento Fiscal',
                type: UI.FieldType.TEXT
            });
            sublist.addField({
                id: 'custpage_vendor',
                label: 'Fornecedor',
                type: UI.FieldType.TEXT
            });
            var transactions = [];
            for (var i = 0; i < len; i++) {
                var data = queryResult[i];
                if (transactions.indexOf(data["id"]) == -1) {
                    sublist.setSublistValue({
                        id: 'custpage_doc_fiscal',
                        value: data['custbody_enl_fiscaldocnumber'],
                        line: i
                    });
                    sublist.setSublistValue({
                        id: 'custpage_vendor',
                        value: String(data['entity']),
                        line: i
                    });
                    transactions.push(data["id"]);
                }
            }
        }
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
    var FormContent = function (ctx) {
        log_1.default.debug('Ctx', ctx.request);
        var form = UI.createForm({
            title: 'Seach Vendor Bill'
        });
        // form.addField({
        // id: 'custpage_incios',
        // label: 'Date (Início)',
        // type: UI.FieldType.DATE
        // })
        // form.addField({
        // id: 'custpage_fim',
        // label: 'Date (Fim)',
        // type: UI.FieldType.DATE
        // })
        var list_periodo = form.addField({
            id: 'custpage_listdate',
            label: 'Período',
            type: UI.FieldType.SELECT
        });
        list_periodo.addSelectOption({
            text: 'Janeiro',
            value: 1
        });
        list_periodo.addSelectOption({
            text: 'Fevereiro',
            value: 2
        });
        list_periodo.addSelectOption({
            text: 'Março',
            value: 3
        });
        list_periodo.addSelectOption({
            text: 'Abril',
            value: 4
        });
        list_periodo.addSelectOption({
            text: 'Maio',
            value: 5
        });
        list_periodo.addSelectOption({
            text: 'Junho',
            value: 6
        });
        list_periodo.addSelectOption({
            text: 'Julho',
            value: 7
        });
        list_periodo.addSelectOption({
            text: 'Agosto',
            value: 8
        });
        list_periodo.addSelectOption({
            text: 'Setembro',
            value: 9
        });
        list_periodo.addSelectOption({
            text: 'Outubro',
            value: 10
        });
        list_periodo.addSelectOption({
            text: 'Novembro',
            value: 11
        });
        list_periodo.addSelectOption({
            text: 'Dezembro',
            value: 12
        });
        form.addSubmitButton({
            label: 'Buscar'
        });
        return form;
    };
});
