/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/record"], function (require, exports, currentRecord_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.criarContratoDeCompra = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    record_1 = __importDefault(record_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var criarContratoDeCompra = function () {
        var currRecord = currentRecord_1.default.get();
        var date = currRecord.getValue({
            fieldId: 'trandate'
        });
        var subsidiary = currRecord.getValue({
            fieldId: 'subsidiary'
        });
        var contrato = record_1.default.create({
            type: 'purchasecontract',
        });
        var line = currRecord.getLineCount({
            sublistId: 'item'
        });
        for (var i = 0; i < line; i++) {
            var sublist = currRecord.getSublistValue({
                fieldId: 'item',
                sublistId: 'item',
                line: i
            });
            console.log('sublist', sublist);
            contrato.setSublistValue({
                sublistId: 'item',
                line: i,
                fieldId: 'item',
                value: sublist
            });
        }
        contrato.setValue({
            fieldId: 'subsidiary',
            value: subsidiary
        });
        contrato.setValue({
            fieldId: 'trandate',
            value: date
        });
        contrato.save();
    };
    exports.criarContratoDeCompra = criarContratoDeCompra;
});
