/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 @author Wilson
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/file", "N/log", "N/config", "N/query"], function (require, exports, file_1, log_1, config_1, query_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    file_1 = __importDefault(file_1);
    log_1 = __importDefault(log_1);
    config_1 = __importDefault(config_1);
    query_1 = __importDefault(query_1);
    var onRequest = function (ctx) {
        if (ctx.request.method == 'POST') {
            var body = JSON.parse(ctx.request.body);
            log_1.default.debug('Body', body['id']);
            var type_register = body["type_register"];
            var entity = body["entity"];
            var type_operation = body["type_operation"];
            var method_pag = body["method_pag"];
            var iss_code_ibge = body["iss_code_ibge"];
            var number_fiscal = body["number_fiscal"];
            var doc_serie = body["doc_serie"];
            var date_fiscal_doc = body["date_fiscal_doc"];
            var situation = body["situation"];
            var incricao_mnicipal = body["incricao_mnicipal"];
            var periodo_escritura = body["pediodo_escritura"];
            var CompanyInfo = config_1.default.load({
                type: config_1.default.Type.COMPANY_INFORMATION
            });
            var tax_code_avalara = CompanyInfo.getValue('custrecord_avlr_tco_companycode');
            //Log.debug(tax_code_avalara)
            var key = "Tipo de registro;Companhia;Estabelecimento Fiscal;Inscrição Municipal;Código Parceiro;Código Modelo;Modelo Serviço;Número Documento;Tipo operação;Número de série;Subsérie;Data Emissão Documento;Data de Entrada/Saída;Data de Execução do Serviço;Local de Execução do Serviço;Situação;Finalidade do Documento Fiscal;Chave Nota Fiscal Eletrônica;Tipo de Consumo;Tipo de Pagamento;Classe de Consumo;Tipo de Ligação;Grupo de Tensão;Status;Indicador NF de Ativo;Local de Recolhimento do ISS;Município de Exec. do Serviço;Indicador Operação com Consumidor Final;Indicador Presença Comprador;Indicador de Intermediário ou Marketplace;Indicador da IE do Destinatário;Código de Referência da Integração;IE Substituto;Data Cancelamento;Período Escrituração;Código Obra;Código Obra Filial;Código CEI;Nro. Lançamento Contábil;Motivo Cancelamento;Nota Fiscal de Entrada Emitida pelo próprio Estabelecimento;Base do ICMS;Valor do ICMS;Base do ICMS Reduzido;Valor Total FCP UF Destino;Valor Total ICMS Interestadual UF Destino;Valor Total ICMS Interestadual UF Remetente;Base de Cálculo do ICMS ST;Valor do ICMS ST;Valor do ICMS ST - Não Tributado;Valor FCP ST;Valor FCP Retido ST;Valor do IPI;Valor IPI - Não Tributado;Valor IPI Devolvido;Valor do PIS;Valor do PIS Retido por ST;Valor do COFINS;Valor do COFINS ST;Valor da Previdência Retida;Valor da Previdência Devida;Valor dos Serviços;Valor do ISSQN;Valor do IRRF;Desconto Livre de Comércio;Desconto da Zona Franca;Valor Total do Desconto;Valor de Outras Despesas;Valor do frete;Valor do Seguro;Valor Dedução;Valor Total das Mercadorias;Valor Total do Documento;Transportadora;Placa do Veículo;Via de Transporte;Espécie do Volume;Quantidade;Peso Bruto;Peso Líquido;Marca;Numero;Estado;Tipo de Frete;Indicador Natureza Frete;Tipo de CT-e;Chave CT-e;Chave CT-e de Referência;País Embarque;Estado embarque;Local Embarque;Local Despacho;Descrição Complementar;Indicativo do Intermediador/Marketplace;Categoria Documento Fiscal\n";
            var values = type_register + ";" + tax_code_avalara + ";" + incricao_mnicipal + ";;" + entity + ";SV;;" + number_fiscal + ";" + type_operation + ";" + (doc_serie == '' ? 'U' : doc_serie) + ";;" + date_fiscal_doc + ";06/10/2021;;;" + situation + ";;;;" + method_pag + ";;;;;;" + iss_code_ibge + ";" + iss_code_ibge + ";;;;;;;;" + periodo_escritura + ";;;;;;;0.00;0.00;;;;;;;;;;;;;0.00;;0.00;;;;;;;;;;;;;;0.00;1024.80;;;;;;;;;;;;;;;;;;;;;";
            // const key_split = key.split(';')
            // Log.audit('Length', key_split)
            // const values_split = values.split(';')
            // Log.audit('Lenght of Vlaue', values_split)
            // for (let i = 0; i < values_split.length; i++){
            // if (key_split[i] == 'Local de Recolhimento do ISS') {
            // Log.debug('Chegou no IF')
            // values_split[i] = 'Teste'
            // }
            // Log.audit(key_split[i], values_split[i])
            // } 
            // const new_content = key_split.join(',') + values_split.join(',')
            // Log.debug('Content', new_content)
            var content = key + values;
            var newFile = file_1.default.create({
                name: "File " + body["id"] + ".csv",
                fileType: file_1.default.Type.CSV,
                contents: content,
                folder: 1029
            });
            var fileId = newFile.save();
            //Log.debug('FileId', fileId)
            if (fileId) {
                var csv_file = file_1.default.load({
                    id: fileId
                });
                var sql = "SELECT url FROM file WHERE id=" + fileId;
                var query_result = query_1.default.runSuiteQL({
                    query: sql
                }).asMappedResults();
                log_1.default.debug('result query', query_result);
                ctx.response.write(query_result[0].url);
            }
        }
    };
    exports.onRequest = onRequest;
});
