/**
 *@NApiVersion 2.1
*@NScriptType UserEventScript
*/

const custPage = 'custpage_rsc_';
const hoje = new Date();

define(['N/file', 'N/log', 'N/query', 'N/record', 'N/runtime', 'N/search', 'N/task', 'N/ui/serverWidget'], (file, log, query, record, runtime, search, task, serverWidget) => {
const lancamentoAdicionais = (id, valor, status) => {
    log.audit('lancamentoAdicionais', {id: id, valor: valor, status: status});

    var lkpFI = search.lookupFields({type: 'customsale_rsc_financiamento',
        id: id,
        columns: ['entity','location','subsidiary','tranid']
    });

    var campos;
    
    if (!status) {
        campos = {
            memo: 'GAFISA',
            custbody_ref_parcela: id,
            subsidiary: lkpFI.subsidiary[0].value,
            line: [{
                account: contas.CREDITO.acrescimos.id,
                credit: valor,
                memo: contas.CREDITO.acrescimos.nome,
                entity: lkpFI.entity[0].value,
                location: lkpFI.location[0].value
            },{
                account: contas.DEBITO.acrescimos.id,
                debit: valor,
                memo: contas.DEBITO.acrescimos.nome,
                entity: lkpFI.entity[0].value,
                location: lkpFI.location[0].value
            }]
        }
    } else {
        campos = {
            memo: 'GAFISA',
            custbody_ref_parcela: id,
            subsidiary: lkpFI.subsidiary[0].value,
            line: [{
                account: contas.CREDITO.pagamentos.id,
                credit: valor,
                memo: contas.CREDITO.pagamentos.nome,
                entity: lkpFI.entity[0].value,
                location: lkpFI.location[0].value
            },{
                account: contas.DEBITO.pagamentos.id,
                debit: valor,
                memo: contas.DEBITO.pagamentos.nome,
                entity: lkpFI.entity[0].value,
                location: lkpFI.location[0].value
            }]
        } 
    }   
    
    log.audit('campos', campos);

    var lancamento = record.create({type: 'journalentry', 
        isDynamic: true,
        defaultValues: {'bookje': 'T'}
    });
    log.audit('lancamento', lancamento);

    Object.keys(campos).forEach(function(bodyField) {
        lancamento.setValue({
            fieldId: bodyField, 
            value: campos[bodyField]
        });
    });

    for (var key in campos.line) {
        lancamento.selectNewLine({
            sublistId: 'line' 
        });

        lancamento.setCurrentSublistValue({
            sublistId: 'line',
            fieldId: 'account',
            value: campos.line[key].account
        });

        if (campos.line[key].credit > 0) {
            lancamento.setCurrentSublistValue({
                sublistId: 'line',
                fieldId: 'credit',
                value: campos.line[key].credit
            });
        } else {
            lancamento.setCurrentSublistValue({
                sublistId: 'line',
                fieldId: 'debit',
                value: campos.line[key].debit
            });
        }

        lancamento.setCurrentSublistValue({
            sublistId: 'line',
            fieldId: 'memo',
            value: campos.line[key].memo
        });

        lancamento.setCurrentSublistValue({
            sublistId: 'line',
            fieldId: 'entity',
            value: campos.line[key].entity
        });

        lancamento.setCurrentSublistValue({
            sublistId: 'line',
            fieldId: 'location',
            value: campos.line[key].location
        });

        lancamento.commitLine({
            sublistId: 'line'
        });
    }

    var idLancamento = lancamento.save({ignoreMandatoryFields: true});

    if (idLancamento) {
        var lpkLancamento = search.lookupFields({type: 'journalentry',
            id: idLancamento,
            columns: ['tranid']
        });
        log.audit(lkpFI.tranid, {idLancamento: idLancamento, numeroEntrada: lpkLancamento.tranid});
 
        if (status) {
            record.load({type: 'customsale_rsc_financiamento', id: id})
            .setValue('custbody_rsc_pago', status)
            .save({ignoreMandatoryFields: true})
        }
    }
}

const gerarLancamentos = (dados) => {
    log.audit('gerarLancamentos', dados);

    dados.forEach(function(campos, indice) {
        var num = Number(indice+1);
        log.audit((num)+'º Lançamento', campos);

        var lancamento = record.create({type: 'journalentry', 
            isDynamic: true,
            defaultValues: {'bookje': 'T'}
        });

        Object.keys(campos).forEach(function(bodyField) {
            lancamento.setValue(bodyField, campos[bodyField]);              
        });

        for (var key in campos.line) {
            lancamento.selectNewLine('line')
            .setCurrentSublistValue('line', 'account', campos.line[key].account);

            if (campos.line[key].credit > 0) {
                lancamento.setCurrentSublistValue('line', 'credit', campos.line[key].credit);
            } else {
                lancamento.setCurrentSublistValue('line', 'debit', campos.line[key].debit);
            }

            lancamento.setCurrentSublistValue('line', 'memo', campos.line[key].memo)
            .setCurrentSublistValue('line', 'entity', campos.line[key].entity)
            .setCurrentSublistValue('line', 'location', campos.line[key].location)
            .commitLine('line');
        }

        var idLancamento = lancamento.save({ignoreMandatoryFields: true});

        if (idLancamento) {
            var lpkLancamento = search.lookupFields({type: 'journalentry',
                id: idLancamento,
                columns: ['tranid']
            });
            log.audit('Sucesso', {idLancamento: idLancamento, numeroEntrada: lpkLancamento.tranid});
        }
    });      
}

const remold = (array) => {
    var arrayLancamentos = [];

    for (var prop in array) {
        if (arrayLancamentos.length > 0) {
            const result = arrayLancamentos.find(lancamento => lancamento.id === array[prop].id && lancamento.expenseaccount === array[prop].expenseaccount);

            if (result) {
                log.audit('Finded!', result);
            } else {
                arrayLancamentos.push({
                    id: array[prop].id,
                    tranid: array[prop].tranid,
                    trandate: array[prop].trandate,
                    custbody_ref_parcela: array[prop].custbody_ref_parcela,
                    expenseaccount: array[prop].expenseaccount,
                    memo: array[prop].memo,
                    debitforeignamount: array[prop].debitforeignamount,
                    creditforeignamount: array[prop].creditforeignamount,
                    location: array[prop].location
                });
            }
        } else {
            arrayLancamentos.push({
                id: array[prop].id,
                tranid: array[prop].tranid,
                trandate: array[prop].trandate,
                custbody_ref_parcela: array[prop].custbody_ref_parcela,
                expenseaccount: array[prop].expenseaccount,
                memo: array[prop].memo,
                debitforeignamount: array[prop].debitforeignamount,
                creditforeignamount: array[prop].creditforeignamount,
                location: array[prop].location
            });
        }
    }

    return arrayLancamentos;
}

const localizarLancamentos = (idFI) => {
    // log.audit('localizarLancamentos', {idFI: idFI});

    var arrayLancamentos = [];

    var sql = "SELECT t.id, t.tranid, t.trandate, t.custbody_ref_parcela, "+
    "tl.expenseaccount, tl.memo, tl.debitforeignamount, tl.creditforeignamount, tl.location "+
    "FROM transaction as t "+
    "INNER JOIN transactionline AS tl ON (tl.transaction = t.id) "+
    "WHERE t.custbody_ref_parcela = ? ";

    var consulta = query.runSuiteQL({
        query: sql,
        params: [idFI]
    });

    var sqlResults = consulta.asMappedResults();  

    var fileObj = file.create({
        name: 'arrayLancamentos.txt',
        fileType: file.Type.PLAINTEXT,
        folder: 704, // SuiteScripts > teste > Arquivos
        contents: JSON.stringify(sqlResults)
    });

    var fileObjId = fileObj.save();

    if (sqlResults.length > 0) {
        // log.audit('sqlResults', sqlResults);

        for (i=0; i<sqlResults.length; i++) {
            arrayLancamentos.push({
                id: sqlResults[i].id,
                tranid: sqlResults[i].tranid,
                trandate: sqlResults[i].trandate,
                custbody_ref_parcela: sqlResults[i].custbody_ref_parcela,
                expenseaccount: sqlResults[i].expenseaccount,
                memo: sqlResults[i].memo,
                debitforeignamount: sqlResults[i].debitforeignamount,
                creditforeignamount: sqlResults[i].creditforeignamount,
                location: sqlResults[i].location
            });
        }
    }

    arrayLancamentos = arrayLancamentos.filter(function (dados) {
        return !this[JSON.stringify(dados)] && (this[JSON.stringify(dados)] = true);
    }, Object.create(null));

    arrayLancamentos = [...new Set(arrayLancamentos)];
    
    // var fileObj = file.create({
    //     name: 'arrayLancamentos.txt',
    //     fileType: file.Type.PLAINTEXT,
    //     folder: 704, // SuiteScripts > teste > Arquivos
    //     contents: JSON.stringify(arrayLancamentos)
    // });

    // var fileObjId = fileObj.save();
    // log.audit('fileObjId: '+fileObjId, {arrayParcelas: arrayParcelas});
    arrayLancamentos = remold(arrayLancamentos);
    // log.audit('arrayLancamentos', arrayLancamentos);

    return arrayLancamentos;
}

const sublistaLancamentos = (form, idFI) => {
    // log.audit('sublistaLancamentos', {form: form, idFI: idFI});

    // Guia Lançamentos
    const guia_fluxo_lancamentos = form.addTab({
        id: custPage+'guia_fluxo_lancamentos',
        label: 'Contabilidade'
    });

    // Sublista Lançamentos
    const listaLancamentos = form.addSublist({
        id: custPage+'lancamentos',
        type: 'list',
        label: 'Lançamentos',
        tab: custPage+'guia_fluxo_lancamentos'
    });

    var linhaLancamento = listaLancamentos.addField({
        id: custPage+'linha_lancamento',
        type: 'integer',
        label: '#'
    });

    var tranid = listaLancamentos.addField({
        id: custPage+'tranid',
        type: 'text',
        label: 'Tranid'
    });

    var data = listaLancamentos.addField({
        id: custPage+'data',
        type: 'date',
        label: 'Data'
    });

    var conta = listaLancamentos.addField({
        id: custPage+'conta',
        type: 'select',
        label: 'Conta',
        source: 'account'
    });

    conta.updateDisplayType({
        displayType: serverWidget.FieldDisplayType.INLINE
    });

    var debito = listaLancamentos.addField({
        id: custPage+'debito',
        type: 'currency',
        label: 'Débito'
    });

    var credito = listaLancamentos.addField({
        id: custPage+'credito',
        type: 'currency',
        label: 'Crédito'
    });
    
    var memorando = listaLancamentos.addField({
        id: custPage+'memorando',
        type: 'text',
        label: 'Memorando'
    });

    var localidade = listaLancamentos.addField({
        id: custPage+'localidade',
        type: 'select',
        label: 'Localidade',
        source: 'location'
    });

    localidade.updateDisplayType({
        displayType: serverWidget.FieldDisplayType.INLINE
    });

    var lancamentos = localizarLancamentos(idFI);

    if (lancamentos.length > 0) {
        for (i=0; i<lancamentos.length; i++) {
            listaLancamentos.setSublistValue({
                id: linhaLancamento.id,
                line: i,
                value: i+1
            });

            listaLancamentos.setSublistValue({
                id: tranid.id,
                line: i,
                value: lancamentos[i].tranid
            });

            listaLancamentos.setSublistValue({
                id: data.id,
                line: i,
                value: lancamentos[i].trandate
            });

            listaLancamentos.setSublistValue({
                id: conta.id,
                line: i,
                value: lancamentos[i].expenseaccount
            });

            listaLancamentos.setSublistValue({
                id: debito.id,
                line: i,
                value: lancamentos[i].debitforeignamount
            });

            listaLancamentos.setSublistValue({
                id: credito.id,
                line: i,
                value: lancamentos[i].creditforeignamount
            });

            listaLancamentos.setSublistValue({
                id: memorando.id,
                line: i,
                value: lancamentos[i].memo
            });

            listaLancamentos.setSublistValue({
                id: localidade.id,
                line: i,
                value: lancamentos[i].location
            });
        }
    }
}

const fecharPedido = (acao, transacao, id, tipoTransacaoWF, statusContrato, location, numProposta, tipoContrato) => {
    log.audit('fecharPedido', {acao: acao, transacao: transacao, id: id, tipoTransacaoWF: tipoTransacaoWF, statusContrato: statusContrato, location: location, numProposta: numProposta, tipoContrato: tipoContrato});

    var dia = hoje.getDate() > 9 ? hoje.getDate() : '0'+hoje.getDate();
    var mes = hoje.getMonth() > 9 ? hoje.getMonth() : '0'+(hoje.getMonth()+1); 
    var ano = hoje.getFullYear();
    var str = ' || Approved...';

    var memo = dia+'/'+mes+'/'+ano+str;
    
    var locationProposta = (location.substr(1,4) + numProposta).replace(/\s/g, '');

    var arrayLancamentos = [];

    var loadReg = record.load({type: transacao, id: id});

    loadReg.setValue('memo', memo)
    .setValue('custbody_rsc_tipo_transacao_workflow', tipoTransacaoWF)
    .setValue('custbody_rsc_status_contrato', statusContrato)
    .setValue('custbody_lrc_numero_contrato', locationProposta)
    .setValue('custbody_lrc_tipo_contrato', tipoContrato)
    .save({ignoreMandatoryFields : true});
    log.audit('status', 'Contrato Fechado!');

    // arrayLancamentos.push({
    //     acao: acao,
    //     transacao: transacao,
    //     id: id,
    //     memo: memo,
    //     custbody_rsc_tipo_transacao_workflow: tipoTransacaoWF,
    //     custbody_rsc_status_contrato: statusContrato,
    //     custbody_lrc_numero_contrato: locationProposta,
    //     custbody_lrc_tipo_contrato: tipoContrato
    // });

    // if (arrayLancamentos.length > 0) {
    //     log.audit('arrayLancamentos', arrayLancamentos);
    //     scriptTask = task.create({
    //         taskType: task.TaskType.SCHEDULED_SCRIPT,
    //         scriptId: 1315,    //         
    //         params: {
    //             custscript_rsc_journal_entries: arrayLancamentos
    //         }
    //     });
    //     log.audit('scriptTask', scriptTask);

    //     scriptTaskId = scriptTask.submit();
    //     log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
    // }
}

const beforeLoad = (context) => {
    // log.audit('beforeLoad', context);

    const novoRegistro = context.newRecord;

    const form = context.form;
    var ambiente = runtime.envType;

    if (novoRegistro.id) {
        sublistaLancamentos(form, novoRegistro.id);
    }
}

const beforeSubmit = (context) => {
    // log.audit('beforeSubmit', context);

    const novoRegistro = context.newRecord;

    const tipo = context.type;

    const transacao = novoRegistro.type;

    var ambiente = runtime.envType;
    var usuarioAtual = runtime.getCurrentUser();

    var arrayLancamentos = [];
    var bscTransacao, scriptTask, scriptTaskId;

    // if (usuarioAtual.id == 3588) {
    // if (tipo == 'create') {
        switch(transacao) {
            case 'customerpayment': 
                if (tipo == 'delete') {
                    bscTransacao = search.create({type: "journalentry",
                        filters: [
                           ["shipping","is","F"], "AND", 
                           ["taxline","is","F"], "AND", 
                           ["mainline","is","T"], "AND", 
                           ["type","anyof","Journal"], "AND", 
                           ["custbody_ref_parcela","anyof",novoRegistro.id]
                        ],
                        columns: [
                            "datecreated","internalid","custbody_ref_parcela","amount",
                            search.createColumn({name: "formulatext", formula: "{tranid}", label: "Fórmula (texto)"})
                        ]
                    }).run().getRange(0,1000);
                    log.audit(transacao, {bscTransacao: bscTransacao});
                    
                    if (bscTransacao.length > 0) {
                        for (i=0; i<bscTransacao.length; i++) {
                            var loadReg = record.load({type: 'journalentry', id: bscTransacao[i].id});

                            var reversao = {
                                id: loadReg.id, 
                                status: 'Revertido',
                                tranid: loadReg.getValue('tranid'),
                            }

                            loadReg.setValue('reversaldefer', true)
                            .setValue('reversaldate', new Date())
                            .save({ignoreMandatoryFields: true});
                            
                            log.audit(transacao, reversao);
                        }
                    }
                }
            break;

            case 'invoice': 
                if (tipo == 'delete') {
                    bscTransacao = search.create({type: "journalentry",
                        filters: [
                           ["shipping","is","F"], "AND", 
                           ["taxline","is","F"], "AND", 
                           ["mainline","is","T"], "AND", 
                           ["type","anyof","Journal"], "AND", 
                           ["custbody_ref_parcela","anyof",novoRegistro.id]
                        ],
                        columns: [
                            "datecreated","internalid","custbody_ref_parcela","amount",
                            search.createColumn({name: "formulatext", formula: "{tranid}", label: "Fórmula (texto)"})
                        ]
                    }).run().getRange(0,1000);
                    log.audit(transacao, {bscTransacao: bscTransacao});
                    
                    if (bscTransacao.length > 0) {
                        for (i=0; i<bscTransacao.length; i++) {
                            arrayLancamentos.push({
                                acao: 'delete',
                                transacao: 'journalentry',
                                id: bscTransacao[i].id,
                                tranid: bscTransacao[i].getValue({name: 'formulatext', formula:'{tranid}'})
                            });
                        }
                    }

                    if (arrayLancamentos.length > 0) {
                        scriptTask = task.create({
                            taskType: task.TaskType.SCHEDULED_SCRIPT,
                            scriptId: 1315,                            
                            params: {
                                custscript_rsc_journal_entries: arrayLancamentos
                            }
                        });

                        scriptTaskId = scriptTask.submit();
                        log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                    }
                }
            break;

            case 'salesorder': 
                if (tipo == 'delete') {
                    bscTransacao = search.create({type: "invoice",
                        filters: [
                            ["shipping","is","F"], "AND", 
                            ["taxline","is","F"], "AND", 
                            ["mainline","is","T"], "AND", 
                            ["type","anyof","CustInvc"], "AND", 
                            ["custbody_lrc_fatura_principal","anyof",novoRegistro.id]
                        ],
                        columns: [
                            "internalid","tranid","trandate","total"
                        ]
                    }).run().getRange(0,1000);
                    log.audit(transacao, {bscTransacao: bscTransacao});
                    
                    if (bscTransacao.length > 0) {
                        for (i=0; i<bscTransacao.length; i++) {
                            arrayLancamentos.push({
                                acao: 'delete',
                                transacao: transacao,
                                id: novoRegistro.id,
                                custbody_ref_parcela: bscTransacao[i].id              
                            });
                        }
                    }

                    if (arrayLancamentos.length > 0) {
                        scriptTask = task.create({
                            taskType: task.TaskType.SCHEDULED_SCRIPT,
                            scriptId: 1315,                            
                            params: {
                                custscript_rsc_journal_entries: arrayLancamentos
                            }
                        });

                        scriptTaskId = scriptTask.submit();
                        log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                    }
                }
            break;
        }
    // }    
}

const afterSubmit = (context) => {
    // log.audit('afterSubmit', context);

    const novoRegistro = context.newRecord;
    log.audit('novoRegistro', novoRegistro);
    const velhoRegistro = context.oldRecord;

    const contextoExecucao = runtime.executionContext;
    log.audit('contextoExecucao',contextoExecucao);

    const tipo = context.type;

    const transacao = novoRegistro.type;
    log.audit(transacao, tipo);

    const parametroScript = runtime.getCurrentScript();

    var ambiente = runtime.envType;
    var usuarioAtual = runtime.getCurrentUser();

    var arrayLancamentos = [];
    var sql, consulta, sqlResults, bscTransacao, lkpTransacao, conta, scriptTask, scriptTaskId;

    // if (usuarioAtual.id == 3588) {
    switch(transacao) {
        case 'salesorder': 
            if (tipo == 'edit') {
                var tipoTransacaoWF = novoRegistro.getValue('custbody_rsc_tipo_transacao_workflow');

                if (tipoTransacaoWF == 24) {// PV - Contrato
                    bscTransacao = search.create({type: "invoice",
                        filters: [
                            ["shipping","is","F"], "AND", 
                            ["taxline","is","F"], "AND", 
                            ["mainline","is","T"], "AND", 
                            ["type","anyof","CustInvc"], "AND", 
                            ["custbody_lrc_fatura_principal","anyof",novoRegistro.id]
                        ],
                        columns: [
                            "internalid","tranid","trandate","total"
                        ]
                    }).run().getRange(0,1000);
                    log.audit(transacao, {bscTransacao: bscTransacao});

                    conta = search.lookupFields({type: 'serviceitem',
                        id: parametroScript.getParameter('custscript_rsc_cdt_venda_unidade_1'),
                        columns: ['incomeaccount']
                    }).incomeaccount[0].value;
                    
                    if (bscTransacao.length > 0) {
                        for (i=0; i<bscTransacao.length; i++) {
                            sql = "SELECT id, voided "+
                            "FROM transaction "+
                            "WHERE transaction.id = ? ";

                            consulta = query.runSuiteQL({
                                query: sql,
                                params: [bscTransacao[i].id]
                            });
                        
                            sqlResults = consulta.asMappedResults();

                            if (sqlResults.length == 0) {
                                arrayLancamentos.push({
                                    acao: tipo,
                                    transacao: transacao,
                                    trandate: bscTransacao[i].getValue('trandate'),
                                    memo: 'GAFISA',
                                    subsidiary: novoRegistro.getValue('subsidiary'),
                                    custbody_ref_parcela: bscTransacao[i].id,
                                    line: [{
                                        account: parametroScript.getParameter('custscript_rsc_dbt_venda_unidade_1'),
                                        debit: bscTransacao[i].getValue('total'),
                                        memo: '',
                                        entity: novoRegistro.getValue('entity'),
                                        location: novoRegistro.getValue('location')
                                    },{
                                        account: conta,
                                        credit: bscTransacao[i].getValue('total'),
                                        memo: '',
                                        entity: novoRegistro.getValue('entity'),
                                        location: novoRegistro.getValue('location')
                                    }]               
                                });
                            }
                        }
                    }

                    if (arrayLancamentos.length > 0) {
                        scriptTask = task.create({
                            taskType: task.TaskType.SCHEDULED_SCRIPT,
                            scriptId: 1315,                                
                            params: {
                                custscript_rsc_journal_entries: arrayLancamentos
                            }
                        });
                        log.audit('scriptTask', scriptTask);

                        scriptTaskId = scriptTask.submit();
                        log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                    }
                }
            }
        break;

        case 'invoice':                
            var total = novoRegistro.getValue('total');
            var criadoDe = novoRegistro.getValue('createdfrom');
            var approvalstatus = novoRegistro.getValue('approvalstatus');
            var cessaoDireito = novoRegistro.getValue('custbody_rsc_cessao_direito');
            var tipoRenegociacao = novoRegistro.getValue('custbody_rsc_tipo_renegociacao');

            if (tipo == 'create') {
                if (approvalstatus == 1) {
                    for (i=0; i<novoRegistro.getLineCount('item'); i++) {
                        var item = novoRegistro.getSublistValue('item', 'item', i);
                        var amount = novoRegistro.getSublistValue('item', 'amount', i);

                        if (ambiente == 'PRODUCTION') {
                            log.audit('ambiente', ambiente);
                        } else {
                            switch(item) {
                                case '19420': // FRAÇÃO PRINCIPAL                                
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_venda_unidade_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;

                                    arrayLancamentos.push({
                                        acao: tipo,
                                        transacao: transacao,
                                        memo: 'GAFISA',
                                        subsidiary: novoRegistro.getValue('subsidiary'),
                                        custbody_ref_parcela: novoRegistro.id,                                            
                                        custbody_lrc_fatura_principal: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                        line: [{
                                            account: parametroScript.getParameter('custscript_rsc_dbt_venda_unidade_1'),
                                            debit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        },{
                                            account: conta,
                                            credit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        }]               
                                    });
                                break; 

                                case '19423': // INCC 
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_incc_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;

                                    arrayLancamentos.push({
                                        acao: tipo,
                                        transacao: transacao,
                                        memo: 'GAFISA',
                                        subsidiary: novoRegistro.getValue('subsidiary'),
                                        custbody_ref_parcela: novoRegistro.id,                                            
                                        custbody_lrc_fatura_principal: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                        line: [{
                                            account: parametroScript.getParameter('custscript_rsc_dbt_incc_1'),
                                            debit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        },{
                                            account: conta,
                                            credit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        }]               
                                    });
                                break; 

                                case '19590': // IGP-M
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_igpm_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;

                                    arrayLancamentos.push({
                                        acao: tipo,
                                        transacao: transacao,
                                        memo: 'GAFISA',
                                        subsidiary: novoRegistro.getValue('subsidiary'),
                                        custbody_ref_parcela: novoRegistro.id,                                            
                                        approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                        line: [{
                                            account: parametroScript.getParameter('custscript_rsc_dbt_igpm_1'),
                                            debit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        },{
                                            account: conta,
                                            credit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        }]               
                                    });
                                break;

                                // case '19593': // 6000013 (Serviço Modificação Unidade)
                                //     conta = search.lookupFields({type: 'serviceitem',
                                //         id: parametroScript.getParameter('custscript_rsc_cdt_srv_mod_unidade_1'),
                                //         columns: ['incomeaccount']
                                //     }).incomeaccount[0].value;

                                //     arrayLancamentos.push({
                                //         acao: 'create',
                                //         transacao: transacao,
                                //         memo: 'GAFISA',
                                //         subsidiary: novoRegistro.getValue('subsidiary'),
                                //         custbody_ref_parcela: novoRegistro.id,                                            
                                //         approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                //         line: [{
                                //             account: parametroScript.getParameter('custscript_rsc_dbt_srv_mod_unidade_1'),
                                //             debit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         },{
                                //             account: conta,
                                //             credit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         }]               
                                //     });
                                // break;

                                // case '19594': // 6000101 (Faturamento Serviço Corretagem)
                                //     conta = search.lookupFields({type: 'serviceitem',
                                //         id: parametroScript.getParameter('custscript_rsc_cdt_fat_srv_corretagem_1'),
                                //         columns: ['incomeaccount']
                                //     }).incomeaccount[0].value;

                                //     arrayLancamentos.push({
                                //         acao: 'create',
                                //         transacao: transacao,
                                //         memo: 'GAFISA',
                                //         subsidiary: novoRegistro.getValue('subsidiary'),
                                //         custbody_ref_parcela: novoRegistro.id,                                            
                                //         approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                //         line: [{
                                //             account: parametroScript.getParameter('custscript_rsc_dbt_fat_srv_corretagem_1'),
                                //             debit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         },{
                                //             account: conta,
                                //             credit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         }]               
                                //     });
                                // break;

                                // case '19595': // 6000003 (Gestão Imobiliária)
                                //     conta = search.lookupFields({type: 'serviceitem',
                                //         id: parametroScript.getParameter('custscript_rsc_cdt_gestao_imobiliaria_1'),
                                //         columns: ['incomeaccount']
                                //     }).incomeaccount[0].value;

                                //     arrayLancamentos.push({
                                //         acao: 'create',
                                //         transacao: transacao,
                                //         memo: 'GAFISA',
                                //         subsidiary: novoRegistro.getValue('subsidiary'),
                                //         custbody_ref_parcela: novoRegistro.id,                                            
                                //         approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                //         line: [{
                                //             account: parametroScript.getParameter('custscript_rsc_dbt_gestao_imobiliaria_1'),
                                //             debit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         },{
                                //             account: conta,
                                //             credit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         }]               
                                //     });
                                // break;

                                // case '19596': // 6000017 (Taxa de Cessão)
                                //     conta = search.lookupFields({type: 'serviceitem',
                                //         id: parametroScript.getParameter('custscript_rsc_cdt_taxa_cessao_1'),
                                //         columns: ['incomeaccount']
                                //     }).incomeaccount[0].value;

                                //     arrayLancamentos.push({
                                //         acao: 'create',
                                //         transacao: transacao,
                                //         memo: 'GAFISA',
                                //         subsidiary: novoRegistro.getValue('subsidiary'),
                                //         custbody_ref_parcela: novoRegistro.id,                                            
                                //         approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                //         line: [{
                                //             account: parametroScript.getParameter('custscript_rsc_dbt_taxa_cessao_1'),
                                //             debit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         },{
                                //             account: conta,
                                //             credit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         }]               
                                //     });
                                // break;

                                // case '19597': // 6000020 (Taxa de distrato)
                                //     conta = search.lookupFields({type: 'serviceitem',
                                //         id: parametroScript.getParameter('custscript_rsc_cdt_taxa_distrato_1'),
                                //         columns: ['incomeaccount']
                                //     }).incomeaccount[0].value;

                                //     arrayLancamentos.push({
                                //         acao: 'create',
                                //         transacao: transacao,
                                //         memo: 'GAFISA',
                                //         subsidiary: novoRegistro.getValue('subsidiary'),
                                //         custbody_ref_parcela: novoRegistro.id,                                            
                                //         approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                //         line: [{
                                //             account: parametroScript.getParameter('custscript_rsc_dbt_taxa_distrato_1'),
                                //             debit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         },{
                                //             account: conta,
                                //             credit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         }]               
                                //     });
                                // break;

                                // case '19598': // 6000102 (Comissionamento House UP)
                                //     conta = search.lookupFields({type: 'serviceitem',
                                //         id: parametroScript.getParameter('custscript_rsc_cdt_comiss_house_up_1'),
                                //         columns: ['incomeaccount']
                                //     }).incomeaccount[0].value;

                                //     arrayLancamentos.push({
                                //         acao: 'create',
                                //         transacao: transacao,
                                //         memo: 'GAFISA',
                                //         subsidiary: novoRegistro.getValue('subsidiary'),
                                //         custbody_ref_parcela: novoRegistro.id,                                            
                                //         approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                //         line: [{
                                //             account: parametroScript.getParameter('custscript_rsc_dbt_comiss_house_up_1'),
                                //             debit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         },{
                                //             account: conta,
                                //             credit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         }]               
                                //     });
                                // break;

                                // case '19599': // 6000013 (Taxa Administrativa)
                                //     conta = search.lookupFields({type: 'serviceitem',
                                //         id: parametroScript.getParameter('custscript_rsc_cdt_taxa_administrativa_1'),
                                //         columns: ['incomeaccount']
                                //     }).incomeaccount[0].value;

                                //     arrayLancamentos.push({
                                //         acao: 'create',
                                //         transacao: transacao,
                                //         memo: 'GAFISA',
                                //         subsidiary: novoRegistro.getValue('subsidiary'),
                                //         custbody_ref_parcela: novoRegistro.id,                                            
                                //         approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                //         line: [{
                                //             account: parametroScript.getParameter('custscript_rsc_dbt_taxa_administrativa_1'),
                                //             debit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         },{
                                //             account: conta,
                                //             credit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         }]               
                                //     });
                                // break;

                                // case '19600': // 6000002 (Equipe Técnica Taxa Administrativa)
                                //     conta = search.lookupFields({type: 'serviceitem',
                                //         id: parametroScript.getParameter('custscript_rsc_cdt_eqp_tec_tx_adm_1'),
                                //         columns: ['incomeaccount']
                                //     }).incomeaccount[0].value;

                                //     arrayLancamentos.push({
                                //         acao: tipo,
                                //         transacao: transacao,
                                //         memo: 'GAFISA',
                                //         subsidiary: novoRegistro.getValue('subsidiary'),
                                //         custbody_ref_parcela: novoRegistro.id,                                            
                                //         custbody_lrc_fatura_principal: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                //         line: [{
                                //             account: parametroScript.getParameter('custscript_rsc_dbt_eqp_tec_tx_adm_1'),
                                //             debit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         },{
                                //             account: conta,
                                //             credit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         }]               
                                //     });
                                // break;

                                case '19606': // JUROS PRICE INCORRIDO
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_juros_incorridos_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;

                                    arrayLancamentos.push({
                                        acao: tipo,
                                        transacao: transacao,
                                        memo: 'GAFISA',
                                        subsidiary: novoRegistro.getValue('subsidiary'),
                                        custbody_ref_parcela: novoRegistro.id,                                            
                                        custbody_lrc_fatura_principal: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                        line: [{
                                            account: parametroScript.getParameter('custscript_rsc_dbt_juros_incorridos_1'),
                                            debit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        },{
                                            account: conta,
                                            credit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        }]               
                                    });
                                break;

                                case '19607': // JUROS PRICE A INCORRER
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_juros_incorrer_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;

                                    arrayLancamentos.push({
                                        acao: tipo,
                                        transacao: transacao,
                                        memo: 'GAFISA',
                                        subsidiary: novoRegistro.getValue('subsidiary'),
                                        custbody_ref_parcela: novoRegistro.id,                                            
                                        custbody_lrc_fatura_principal: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                                        line: [{
                                            account: parametroScript.getParameter('custscript_rsc_dbt_juros_incorrer_1'),
                                            debit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        },{
                                            account: conta,
                                            credit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        }]               
                                    });
                                break;
                            }
                        }
                    }
                }

                if (cessaoDireito) {
                    conta = search.lookupFields({type: 'serviceitem',
                        id: parametroScript.getParameter('custscript_rsc_cdt_taxa_cessao_1'),
                        columns: ['incomeaccount']
                    }).incomeaccount[0].value;

                    arrayLancamentos.push({
                        acao: tipo,
                        transacao: transacao,
                        memo: 'GAFISA',
                        subsidiary: novoRegistro.getValue('subsidiary'),
                        custbody_ref_parcela: novoRegistro.id,                                            
                        approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                        line: [{
                            account: parametroScript.getParameter('custscript_rsc_dbt_taxa_cessao_1'),
                            debit: total,
                            memo: '',
                            entity: novoRegistro.getValue('entity'),
                            location: novoRegistro.getValue('location')
                        },{
                            account: conta,
                            credit: total,
                            memo: '',
                            entity: novoRegistro.getValue('entity'),
                            location: novoRegistro.getValue('location')
                        }]               
                    });

                    conta = search.lookupFields({type: 'serviceitem',
                        id: parametroScript.getParameter('custscript_rsc_cdt_taxa_cessao_2'),
                        columns: ['incomeaccount']
                    }).incomeaccount[0].value;

                    arrayLancamentos.push({
                        acao: tipo,
                        transacao: transacao,
                        memo: 'GAFISA',
                        subsidiary: novoRegistro.getValue('subsidiary'),
                        custbody_ref_parcela: novoRegistro.id,                                            
                        approvalstatus: novoRegistro.getValue('custbody_lrc_fatura_principal'),
                        line: [{
                            account: parametroScript.getParameter('custscript_rsc_dbt_taxa_cessao_2'),
                            debit: total,
                            memo: '',
                            entity: novoRegistro.getValue('entity'),
                            location: novoRegistro.getValue('location')
                        },{
                            account: conta,
                            credit: total,
                            memo: '',
                            entity: novoRegistro.getValue('entity'),
                            location: novoRegistro.getValue('location')
                        }]               
                    });
                }
                    
                if (arrayLancamentos.length > 0) {
                    scriptTask = task.create({
                        taskType: task.TaskType.SCHEDULED_SCRIPT,
                        scriptId: 1315,                                
                        params: {
                            custscript_rsc_journal_entries: arrayLancamentos
                        }
                    });

                    scriptTaskId = scriptTask.submit();
                    log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                }
            }

            if (tipo == 'edit') {                    
                sql = "SELECT id, voided "+
                "FROM transaction "+
                "WHERE transaction.id = ? ";

                consulta = query.runSuiteQL({
                    query: sql,
                    params: [novoRegistro.id]
                });
            
                sqlResults = consulta.asMappedResults();

                var anulado = sqlResults[0].voided;

                if (anulado == 'T' || anulado == true) {
                    arrayLancamentos.push({
                        acao: tipo,
                        transacao: transacao,
                        custbody_ref_parcela: novoRegistro.id,
                        anulado: anulado           
                    });

                    scriptTask = task.create({
                        taskType: task.TaskType.SCHEDULED_SCRIPT,
                        scriptId: 1315,                            
                        params: {
                            custscript_rsc_journal_entries: arrayLancamentos
                        }
                    });
                    log.audit('scriptTask', scriptTask);

                    scriptTaskId = scriptTask.submit();
                    log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                } else {
                    var diferenca = 0;
                    for (i=0; i<novoRegistro.getLineCount('item'); i++) {
                        var item = novoRegistro.getSublistValue('item', 'item', i);
                        var amount = novoRegistro.getSublistValue('item', 'amount', i);
                        var oldAmount = velhoRegistro.getSublistValue('item', 'amount', i);
                        diferenca = Math.abs(amount - oldAmount);
                        
                        log.audit('record', {item: item, amount: amount, oldAmount: oldAmount, diferenca: diferenca});

                        if (ambiente == 'PRODUCTION') {
                            log.audit('ambiente', ambiente);
                        } else {
                            switch(item) {
                                case '19420': // FRAÇÃO PRINCIPAL                                
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_venda_unidade_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;

                                    if (diferenca > 0) {
                                        arrayLancamentos.push({
                                            acao: 'create',
                                            transacao: transacao,
                                            memo: 'GAFISA',
                                            subsidiary: novoRegistro.getValue('subsidiary'),
                                            custbody_ref_parcela: novoRegistro.id,
                                            line: [{
                                                account: parametroScript.getParameter('custscript_rsc_dbt_venda_unidade_1'),
                                                debit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            },{
                                                account: conta,
                                                credit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            }]               
                                        });
                                    }
                                break; 

                                case '19423': // INCC 
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_incc_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;

                                    if (diferenca > 0) {
                                        arrayLancamentos.push({
                                            acao: 'create',
                                            transacao: transacao,
                                            memo: 'GAFISA',
                                            subsidiary: novoRegistro.getValue('subsidiary'),
                                            custbody_ref_parcela: novoRegistro.id,
                                            line: [{
                                                account: parametroScript.getParameter('custscript_rsc_dbt_incc_1'),
                                                debit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            },{
                                                account: conta,
                                                credit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            }]               
                                        });
                                    }
                                break; 

                                case '19590': // IGP-M
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_igpm_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;
                                    
                                    if (diferenca > 0) {
                                        arrayLancamentos.push({
                                            acao: 'create',
                                            transacao: transacao,
                                            memo: 'GAFISA',
                                            subsidiary: novoRegistro.getValue('subsidiary'),
                                            custbody_ref_parcela: novoRegistro.id,
                                            line: [{
                                                account: parametroScript.getParameter('custscript_rsc_dbt_igpm_1'),
                                                debit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            },{
                                                account: conta,
                                                credit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            }]               
                                        });
                                    }
                                break;

                                case '19606': // JUROS PRICE INCORRIDO
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_juros_incorridos_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;

                                    if (diferenca > 0) {
                                        arrayLancamentos.push({
                                            acao: 'create',
                                            transacao: transacao,
                                            memo: 'GAFISA',
                                            subsidiary: novoRegistro.getValue('subsidiary'),
                                            custbody_ref_parcela: novoRegistro.id,
                                            line: [{
                                                account: parametroScript.getParameter('custscript_rsc_dbt_juros_incorridos_1'),
                                                debit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            },{
                                                account: conta,
                                                credit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            }]               
                                        });
                                    }
                                break;

                                case '19607': // JUROS PRICE A INCORRER
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_juros_incorrer_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;

                                    if (diferenca > 0) {
                                        arrayLancamentos.push({
                                            acao: 'create',
                                            transacao: transacao,
                                            memo: 'GAFISA',
                                            subsidiary: novoRegistro.getValue('subsidiary'),
                                            custbody_ref_parcela: novoRegistro.id,
                                            line: [{
                                                account: parametroScript.getParameter('custscript_rsc_dbt_juros_incorrer_1'),
                                                debit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            },{
                                                account: conta,
                                                credit: diferenca,
                                                memo: '',
                                                entity: novoRegistro.getValue('entity'),
                                                location: novoRegistro.getValue('location')
                                            }]               
                                        });
                                    }
                                break;
                            }
                        }
                    }
                    log.audit('arrayLancamentos', arrayLancamentos);
                    
                    if (arrayLancamentos.length > 0) {
                        scriptTask = task.create({
                            taskType: task.TaskType.SCHEDULED_SCRIPT,
                            scriptId: 1315,                                
                            params: {
                                custscript_rsc_journal_entries: arrayLancamentos
                            }
                        });

                        scriptTaskId = scriptTask.submit();
                        log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                    }
                }
            }
        break;

        case 'creditmemo':
            var status = novoRegistro.getValue('status');
            var pago = novoRegistro.getValue('custbody_rsc_pago');
            var tipoRenegociacao = search.lookupFields({type: 'customrecord_rsc_tab_efetiva_reparcela',
                id: novoRegistro.getValue('custbody_rsc_numero_renegociacao'),
                columns: ['custrecord_rsc_tipo_renegociacao']
            }).custrecord_rsc_tipo_renegociacao[0].value;
            log.audit('tipoRenegociacao', tipoRenegociacao);
            var total = novoRegistro.getValue('total');

            if (tipo == 'edit') {
                if (status == 'Valores aplicados completamente' || status == 'Fully Applied' || pago == 1) {
                    for (i=0; i<novoRegistro.getLineCount('apply'); i++) {
                        var aplicado = novoRegistro.getSublistValue('apply', 'apply', i);
                        var internalid = novoRegistro.getSublistValue('apply', 'internalid', i);
                        var tipoTransacao = novoRegistro.getSublistValue('apply', 'trantype', i);
                        
                        if (aplicado == true && tipoTransacao == 'CustInvc') {
                            var loadReg = record.load({type: 'invoice', id: internalid});

                            for (j=0; j<loadReg.getLineCount('item'); j++) {
                                var item = loadReg.getSublistValue('item', 'item', j);
                                var amount = loadReg.getSublistValue('item', 'amount', j);

                                // if (item == 19420) { // FRAÇÃO PRINCIPAL
                                //     conta = search.lookupFields({type: 'serviceitem',
                                //         id: parametroScript.getParameter('custscript_rsc_cdt_venda_unidade_1'),
                                //         columns: ['incomeaccount']
                                //     }).incomeaccount[0].value;
                                    
                                //     arrayLancamentos.push({
                                //         acao: 'create',
                                //         transacao: 'invoice',
                                //         memo: 'GAFISA',
                                //         subsidiary: novoRegistro.getValue('subsidiary'),
                                //         custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                                //         custbody_ref_parcela: internalid,
                                //         line: [{
                                //             account: parametroScript.getParameter('custscript_rsc_dbt_venda_unidade_1'),
                                //             debit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         },{
                                //             account: conta,
                                //             credit: amount,
                                //             memo: '',
                                //             entity: novoRegistro.getValue('entity'),
                                //             location: novoRegistro.getValue('location')
                                //         }]               
                                //     }); 
                                // }

                                if (item == 19423) { // INCC 
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_incc_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;
                                    
                                    arrayLancamentos.push({
                                        acao: 'create',
                                        transacao: 'invoice',
                                        memo: 'GAFISA',
                                        subsidiary: novoRegistro.getValue('subsidiary'),
                                        custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                                        custbody_ref_parcela: internalid,
                                        line: [{
                                            account: parametroScript.getParameter('custscript_rsc_dbt_incc_1'),
                                            debit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        },{
                                            account: conta,
                                            credit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        }]               
                                    }); 
                                }

                                if (item == 19590) { // IGP-M  
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_igpm_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;                                        
                                    
                                    arrayLancamentos.push({
                                        acao: 'create',
                                        transacao: 'invoice',
                                        memo: 'GAFISA',
                                        subsidiary: novoRegistro.getValue('subsidiary'),
                                        custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                                        custbody_ref_parcela: internalid,
                                        line: [{
                                            account: parametroScript.getParameter('custscript_rsc_dbt_igpm_1'),
                                            debit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        },{
                                            account: conta,
                                            credit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        }]               
                                    });
                                }

                                if (item == 19606) { // JUROS PRICE INCORRIDO
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_juros_incorridos_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;
                                    
                                    arrayLancamentos.push({
                                        acao: 'create',
                                        transacao: 'invoice',
                                        memo: 'GAFISA',
                                        subsidiary: novoRegistro.getValue('subsidiary'),
                                        custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                                        custbody_ref_parcela: internalid,
                                        line: [{
                                            account: parametroScript.getParameter('custscript_rsc_dbt_juros_incorridos_1'),
                                            debit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        },{
                                            account: conta,
                                            credit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        }]               
                                    }); 
                                }

                                if (item == 19607 || item == 19422) { // JUROS PRICE A INCORRER OU ACRÉSCIMO SOBRE FINANCIAMENTO 
                                    conta = search.lookupFields({type: 'serviceitem',
                                        id: parametroScript.getParameter('custscript_rsc_cdt_juros_incorrer_1'),
                                        columns: ['incomeaccount']
                                    }).incomeaccount[0].value;
                                
                                    arrayLancamentos.push({
                                        acao: 'create',
                                        transacao: 'invoice',
                                        memo: 'GAFISA',
                                        subsidiary: novoRegistro.getValue('subsidiary'),
                                        custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                                        custbody_ref_parcela: internalid,
                                        line: [{
                                            account: parametroScript.getParameter('custscript_rsc_dbt_juros_incorrer_1'),
                                            debit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        },{
                                            account: conta,
                                            credit: amount,
                                            memo: '',
                                            entity: novoRegistro.getValue('entity'),
                                            location: novoRegistro.getValue('location')
                                        }]               
                                    }); 
                                }
                            }
                        }
                    }

                    // if (tipoRenegociacao == 1) { // Amortização
                    //     conta = search.lookupFields({type: 'serviceitem',
                    //         id: parametroScript.getParameter('custscript_rsc_cdt_amortizacao_1'), // Conta Crédito 1
                    //         columns: ['incomeaccount']
                    //     }).incomeaccount[0].value;
                    
                    //     arrayLancamentos.push({
                    //         acao: 'create',
                    //         transacao: 'invoice',
                    //         memo: 'GAFISA',
                    //         subsidiary: novoRegistro.getValue('subsidiary'),
                    //         custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                    //         custbody_ref_parcela: internalid,
                    //         line: [{
                    //             account: parametroScript.getParameter('custscript_rsc_dbt_amortizacao_1'),
                    //             debit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         },{
                    //             account: conta,
                    //             credit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         }]               
                    //     }); 

                    //     conta = search.lookupFields({type: 'serviceitem',
                    //         id: parametroScript.getParameter('custscript_rsc_cdt_amortizacao_2'), // Conta Crédito 2
                    //         columns: ['incomeaccount']
                    //     }).incomeaccount[0].value;

                    //     arrayLancamentos.push({
                    //         acao: 'create',
                    //         transacao: 'invoice',
                    //         memo: 'GAFISA',
                    //         subsidiary: novoRegistro.getValue('subsidiary'),
                    //         custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                    //         custbody_ref_parcela: internalid,
                    //         line: [{
                    //             account: conta,
                    //             credit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         }]               
                    //     }); 
                    // }

                    // if (tipoRenegociacao == 2) { // Inadimplentes
                    //     conta = search.lookupFields({type: 'serviceitem',
                    //         id: parametroScript.getParameter('custscript_rsc_cdt_inadimplentes_1'), // Conta Crédito 1
                    //         columns: ['incomeaccount']
                    //     }).incomeaccount[0].value;
                    
                    //     arrayLancamentos.push({
                    //         acao: 'create',
                    //         transacao: 'invoice',
                    //         memo: 'GAFISA',
                    //         subsidiary: novoRegistro.getValue('subsidiary'),
                    //         custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                    //         custbody_ref_parcela: internalid,
                    //         line: [{
                    //             account: parametroScript.getParameter('custscript_rsc_dbt_inadimplentes_1'),
                    //             debit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         },{
                    //             account: conta,
                    //             credit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         }]               
                    //     }); 

                    //     conta = search.lookupFields({type: 'serviceitem',
                    //         id: parametroScript.getParameter('custscript_rsc_cdt_inadimplentes_2'), // Conta Crédito 2
                    //         columns: ['incomeaccount']
                    //     }).incomeaccount[0].value;

                    //     arrayLancamentos.push({
                    //         acao: 'create',
                    //         transacao: 'invoice',
                    //         memo: 'GAFISA',
                    //         subsidiary: novoRegistro.getValue('subsidiary'),
                    //         custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                    //         custbody_ref_parcela: internalid,
                    //         line: [{
                    //             account: conta,
                    //             credit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         }]               
                    //     }); 
                    // }

                    // if (tipoRenegociacao == 3) { // Adimplentes
                    //     conta = search.lookupFields({type: 'serviceitem',
                    //         id: parametroScript.getParameter('custscript_rsc_cdt_adimplentes_1'), // Conta Crédito 1
                    //         columns: ['incomeaccount']
                    //     }).incomeaccount[0].value;
                    
                    //     arrayLancamentos.push({
                    //         acao: 'create',
                    //         transacao: 'invoice',
                    //         memo: 'GAFISA',
                    //         subsidiary: novoRegistro.getValue('subsidiary'),
                    //         custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                    //         custbody_ref_parcela: internalid,
                    //         line: [{
                    //             account: parametroScript.getParameter('custscript_rsc_dbt_adimplentes_1'),
                    //             debit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         },{
                    //             account: conta,
                    //             credit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         }]               
                    //     }); 

                    //     conta = search.lookupFields({type: 'serviceitem',
                    //         id: parametroScript.getParameter('custscript_rsc_cdt_adimplentes_2'), // Conta Crédito 2
                    //         columns: ['incomeaccount']
                    //     }).incomeaccount[0].value;

                    //     arrayLancamentos.push({
                    //         acao: 'create',
                    //         transacao: 'invoice',
                    //         memo: 'GAFISA',
                    //         subsidiary: novoRegistro.getValue('subsidiary'),
                    //         custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                    //         custbody_ref_parcela: internalid,
                    //         line: [{
                    //             account: conta,
                    //             credit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         }]               
                    //     }); 
                    // }

                    // if (tipoRenegociacao == 4) { // Recáculo de Atraso
                    //     conta = search.lookupFields({type: 'serviceitem',
                    //         id: parametroScript.getParameter('custscript_rsc_cdt_recalculo_atraso_1'),
                    //         columns: ['incomeaccount']
                    //     }).incomeaccount[0].value;
                    
                    //     arrayLancamentos.push({
                    //         acao: 'create',
                    //         transacao: 'invoice',
                    //         memo: 'GAFISA',
                    //         subsidiary: novoRegistro.getValue('subsidiary'),
                    //         custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                    //         custbody_ref_parcela: internalid,
                    //         line: [{
                    //             account: parametroScript.getParameter('custscript_rsc_dbt_recalculo_atraso_1'),
                    //             debit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         },{
                    //             account: conta,
                    //             credit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         }]               
                    //     }); 
                    // }

                    // if (tipoRenegociacao == 5) { // Antecipação
                    //     conta = search.lookupFields({type: 'serviceitem',
                    //         id: parametroScript.getParameter('custscript_rsc_cdt_antecipacao_1'),
                    //         columns: ['incomeaccount']
                    //     }).incomeaccount[0].value;
                    
                    //     arrayLancamentos.push({
                    //         acao: 'create',
                    //         transacao: 'invoice',
                    //         memo: 'GAFISA',
                    //         subsidiary: novoRegistro.getValue('subsidiary'),
                    //         custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                    //         custbody_ref_parcela: internalid,
                    //         line: [{
                    //             account: parametroScript.getParameter('custscript_rsc_dbt_antecipacao_1'),
                    //             debit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         },{
                    //             account: conta,
                    //             credit: total,
                    //             memo: '',
                    //             entity: novoRegistro.getValue('entity'),
                    //             location: novoRegistro.getValue('location')
                    //         }]               
                    //     }); 
                    // }
                }
                log.audit('arrayLancamentos', arrayLancamentos);

                if (arrayLancamentos.length > 0) {
                    scriptTask = task.create({
                        taskType: task.TaskType.SCHEDULED_SCRIPT,
                        scriptId: 1315,                                
                        params: {
                            custscript_rsc_journal_entries: arrayLancamentos
                        }
                    });
    
                    scriptTaskId = scriptTask.submit();
                    log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                }                     
            } 
        break;

        case 'customerpayment': 
            if (tipo == 'create') {
                for (i=0; i<novoRegistro.getLineCount('apply'); i++) {
                    var amount = novoRegistro.getSublistValue('apply', 'amount', i);
                    var aplicado = novoRegistro.getSublistValue('apply', 'apply', i);
                    var internalid = novoRegistro.getSublistValue('apply', 'internalid', i);
                    var tipoTransacao = novoRegistro.getSublistValue('apply', 'trantype', i);
                    
                    if (aplicado == true && tipoTransacao == 'CustInvc') {
                        var loadReg = record.load({type: 'invoice', id: internalid});

                        conta = search.lookupFields({type: 'serviceitem',
                            id: parametroScript.getParameter('custscript_rsc_cdt_pagamento_fatura_1'),
                            columns: ['incomeaccount']
                        }).incomeaccount[0].value;
                    
                        arrayLancamentos.push({
                            acao: 'create',
                            transacao: 'invoice',
                            memo: 'GAFISA',
                            subsidiary: novoRegistro.getValue('subsidiary'),
                            custbody_lrc_fatura_principal: loadReg.getValue('custbody_lrc_fatura_principal'),
                            custbody_ref_parcela: novoRegistro.id,
                            line: [{
                                account: parametroScript.getParameter('custscript_rsc_dbt_pagamento_fatura_1'),
                                debit: amount,
                                memo: '',
                                entity: novoRegistro.getValue('entity'),
                                location: novoRegistro.getValue('location')
                            },{
                                account: conta,
                                credit: amount,
                                memo: '',
                                entity: novoRegistro.getValue('entity'),
                                location: novoRegistro.getValue('location')
                            }]               
                        }); 
                    }
                }
                log.audit('arrayLancamentos', arrayLancamentos);

                if (arrayLancamentos.length > 0) {
                    scriptTask = task.create({
                        taskType: task.TaskType.SCHEDULED_SCRIPT,
                        scriptId: 1315,                                
                        params: {
                            custscript_rsc_journal_entries: arrayLancamentos
                        }
                    });
    
                    scriptTaskId = scriptTask.submit();
                    log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                }
            } 
        break;

        case 'job': 
            if (tipo == 'edit') {
                var securitizado = novoRegistro.getValue('custentity_rsc_securitizado');
                
                if (securitizado == true) {
                    bscTransacao = search.create({type: "journalentry",
                        filters: [
                            ["shipping","is","F"], "AND", 
                            ["taxline","is","F"], "AND", 
                            ["mainline","is","T"], "AND", 
                            ["type","anyof","Journal"], "AND", 
                            ["custbody_rsc_projeto_obra_gasto_compra","anyof",novoRegistro.id], "AND",
                            ["custbody_rsc_empproj_securitizado","is","T"]
                        ],
                        columns: [
                            "datecreated","internalid","custbody_ref_parcela","amount",
                            search.createColumn({name: "formulatext", formula: "{tranid}", label: "Fórmula (texto)"})
                        ]
                    }).run().getRange(0,1000);
                    log.audit(transacao, {bscTransacao: bscTransacao});

                    if (bscTransacao.length == 0) {
                        bscTransacao = search.create({type: "invoice",
                            filters: [
                                ["shipping","is","F"], "AND", 
                                ["taxline","is","F"], "AND", 
                                ["mainline","is","T"], "AND", 
                                ["type","anyof","CustInvc"], "AND",
                                ["custbody_rsc_projeto_obra_gasto_compra","anyof",novoRegistro.id]
                            ],
                            columns: [
                                "internalid","entity","location","tranid","trandate","total"
                            ]
                        }).run().getRange(0,1000);
                        log.audit(transacao, {bscTransacao: bscTransacao});

                        if (bscTransacao.length > 0) {
                            for (i=0; i<bscTransacao.length; i++) {
                                arrayLancamentos.push({
                                    acao: 'create',
                                    transacao: transacao,
                                    memo: 'Securitização: Projeto '+novoRegistro.getValue('companyname'),
                                    subsidiary: novoRegistro.getValue('subsidiary'),
                                    custbody_rsc_projeto_obra_gasto_compra: novoRegistro.id,
                                    custbody_ref_parcela: bscTransacao[i].id,
                                    custbody_rsc_empproj_securitizado: true,
                                    line: [{
                                        account: novoRegistro.getValue('custentity_rsc_d_const_div_gar_op'),
                                        debit: bscTransacao[i].getValue('total'),
                                        memo: 'Securitização: Projeto '+novoRegistro.getValue('companyname'),
                                        entity: bscTransacao[i].getValue('entity'),
                                        location: bscTransacao[i].getValue('location')
                                    },{
                                        account: novoRegistro.getValue('custentity_rsc_c_const_div_gar_op'),
                                        credit: bscTransacao[i].getValue('total'),
                                        memo: 'Securitização: Projeto '+novoRegistro.getValue('companyname'),
                                        entity: bscTransacao[i].getValue('entity'),
                                        location: bscTransacao[i].getValue('location')
                                    }]               
                                });
                            }
                        }

                        if (arrayLancamentos.length > 0) {
                            scriptTask = task.create({
                                taskType: task.TaskType.SCHEDULED_SCRIPT,
                                scriptId: 1315,                            
                                params: {
                                    custscript_rsc_journal_entries: arrayLancamentos
                                }
                            });

                            scriptTaskId = scriptTask.submit();
                            log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                        } 
                    }                    
                }
            }
        break;

        case 'deposit':
            if (tipo == 'create') {
                var nomeProjeto = {
                    text: novoRegistro.getText('custbody_rsc_projeto_obra_gasto_compra'),
                    value: novoRegistro.getValue('custbody_rsc_projeto_obra_gasto_compra')
                }
                log.audit('nomeProjeto', nomeProjeto);

                var lkpProjeto = search.lookupFields({type: 'job',
                    id: nomeProjeto.value,
                    columns: ['companyname','custentity_rsc_securitizado','custentity_rsc_c_liberacao_recursos','custentity_rsc_d_liberacao_recursos']
                });
                log.audit('lkpProjeto', lkpProjeto);

                if (lkpProjeto.custentity_rsc_securitizado == true) {
                    arrayLancamentos.push({
                        acao: tipo,
                        transacao: transacao,   
                        memo: 'Securitização: Projeto '+lkpProjeto.companyname,
                        subsidiary: novoRegistro.getValue('subsidiary'),
                        custbody_rsc_projeto_obra_gasto_compra: nomeProjeto.value,
                        custbody_ref_parcela: novoRegistro.id,
                        custbody_lrc_fatura_principal: novoRegistro.id,
                        custbody_rsc_empproj_securitizado: true,
                        line: [{
                            account: lkpProjeto.custentity_rsc_d_liberacao_recursos[0].value,
                            debit: novoRegistro.getValue('total'),
                            memo: 'Securitização: Projeto '+lkpProjeto.companyname,
                            entity: '',
                            location: ''
                        },{
                            account: lkpProjeto.custentity_rsc_c_liberacao_recursos[0].value,
                            credit: novoRegistro.getValue('total'),
                            memo: 'Securitização: Projeto '+lkpProjeto.companyname,
                            entity: '',
                            location: ''
                        }]               
                    });
                    log.audit('arrayLancamentos', arrayLancamentos);

                    if (arrayLancamentos.length > 0) {
                        scriptTask = task.create({
                            taskType: task.TaskType.SCHEDULED_SCRIPT,
                            scriptId: 1315,                            
                            params: {
                                custscript_rsc_journal_entries: arrayLancamentos
                            }
                        });

                        scriptTaskId = scriptTask.submit();
                        log.audit('task', {scriptTaskId: scriptTaskId, scriptTask: scriptTask});
                    } 
                }
            }
        break;
    }
    // }    

    // if (usuarioAtual.id == 3588) {
    //     const loadArq = file.load({id: 71901});
    //     log.audit('loadArq', loadArq);

    //     var conteudo = loadArq.getContents();
    //     log.audit('conteudo', conteudo);

    //     var iterator = loadArq.lines.iterator();

    //     //Skip the first line (CSV header)
    //     iterator.each(function (line, index) {
    //         log.audit('Line antes', line);
    //         var segmento = line.value.substr(13,1);
    //         var vencimento = line.value.substr(77,8);
    //         var valorTitulo = line.value.substr(85,16);
    //         var jurosMora = line.value.substr(126,16);
    //         var desconto = line.value.substr(150,16);
    //         var IOF = line.value.substr(165,16);
    //         var abatimento = line.value.substr(180,16);            
    //         var identificacaoTitulo = line.value.substr(195,25);
    //         if (segmento == 'P') {
    //             log.audit('Dados extraídos', {
    //                 segmento: segmento,
    //                 vencimento: vencimento,
    //                 valorTitulo: valorTitulo,
    //                 jurosMora: jurosMora,
    //                 desconto: desconto,
    //                 IOF: IOF,
    //                 abatimento: abatimento,
    //                 identificacaoTitulo: identificacaoTitulo
    //             });
    //         }            
    //         return true;
    //     });
    // }

    // const total = novoRegistro.getValue('total');

    // const linhaItens = novoRegistro.getLineCount('item');

    // var arrayLancamento = [];  

    // if (linhaItens > 0) {
    //     for (i=0; i<linhaItens; i++) {
    //         var item = novoRegistro.getSublistValue('item', 'item', i);
    //         var amount = novoRegistro.getSublistValue('item', 'amount', i);
            
    //         arrayLancamento.push({item: item, amount: amount});
    //     }
    // }
    // log.audit('arrayLancamento', arrayLancamento);
    
    // const linhaLancamentos = novoRegistro.getLineCount('custpage_rsc_lancamentos');

    // var totalLancamentos = 0;  

    // if (linhaLancamentos > 0) {
    //     for (i=0; i<linhaLancamentos; i++) {
    //         var credito = Number(novoRegistro.getSublistValue('custpage_rsc_lancamentos', 'custpage_rsc_credito', i));
    //         if (credito > 0) {
    //             totalLancamentos += credito;
    //         }            
    //     }
    // }

    // const linhaLinks = novoRegistro.getLineCount('links');
    
    // const pago = novoRegistro.getValue('custbody_rsc_pago');

    // var totalLinks = 0; 

    // const valorPagamento = (id) => {
    //     log.audit('valorPagamento', {idFI: id});
    //     var bscPagamento = search.create({type: "customerpayment",
    //         filters: [
    //            ["mainline","is","F"], "AND", 
    //            ["type","anyof","CustPymt"], "AND", 
    //            ["appliedtotransaction.internalid","anyof",id]
    //         ],
    //         columns: [
    //             "tranid","total"
    //         ]
    //     }).run().getRange(0,1);
    //     log.audit('bscPagamento', bscPagamento);

    //     return Number(bscPagamento[0].getValue('total'));
    // }  

    // if (novoRegistro.id) {
    //     if (context.type == 'create') {
    //         gerarLancamentos(novoRegistro.id, arrayLancamento);
    //     } else {
    //         var diferenca = total - totalLancamentos;
    //         log.audit('diferenca', diferenca);
    //         if (diferenca > 0) {
    //             lancamentoAdicionais(novoRegistro.id, diferenca);
    //         }
    //         if (!pago || pago == 2) {
    //             if (linhaLinks > 0) {
    //                 for (i=0; i<linhaLinks; i++) {
    //                     var totalPagamento = novoRegistro.getSublistValue('links', 'total', i);
    //                     var tipo = novoRegistro.getSublistValue('links', 'type', i);
    //                     var id = novoRegistro.getSublistValue('links', 'id', i);
    //                     if (i == 0) {
    //                         totalLinks += valorPagamento(novoRegistro.id);
    //                     }                        
    //                 }
    //             }
    //             log.audit('totalLinks', totalLinks);
    //             lancamentoAdicionais(novoRegistro.id, totalLinks, 1);
    //         }  
    //     }        
    // }
}

return {
    beforeLoad: beforeLoad,
    beforeSubmit: beforeSubmit,
    afterSubmit: afterSubmit
}
});
