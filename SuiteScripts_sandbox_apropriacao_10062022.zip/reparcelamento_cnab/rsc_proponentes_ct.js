/**
*@NApiVersion 2.1
*@NScriptType ClientScript
*/
define(['N/currentRecord', 'N/ui/dialog', 'N/record', 'N/runtime', 'N/search'], (currentRecord, dialog, record, runtime, search) => {
const registrarLog = (dados) => {
    const logProponente = record.create({type: 'customrecord_rsc_logs_proponentes', isDynamic: true});

    var campos = {
        custrecord_rsc_data_log: dados.custrecord_rsc_data_log,
        custrecord_rsc_contrato_proponentes: dados.custrecord_rsc_contrato_proponentes,
        custrecord_rsc_tipo: dados.custrecord_rsc_tipo,
        custrecord_rsc_id_proponente: dados.custrecord_rsc_id_proponente,
        custrecord_rsc_nome_proponente: dados.custrecord_rsc_nome_proponente,
        custrecord_rsc_perc_proponentes: dados.custrecord_rsc_perc_proponentes,
        custrecord_rsc_responsavel: dados.custrecord_rsc_responsavel
    }

    Object.keys(campos).forEach(function(bodyField) {
        logProponente.setValue(bodyField, campos[bodyField]);
    });

    try {
        const idLogProponente = logProponente.save();
        return {status: 'Sucesso'}
    } catch(e) {
        console.log('Erro registrarLog', JSON.stringify(e));
        return {status: 'Erro'}
    }    
}

const percentualParticipacao = (idContrato, idCliente) => {
    const bscProponentes = search.create({type: "customrecord_rsc_finan_client_contrato",
        filters: [
           ["custrecord_rsc_fat_contrato","anyof",idContrato], "AND", 
           ["custrecord_rsc_clientes_contratos","noneof",idCliente]
        ],
        columns: [
            "id","custrecord_rsc_clientes_contratos","custrecord_rsc_pct_part","custrecord_rsc_fat_contrato"
        ]
    }).run().getRange(0,100);

    var percParticipacao = 0;
    
    if (bscProponentes.length > 0) {
        for (i=0; i<bscProponentes.length; i++) {
            percParticipacao += Number(bscProponentes[i].getValue('custrecord_rsc_pct_part').replace('%',''));
        }
    }

    return percParticipacao+'%';
}

const pageInit = (context) => {}

const saveRecord = (context) => {
    const registroAtual = context.currentRecord;

    const clientes = registroAtual.getValue('custrecord_rsc_clientes_contratos');

    const principal = registroAtual.getValue('custrecord_rsc_principal');

    const participacao_perc = registroAtual.getValue('custrecord_rsc_pct_part') || 0;
    
    const fatura_prinicipal_contrato = registroAtual.getValue('custrecord_rsc_fat_contrato');

    var bscProponentes = search.create({type: "customrecord_rsc_finan_client_contrato",
        filters: [
           ["custrecord_rsc_fat_contrato","anyof",fatura_prinicipal_contrato], 
           "AND",
        //    ["custrecord_rsc_clientes_contratos","noneof",clientes], "AND", 
           ["isinactive","is","F"]
        ],
        columns: [
            "id","custrecord_rsc_clientes_contratos","custrecord_rsc_principal","custrecord_rsc_pct_part","custrecord_rsc_fat_contrato"
        ]
    }).run().getRange(0,100);
    console.log('bscProponentes', JSON.stringify(bscProponentes));

    var percParticipacao = 0;
    
    if (bscProponentes.length > 0) {
        for (i=0; i<bscProponentes.length; i++) {
            if (bscProponentes[i].getValue('id') != registroAtual.id) {
                var main = bscProponentes[i].getValue('custrecord_rsc_principal');
                
                if (main == principal && main == true) {
                    dialog.alert({
                        title: 'Aviso!',
                        message: 'Contrato já possui proponente principal. <br />'+
                        'Nome: ' + bscProponentes[i].getText('custrecord_rsc_clientes_contratos')
                    });
            
                    return false;
                }

                percParticipacao += Number(bscProponentes[i].getValue('custrecord_rsc_pct_part').replace('%',''));
                console.log('percParticipacao', percParticipacao);
            }
        }    

        var percTotal = percParticipacao + participacao_perc;
        console.log('percTotal', percTotal);

        var msg = 'Percentual de participação deve ser igual a 100%. \n'+
        '% Contrato: ' + percTotal + '%';

        if (percTotal < 100 && bscProponentes.length > 0) {
            if (confirm(msg)) {
                return true;
            } else {
                return false;
            }
        }

        if (percTotal > 100) {
            if (bscProponentes.length > 0) {
                dialog.alert({
                    title: 'Aviso!',
                    message: 'Percentual de participação deve ser igual a 100%. <br />'+
                    '% Contrato: ' + percTotal + '%'
                });
        
                return false;
            } else {
                dialog.alert({
                    title: 'Aviso!',
                    message: 'Percentual de participação deve ser igual a 100%. <br />'+
                    '% Contrato: ' + percTotal + '%'
                });
        
                return false;
            }        
        }

        if (registroAtual.id) {
            registrarLog({
                custrecord_rsc_data_log: new Date(),
                custrecord_rsc_contrato_proponentes: fatura_prinicipal_contrato,
                custrecord_rsc_tipo: 1,
                custrecord_rsc_id_proponente: registroAtual.id,
                custrecord_rsc_nome_proponente: clientes,
                custrecord_rsc_perc_proponentes: participacao_perc,
                custrecord_rsc_responsavel: runtime.getCurrentUser().id
            });
        }
    } else if (participacao_perc > 100 && !registroAtual.id) {
        // var msg2 = 'Percentual de participação deve ser igual a 100%. \n'+
        // '% Contrato: ' + participacao_perc + '%';

        // if (confirm(msg2)) {
        //     return true;
        // } else {
        //     return false;
        // }

        dialog.alert({
            title: 'Aviso!',
            message: 'Percentual de participação deve ser igual a 100%. <br />'+
            '% Contrato: ' + participacao_perc + '%'
        });

        return false;
    }
    
    return true;
}

const validateField = (context) => {}

const fieldChanged = (context) => {}

const postSourcing = (context) => {}

const lineInit = (context) => {}

const validateDelete = (context) => {}

const validateInsert = (context) => {}

const validateLine = (context) => {}

const sublistChanged = (context) => {}

const excluirProponente = () => {
    const registroAtual = currentRecord.get();

    const clientes = registroAtual.getValue('custrecord_rsc_clientes_contratos');

    const participacao_perc = registroAtual.getValue('custrecord_rsc_pct_part') || 0;
    
    const fatura_prinicipal_contrato = registroAtual.getValue('custrecord_rsc_fat_contrato');

    const recover_share_percentage = percentualParticipacao(fatura_prinicipal_contrato, clientes);

    const mensagem = 'Percentual de Participação: '+recover_share_percentage+'. \n Confirma exclusão?'

    if (confirm(mensagem)) {
        const logExclusao = registrarLog({
            custrecord_rsc_data_log: new Date(),
            custrecord_rsc_contrato_proponentes: fatura_prinicipal_contrato,
            custrecord_rsc_tipo: 2,
            custrecord_rsc_id_proponente: registroAtual.id,
            custrecord_rsc_nome_proponente: clientes,
            custrecord_rsc_perc_proponentes: participacao_perc,
            custrecord_rsc_responsavel: runtime.getCurrentUser().id
        });

        if (logExclusao.status == 'Sucesso') {
            record.delete({type: 'customrecord_rsc_finan_client_contrato', id: registroAtual.id});
            // Recarrega a página
            document.location.reload(true);
        } else {
            dialog.alert({
                title: 'Aviso!',
                message: 'Houve um erro no processamento da solicitação.'
            })
            return false;
        }
    } else {
        return false;
    }
}

return {
    excluirProponente: excluirProponente,
    pageInit: pageInit,
    saveRecord: saveRecord,
    // validateField: validateField,
    // fieldChanged: fieldChanged,
    // postSourcing: postSourcing,
    // lineInit: lineInit,
    // validateDelete: validateDelete,
    // validateInsert: validateInsert,
    // validateLine: validateLine,
    // sublistChanged: sublistChanged
}
});
