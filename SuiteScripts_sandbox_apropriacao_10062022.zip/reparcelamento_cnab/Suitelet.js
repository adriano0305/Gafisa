/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/ui/serverWidget'],
  (serverWidget) => {
    /**
     * Defines the Suitelet script trigger point.
     * @param {Object} scriptContext
     * @param {ServerRequest} scriptContext.request - Incoming request
     * @param {ServerResponse} scriptContext.response - Suitelet response
     * @since 2015.2
     */
    const onRequest = (scriptContext) => {
      const request = scriptContext.request
      const response = scriptContext.response
      const parameters = request.parameters

      if (request.method === 'GET') {
        // escreve o formulário
        const invoiceId = parameters.invoiceId

        const form = serverWidget.createForm({ title: 'Simple Form' })

        form.clientScriptModulePath = './ClientScript.js'

        response.writePage({ pageObject: form })
      } else { // POST
        // recebe as informções fo form escrito no GET e faz algum coisa
        try {



        } catch (e) {
          const form = serverWidget.createForm({ title: 'Erros' })

          form.addField({ id: 'errors', type: serverWidget.FieldType.INLINEHTML, label: 'Erros' })
            .defaultValue = '<p>' + e.message + '</p>'

          response.writePage({ pageObject: form })
        }
      }
    }

    return { onRequest }
  })
