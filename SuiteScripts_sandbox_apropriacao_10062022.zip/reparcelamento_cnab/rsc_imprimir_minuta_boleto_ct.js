/**
 *@NApiVersion 2.1
 *@NScriptType ClientScript
 */
define(['N/currentRecord', 'N/log', 'N/ui/dialog'], function(currentRecord, log, dialog) {
function imprimirMinutaBoleto() {    
    const registroAtual = currentRecord.get();
    console.log('imprimirMinutaBoleto: '+JSON.stringify(registroAtual));

    dialog.alert({
        title: 'Aviso!',
        message: 'imprimirMinutaBoleto: aguardando modelo...'
    });
}

function reenviarMinutaBoleto() {
    const registroAtual = currentRecord.get();
    console.log('reenviarMinutaBoleto: '+JSON.stringify(registroAtual));

    dialog.alert({
        title: 'Aviso!',
        message: 'reenviarMinutaBoleto: aguardando modelo...'
    });
}

function pageInit(context) {
    log.audit('pageInit', context);

    const registroAtual = context.currentRecord;
}

function saveRecord(context) {
    
}

function validateField(context) {
    
}

function fieldChanged(context) {
    
}

function postSourcing(context) {
    
}

function lineInit(context) {
    
}

function validateDelete(context) {
    
}

function validateInsert(context) {
    
}

function validateLine(context) {
    
}

function sublistChanged(context) {
    
}

return {
    imprimirMinutaBoleto: imprimirMinutaBoleto,
    reenviarMinutaBoleto: reenviarMinutaBoleto,
    pageInit: pageInit,
    // saveRecord: saveRecord,
    // validateField: validateField,
    // fieldChanged: fieldChanged,
    // postSourcing: postSourcing,
    // lineInit: lineInit,
    // validateDelete: validateDelete,
    // validateInsert: validateInsert,
    // validateLine: validateLine,
    // sublistChanged: sublistChanged
}
});
