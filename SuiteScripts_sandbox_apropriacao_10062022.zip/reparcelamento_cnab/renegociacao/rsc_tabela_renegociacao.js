/**
 * @NApiVersion 2.x
 * @NModuleScope public
 * @author Adriano Barbosa
 * @since 2021.9
 */
define(["N/log", "N/record", "N/search", "N/url"], function(log, record, search, url) {
function reneg(context) {
    console.log('reneg: '+JSON.stringify(context));

    // {
    //     "dadosGerais": {
    //         "clienteTarefa": {
    //             "id": "4846",
    //             "nome": "49 ALEXSANDRA PEREIRA DA SILVA"
    //         },
    //         "fatura": "{\"id\":\"33113\",\"nome\":\"Fatura Nº 893\"}"
    //     },
    //     "simulacao": {
    //         "quantidadeParcelas": 2,
    //         "primeiroVencimento": "2021-09-07T03:00:00.000Z",
    //         "periodicidade": "1",
    //         "observacao": "O Palmeiras não tem Mundial"
    //     },
    //     "arrayParcelas": [{
    //         "linha": "1",
    //         "id_financiamento_invoice": 33114,
    //         "vencimento": "2022-09-02T03:00:00.000Z"
    //     }]
    // }

    var campos = {
        custrecord_rsc_cliente_tarefa: context.dadosGerais.clienteTarefa.nome,
        custrecord_rsc_fatura_contrato: JSON.parse(context.dadosGerais.fatura).id,
        custrecord_rsc_quantidade_parcelas: context.simulacao.quantidadeParcelas,
        custrecord_rsc_1o_vencimento: context.simulacao.primeiroVencimento.value,
        custrecord_rsc_periodicidade: context.simulacao.periodicidade.id,
        custrecord_rsc_array_parcelas: JSON.stringify(context.arrayParcelas),
        custrecord_rsc_observacao: context.simulacao.observacao
    }

    const tabelaRenegociacao = record.create({
        type: 'customrecord_rsc_tabela_renegociacao',
    });

    Object.keys(campos).forEach(function (bodyField) {
        tabelaRenegociacao.setValue({
            fieldId: bodyField,
            value: campos[bodyField]
        });
    });

    var tabela_renegociacao_id, erro;

    try {
        tabela_renegociacao_id = tabelaRenegociacao.save();
        console.log('tabela_negociacao_id: '+tabela_renegociacao_id);
    } catch (e) {
        console.log('Erro Tabela Renegociação: '+e);
        erro = e;
    }

    var gerarParcelasRenegociacao;

    if (tabela_renegociacao_id) {
        gerarParcelasRenegociacao = parcelasRenegociacao({
            tabela_renegociacao_id: tabela_renegociacao_id,
            campos: context            
        });

        return {
            status: 'Sucesso', 
            id: tabela_renegociacao_id,
            documento: record.load({type: 'customrecord_rsc_tabela_renegociacao', id: tabela_renegociacao_id}).getValue('tranid'),
            url: urlTransacao({registro: 'customrecord_rsc_tabela_renegociacao', id: tabela_renegociacao_id}),
            statusParcelasRenegociacao: gerarParcelasRenegociacao
        }  
    } else {
        return {
            status: 'Erro Tabela Renegociação', 
            msg: erro.message
        }
    }

    // return JSON.stringify(context);
}

function urlTransacao(dados) {
    return url.resolveRecord({
        recordType: dados.registro,
        recordId: dados.id
    });
}

function formatData(data, dias) {
    console.log('formatData: '+JSON.stringify({data: data, dias: dias}));

    var partesData = data.split("/");
    console.log('partesData: '+partesData);

    var novaData = new Date(partesData[2], partesData[1] - 1, partesData[0]);
    console.log('novaData: '+novaData);

    var novoVencimento = novaData.setDate(novaData.getDate() + dias);
    console.log('novoVencimento: '+new Date(novoVencimento));

    return new Date(novoVencimento);
}

function parcelasRenegociacao(dados) {
    console.log('parcelasRenegociacao: '+JSON.stringify(dados));

    var campos = {
        custrecord_rsc_vencimento: dados.campos.simulacao.primeiroVencimento.text,
        custrecord_rsc_valor: dados.campos.simulacao.novasParcelas
    }

    const parcelasRenegociacao = record.create({
        type: 'customrecord_rsc_parcelas_renegociacao',
        isDynamic: true
    });

    parcelasRenegociacao.setValue('custrecord_rsc_tabela_renegociacao', dados.tabela_renegociacao_id);

    var i = 0;

    for (i=0; i<dados.campos.simulacao.quantidadeParcelas; i++) {
        console.log('Quantidade de parcelas: '+dados.campos.simulacao.quantidadeParcelas);

        parcelasRenegociacao.selectNewLine('recmachcustrecord_rsc_lista_parcelas');

        if (i == 0) {
            console.log('i: '+i);

            parcelasRenegociacao.setCurrentSublistValue(
                'recmachcustrecord_rsc_lista_parcelas', 
                'custrecord_rsc_vencimento', 
                dados.campos.simulacao.primeiroVencimento.value
            );
        } else {
            console.log('i: '+i);

            switch (dados.campos.simulacao.periodicidade.nome) {
                case 'Quinzenal':
                    parcelasRenegociacao.setCurrentSublistValue(
                        'recmachcustrecord_rsc_lista_parcelas', 
                        'custrecord_rsc_vencimento', 
                        formatData(campos.custrecord_rsc_vencimento, 15)
                    );
                break;

                case 'Mensal':                    
                    parcelasRenegociacao.setCurrentSublistValue(
                        'recmachcustrecord_rsc_lista_parcelas', 
                        'custrecord_rsc_vencimento', 
                        formatData(campos.custrecord_rsc_vencimento, 30)
                    );
                break;

                case 'Trimestral':                    
                    parcelasRenegociacao.setCurrentSublistValue(
                        'recmachcustrecord_rsc_lista_parcelas', 
                        'custrecord_rsc_vencimento', 
                        formatData(campos.custrecord_rsc_vencimento, 90)
                    );
                break;

                case 'Semestral':                    
                    parcelasRenegociacao.setCurrentSublistValue(
                        'recmachcustrecord_rsc_lista_parcelas', 
                        'custrecord_rsc_vencimento', 
                        formatData(campos.custrecord_rsc_vencimento, 180)
                    );
                break;

                case 'Anual':
                    parcelasRenegociacao.setCurrentSublistValue(
                        'recmachcustrecord_rsc_lista_parcelas', 
                        'custrecord_rsc_vencimento', 
                        formatData(campos.custrecord_rsc_vencimento, 365)
                    );
                break;
            }
        }

        parcelasRenegociacao.setCurrentSublistValue('recmachcustrecord_rsc_lista_parcelas', 'custrecord_rsc_valor', campos.custrecord_rsc_valor);

        parcelasRenegociacao.commitLine('recmachcustrecord_rsc_lista_parcelas');
    }

    var parcela_renegociacao_id, erro;

    try {
        parcela_renegociacao_id = parcelasRenegociacao.save();
        console.log('parcela_renegociacao_id: '+parcela_renegociacao_id);
    } catch (e) {
        console.log('Erro Parcela Renegociação: '+e);
        erro = e;
    }

    var load_parcela_renegociacao;

    if (parcela_renegociacao_id) {
        try {
            record.submitFields({
                type: 'customrecord_rsc_tabela_renegociacao',
                id: dados.tabela_renegociacao_id,
                values: {
                    'custrecord_rsc_parcela_renegociacao': parcela_renegociacao_id
                }            
            });
        } catch (e) {
            console.log('Erro ao gravar parcela_regociacao na tabela_renegociacao: '+e);

            load_parcela_renegociacao = record.load({type: 'customrecord_rsc_tabela_renegociacao', id: dados.tabela_renegociacao_id});

            load_parcela_renegociacao.setValue('custrecord_rsc_parcela_renegociacao', parcela_renegociacao_id)
            .save(); 
        }      

        return {
            status: 'Sucesso', 
            id: parcela_renegociacao_id
        } 
    } else {
        return {
            status: 'Erro Parcela Renegociação', 
            msg: erro.message
        }
    }   
}

return {
    'reneg': reneg
}
});