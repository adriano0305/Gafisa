/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/log', 'N/runtime', 'N/record'], (log, runtime, record) => {
const registrarLog = (dados) => {
    const logProponente = record.create({type: 'customrecord_rsc_logs_proponentes', isDynamic: true});

    var campos = {
        custrecord_rsc_data_log: dados.custrecord_rsc_data_log,
        custrecord_rsc_contrato_proponentes: dados.custrecord_rsc_contrato_proponentes,
        custrecord_rsc_tipo: dados.custrecord_rsc_tipo,
        custrecord_rsc_id_proponente: dados.custrecord_rsc_id_proponente,
        custrecord_rsc_nome_proponente: dados.custrecord_rsc_nome_proponente,
        custrecord_rsc_perc_proponentes: dados.custrecord_rsc_perc_proponentes,
        custrecord_rsc_responsavel: dados.custrecord_rsc_responsavel
    }

    Object.keys(campos).forEach(function(bodyField) {
        logProponente.setValue(bodyField, campos[bodyField]);
    });

    try {
        const idLogProponente = logProponente.save();
        return {status: 'Sucesso', idLogProponente: idLogProponente}
    } catch(e) {
        return {status: 'Erro', msg: e}
    }    
}

const afterSubmit = (context) => {
    log.audit('afterSubmit', context);

    if (context.type == 'edit') {
        // Novo Registro
        const novoRegistro = context.newRecord;

        var clientes = novoRegistro.getValue('custrecord_rsc_clientes_contratos');
        var participacao_perc = novoRegistro.getValue('custrecord_rsc_pct_part') || 0;        
        var fatura_prinicipal_contrato = novoRegistro.getValue('custrecord_rsc_fat_contrato');

        // Antigo Registro
        const antigoRegistro = context.oldRecord;

        const clientes_a = antigoRegistro.getValue('custrecord_rsc_clientes_contratos');
        const participacao_perc_a = antigoRegistro.getValue('custrecord_rsc_pct_part') || 0;        
        const fatura_prinicipal_contrato_a = antigoRegistro.getValue('custrecord_rsc_fat_contrato');

        if (fatura_prinicipal_contrato_a != fatura_prinicipal_contrato || participacao_perc_a != participacao_perc || clientes_a != clientes) {
            const logEdicao = registrarLog({
                custrecord_rsc_data_log: new Date(),
                custrecord_rsc_contrato_proponentes: fatura_prinicipal_contrato,
                custrecord_rsc_tipo: 1,
                custrecord_rsc_id_proponente: novoRegistro.id,
                custrecord_rsc_nome_proponente: clientes,
                custrecord_rsc_perc_proponentes: participacao_perc,
                custrecord_rsc_responsavel: runtime.getCurrentUser().id
            });
            log.audit('logEdicao', logEdicao);
        }        
    }
}

return {
    afterSubmit: afterSubmit
};

});