/**
 *@NApiVersion 2.1
 *@NScriptType Suitelet
 *@author Vitor Santos 
 */
 define(["N/record", "N/search", "N/ui/serverWidget", "N/task", 'N/config', 'N/runtime', 'N/file' ],
 function (record, search, serverWidget, task, config, runtime, file) {

    function onRequest(context) {
        

        if (context.request.method === 'GET') { 
            const form = serverWidget.createForm({
                title: 'Geração DIMOB - Automatica'
            })        
            const ano_geracao = form.addField({
                id: 'custpage_ano_geracao',
                type: serverWidget.FieldType.TEXT,
                label: 'Ano Geração',
            })
            const button = form.addSubmitButton({label: 'Processar DIMOB',})  
            context.response.writePage(form);               

    } else {
        const form = serverWidget.createForm({
            title: 'Geração DIMOB - Automatica'
        })        
        const ano_geracao = form.addField({
            id: 'custpage_ano_geracao',
            type: serverWidget.FieldType.TEXT,
            label: 'Ano Geração',
        })
        
        var request = context.request
        var anoGeracao = request.parameters.custpage_ano_geracao
        log.debug('anoGeracao', anoGeracao)

        const button = form.addSubmitButton({label: 'Processar DIMOB',})  
        context.response.writePage(form); 


        function _getAllResults(s) {
            var results = s.run();
            var searchResults = [];
            var searchid = 0;
            do {
                var resultslice = results.getRange({ start: searchid, end: searchid + 1000 });
                resultslice.forEach(function(slice) {
                    searchResults.push(slice);
                    searchid++;
                });
            } while (resultslice.length >= 1000);
            return searchResults;
        }

        var dimobR01 = []
        var customrecord_rsc_dimob_r01SearchObj = search.create({
            type: "customrecord_rsc_dimob_r01",
            filters:
            [
               ["custrecord_rsc_status_dimob","anyof","1"], 
               "AND", 
               ["custrecord_rsc_ano_calendario","is", anoGeracao]
            ],
            columns:
            [
                search.createColumn({name: "name", sort: search.Sort.ASC, label: "Nome"}),
                search.createColumn({name: "custrecord_rsc_cnpj_do_declarante", label: "CNPJ do declarante"}),
                search.createColumn({name: "custrecord_rsc_ano_calendario", label: "Ano-calendário"}),
                search.createColumn({name: "custrecord_rsc_declaracao_retificadora", label: "Declaração Retificadora"}),
                search.createColumn({name: "custrecord_rsc_numero_do_recibo", label: "Número do Recibo "}),
                search.createColumn({name: "custrecord_rsc_situacao_especial", label: "Situação Especial"}),
                search.createColumn({name: "custrecord_rsc_data_do_evento", label: "Data do evento situação especial"}),
                search.createColumn({name: "custrecord_rsc_codigo_da_situacao", label: "Código da situação especial"}),
                search.createColumn({name: "custrecord_rsc_nome_empresarial", label: "Nome Empresarial"}),
                search.createColumn({name: "custrecord_rsc_cpf_do_responsavel_rfb", label: "CPF do Responsável pela pessoa jurídica perante à RFB"}),
                search.createColumn({name: "custrecord_rsc_endereco_contribuinte", label: "Endereço completo do contribuinte"}),
                search.createColumn({name: "custrecord_rsc_uf_do_contribuinte", label: "UF do Contribuinte"}),
                search.createColumn({name: "custrecord_rsc_codigo_do_municipio", label: "Código do Município do Contribuinte"}),
                search.createColumn({name: "custrecord_rsc_reservado", label: "Reservado"}),
                search.createColumn({name: "custrecord_rsc_status_dimob", label: "Status"}),
                search.createColumn({name: "internalid", label: "ID interna"})
             ]
         });
        var buscaDimobR01 = _getAllResults(customrecord_rsc_dimob_r01SearchObj);
        buscaDimobR01.forEach(function (res) {
            dimobR01.push({
                tipo: res.getValue(res.columns[0]),
                cnpj_declarante: res.getValue(res.columns[1]),
                ano_calendario: res.getValue(res.columns[2]),
                declaracao_retificadora: res.getValue(res.columns[3]),
                numero_recibo: res.getValue(res.columns[4]), 
                situacao_especial: res.getValue(res.columns[5]),
                data_situacao_especial: res.getValue(res.columns[6]),
                codigo_especial: res.getValue(res.columns[7]),
                nome_empresarial: res.getValue(res.columns[8]),
                responsavel: res.getValue(res.columns[9]),
                end_contribuinte: res.getValue(res.columns[10]),
                uf_contribuinte: res.getValue(res.columns[11]),
                cod_monicipio_contribuinte: res.getValue(res.columns[12]),
                reservado: res.getValue(res.columns[13]),
                status: res.getValue(res.columns[14]),
                id: res.getValue(res.columns[15]),
            });
        });

        dimobR01 = JSON.stringify(dimobR01)
        
        log.debug('dimobR01', dimobR01)
        task.create({
            taskType: task.TaskType.MAP_REDUCE,
            scriptId: 'customscript_rsc_dimob_mr',
            deploymentId: 'customdeploy_rsc_dimob_mr',
            params: { custscript_rsc_dimob_automatico: dimobR01} 
        }).submit()

    }


        
    }

    return {
        onRequest: onRequest
    }
});
