/**
 * @NScriptType ClientScript
 * @NApiVersion 2.1
 * @NModuleScope public
 *
 */
define([ 'N/ui/dialog', 'N/runtime', 'N/currentRecord', 'N/url'],

    function( dialog, runtime, currentRecord, url)
    {
        const pageInit = (context) => {}
        function attSub(){
            var record = currentRecord.get();
            var URL = url.resolveScript({
                scriptId: 'customscript_rsc_attfornecedor_st',
                deploymentId:'customdeploy_rsc_attfornecedor_st',
                params:{
                    'fornId' : record.id
                }
            });
            dialog.alert({
                title: 'Aviso!',
                message: 'As subsidiarias desse fornecedor serão atualizadas'
            });
            window.location.replace(URL)
        };
        return{
            attSub:attSub,
            pageInit:pageInit
        };
    });

