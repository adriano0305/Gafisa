/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/encode', 'N/https', 'N/record', 'N/runtime', 'N/search'],
    /**
     * @param {encode} encode
     * @param {https} https
     * @param {record} record
     * @param {runtime} runtime
     * @param {search} search
     */
    function(encode, https, record, runtime, search)
    {
            /**
             * Marks the beginning of the Map/Reduce process and generates input data.
             *
             * @typedef {Object} ObjectRef
             * @property {number} id - Internal ID of the record instance
             * @property {string} type - Record type id
             *
             * @return {Array|Object|Search|RecordRef} inputSummary
             * @since 2015.1
             */
            function getInputData()
            {
                    try
                    {
                            var itemSearchObj = search.create({
                                    type: "item",
                                    filters:
                                        [
                                                ["type","anyof","InvtPart","Group","Kit","NonInvtPart","Service"],
                                                "AND",
                                                ["isinactive","is","F"]
                                        ]
                            });

                            return itemSearchObj
                    }
                    catch (e)
                    {
                            log.debug('ERROR-getInputData', JSON.stringify(e))
                    }
            }

            /**
             * Executes when the map entry point is triggered and applies to each key/value pair.
             *
             * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
             * @since 2015.1
             */
            function map(context)
            {
                    try
                    {
                            //log.debug('Map Context', context);
                            var _itemSearch = JSON.parse(context.value);

                            var scriptObj = runtime.getCurrentScript();
                            var _itemid = scriptObj.getParameter({name: 'custscript_enl_itemidfield'});
                            var _description = scriptObj.getParameter({name: 'custscript_enl_descriptionfield'});

                            var _internalid = _itemSearch.id;
                            var _type = _itemSearch.recordType;

                            var _itemLoad = record.load({type: _type, id: _internalid, isDynamic: true });
                            var _subsidiary = _itemLoad.getValue('subsidiary');
                            var _integratedWithAvatax = _itemLoad.getValue('custitem_avlr_integratedwithavatax');

                            var _valueObj = {};
                            _valueObj.recordType = _itemLoad.type;
                            _valueObj.internalId = _itemLoad.id;
                            _valueObj.code = _itemLoad.getValue(_itemid);
                            _valueObj.agast = _itemLoad.getText('custitem_enl_it_taxgroup');

                            if(_itemLoad.getValue(_description))
                                    _valueObj.description = _itemLoad.getValue(_description).substr(0,60);

                            _valueObj.cityTaxConf = [];

                            if (_itemLoad.type != "serviceitem")
                            {
                                    _valueObj.source = getSourceItem(_itemLoad.getValue('custitem_enl_taxorigin'));

                                    var _productType = _itemLoad.getValue('custitem_enl_producttype');

                                    if (!_productType)
                                            _valueObj.productType = "NO RESTRICTION";
                                    else
                                            _valueObj.productType = getProductType(_productType);


                                    var _unitsTypeId = _itemLoad.getValue('unitstype')
                                    if(_unitsTypeId)
                                    {
                                            var _unitLoad = record.load({type: 'unitstype', id: _unitsTypeId});
                                            var _saleunit = _unitLoad.getSublistValue({sublistId: 'uom', fieldId: 'abbreviation', line: 1});
                                            if(_saleunit)
                                            {
                                                    _valueObj.salesUnit = _saleunit;
                                                    _valueObj.purchaseUnit = _saleunit;
                                            }
                                    }

                                    _valueObj.firstUse = false;
                                    _valueObj.sealCode = null;
                            }


                            for (var int = 0; int < _subsidiary.length; int++)
                            {
                                    //log.debug('_subsidiary', _subsidiary);

                                    var _index = _integratedWithAvatax.indexOf(_subsidiary[int]);
                                    //log.debug('_index', _index);
                                    if(_index != -1)
                                    {
                                            log.audit('WARNING', 'Item já integrado : ' + JSON.stringify(_valueObj));
                                            continue;
                                    }


                                    _valueObj.subsidiaryId = _subsidiary[int];
                                    //log.debug('Map valueObj', _valueObj);

                                    context.write({
                                            key: _itemLoad.type+'_'+_itemLoad.id+'_'+_subsidiary[int] ,
                                            value: _valueObj
                                    });
                            }

                    }
                    catch (e)
                    {
                            log.error('Map valueObj', _valueObj);

                            log.error('ERROR-map', JSON.stringify(e))
                    }
            }

            function getSourceItem(source)
            {
                    switch (source)
                    {
                            case "1": // Comprado
                                    return "0";
                            case "2": // Importado
                                    return "1";
                            case "3": // Importado Mercado Interno
                                    return "2";
                            case "4": // Nacional - Importação superior 40% e Inferior a 70%
                                    return "3";
                            case "5": // Nacional - Produzido conforme decreto
                                    return "4";
                            case "6": // Nacional - Importação inferior 40%
                                    return "5";
                            case "7": // Importado direto Camex
                                    return "6";
                            case "8": // Importado Mercado Interno Camex
                                    return "7";
                            case "9": // Nacional - mercadoria ou bem com conteúdo superior a 70%
                                    return "8";
                            default:
                                    return "0";
                    }
            }

            function getProductType(_productTypeId)
            {
                    switch (_productTypeId)
                    {
                            case "1":
                                    return "FOR PRODUCT";

                            case "2":
                                    return "FOR MERCHANDISE";

                            case "3":
                                    return "NO RESTRICTION";

                            case "4":
                                    return "SERVICE";

                            case "5":
                                    return "FEEDSTOCK";

                            case "6":
                                    return "FIXED ASSETS";

                            case "7":
                                    return "PACKAGING";

                            case "8":
                                    return "PRODUCT IN PROCESS";

                            case "9":
                                    return "SUBPRODUCT";

                            case "10":
                                    return "INTERMEDIATE PRODUCT";

                            case "11":
                                    return "MATERIAL FOR USAGE AND CONSUMPTION";

                            case "12":
                                    return "OTHER INPUTS";

                            default:
                                    return "FOR MERCHANDISE";
                    }
            }

            /**
             * Executes when the reduce entry point is triggered and applies to each group.
             *
             * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
             * @since 2015.1
             */
            function reduce(context)
            {
                    try
                    {
                            log.debug("begin", "---------------------------------------------------------------------------------")
                            var _itemObj = JSON.parse(context.values[0]);
                            //log.debug('_itemObj', _itemObj);

                            var _subsidiaryLoad = record.load({type: record.Type.SUBSIDIARY, id: _itemObj.subsidiaryId, isDynamic: true});
                            log.debug(_subsidiaryLoad.getValue('name'), _itemObj)

                            var baseURL = _subsidiaryLoad.getValue('custrecord_enl_urlswfiscal');
                            if (!baseURL)
                            {
                                    log.debug('ERROR', 'Campo "FISCAL SW URL" não esta definido.');
                                    return;
                            }

                            var header = {};

                            if(_itemObj.recordType == "serviceitem")
                            {
                                    header["Avalara-Product-Type"] = "service";

                                    var _url = baseURL + "/v2/companies/items/" + encodeURIComponent(_itemObj.code) + "?service";
                            }
                            else
                            {
                                    header["Avalara-Product-Type"] = "goods";

                                    var _url = baseURL + "/v2/companies/items/" + encodeURIComponent(_itemObj.code) + "?goods";
                            }

                            _url = _url.substr(0, 8).concat(_url.substr(8).replace('//', '/'));
                            log.debug("Send To Determination", _url);

                            var user = _subsidiaryLoad.getValue('custrecord_enl_avataxuser');
                            var pwd = _subsidiaryLoad.getValue('custrecord_enl_pwdavatax');
                            var companyCode = _subsidiaryLoad.getValue('custrecord_enl_companyid');

                            var base64String = encode.convert({
                                    string: (user + ':' + pwd),
                                    inputEncoding: encode.Encoding.UTF_8,
                                    outputEncoding: encode.Encoding.BASE_64
                            });

                            header["Authorization"] = "Basic " + base64String;
                            header["Content-Type"] = "application/json";


                            if(companyCode)
                                    header["Avalara-Company-Code"] = companyCode


                            var response = https.get({url: _url, headers: header});
                            //log.debug("response GET", response.body);
                            log.debug("response GET", + response.code + " : " + response.body);

                            if(response.code == 200)
                            {
                                    var response = https.put({url: _url, headers: header, body: JSON.stringify(_itemObj)});
                                    if(response.code == 204)
                                            log.debug("response PUT", "Success " + response.code + " : " + response.body);
                                    else
                                            log.debug("response PUT", response.code + " : " + response.body);
                            }
                            else
                            {
                                    if(_itemObj.recordType == "serviceitem")
                                    {
                                            var _url = baseURL + "/v2/companies/items?service"

                                            if(!_itemObj.agast)
                                                    _itemObj.agast = "BRLC"
                                    }
                                    else
                                    {
                                            var _url = baseURL + "/v2/companies/items?goods"

                                            if(!_itemObj.agast)
                                                    _itemObj.agast = "BRNCM";
                                    }

                                    _url = _url.substr(0, 8).concat(_url.substr(8).replace('//', '/'));
                                    log.debug("Send To Determination", _url);

                                    var response = https.post({url: _url, headers: header, body: JSON.stringify(_itemObj)});
                                    if(response.code == 201)
                                    {
                                            log.debug("response POST", "Success " + response.code + " : " + response.body);
                                    }
                                    else
                                    {
                                            log.debug("response POST", response.code + " : " + response.body);

                                    }
                            }

                            if(response.code == 204 || response.code == 201)
                            {
                                    var _itemLoad = record.load({type: _itemObj.recordType, id: _itemObj.internalId, isDynamic: true });

                                    var _subsidiary = _itemLoad.getValue('custitem_avlr_integratedwithavatax');
                                    if(!_subsidiary)
                                    {
                                            _subsidiary = [];
                                            _subsidiary.push(_itemObj.subsidiaryId)
                                    }
                                    else
                                    {
                                            var _index = _subsidiary.indexOf(_itemObj.subsidiaryId);
                                            if(_index == -1)
                                                    _subsidiary.push(_itemObj.subsidiaryId)
                                    }

                                    _itemLoad.setValue({fieldId: 'custitem_avlr_integratedwithavatax', value: _subsidiary});
                                    log.debug("Update Item", _itemLoad.save());
                            }

                            log.debug("end", "---------------------------------------------------------------------------------")
                    }
                    catch (e)
                    {
                            log.error('ERROR-reduce', JSON.stringify(e))
                            log.error("end", "---------------------------------------------------------------------------------")
                    }
            }


            /**
             * Executes when the summarize entry point is triggered and applies to the result set.
             *
             * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
             * @since 2015.1
             */
            function summarize(summary)
            {
                    try
                    {

                    }
                    catch (e)
                    {
                            log.debug('ERROR-summarize', JSON.stringify(e))
                    }
            }

            return {
                    getInputData: getInputData,
                    map: map,
                    reduce: reduce,
                    summarize: summarize
            };

    });
