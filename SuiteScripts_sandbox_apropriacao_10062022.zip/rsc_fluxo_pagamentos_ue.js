/**
 *@NApiVersion 2.1
 *@NScriptType UserEventScript
 */
const custPage = 'custpage_rsc_';

define(['N/log', 'N/query', 'N/record', 'N/runtime'], (log, query, record, runtime) => {
const novoBL = (id) => {
    log.audit('novoBL', id);

    const loadReg = record.load({type: 'invoice', id: id});
    log.audit('loadReg', loadReg);

    const fluxoPagamentos = loadReg.getLineCount(custPage+'parcelas');
    log.audit('fluxoPagamentos', fluxoPagamentos);
}

const beforeLoad = (context) => {
    log.audit('beforeLoad', context);

    var usuarioAtual = runtime.getCurrentUser();

    if (usuarioAtual.id == 3588) {
        const novoRegistro = context.newRecord;
        log.audit('novoRegistro', novoRegistro);

        novoBL(novoRegistro.id)

        // var dinamico = novoRegistro.isDynamic;
        // log.audit('dinamico antes', dinamico);

        // if (dinamico == false) {
        //     novoRegistro.setValue('isDynamic', 'T');
        //     dinamico = novoRegistro.isDynamic;
        //     log.audit('dinamico antes', dinamico); 
        // }
    
        // const fluxoPagamentos = novoRegistro.getLineCount('custpage_rsc_parcelas');
        // log.audit('fluxoPagamentos', fluxoPagamentos);
    
        // if (fluxoPagamentos > 0) {
        //     for (i=0; i<fluxoPagamentos; i++) {
        //         log.audit(i, novoRegistro.getSublistValue('custpage_rsc_parcelas', 'custpage_rsc_ver', i));
        //     }
        // }
    }    
}

const beforeSubmit = (context) => {}

const afterSubmit = (context) => {}

return {
    beforeLoad: beforeLoad,
    beforeSubmit: beforeSubmit,
    afterSubmit: afterSubmit
}
});
