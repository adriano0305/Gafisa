/**
 *@NApiVersion 2.1
 *@NScriptType Restlet
 */
define(['N/https', 'N/log', 'N/record', 'N/search'], function(https, log, record, search) {
function formatData(data) {
    var partesData = data.split("/");

    var novaData = new Date(partesData[2], partesData[1] - 1, partesData[0]);

    return novaData;
}

function _post(context) {
    log.audit('_post', context);
}

function _get(context) {
    log.audit('_get', context);
}

function _put(context) {
    
}

function _delete(context) {
    
}

return {
    get: _get,
    post: _post,
    put: _put,
    delete: _delete
}
});
