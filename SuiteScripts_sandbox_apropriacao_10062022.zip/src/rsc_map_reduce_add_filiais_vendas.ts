/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*/




import {EntryPoints} from 'N/types';
import Log from 'N/log';
import query from 'N/query';



export const getInputData: EntryPoints.MapReduce.getInputData = () => {
    let sql = 'SELECT id FROM customer'

    return query.runSuiteQL({
        query:  sql
    }).asMappedResults()
}


export const map: EntryPoints.MapReduce.map = (ctx: EntryPoints.MapReduce.mapContext) => {
    Log.debug('ctx', ctx)
}