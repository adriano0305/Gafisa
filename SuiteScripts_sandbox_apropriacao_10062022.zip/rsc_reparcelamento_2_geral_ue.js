/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/log', 'N/record', 'N/search'], (log, record, search) => {
const afterSubmit = (context) => {
    log.audit('afterSubmit', context);

    const registroAtual = context.newRecord;

    const fatura_principal = registroAtual.getValue('custrecord_rsc_fatura_principal');
    
    const id_fatura_principal = registroAtual.getValue('custrecord_rsc_id_fatura_principal');

    if (!fatura_principal) {
        if (id_fatura_principal) {
            var loadReg = record.load({type: 'customrecord_rsc_reparcelamento_2', id: registroAtual.id});
            log.audit('loadReg', loadReg);

            loadReg.setValue('custrecord_rsc_fatura_principal', id_fatura_principal)
            .save({ignoreMandatoryFields: true});
        }
    }
}

return {
    afterSubmit
}
});