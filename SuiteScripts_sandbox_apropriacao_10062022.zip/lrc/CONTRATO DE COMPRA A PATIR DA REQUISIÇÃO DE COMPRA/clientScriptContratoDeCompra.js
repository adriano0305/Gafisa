/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/record", "N/runtime"], function (require, exports, currentRecord_1, record_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.criarContratoDeCompra = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    record_1 = __importDefault(record_1);
    runtime_1 = __importDefault(runtime_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var criarContratoDeCompra = function () {
        var currRecord = currentRecord_1.default.get();
        var record = record_1.default.load({
            id: currRecord.id,
            type: 'purchaserequisition'
        });
        var fornecedor = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_fornecedor' });
        var workflow = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_transacao_workflow' });
        var taxaCambio = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_taxa_de_cambio' });
        var date = String(record.getValue({
            fieldId: 'trandate'
        }));
        var trandate = new Date(date);
        var subsidiary = record.getValue({
            fieldId: 'subsidiary'
        });
        var contrato = record_1.default.create({
            type: 'purchasecontract',
        });
        var line = record.getLineCount({
            sublistId: 'item'
        });
        console.log('line', line);
        for (var i = 0; i < line; i++) {
            console.log('entrou no for');
            var item = record.getSublistValue({
                fieldId: 'item',
                sublistId: 'item',
                line: i
            });
            console.log('item', item);
            var sublist = record.getSublistValue({
                fieldId: 'item',
                sublistId: 'item',
                line: i
            });
            console.log('sublist', sublist);
            var quantidade = record.getSublistValue({
                fieldId: 'initquantity',
                sublistId: 'item',
                line: i
            });
            console.log('quantidade', quantidade);
            var rate = record.getSublistValue({
                fieldId: 'estimatedrate',
                sublistId: 'item',
                line: i
            });
            console.log('rate', rate);
            contrato.setSublistValue({
                sublistId: 'item',
                line: i,
                fieldId: 'item',
                value: item
            });
            contrato.setSublistValue({
                sublistId: 'item',
                line: i,
                fieldId: 'rate',
                value: rate
            });
            contrato.setSublistValue({
                sublistId: 'item',
                line: i,
                fieldId: 'custcol_rsc_qtd_contrato_compra',
                value: quantidade
            });
        }
        contrato.setValue({
            fieldId: 'entity',
            value: fornecedor
        });
        console.log('fornecedor', fornecedor);
        contrato.setValue({
            fieldId: 'custbody_rsc_tipo_transacao_workflow',
            value: workflow,
        });
        console.log('workflow', workflow);
        contrato.setValue({
            fieldId: 'subsidiary',
            value: subsidiary
        });
        console.log('subsidiary', subsidiary);
        contrato.setValue({
            fieldId: 'trandate',
            value: trandate
        });
        console.log('date', date);
        contrato.setValue({
            fieldId: 'exchangerate',
            value: taxaCambio
        });
        console.log('taxacambio', taxaCambio);
        contrato.save();
        alert('Contrato de compra criado!');
    };
    exports.criarContratoDeCompra = criarContratoDeCompra;
});
