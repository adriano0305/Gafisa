/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * User_botoesTelaItem.ts
 * 
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        var form = ctx.form;
        form.clientScriptModulePath = "./ClientScript_getRecordId.js";
        if (ctx.type == ctx.UserEventType.EDIT) {
            form.addButton({
                id: "custpage_button",
                label: "Atualizar Status",
                functionName: "getRecordId"
            });
        }
    };
    exports.beforeLoad = beforeLoad;
});
