/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* Suitelet_getTokens.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/https"], function (require, exports, log_1, https_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = exports.getAcessToken = exports.getAuthCode = void 0;
    log_1 = __importDefault(log_1);
    https_1 = __importDefault(https_1);
    var getAuthCode = function () {
    };
    exports.getAuthCode = getAuthCode;
    var getAcessToken = function () {
        /* O método de autenticação ainda não está bem definido. Dessa maneira, para os testes, utilizaremos
        uma conta criada no DocuSign para o desenvolvimento. Além disso, serão criados alguns parâmetros
        globais como o "access_token" para facilitar o desenvolvimento. No entanto, é importante notar que
        o "access_token" tem um período de expiração relativamente curto. Após nossos testes, a integração
        não estará funcionando após um período de aproximadamente 8 horas.
    
        O conteúdo das variavéis usadas atualmente são apenas para testes,
        */
        var accessCode = "eyJ0eXAiOiJNVCIsImFsZyI6IlJTMjU2Iiwia2lkIjoiNjgxODVmZjEtNGU1MS00Y2U5LWFmMWMtNjg5ODEyMjAzMzE3In0.AQoAAAABAAYABwAAK8mhwO_YSAgAALdP6cDv2EgCAFBRwALUv-pOmwyRn3WjLdcVAAEAAAAYAAEAAAAFAAAADQAkAAAAYWFhMThmMzktZDhiYi00ZmMzLTgyOWYtMmY4MmQyNDJhYTQ0IgAkAAAAYWFhMThmMzktZDhiYi00ZmMzLTgyOWYtMmY4MmQyNDJhYTQ0NwBYkjnetmY8Rbu1MaRdtW-CMAAAmOuMvu_YSA.BDwLytuwIIdSioGYVq6wqkXP5vIOeel0tqKDT7BECFuX-BFcNbeeZ08k2q5muF8FqJKBZSj8HiKtfeJYhsR4Jn-jwaEBOUyyC4ZdO59YmOk8bYUxvv2Pp8b8xZwcdh4JUjfXVgDzv7yLfS8LtIlqVT7t-C0UeZdYUFFllndQxUleV-UJwTVYGszw0PuYDc06QXBlw5md_ld18nwLZQZxvJg9e31YbscJdUUOS1Ca-T3rOCLI71T9uxGSk3oKwpI8TBOSHSbY-nKq-OG8L4MZkV-YddEdHj0bi9U_jQJFsRxxKItGVA44Kf3MzwcwgdBZ7qRQ6skk7FEGPVzytWsMpg";
        var accessAuth = "Basic YWFhMThmMzktZDhiYi00ZmMzLTgyOWYtMmY4MmQyNDJhYTQ0OmQ5YmE4ZTVkLThlZGItNGZmNy05Nzg4LTkwY2Y5NDAwYmJmMw==";
        var accessUrl = "https://account-d.docusign.com/oauth/token";
        var accessBody = {
            "grant_type": "authorization_code",
            "code": accessCode
        };
        var accessHeaders = {
            "Authorization": accessAuth,
            "Content-Type": "application/json"
        };
        var request = https_1.default.request({
            method: https_1.default.Method.POST,
            url: accessUrl,
            body: accessBody,
            headers: accessHeaders
        });
        log_1.default.debug("request", request);
        /* O request terá o seguinte conteúdo:
        {
            "access_token": "eyJ0eXAiOiJNVCIsImFsZyI6IlJTMjU2Iiwia2lkIjoiNjgxODVmZjEtNGU1MS00Y2U5LWFmMWMtNjg5ODEyMjAzMzE3In0.AQoAAAABAAUABwCAtwKuw-_YSAgAgPclvAbw2EgCAFBRwALUv-pOmwyRn3WjLdcVAAEAAAAYAAEAAAAFAAAADQAkAAAAYWFhMThmMzktZDhiYi00ZmMzLTgyOWYtMmY4MmQyNDJhYTQ0IgAkAAAAYWFhMThmMzktZDhiYi00ZmMzLTgyOWYtMmY4MmQyNDJhYTQ0MACAQ1zEwu_YSDcAWJI53rZmPEW7tTGkXbVvgg.ttzjfFkTazivL9WmlIN5QKiWTnZ4kp8isud_ULNQBlm2VKEKD8fln7XOU1W6NS9K8nq9XsIjliGuX2pBlimTxxTpMrCu45nSbC4FN6-KOVpdch7VlvNyjTw9N8jOSc-syHE2VZmvqfZA7SaGPk442m5pdiZzjM4QHt1YdJ6to_zr5YYPxncNJROVAuEI1IIB980dapdFpjCuevdRxiJEO2Pk0ic8dmnoxohbrEesdigvHU-6rZu1QNcAiEIbXr37cx3fWmOkAWAV9qDcFRB_G57QKp-UjJFng-C-h0a8ZzurhvV0iiGAUBk8OktL2l-NnNvbC5ltxunOUFU1J4pGPw",
            "token_type": "Bearer",
            "refresh_token": "eyJ0eXAiOiJNVCIsImFsZyI6IlJTMjU2Iiwia2lkIjoiNjgxODVmZjEtNGU1MS00Y2U5LWFmMWMtNjg5ODEyMjAzMzE3In0.AQoAAAABAAgABwCAtwKuw-_YSAgAgDdnplYH2UgCAFBRwALUv-pOmwyRn3WjLdcVAAEAAAAYAAEAAAAFAAAADQAkAAAAYWFhMThmMzktZDhiYi00ZmMzLTgyOWYtMmY4MmQyNDJhYTQ0IgAkAAAAYWFhMThmMzktZDhiYi00ZmMzLTgyOWYtMmY4MmQyNDJhYTQ0MACAQ1zEwu_YSDcAWJI53rZmPEW7tTGkXbVvgg.wgPYq6LMe1ted_hwEKQI8i6nSOkFzFqjLKkCIPF6yiZkpKj32V0ssRkPsXN5b-xiilxB85Eq2t6XtbaUnH-YbFt-nwujaAqaewFaCywJS7s3HvgnzpVTudXdMTyNAC9Zr1MAUTHsVJqpzK70KCUy-NGk6_JsoQKMu-DpCfmkQtsbuBOnCWSaOXoQ0FUTDpElRjjWl4IxuYgc9AjNXCs1OgOI3raIyUxjkX2Akn9Ny__Dj5NHavDuBa2Fkr1fwnjdtXarjCIFEZ9f_RTshIHrIub3GGzUejkhJ-f1XZQ_OisucAXEHWqPMTjX4lSlZH6BQeCcBrjhkfqlBf5aV29RNg",
            "expires_in": 28800
        }
    
        Note que são retornados 4 valores:
    
        access_token: Token necessário para realizar a maioria das chamadas de requisição
        token_type: "cabeçalho" do token. Para realizar qualquer chamada REST deverá concatenar "token_type" + " " + "access_token"
        expires_in: O "access_token" tem uma vida útil limitada, geralmente de 8 horas.
        refresh_token: Tem duração de 30 dias e é utilizado para renovar o "access_token"
        */
        var codeRefresh = https_1.default.request({
            method: https_1.default.Method.POST,
            url: accessUrl,
            body: {
                "grant_type": "refresh_token",
                "refresh_token": request.refresh_token
            },
            headers: {
                "Authorization": accessAuth,
                "Content-Type": "application/json"
            }
        });
        return request;
    };
    exports.getAcessToken = getAcessToken;
    var onRequest = function (ctx) {
        var request = ctx.request; // oq vem?
        log_1.default.debug("request", request);
    };
    exports.onRequest = onRequest;
});
