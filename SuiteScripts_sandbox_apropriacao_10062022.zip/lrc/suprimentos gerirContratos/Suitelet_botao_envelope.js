/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_botao_envelope.ts
* 
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/runtime", "N/record", "N/log", "N/redirect", "N/https"], function (require, exports, runtime_1, record_1, log_1, redirect_1, https_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    runtime_1 = __importDefault(runtime_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    redirect_1 = __importDefault(redirect_1);
    https_1 = __importDefault(https_1);
    // import { getAcessToken } from "./Suitelet_getToken";
    var onRequest = function (ctx) {
        var parameters = ctx.request.parameters;
        log_1.default.debug("parameters", parameters);
        // let request = getAcessToken();
        var GUID = parameters.GUID;
        var access_token = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_access_token' });
        var base_uri = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_base_uri' });
        var account_id = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_account_id' });
        var response = https_1.default.request({
            method: https_1.default.Method.GET,
            url: base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID,
            headers: {
                "Authorization": "Bearer" + " " + access_token
            },
        });
        log_1.default.error('requisição', response);
        log_1.default.error('url', base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID);
        var record = record_1.default.load({
            type: "customrecord_lrc_envelopedocusign",
            id: parameters.recordId,
            isDynamic: true
        });
        var bodyobj = JSON.parse(response.body);
        log_1.default.error('objeto', bodyobj);
        record.setValue({
            fieldId: 'custrecord_lrc_status_envelopeducusign',
            value: bodyobj.status
        });
        record.save();
        redirect_1.default.toRecord({
            type: "customrecord_lrc_envelopedocusign",
            id: parameters.recordId
        });
    };
    exports.onRequest = onRequest;
});
