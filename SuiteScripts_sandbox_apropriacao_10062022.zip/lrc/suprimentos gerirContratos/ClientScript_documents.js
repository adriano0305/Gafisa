/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript_documents.ts
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.pageInit = void 0;
    var pageInit = function (ctx) {
        var record = ctx.currentRecord;
        var verifica = record.getValue('custrecord_lrc_verificar_att');
        console.log(verifica);
        console.log(record);
        if (verifica == true) {
            alert("O documento está sendo editado por outra pessoa. Em breve, um script programado irá realizar as mudanças solicitadas.");
        }
    };
    exports.pageInit = pageInit;
});
