/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * User_botoesTelaItem.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        var form = ctx.form;
        var newRecord = ctx.newRecord;
        var GUID = newRecord.getValue('custrecord_lrc_camp_campo');
        log_1.default.error('guid', GUID);
        if (ctx.type == ctx.UserEventType.EDIT) {
            if (GUID) {
                form.addButton({
                    id: "custpage_button",
                    label: "Pré-Visualizar Envelope",
                    functionName: "getRecordIdBotaoPreview"
                });
            }
            form.clientScriptModulePath = "./ClientScript_funcionalidade_botaopreview.js";
        }
    };
    exports.beforeLoad = beforeLoad;
});
