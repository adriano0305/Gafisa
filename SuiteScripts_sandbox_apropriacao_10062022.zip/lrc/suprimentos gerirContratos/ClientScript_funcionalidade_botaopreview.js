/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* TestClientSublist.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url"], function (require, exports, currentRecord_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getRecordIdBotaoPreview = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var getRecordIdBotaoPreview = function () {
        var currentRecord = currentRecord_1.default.get();
        var GUID = currentRecord.getValue('custrecord_lrc_camp_campo');
        var envelopeId = currentRecord.id;
        var url = url_1.default.resolveScript({
            scriptId: 'customscript_lrc_suitelet_botaopreview',
            deploymentId: 'customdeploy_lrc_impl_suitelet_botaoprev',
            params: {
                GUID: GUID,
                envelopeId: envelopeId,
            },
            returnExternalUrl: true
        });
        window.open(url);
    };
    exports.getRecordIdBotaoPreview = getRecordIdBotaoPreview;
});
