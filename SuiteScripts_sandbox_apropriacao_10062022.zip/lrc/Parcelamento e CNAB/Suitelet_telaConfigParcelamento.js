/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_mudaCliente.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/ui/serverWidget"], function (require, exports, search_1, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    search_1 = __importDefault(search_1);
    UI = __importStar(UI);
    var onRequest = function (ctx) {
        var form = UI.createForm({
            title: 'Configuração de Parcelamento'
        });
        var selectDoc = form.addField({
            id: 'custpage_lrc_tipo_doc',
            type: UI.FieldType.SELECT,
            label: 'Tipo de Documento Fiscal (S/ Software Fiscal)',
        });
        selectDoc.addSelectOption({
            value: '',
            text: ''
        });
        search_1.default.create({
            type: 'customrecord_enl_fiscaldocumenttype',
            filters: ['custrecord_enl_sendtofiscal', 'IS', 'F'],
            columns: ['name']
        }).run().each(function (result) {
            selectDoc.addSelectOption({
                value: result.id,
                text: result.getValue('name').toString()
            });
            return true;
        });
        form.addField({
            id: 'custpage_lrc_arrend_parcela',
            type: UI.FieldType.CHECKBOX,
            label: 'Arredondamento na Primeira Parcela'
        });
        var sublist = form.addSublist({
            id: 'custpage_lrc_item',
            type: UI.SublistType.INLINEEDITOR,
            label: 'Itens'
        });
        sublist.addField({
            id: 'custpage_lrc_camp_item',
            type: UI.FieldType.SELECT,
            label: 'Item',
            source: 'item'
        });
        sublist.addField({
            id: 'custpage_lrc_unidade_correcao',
            type: UI.FieldType.SELECT,
            source: 'customrecord_lrc_unidade_correcao',
            label: 'Unidade de Correção'
        });
        form.addButton({
            id: 'button_lrc_salvarConfig',
            label: 'Salvar Configuração',
            functionName: 'salvarConfig'
        });
        form.clientScriptModulePath = "./ClientScript_telaConfigParcelamento.js";
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
});
