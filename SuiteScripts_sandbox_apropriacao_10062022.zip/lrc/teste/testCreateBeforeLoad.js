/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* suitelet_toggleInvoiceStatus.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/record"], function (require, exports, log_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var params = ctx.request.parameters;
            var record = record_1.default.create({
                type: "customrecord_lrc_teste2",
            });
            record.setSublistValue({
                sublistId: "custpage_lrc_test",
                fieldId: "custpage_lrc_pontos",
                line: 0,
                value: 10
            });
            log_1.default.error("sublists", record.getSublists());
        }
    };
});
