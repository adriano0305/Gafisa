/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/file"], function (require, exports, file_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    file_1 = __importDefault(file_1);
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var htmlFile = file_1.default.load({
                id: "5980"
            });
            ctx.response.write({ output: htmlFile.getContents() });
        }
    };
});
