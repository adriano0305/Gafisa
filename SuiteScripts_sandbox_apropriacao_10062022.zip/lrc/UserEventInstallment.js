/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record"], function (require, exports, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = void 0;
    record_1 = __importDefault(record_1);
    exports.afterSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT || ctx.UserEventType.XEDIT) { // Devemos criar a fatura filha relacionada
            if (ctx.type == ctx.UserEventType.CREATE) {
                var isPaid = ctx.newRecord.getValue("custbody_lrc_parcela_paga");
                if (isPaid) {
                    // Se a parcela estiver paga, crie a fatura filha
                    var childInvoice = record_1.default.transform({
                        fromType: "customsale_termos_rsc",
                        fromId: ctx.newRecord.id,
                        toType: record_1.default.Type.INVOICE
                    });
                    childInvoice.setValue({
                        fieldId: "custbody_lrc_parcela_rsc",
                        value: ctx.newRecord.id
                    });
                    childInvoice.setValue({
                        fieldId: "trandate",
                        value: ctx.newRecord.getValue("trandate")
                    });
                    var invoiceId = childInvoice.save();
                    var parcelaRSC = record_1.default.load({
                        type: "customsale_termos_rsc",
                        id: ctx.newRecord.id
                    });
                    parcelaRSC.setValue({
                        fieldId: "custbody_lrc_fatura_filha",
                        value: invoiceId
                    });
                    parcelaRSC.save();
                }
            }
            else {
                if (ctx.newRecord.getValue("custbody_lrc_parcela_paga") != ctx.oldRecord.getValue("custbody_lrc_parcela_paga")) {
                    var isPaid = ctx.newRecord.getValue("custbody_lrc_parcela_paga");
                    if (isPaid) {
                        // Se a parcela estiver paga, crie a fatura filha
                        var childInvoice = record_1.default.transform({
                            fromType: "customsale_termos_rsc",
                            fromId: ctx.newRecord.id,
                            toType: record_1.default.Type.INVOICE
                        });
                        childInvoice.setValue({
                            fieldId: "custbody_lrc_parcela_rsc",
                            value: ctx.newRecord.id
                        });
                        childInvoice.setValue({
                            fieldId: "trandate",
                            value: ctx.newRecord.getValue("trandate")
                        });
                        var invoiceId = childInvoice.save();
                        var parcelaRSC = record_1.default.load({
                            type: "customsale_termos_rsc",
                            id: ctx.newRecord.id
                        });
                        parcelaRSC.setValue({
                            fieldId: "custbody_lrc_fatura_filha",
                            value: invoiceId
                        });
                        parcelaRSC.save();
                    }
                }
            }
        }
    };
});
