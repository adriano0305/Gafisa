/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteLet_mudaCliente.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/file", "N/runtime", "N/log", "N/redirect"], function (require, exports, record_1, file_1, runtime_1, log_1, redirect_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    file_1 = __importDefault(file_1);
    runtime_1 = __importDefault(runtime_1);
    log_1 = __importDefault(log_1);
    redirect_1 = __importDefault(redirect_1);
    var onRequest = function (ctx) {
        var folderId = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_adp_pasta' });
        var parametros = ctx.request.parameters;
        log_1.default.error('content', parametros.content);
        log_1.default.error('name', parametros.nDocto);
        log_1.default.error('Id', parametros.id);
        var arqJSON = file_1.default.create({
            name: parametros.nDocto + '_ADP_exportado.txt',
            fileType: file_1.default.Type.PLAINTEXT,
            contents: parametros.content
        });
        arqJSON.folder = folderId;
        var arqJSONID = arqJSON.save();
        var vendorRecord = record_1.default.load({
            type: 'vendorbill',
            id: parametros.id
        });
        vendorRecord.setValue({
            fieldId: 'custbody_lrc_arquivo_adp',
            value: arqJSONID
        });
        vendorRecord.save({
            ignoreMandatoryFields: true
        });
        redirect_1.default.toRecord({
            type: 'vendorbill',
            id: parametros.id
        });
    };
    exports.onRequest = onRequest;
});
