/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* MapReduce_fluxoEscritura.js
*
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record", "N/log"], function (require, exports, search_1, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    var getInputData = function () {
        return search_1.default.create({
            type: 'customrecord_lrc_log_item',
            filters: [
                ['custrecord_lrc_processado_item', 'IS', 'F']
            ],
            columns: [
                'custrecord_lrc_json_item',
                'custrecord_lrc_tipo_item'
            ]
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var req = JSON.parse(ctx.value);
        log_1.default.error('req', req);
        var tipoItem = req.values['custrecord_lrc_tipo_item'];
        var inputData = JSON.parse(req.values['custrecord_lrc_json_item']);
        var itemId = '';
        var erros = '';
        var itemEstoque;
        var LOGitem = record_1.default.load({
            type: 'customrecord_lrc_log_item',
            id: req.id
        });
        try {
            if (tipoItem == 'inventoryitem') {
                var fieldsCustomer_1 = {
                    "itemid": inputData['itemid'],
                    "upccode": inputData['upccode'],
                    "displayname": inputData['displayname'],
                    "vendorname": inputData['vendorname'],
                    "unitstype": inputData['unitstype'],
                    "stockunit": inputData['stockunit'],
                    "purchaseunit": inputData['purchaseunit'],
                    "saleunit": inputData['saleunit'],
                    "parent": inputData['parent'],
                    "subsidiary": inputData['subsidiary'],
                    "includechildren": inputData['includechildren'],
                    "department": inputData['department'],
                    "class": inputData['class'],
                    "location": inputData['location'],
                    "cogsaccount": inputData['cogsaccount'],
                    "intercocogsaccount": inputData['intercocogsaccount'],
                    "assetaccount": inputData['assetaccount'],
                    "incomeaccount": inputData['incomeaccount'],
                    "intercoincomeaccount": inputData['intercoincomeaccount'],
                    "gainlossaccount": inputData['gainlossaccount'],
                    "billpricevarianceacct": inputData['billpricevarianceacct'],
                    "billqtyvarianceacct": inputData['billqtyvarianceacct'],
                    "billexchratevarianceacct": inputData['billexchratevarianceacct'],
                    "custreturnvarianceaccount": inputData['custreturnvarianceaccount'],
                    "vendreturnvarianceaccount": inputData['vendreturnvarianceaccount'],
                    "dropshipexpenseaccount": inputData['dropshipexpenseaccount'],
                    "taxschedule": inputData['taxschedule'],
                    "custitem_enl_taxorigin": inputData['custitem_enl_taxorigin'],
                    "custitem_enl_ncmitem": inputData['custitem_enl_ncmitem'],
                    "custitem_enl_it_taxgroup": inputData['custitem_enl_it_taxgroup'],
                    "custitem_enl_cest": inputData['custitem_enl_cest'],
                    "custitem_enl_producttype": inputData['custitem_enl_producttype']
                };
                itemEstoque = record_1.default.create({
                    type: record_1.default.Type.INVENTORY_ITEM,
                    isDynamic: false
                });
                Object.keys(fieldsCustomer_1).forEach(function (key) {
                    itemEstoque.setValue({
                        fieldId: key,
                        value: fieldsCustomer_1[key],
                    });
                    log_1.default.error('fieldsCustomer', fieldsCustomer_1[key]);
                });
                var itemId_1 = itemEstoque.save({ ignoreMandatoryFields: true });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_item_item',
                    value: itemId_1
                });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_processado_item',
                    value: true
                });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_log_item_status',
                    value: false
                });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_log_item_saida',
                    value: ''
                });
                LOGitem.save({ ignoreMandatoryFields: true });
            }
        }
        catch (e) {
            erros = e.message;
        }
        try {
            if (tipoItem == 'noninventoryitem') {
                var fieldsCustomer_2 = {
                    "itemid": inputData['itemid'],
                    "displayname": inputData['displayname'],
                    "vendorname": inputData['vendorname'],
                    "unitstype": inputData['unitstype'],
                    "purchaseunit": inputData['purchaseunit'],
                    "subsidiary": inputData['subsidiary'],
                    "includechildren": inputData['includechildren'],
                    "department": inputData['department'],
                    "class": inputData['class'],
                    "location": inputData['location'],
                    "expenseaccount": inputData['expenseaccount'],
                    "currency": inputData['currency'],
                    "billexchratevarianceacct": inputData['billexchratevarianceacct'],
                    "billpricevarianceacct": inputData['billpricevarianceacct'],
                    "billqtyvarianceacct": inputData['billqtyvarianceacct'],
                    "taxschedule": inputData['taxschedule'],
                    "custitem_enl_taxorigin": inputData['custitem_enl_taxorigin'],
                    "custitem_enl_ncmitem": inputData['custitem_enl_ncmitem'],
                    "custitem_enl_it_taxgroup": inputData['custitem_enl_it_taxgroup'],
                    "custitem_enl_cest": inputData['custitem_enl_cest'],
                    "custitem_enl_producttype": inputData['custitem_enl_producttype']
                };
                itemEstoque = record_1.default.create({
                    type: 'noninventoryitem',
                    isDynamic: false
                });
                Object.keys(fieldsCustomer_2).forEach(function (key) {
                    itemEstoque.setValue({
                        fieldId: key,
                        value: fieldsCustomer_2[key],
                    });
                });
                var itemId_2 = itemEstoque.save({ ignoreMandatoryFields: true });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_item_item',
                    value: itemId_2
                });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_processado_item',
                    value: true
                });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_log_item_status',
                    value: false
                });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_log_item_saida',
                    value: ''
                });
                LOGitem.save({ ignoreMandatoryFields: true });
            }
        }
        catch (e) {
            erros = e.message;
        }
        try {
            if (tipoItem == 'serviceitem') {
                var fieldsCustomer_3 = {
                    "itemid": inputData['itemid'],
                    "displayname": inputData['displayname'],
                    "vendorname": inputData['vendorname'],
                    "unitstype": inputData['unitstype'],
                    "purchaseunit": inputData['purchaseunit'],
                    "subsidiary": inputData['subsidiary'],
                    "includechildren": inputData['includechildren'],
                    "department": inputData['department'],
                    "class": inputData['class'],
                    "location": inputData['location'],
                    "expenseaccount": inputData['expenseaccount'],
                    "currency": inputData['currency'],
                    "billexchratevarianceacct": inputData['billexchratevarianceacct'],
                    "billpricevarianceacct": inputData['billpricevarianceacct'],
                    "billqtyvarianceacct": inputData['billqtyvarianceacct'],
                    "taxschedule": inputData['taxschedule'],
                    "custitem_enl_it_taxgroup": inputData['custitem_enl_it_taxgroup'],
                    "custitem_enl_codigodeservico": inputData['custitem_enl_codigodeservico'],
                };
                itemEstoque = record_1.default.create({
                    type: 'serviceitem',
                    isDynamic: false
                });
                Object.keys(fieldsCustomer_3).forEach(function (key) {
                    itemEstoque.setValue({
                        fieldId: key,
                        value: fieldsCustomer_3[key],
                    });
                });
                var itemId_3 = itemEstoque.save({ ignoreMandatoryFields: true });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_item_item',
                    value: itemId_3
                });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_processado_item',
                    value: true
                });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_log_item_status',
                    value: false
                });
                LOGitem.setValue({
                    fieldId: 'custrecord_lrc_log_item_saida',
                    value: ''
                });
                LOGitem.save({ ignoreMandatoryFields: true });
            }
        }
        catch (e) {
            erros = e.message;
        }
        LOGitem.setValue({
            fieldId: 'custrecord_lrc_log_item_saida',
            value: 'Ocorreu o seguinte erro na criação do item: \n' + erros
        });
        LOGitem.setValue({
            fieldId: 'custrecord_lrc_log_item_status',
            value: true
        });
        LOGitem.save({ ignoreMandatoryFields: true });
    };
    exports.map = map;
});
