/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript para botão "CONTA DE PAGAMENTO" no registro de cobrança
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = exports.pageInit = void 0;
    var pageInit = function (ctx) {
        var record = ctx.currentRecord;
        var verificar_metodo = record.getValue({
            fieldId: 'custbody_lrc_vendor_metodo_pagamento',
        });
        ctx.currentRecord.getField({
            fieldId: 'custbody_lrc_vendor_conta_paga'
        }).isDisabled = true;
        if (verificar_metodo == 1) {
            ctx.currentRecord.getField({
                fieldId: 'custbody_lrc_vendor_conta_paga'
            }).isDisabled = false;
        }
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var fieldId = ctx.fieldId;
        var record = ctx.currentRecord;
        var verificar_metodo = record.getValue({
            fieldId: 'custbody_lrc_vendor_metodo_pagamento',
        });
        console.log('verificar', verificar_metodo);
        console.log('fieldid', fieldId);
        if (fieldId == 'custbody_lrc_vendor_metodo_pagamento') {
            if (verificar_metodo == 1) {
                ctx.currentRecord.getField({
                    fieldId: 'custbody_lrc_vendor_conta_paga'
                }).isDisabled = false;
            }
            else {
                ctx.currentRecord.getField({
                    fieldId: 'custbody_lrc_vendor_conta_paga'
                }).isDisabled = true;
            }
        }
    };
    exports.fieldChanged = fieldChanged;
});
