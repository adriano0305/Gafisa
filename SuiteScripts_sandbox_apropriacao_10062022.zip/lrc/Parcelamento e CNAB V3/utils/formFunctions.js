var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget", "N/log"], function (require, exports, UI, Log) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.createFieldsForSearch = exports.createParcelasSublist_list = exports.createParcelasSublist = void 0;
    UI = __importStar(UI);
    Log = __importStar(Log);
    var createParcelasSublist = function (form) {
        var sublistParcelas = form.addSublist({
            id: 'custpage_sublist_parcelas',
            type: UI.SublistType.INLINEEDITOR,
            label: 'Lista de parcelas filtradas'
        });
        sublistParcelas.addField({
            id: 'custpage_campo_status_parcela',
            label: 'Status da parcela',
            type: UI.FieldType.SELECT,
            source: 'customlist_lrc_list_status_aprov'
        });
        sublistParcelas.addField({
            id: 'custpage_campo_contas_pagar',
            label: 'Número do Contas a pagar',
            type: UI.FieldType.SELECT
        });
        sublistParcelas.addField({
            id: 'custpage_campo_numero_parcela',
            label: 'Número da parcela',
            type: UI.FieldType.TEXT,
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        sublistParcelas.addField({
            id: 'custpage_entidade_campo',
            label: 'Entidade',
            type: UI.FieldType.SELECT,
            source: 'customer'
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        sublistParcelas.addField({
            id: 'custpage_campo_base_parcela',
            label: 'Valor base da parcela',
            type: UI.FieldType.CURRENCY
        });
        sublistParcelas.addField({
            id: 'custpage_campo_data_vencimentos',
            label: 'Data do vencimento',
            type: UI.FieldType.DATE,
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        sublistParcelas.addField({
            id: 'custpage_campo_data_pgts',
            label: 'Data do pagamento',
            type: UI.FieldType.DATE,
        });
        sublistParcelas.addField({
            id: 'custpage_campo_metodo_pgts',
            label: 'Método de pagamento',
            type: UI.FieldType.SELECT,
            source: 'customlistlrc_metodos_pagamento'
        });
        sublistParcelas.addField({
            id: 'custpage_campo_conta_pgts',
            label: 'Conta de pagamento',
            type: UI.FieldType.SELECT,
            source: 'customrecord_lrc_reg_contas_bancarias'
        });
        sublistParcelas.addField({
            id: 'custpage_campo_selecionar',
            label: 'Selecionar parcela',
            type: UI.FieldType.CHECKBOX
        });
        sublistParcelas.addButton({
            id: 'custpage_btn_select_all_itens',
            label: 'Selecionar Tudo',
            functionName: 'selecionarTudo'
        });
        return form;
    };
    exports.createParcelasSublist = createParcelasSublist;
    var createParcelasSublist_list = function (form) {
        var sublistParcelas = form.addSublist({
            id: 'custpage_sublist_parcelas',
            type: UI.SublistType.LIST,
            label: 'Lista de parcelas filtradas'
        });
        sublistParcelas.addField({
            id: 'custpage_campo_status_parcela',
            label: 'Status da parcela',
            type: UI.FieldType.SELECT,
            source: 'customlist_lrc_list_status_aprov'
        });
        sublistParcelas.addField({
            id: 'custpage_campo_contas_pagar',
            label: 'Número do Contas a pagar',
            type: UI.FieldType.SELECT
        });
        sublistParcelas.addField({
            id: 'custpage_campo_numero_parcela',
            label: 'Número da parcela',
            type: UI.FieldType.TEXT,
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        sublistParcelas.addField({
            id: 'custpage_entidade_campo',
            label: 'Entidade',
            type: UI.FieldType.SELECT,
            source: 'customer'
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        sublistParcelas.addField({
            id: 'custpage_campo_base_parcela',
            label: 'Valor base da parcela',
            type: UI.FieldType.CURRENCY
        });
        sublistParcelas.addField({
            id: 'custpage_campo_data_vencimentos',
            label: 'Data do vencimento',
            type: UI.FieldType.DATE,
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        sublistParcelas.addField({
            id: 'custpage_campo_data_pgts',
            label: 'Data do pagamento',
            type: UI.FieldType.DATE,
        });
        sublistParcelas.addField({
            id: 'custpage_campo_metodo_pgts',
            label: 'Método de pagamento',
            type: UI.FieldType.SELECT,
            source: 'customlistlrc_metodos_pagamento'
        });
        sublistParcelas.addField({
            id: 'custpage_campo_conta_pgts',
            label: 'Conta de pagamento',
            type: UI.FieldType.SELECT,
            source: 'customrecord_lrc_reg_contas_bancarias'
        });
        sublistParcelas.addField({
            id: 'custpage_campo_selecionar',
            label: 'Selecionar parcela',
            type: UI.FieldType.CHECKBOX
        });
        sublistParcelas.addButton({
            id: 'custpage_btn_select_all_itens',
            label: 'Selecionar Tudo',
            functionName: 'selecionarTudo'
        });
        return form;
    };
    exports.createParcelasSublist_list = createParcelasSublist_list;
    var createFieldsForSearch = function (form) {
        var isArqCnab = Boolean(form.getField({ id: 'custpage_campo_is_arq_cnab' })) || false;
        Log.error('form', form);
        Log.error('isArqCnab', isArqCnab);
        form.addField({
            id: 'custpage_campo_subsidiaria',
            label: 'Subsidiária',
            type: UI.FieldType.SELECT,
            source: 'subsidiary',
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_localidade',
            label: 'Localidade',
            type: UI.FieldType.SELECT,
            source: 'location',
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_statusparcela',
            label: 'Status de aprovação da parcela',
            type: UI.FieldType.SELECT,
            source: 'customlist_lrc_list_status_aprov',
            container: 'custpage_fieldgroup_filtros'
        }).updateDisplayType({ displayType: isArqCnab ? UI.FieldDisplayType.HIDDEN : UI.FieldDisplayType.NORMAL });
        form.addField({
            id: 'custpage_campo_contapgt',
            label: 'Conta do pagamento',
            type: UI.FieldType.SELECT,
            source: 'customrecord_lrc_reg_contas_bancarias',
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_metodopgt',
            label: 'Método de pagamento',
            source: 'customlistlrc_metodos_pagamento',
            type: UI.FieldType.SELECT,
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_vencimentode',
            label: 'Data de vencimento de',
            type: UI.FieldType.DATE,
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_vencimentoate',
            label: 'Data de vencimento até',
            type: UI.FieldType.DATE,
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_pagamentode',
            label: 'Data de pagamento de',
            type: UI.FieldType.DATE,
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_pagamentoate',
            label: 'Data de pagamento até',
            type: UI.FieldType.DATE,
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_departamento',
            label: 'Departamento',
            type: UI.FieldType.SELECT,
            source: 'department',
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_centrodecusto',
            label: 'Centro de custo',
            type: UI.FieldType.SELECT,
            source: 'classification',
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_numerodoc',
            label: 'Número do documento',
            type: UI.FieldType.TEXT,
            container: 'custpage_fieldgroup_filtros'
        });
        form.addField({
            id: 'custpage_campo_entidades',
            label: 'Entidade',
            type: UI.FieldType.SELECT,
            source: 'vendor',
            container: 'custpage_fieldgroup_filtros'
        });
        return form;
    };
    exports.createFieldsForSearch = createFieldsForSearch;
});
