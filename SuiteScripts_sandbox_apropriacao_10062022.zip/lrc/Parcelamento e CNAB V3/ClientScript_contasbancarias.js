/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript_contasbancarias.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = exports.pageInit = void 0;
    log_1 = __importDefault(log_1);
    var pageInit = function (ctx) {
        var record = ctx.currentRecord;
        var contaPropria = record.getValue('custrecord_lrc_camp_conta_propria');
        log_1.default.error('checkbox', contaPropria);
        if (contaPropria == true) {
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_campo_localidade'
            }).isDisabled = false;
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_campo_conta_contabil'
            }).isDisabled = false;
            ctx.currentRecord.getField({
                fieldId: 'custrecordlrc_campo_forn'
            }).isDisabled = true;
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_campo_cliente'
            }).isDisabled = true;
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_campo_funci'
            }).isDisabled = true;
        }
        else {
            log_1.default.error('else', 'fieldchanged');
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_campo_localidade'
            }).isDisabled = true;
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_campo_conta_contabil'
            }).isDisabled = true;
            ctx.currentRecord.getField({
                fieldId: 'custrecordlrc_campo_forn'
            }).isDisabled = false;
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_campo_cliente'
            }).isDisabled = false;
            ctx.currentRecord.getField({
                fieldId: 'custrecord_lrc_campo_funci'
            }).isDisabled = false;
        }
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var fieldId = ctx.fieldId;
        var record = ctx.currentRecord;
        var contaPropria = record.getValue('custrecord_lrc_camp_conta_propria');
        log_1.default.error('checkbox', contaPropria);
        if (fieldId == 'custrecord_lrc_camp_conta_propria') {
            console.log(contaPropria);
            if (contaPropria == true) {
                log_1.default.error('if', 'fieldchanged');
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_localidade'
                }).isDisabled = false;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_conta_contabil'
                }).isDisabled = false;
                ctx.currentRecord.getField({
                    fieldId: 'custrecordlrc_campo_forn'
                }).isDisabled = true;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_cliente'
                }).isDisabled = true;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_funci'
                }).isDisabled = true;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_localidade'
                }).isMandatory = true;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_conta_contabil'
                }).isMandatory = true;
            }
            else {
                log_1.default.error('else', 'fieldchanged');
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_localidade'
                }).isDisabled = true;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_conta_contabil'
                }).isDisabled = true;
                ctx.currentRecord.getField({
                    fieldId: 'custrecordlrc_campo_forn'
                }).isDisabled = false;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_cliente'
                }).isDisabled = false;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_funci'
                }).isDisabled = false;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_localidade'
                }).isMandatory = false;
                ctx.currentRecord.getField({
                    fieldId: 'custrecord_lrc_campo_conta_contabil'
                }).isMandatory = false;
            }
        }
    };
    exports.fieldChanged = fieldChanged;
});
