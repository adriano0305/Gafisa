/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 *
 *  UserEvent_valor_registro.ts
 *
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        // const parametros = ctx.request.parameters;
        // const chaveDeacesso = parametros.chaveDeacesso
        // const record = ctx.newRecord;
        // const form=ctx.form;
        // Log.error("chaveDeacesso 01", chaveDeacesso)
        // if(chaveDeacesso)
        // {
        //     record.setValue({ 
        //                 fieldId: 'custbody_enl_accesskey',
        //                 value: String(chaveDeacesso)
        //             });
        // } 
        //     Log.error("chaveDeacesso 02", chaveDeacesso)
        //     try{
        //         form.getField({
        //             id: 'custbody_enl_accesskey',
        //         }).defaultValue=chaveDeacesso.toString()
        //     }catch (e)
        //     {
        //         Log.error('e',e)
        //     }
    };
    exports.beforeLoad = beforeLoad;
});
