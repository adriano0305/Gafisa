/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 *
 *  UserEvent_transacao_cobranca
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/redirect", "N/log"], function (require, exports, search_1, redirect_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    search_1 = __importDefault(search_1);
    redirect_1 = __importDefault(redirect_1);
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        var record = ctx.newRecord;
        var numero_pedido = record.getValue('custbody16');
        var numero_chave = record.getValue('custbody_enl_accesskey');
        log_1.default.error('id', record.getValue('id'));
        // let cont=0;
        // if(ctx.type == ctx.UserEventType.EDIT)
        // {
        if (numero_pedido && !numero_chave) // Verifica se há numero de pedido e se não há chave
         {
            //Faz uma pesquisa no registro List NF-e
            var idcob = record.getValue('id');
            var searchNumero = search_1.default.create({
                type: 'customrecord_lrc_nf',
                filters: [
                    ['custrecord_lrc_num_nfe', 'IS', numero_pedido]
                ],
                columns: [
                    'internalid',
                    'custrecord_lrc_chave_acesso',
                    'custrecord_lrc_num_nfe',
                    'custrecord_lrc_xped'
                ]
            }).run().getRange({
                start: 0,
                end: 10
            });
            if (searchNumero.length > 1) {
                redirect_1.default.redirect({
                    url: '/app/site/hosting/scriptlet.nl?script=1209&deploy=1',
                    parameters: {
                        'list_nfe': JSON.stringify(searchNumero),
                        'id_cobranca': idcob
                    }
                });
            }
            else {
                log_1.default.error("resultadoPesquisa 04", searchNumero);
                //Se encontrar algum resultado ele seta o valor na chave de acesso no registro de cobrança
                var lookupf = search_1.default.lookupFields({
                    type: 'customrecord_lrc_nf',
                    id: searchNumero[0].getValue('internalid'),
                    columns: [
                        'custrecord_lrc_chave_acesso'
                    ]
                });
                record.setValue({
                    fieldId: 'custbody_enl_accesskey',
                    value: String(lookupf.custrecord_lrc_chave_acesso)
                });
                record.save();
            }
        }
    };
    exports.beforeLoad = beforeLoad;
});
