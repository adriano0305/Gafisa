/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* MapReduce_getXmlNfe.js
*
* MapReduce reponsável por obter os XMLs das NFE's da api da Avalara
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/https", "N/search", "N/record", "N/log", "N/runtime"], function (require, exports, https_1, search_1, record_1, log_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    https_1 = __importDefault(https_1);
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    runtime_1 = __importDefault(runtime_1);
    var getInputData = function () {
        //Busca os registros que não possuem o xml
        return search_1.default.create({
            type: 'customrecord_lrc_nf',
            filters: [
                ['custrecord_lrc_xml_nfe', 'IS', '']
            ],
            columns: [
                'custrecord_lrc_xml_nfe',
                'custrecord_lrc_chave_acesso'
            ]
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var nfe = JSON.parse(ctx.value);
        log_1.default.error("nfe", nfe.values.custrecord_lrc_chave_acesso);
        //Chamada da api 
        var urlget = 'https://api-taxdocs-external.avalarabrasil.com.br/api/v1/NFE/' + nfe.values.custrecord_lrc_chave_acesso + '';
        var response2 = https_1.default.get({
            headers: getbearer(),
            url: urlget,
        });
        log_1.default.error("xmlresponse", response2.body);
        log_1.default.error("xmlresponse2", atob(response2.body));
        //Conversão base64 para string
        var xmlresponse = JSON.parse(atob(response2.body));
        var nfe_att = record_1.default.load({
            id: nfe.internalid,
            type: "customrecord_lrc_nf"
        });
        nfe_att.setValue({
            fieldId: 'custrecord_lrc_xml_nfe',
            value: xmlresponse.xml
        });
        nfe_att.setValue({
            fieldId: '	custrecord_lrc_xped',
            value: xmlresponse.xped
        });
        nfe_att.save({ ignoreMandatoryFields: true });
    };
    exports.map = map;
    var getbearer = function () {
        //credenciais
        var jsoncrend = {
            "grant_type": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptgrant_type'
            }),
            "client_id": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptclient_id'
            }),
            "username": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptusername'
            }),
            "password": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptpassword'
            }),
            "client_secret": runtime_1.default.getCurrentScript().getParameter({
                name: 'custscriptclient_secret'
            })
        };
        var response = https_1.default.post({
            body: JSON.stringify(jsoncrend),
            url: 'https://api-gateway.avalarabrasil.com.br/oauth/token',
            headers: { "Content-Type": "application/json" }
        });
        var objResponse = JSON.parse(response.body);
        var bearer_resp = objResponse.access_token;
        //Log.error("bearer_resp", bearer_resp);
        return { Authorization: "Bearer " + bearer_resp + "" };
    };
});
