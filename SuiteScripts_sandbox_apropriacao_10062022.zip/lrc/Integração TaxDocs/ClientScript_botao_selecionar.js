/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 *
 * ClientScript_botao_selecionar.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url"], function (require, exports, currentRecord_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.selecionar = exports.fieldChanged = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    var pageInit = function (ctx) { };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var currRecord = ctx.currentRecord;
        var fieldId = ctx.fieldId;
        var sublistId = ctx.sublistId;
        if (sublistId == "custpage_lrc_nf" && fieldId == "custpage_lrc_check") {
            var num_lines = currRecord.getLineCount({ sublistId: "custpage_lrc_nf" });
            for (var line = 0; line < num_lines; line++) {
                console.log('ctx.line', ctx.line);
                console.log('line', line);
                if (ctx.line == line) {
                    console.log('T');
                    currRecord.selectLine({
                        line: line,
                        sublistId: "custpage_lrc_nf"
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: "custpage_lrc_check",
                        sublistId: "custpage_lrc_nf",
                        value: true,
                        ignoreFieldChange: true
                    });
                    if (line != num_lines - 1) {
                        currRecord.commitLine({
                            sublistId: "custpage_lrc_nf"
                        });
                    }
                }
                else {
                    console.log('F');
                    currRecord.selectLine({
                        line: line,
                        sublistId: "custpage_lrc_nf"
                    });
                    currRecord.setCurrentSublistValue({
                        fieldId: "custpage_lrc_check",
                        sublistId: "custpage_lrc_nf",
                        value: false,
                        ignoreFieldChange: true
                    });
                    if (line != num_lines - 1) {
                        currRecord.commitLine({
                            sublistId: "custpage_lrc_nf",
                        });
                    }
                }
            }
        }
    };
    exports.fieldChanged = fieldChanged;
    var selecionar = function () {
        var currRecord = currentRecord_1.default.get();
        var idCobranca = String(currRecord.getValue('custpage_lrc_invisivel'));
        console.log("ID:", idCobranca);
        var num_lines = currRecord.getLineCount({ sublistId: "custpage_lrc_nf" });
        console.log("Num_line: ", num_lines);
        for (var i = 0; i < num_lines; i++) {
            currRecord.selectLine({
                line: i,
                sublistId: "custpage_lrc_nf"
            });
            var currCheckBoxValue = currRecord.getCurrentSublistValue({
                fieldId: 'custpage_lrc_check',
                sublistId: 'custpage_lrc_nf'
            });
            console.log("currCheckBoxValue 01", currCheckBoxValue);
            if (currCheckBoxValue) {
                var chaveDeacesso = currRecord.getSublistValue({
                    sublistId: 'custpage_lrc_nf',
                    line: i,
                    fieldId: 'custpage_lrc_chave_acesso'
                });
                console.log("currCheckBoxValue 02", currCheckBoxValue);
                console.log("chaveDeAcesso: ", chaveDeacesso);
                var url = url_1.default.resolveRecord({
                    recordId: idCobranca,
                    isEditMode: true,
                    recordType: 'vendorbill',
                    params: {
                        chaveDeacesso: chaveDeacesso
                    }
                });
                window.open(url, "_blank");
            }
        }
    };
    exports.selecionar = selecionar;
});
