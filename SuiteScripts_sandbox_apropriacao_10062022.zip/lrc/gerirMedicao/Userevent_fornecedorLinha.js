/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEventReturnAuth.ts
 *
 *
 *
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log", "N/search"], function (require, exports, record_1, log_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    exports.afterSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.DELETE) {
            var oldRecord = ctx.oldRecord;
            var avaliacaoId = oldRecord.getValue('custrecord_lrc_avaliacao_forncedor');
            var criterioId = oldRecord.getValue("custrecord_lrc_criterio");
            log_1.default.error("avaliacaoId", avaliacaoId);
            log_1.default.error("criterioId", criterioId);
            if (avaliacaoId && criterioId) {
                var criterioLookup = search_1.default.lookupFields({
                    type: "customrecord_lrc_criterio",
                    id: criterioId.toString(),
                    columns: [
                        "custrecord_lrc_peso_criterio"
                    ]
                });
                log_1.default.error("criterioLookup", criterioLookup);
                var avaliacaoLookup = search_1.default.lookupFields({
                    type: "customrecord_lrc_avaliacao_fornecedores",
                    id: avaliacaoId.toString(),
                    columns: [
                        "custrecord_lrc_campo_total_avaliacao"
                    ]
                });
                log_1.default.error("avaliacaoLookup", avaliacaoLookup);
                var totalPontos = Number(avaliacaoLookup["custrecord_lrc_campo_total_avaliacao"]);
                log_1.default.error("totalPontos", totalPontos);
                var pesoCriterio = Number(criterioLookup["custrecord_lrc_peso_criterio"]);
                log_1.default.error("pesoCriterio", pesoCriterio);
                var avaliacao = Number(oldRecord.getValue("custrecord_lrc_avaliacao"));
                log_1.default.error("avaliacao", avaliacao);
                var pontos = totalPontos - (pesoCriterio * avaliacao) / 100;
                log_1.default.error("pontos", pontos);
                record_1.default.submitFields({
                    type: "customrecord_lrc_avaliacao_fornecedores",
                    id: avaliacaoId.toString(),
                    values: {
                        "custrecord_lrc_campo_total_avaliacao": pontos
                    },
                    options: {
                        enableSourcing: false,
                        ignoreMandatoryFields: true
                    }
                });
            }
        }
    };
});
