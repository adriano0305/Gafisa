/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * checarValorCaucao.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateField = exports.fieldChanged = void 0;
    log_1 = __importDefault(log_1);
    exports.fieldChanged = function (ctx) {
        // ctx.field -> é o campo que causou o gatilho no fieldChanged 
        log_1.default.error("ctx", ctx);
        if (ctx.fieldId == "custbody_lrc_retencao_caucao" && !ctx.sublistId) {
            var record = ctx.currentRecord;
            var valorCaucao = record.getField({
                fieldId: 'custbody_lrc_valor_caucao'
            });
            var retencaoCaucao = record.getValue("custbody_lrc_retencao_caucao");
            log_1.default.error("retencaoCaucao", retencaoCaucao);
            valorCaucao.isDisabled = retencaoCaucao ? false : true;
            log_1.default.error("isDisabled", valorCaucao.isDisabled);
        }
    };
    exports.validateField = function (ctx) {
        var fieldId = ctx.fieldId;
        var sublistId = ctx.sublistId;
        var currRecord = ctx.currentRecord;
        if (fieldId == "custbody_lrc_valor_caucao" && !sublistId) {
            var valorCaucao = Number(currRecord.getValue("custbody_lrc_valor_caucao"));
            if (valorCaucao < 0 || valorCaucao > 100) {
                alert('O campo "VALOR DO CAUÇÃO EM % está fora do intervalo [0,100]');
                return false;
            }
        }
        return true;
    };
});
