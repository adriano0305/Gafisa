/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript_btn_posicaoFinanceira.ts
* CS responsável pela busca de registros para renderização do html/pdf
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/url"], function (require, exports, currentRecord_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ImprimirPosicaoFinanceira = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    // Implementação obrigatória
    var pageInit = function () { };
    exports.pageInit = pageInit;
    // Função para executar o relatório
    var ImprimirPosicaoFinanceira = function () {
        try {
            var rec = currentRecord_1.default.get(), url = url_1.default.resolveScript({
                deploymentId: 'customdeploy_lrc_imprimir_posicao',
                scriptId: 'customscript_lrc_imprimir_posicao',
                params: {
                    idFatura: rec.id
                }
            });
            console.log("rec.id " + rec.id);
            window.open(url);
        }
        catch (error) {
            alert('Erro ao gerar a posição financeira!');
            console.log('Erro ao gerar a posição financeira! ' + error);
        }
    };
    exports.ImprimirPosicaoFinanceira = ImprimirPosicaoFinanceira;
});
