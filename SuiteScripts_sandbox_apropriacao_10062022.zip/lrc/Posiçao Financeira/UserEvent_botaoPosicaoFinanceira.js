/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 *
 *  UserEvent_transacao_cobranca
 *  UE responsável pela inserção do botão de impressão de posição financeira
 *  no registro de contrato (invoice)
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        // Carrega o form do contexto
        var form = ctx.form;
        //Insere o botão
        var record = ctx.newRecord;
        form.addButton({
            id: "custpage_imprimir_posicao_financeira",
            label: "Imprimir posição financeira",
            functionName: "ImprimirPosicaoFinanceira"
        });
        // Define o arquivo de script que deve executar a geração do relatório
        form.clientScriptModulePath = "./ClientScript_btn_posicaoFinanceira.js";
    };
    exports.beforeLoad = beforeLoad;
});
