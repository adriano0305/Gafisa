/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* Userevent no registro de modelo de projeto (projecttemplate) para funcionamento da criação do modelo de requisição
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log", "N/record", "N/ui/serverWidget"], function (require, exports, search_1, log_1, record_1, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = exports.beforeLoad = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    UI = __importStar(UI);
    var beforeLoad = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE) {
            ctx.newRecord.setValue({
                fieldId: 'custentity_rsc_id_modelo_projeto',
                value: ctx.newRecord.id
            });
            ctx.newRecord.save({
                ignoreMandatoryFields: true
            });
        }
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.XEDIT || ctx.type == ctx.UserEventType.VIEW || ctx.type == ctx.UserEventType.EDIT) {
            ctx.form.addTab({
                id: 'custpage_subtab_requisicoes',
                label: 'Modelo de Requisições'
            });
            var modelosReqSublist_1 = ctx.form.addSublist({
                id: 'custpage_modelos_req',
                label: 'Modelos de Requisição',
                type: UI.SublistType.LIST,
                tab: 'custpage_subtab_requisicoes'
            });
            //função se encontra em ClientScript_criacaoModeloRequisicao
            ctx.form.addButton({
                id: 'custpage_btn_criar_req',
                label: 'Criar Modelo de Requisição',
                functionName: 'abrirInterfaceCriacaoModeloRequisicao',
            });
            modelosReqSublist_1.addField({
                id: 'custpage_data',
                label: 'Data',
                type: UI.FieldType.DATE,
            });
            modelosReqSublist_1.addField({
                id: 'custpage_tipo',
                label: 'Tipo',
                type: UI.FieldType.TEXT,
            });
            modelosReqSublist_1.addField({
                id: 'custpage_tarefa_relacionada',
                label: 'Tarefa relacionada',
                type: UI.FieldType.SELECT,
                source: 'projecttask'
            });
            modelosReqSublist_1.addField({
                id: 'custpage_item',
                label: 'Item',
                type: UI.FieldType.SELECT,
                source: 'noninventoryitem'
            });
            modelosReqSublist_1.addField({
                id: 'custpage_quantidade',
                label: 'Quantidade',
                type: UI.FieldType.INTEGER,
            });
            modelosReqSublist_1.addField({
                id: 'custpage_valor',
                label: 'Valor',
                type: UI.FieldType.CURRENCY,
            });
            modelosReqSublist_1.addField({
                id: 'custpage_num_document',
                label: 'Número Documento',
                type: UI.FieldType.SELECT,
                source: 'purchaserequisition'
            });
            modelosReqSublist_1.addField({
                id: 'custpage_fornecedor',
                label: 'Fornecedor',
                type: UI.FieldType.SELECT,
                source: 'vendor'
            });
            modelosReqSublist_1.addField({
                id: 'custpage_unidades',
                label: 'Unidades',
                type: UI.FieldType.SELECT,
                // source: 'string'
            });
            modelosReqSublist_1.addField({
                id: 'custpage_descricao',
                label: 'Descrição',
                type: UI.FieldType.TEXTAREA,
            });
            modelosReqSublist_1.addField({
                id: 'custpage_taxa_estimada',
                label: 'Taxa Estimada',
                type: UI.FieldType.PERCENT,
            });
            modelosReqSublist_1.addField({
                id: 'custpage_param_requi',
                label: 'Parametro de requisição',
                type: UI.FieldType.SELECT,
                source: 'customrecord_lrc_param_req_mod_projeto'
            }).updateDisplayType({
                displayType: UI.FieldDisplayType.HIDDEN
            });
            var lineCount_1 = 0;
            if (ctx.type == ctx.UserEventType.XEDIT || ctx.type == ctx.UserEventType.VIEW || ctx.type == ctx.UserEventType.EDIT) {
                search_1.default.create({
                    type: 'customrecord_lrc_param_req_mod_projeto',
                    filters: ['custrecord_lrc_mod_proj', search_1.default.Operator.IS, ctx.newRecord.id],
                    columns: [
                        'custrecord_lrc_mod_proj_subsidiaria',
                        'custrecord_lrc_mod_proj_solicitante',
                        'custrecord_lrc_mod_proj_data',
                        'custrecord_lrc_mod_proj',
                        'custrecord_lrc_mod_proj_data_entrega',
                        'custrecord_lrc_taf_proj_relacionada',
                        'custrecord_lrc_sublist_itens_data',
                        'custrecord_lrc_num_document', // Num documento
                    ]
                }).run().each(function (paramReq) {
                    var item = JSON.parse(paramReq.getValue('custrecord_lrc_sublist_itens_data'));
                    for (var i = 0; i < item.length; i++) {
                        if (paramReq.getValue('custrecord_lrc_taf_proj_relacionada')) {
                            modelosReqSublist_1.setSublistValue({
                                id: 'custpage_tarefa_relacionada',
                                line: lineCount_1,
                                value: String(paramReq.getValue('custrecord_lrc_taf_proj_relacionada'))
                            });
                        }
                        modelosReqSublist_1.setSublistValue({
                            line: lineCount_1,
                            id: 'custpage_tipo',
                            value: 'Requisição'
                        });
                        modelosReqSublist_1.setSublistValue({
                            line: lineCount_1,
                            id: 'custpage_param_requi',
                            value: paramReq.id
                        });
                        if (paramReq.getValue('custrecord_lrc_mod_proj_data')) {
                            modelosReqSublist_1.setSublistValue({
                                id: 'custpage_data',
                                line: lineCount_1,
                                value: String(paramReq.getValue('custrecord_lrc_mod_proj_data'))
                            });
                        }
                        log_1.default.error('item atual for', item[i]);
                        modelosReqSublist_1.setSublistValue({
                            line: lineCount_1,
                            id: 'custpage_item',
                            value: item[i].item
                        });
                        modelosReqSublist_1.setSublistValue({
                            line: lineCount_1,
                            id: 'custpage_quantidade',
                            value: String(item[i].quantidade) || ""
                        });
                        modelosReqSublist_1.setSublistValue({
                            line: lineCount_1,
                            id: 'custpage_valor',
                            value: String((item[i].taxaEstimada * item[i].quantidade)) || ""
                        });
                        if (item[i].fornecedor) {
                            modelosReqSublist_1.setSublistValue({
                                id: 'custpage_fornecedor',
                                line: lineCount_1,
                                value: String(item[i].fornecedor) || ""
                            });
                        }
                        if (item[i].unidades) {
                            modelosReqSublist_1.setSublistValue({
                                id: 'custpage_unidades',
                                line: lineCount_1,
                                value: String(item[i].unidades) || ""
                            });
                        }
                        if (item[i].descricao) {
                            modelosReqSublist_1.setSublistValue({
                                id: 'custpage_descricao',
                                line: lineCount_1,
                                value: String(item[i].descricao) || ""
                            });
                        }
                        if (item[i].taxaEstimada) {
                            modelosReqSublist_1.setSublistValue({
                                id: 'custpage_taxa_estimada',
                                line: lineCount_1,
                                value: String(item[i].taxaEstimada) || ""
                            });
                        }
                        if (paramReq.getValue('custrecord_lrc_num_document')) {
                            modelosReqSublist_1.setSublistValue({
                                line: lineCount_1,
                                id: 'custpage_num_document',
                                value: String(paramReq.getValue('custrecord_lrc_num_document')) || ""
                            });
                        }
                        lineCount_1++;
                    }
                    return true;
                });
            }
            ctx.form.clientScriptModulePath = './Clientscript_criacaoModeloRequisicao.js';
        }
    };
    exports.beforeLoad = beforeLoad;
    var afterSubmit = function (ctx) {
        // Verifica se o campo "Criar Requisições Junto ao Modelo" está selecionado
        // if (ctx.newRecord.getValue('custentity_lrc_criar_req_junto_projeto')) {
        //     Search.create({
        //         type: "customrecord_lrc_param_req_mod_projeto",
        //         filters: [
        //             ["custrecord_lrc_num_document","ISEMPTY", ""],
        //             'AND',
        //             ['custrecord_lrc_mod_proj', 'IS', ctx.newRecord.getValue('id')]
        //         ],
        //         columns: [
        //             'custrecord_lrc_mod_proj_subsidiaria', // Subsidiaria
        //             'custrecord_lrc_mod_proj_solicitante', // Solicitante
        //             'custrecord_lrc_mod_proj_data_entrega', // Data entrega
        //             'custrecord_lrc_mod_proj_valor_total', // Valor total
        //             'custrecord_lrc_sublist_itens_data', // Sublista de itens
        //             'custrecord_lrc_mod_proj_data', // Data criação registro
        //             'custrecord_lrc_mod_proj' // Modelo projeto
        //         ]
        //     }).run().each((paramModeloRequisicao: { id: any; getValue: (arg0: string) => any; }) => {
        //         const paramModeloRequisicaoId = paramModeloRequisicao.id;
        //         let requisicoesCompra: CriarRequisicao.RequisicaoCompra[] = [];
        //         let requisicaoCompra: CriarRequisicao.RequisicaoCompra = {
        //             subsidiaria: String(paramModeloRequisicao.getValue('custrecord_lrc_mod_proj_subsidiaria')),
        //             solicitante: String(paramModeloRequisicao.getValue('custrecord_lrc_mod_proj_solicitante')),
        //             data: String(paramModeloRequisicao.getValue('custrecord_lrc_mod_proj_data')),
        //             modeloProjeto: String(paramModeloRequisicao.getValue('custrecord_lrc_mod_proj')),
        //             dataEntrega: String(paramModeloRequisicao.getValue('custrecord_lrc_mod_proj_data_entrega')),
        //             numeroDocumento: String(paramModeloRequisicao.getValue('custrecord_lrc_num_document')),
        //             valorTotal: Number(paramModeloRequisicao.getValue('custrecord_lrc_mod_proj_valor_total')),
        //             itens: JSON.parse(String(paramModeloRequisicao.getValue('custrecord_lrc_sublist_itens_data')))
        //         };
        //         requisicoesCompra.push(requisicaoCompra);
        //         const createdRequisicaoCompraId = CriarRequisicao.criarRequisicao(requisicoesCompra);
        //         const paramModeloReqRecord = Record.load({
        //             type: 'customrecord_lrc_param_req_mod_projeto',
        //             id: paramModeloRequisicaoId
        //         });
        //         paramModeloReqRecord.setValue({
        //             fieldId: 'custrecord_lrc_num_document',
        //             value: String(createdRequisicaoCompraId[0])
        //         });
        //         paramModeloReqRecord.save();
        //         return true;
        //     });
        // }
        var newRecord = ctx.newRecord;
        var linhas = newRecord.getLineCount({ sublistId: 'custpage_modelos_req' });
        var objInicial = {};
        for (var i = 0; i < linhas; i++) {
            var parametroModelo = newRecord.getSublistValue({
                sublistId: 'custpage_modelos_req',
                fieldId: 'custpage_param_requi',
                line: i
            });
            var data = newRecord.getSublistValue({
                fieldId: 'custpage_data',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            data = data.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            var date = new Date(data);
            log_1.default.error('data', data);
            log_1.default.error('data New', date);
            var tarefa = newRecord.getSublistValue({
                fieldId: 'custpage_tarefa_relacionada',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            var item = newRecord.getSublistValue({
                fieldId: 'custpage_item',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            var quantidade = newRecord.getSublistValue({
                fieldId: 'custpage_quantidade',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            var valor = newRecord.getSublistValue({
                fieldId: 'custpage_valor',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            var numero = newRecord.getSublistValue({
                fieldId: 'custpage_num_document',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            var taxa = newRecord.getSublistValue({
                fieldId: 'custpage_taxa_estimada',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            var fornecedor = newRecord.getSublistValue({
                fieldId: 'custpage_fornecedor',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            var descricao = newRecord.getSublistValue({
                fieldId: 'custpage_descricao',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            var unidades = newRecord.getSublistValue({
                fieldId: 'custpage_unidades',
                sublistId: 'custpage_modelos_req',
                line: i
            });
            var objSublista = {};
            objSublista['data'] = date || "";
            objSublista['tarefa'] = tarefa || "";
            objSublista['numeroDoc'] = numero || "";
            objSublista['item'] = item || "";
            objSublista['quantidade'] = quantidade || "";
            objSublista['fornecedor'] = fornecedor || "";
            objSublista['unidades'] = unidades || "";
            objSublista['descricao'] = descricao || "";
            objSublista['taxaEstimada'] = taxa || "";
            objSublista['valorEstimado'] = valor || "";
            var arrayObjInicial = objInicial[parametroModelo.toString()];
            if (arrayObjInicial) {
                arrayObjInicial.push(objSublista);
            }
            else {
                objInicial[parametroModelo.toString()] = [objSublista];
            }
        }
        Object.keys(objInicial).forEach(function (key) {
            var array = objInicial[key];
            var parametroRecord = record_1.default.load({
                id: key,
                type: 'customrecord_lrc_param_req_mod_projeto'
            });
            parametroRecord.setValue({
                fieldId: 'custrecord_lrc_mod_proj_data',
                value: array[0].data
            });
            parametroRecord.setValue({
                fieldId: 'custrecord_lrc_taf_proj_relacionada',
                value: array[0].tarefa
            });
            parametroRecord.setValue({
                fieldId: 'custrecord_lrc_num_document',
                value: array[0].numeroDoc
            });
            var arrayDadosItens = [];
            log_1.default.error('array lenght', array.length);
            for (var i = 0; i < array.length; i++) {
                log_1.default.error('array atual', array[i]);
                var objDadosItens = {};
                objDadosItens['item'] = array[i].item;
                objDadosItens['quantidade'] = array[i].quantidade;
                objDadosItens['fornecedor'] = array[i].fornecedor;
                objDadosItens['unidades'] = array[i].unidades;
                objDadosItens['descricao'] = array[i].descricao;
                objDadosItens['taxaEstimada'] = array[i].taxaEstimada;
                objDadosItens['valorEstimado'] = array[i].valorEstimado;
                arrayDadosItens.push(objDadosItens);
            }
            parametroRecord.setValue({
                fieldId: 'custrecord_lrc_sublist_itens_data',
                value: JSON.stringify(arrayDadosItens)
            });
            parametroRecord.save({
                ignoreMandatoryFields: true
            });
        });
    };
    exports.afterSubmit = afterSubmit;
});
