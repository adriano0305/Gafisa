/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
*
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/record"], function (require, exports, log_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    var beforeLoad = function (ctx) {
        var newRecord = ctx.newRecord;
        var requisicaoID = newRecord.getSublistValue({
            fieldId: 'custcol_appliedprid_cc',
            line: 0,
            sublistId: 'item'
        });
        log_1.default.error('requisicaoID', requisicaoID);
        if (requisicaoID) {
            var reqRecord = record_1.default.load({
                type: 'purchaserequisition',
                id: requisicaoID,
            });
            var modeloId = reqRecord.getValue('custbody_lrc_modelo');
            log_1.default.error('modeloId', modeloId);
            if (modeloId) {
                var dateCreated = newRecord.getValue('createddate');
                // let dateSplted = dateCreated.split(' ');
                // let dataFinal = dateSplted[0].replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                // dataFinal = new Date(dataFinal);
                var paraReq = record_1.default.load({
                    type: 'customrecord_lrc_param_req_mod_projeto',
                    id: modeloId,
                });
                paraReq.setValue({
                    fieldId: 'custrecord_rsc_data_pedido_criado',
                    value: new Date(dateCreated)
                });
                paraReq.save({
                    ignoreMandatoryFields: true
                });
            }
        }
    };
    exports.beforeLoad = beforeLoad;
});
