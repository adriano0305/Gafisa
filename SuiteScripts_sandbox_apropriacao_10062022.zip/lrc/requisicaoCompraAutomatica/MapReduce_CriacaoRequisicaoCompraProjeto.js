/**
 *@NApiVersion 2.x
 *@NScriptType MapReduceScript
 *
 * Deve ser implementado um script programado mapReduce para realizar a criação das requisições de compra de um projeto.
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/runtime", "N/record", "./criarRequisicao"], function (require, exports, search_1, runtime_1, record_1, CriarRequisicao) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    runtime_1 = __importDefault(runtime_1);
    record_1 = __importDefault(record_1);
    CriarRequisicao = __importStar(CriarRequisicao);
    var getInputData = function () {
        return search_1.default.create({
            type: 'customrecord_lrc_param_req_mod_projeto',
            filters: ['custrecord_lrc_num_document', search_1.default.Operator.ISEMPTY, ""],
            columns: [
                'custrecord_lrc_mod_proj_subsidiaria',
                'custrecord_lrc_mod_proj_solicitante',
                'custrecord_lrc_mod_proj_data',
                'custrecord_lrc_mod_proj',
                'custrecord_lrc_mod_proj_data_entrega',
                'custrecord_lrc_taf_proj_relacionada',
                'custrecord_lrc_sublist_itens_data', // Sublista de itens
            ]
        });
    };
    exports.getInputData = getInputData;
    //usar o reduce para reduzir as requisoes que devem ser criadas
    var map = function (ctx) {
        var req = JSON.parse(ctx.value);
        var searchedModeloProjeto = search_1.default.lookupFields({
            type: 'projecttemplate',
            id: req.values.custrecord_lrc_mod_proj.value,
            columns: ['startdate']
        });
        var prazoParametrizado = runtime_1.default.getCurrentScript().getParameter({ name: "custscript_lrc_prazo_criacao_req_compra" });
        var diffDataAtualDataModeloProjeto = calculateDaysDiffIniciarOutorga(searchedModeloProjeto.startdate);
        if (diffDataAtualDataModeloProjeto > prazoParametrizado) {
            var paramModeloRequisicaoId = req.id;
            var paramModeloRequisicao = req.values;
            var requisicoesCompra = [];
            var requisicaoCompra = {
                subsidiaria: paramModeloRequisicao.custrecord_lrc_mod_proj_subsidiaria.value,
                solicitante: paramModeloRequisicao.custrecord_lrc_mod_proj_solicitante.value,
                data: paramModeloRequisicao.custrecord_lrc_mod_proj_data,
                modeloProjeto: paramModeloRequisicao.custrecord_lrc_mod_proj,
                dataEntrega: paramModeloRequisicao.custrecord_lrc_mod_proj_data_entrega,
                numeroDocumento: paramModeloRequisicao.custrecord_lrc_num_document,
                valorTotal: paramModeloRequisicao.custrecord_lrc_mod_proj_valor_total,
                itens: JSON.parse(paramModeloRequisicao.custrecord_lrc_sublist_itens_data)
            };
            requisicoesCompra.push(requisicaoCompra);
            var createdRequisicoesCompraId = CriarRequisicao.criarRequisicao(requisicoesCompra);
            var paramModeloReqRecord = record_1.default.load({
                type: 'customrecord_lrc_param_req_mod_projeto',
                id: paramModeloRequisicaoId
            });
            paramModeloReqRecord.setValue({
                fieldId: 'custrecord_lrc_num_document',
                value: String(createdRequisicoesCompraId[0])
            });
            //const id = 
            paramModeloReqRecord.save();
        }
    };
    exports.map = map;
    //recebe a data de criação da requisição do registro
    var calculateDaysDiffIniciarOutorga = function (dataInicioEscrituracao) {
        // converte a data pra string
        var dataInicioEscrituracaoObj = stringToDate(dataInicioEscrituracao);
        // calcula a diferença da data atual pra data recebida
        var diffInMiliseconds = Math.abs(new Date().getTime() - dataInicioEscrituracaoObj.getTime());
        // converte a diferença para dias 
        return Math.floor(diffInMiliseconds / (1000 * 60 * 60 * 24));
    };
    var stringToDate = function (date) {
        // Regex
        return new Date(date.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3"));
    };
});
