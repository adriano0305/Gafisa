/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* Userevent aplicado ao suitelet de criação de parametros de modelos de requisição
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record"], function (require, exports, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = void 0;
    record_1 = __importDefault(record_1);
    // Após clicar no botão, os atributos serão armazenados na sublista
    var afterSubmit = function (ctx) {
        if (ctx.type === ctx.UserEventType.CREATE || ctx.type === ctx.UserEventType.EDIT) {
            var itens = [];
            var item = {
                item: '',
                quantidade: '',
                fornecedor: '',
                unidades: '',
                descricao: '',
                taxaEstimada: 0,
                valorEstimado: 0
            };
            var quantItensLines = ctx.newRecord.getLineCount({
                sublistId: 'custpage_modelos_req'
            });
            for (var i = 0; i < quantItensLines; i++) {
                item.item = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_item',
                    line: i
                }));
                item.quantidade = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_quantidade',
                    line: i
                }));
                item.fornecedor = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_fornecedor',
                    line: i
                }));
                item.unidades = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_unidades',
                    line: i
                }));
                item.descricao = String(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_descricao',
                    line: i
                }));
                item.taxaEstimada = Number(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_taxa_estimada',
                    line: i
                }));
                item.valorEstimado = Number(ctx.newRecord.getSublistValue({
                    sublistId: 'custpage_itens',
                    fieldId: 'custpage_valor_estimado',
                    line: i
                }));
                itens.push(item);
            }
            var newParamReqRecord = record_1.default.create({
                type: 'customrecord_lrc_param_req_mod_projeto',
            });
            newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_mod_proj_subsidiaria',
                value: ctx.newRecord.getValue('custpage_lrc_subsidiaria')
            });
            newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_mod_proj_solicitante',
                value: ctx.newRecord.getValue('custpage_lrc_solicitante')
            });
            newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_mod_proj_data',
                value: ctx.newRecord.getValue('custpage_lrc_data')
            });
            newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_mod_proj',
                value: ctx.newRecord.getValue('custpage_lrc_modelo_relacionado')
            });
            newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_mod_proj_valor_total',
                value: ctx.newRecord.getValue('custpage_lrc_mod_proj_taf_relacionada')
            });
            newParamReqRecord.setValue({
                fieldId: 'custrecord_lrc_sublist_itens_data',
                value: JSON.stringify(itens)
            });
            newParamReqRecord.save();
        }
    };
    exports.afterSubmit = afterSubmit;
});
