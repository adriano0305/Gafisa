/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* UserEventScript_telaConfigParcelamento.ts
* 
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    log_1 = __importDefault(log_1);
    var beforeLoad = function (ctx) {
        var newRecord = ctx.newRecord;
        var cancelada = newRecord.getValue('custbody_lrc_parcela_cancelada');
        if (cancelada == true) {
            log_1.default.error('cancelada', cancelada);
            newRecord.setValue({
                fieldId: 'approvalstatus',
                value: 3
            });
            newRecord.save({
                ignoreMandatoryFields: true
            });
        }
    };
    exports.beforeLoad = beforeLoad;
});
