/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * suitelet_pedido_de_vendas.ts
 *
 */
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/search"], function (require, exports, ServerWidget, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    ServerWidget = __importStar(ServerWidget);
    search_1 = __importDefault(search_1);
    exports.onRequest = function (ctx) {
        var form = ServerWidget.createForm({
            title: 'Vendas dos clientes com ação judicial'
        });
        form.clientScriptModulePath = './client_enviar.js';
        var formData = form.addSublist({
            id: 'lrc_orders',
            type: ServerWidget.SublistType.LIST,
            label: 'Tabela de Pedidos de Vendas'
        });
        formData.addField({
            type: ServerWidget.FieldType.TEXT,
            id: 'lbl_internal_id',
            label: 'ID',
        });
        formData.addField({
            type: ServerWidget.FieldType.TEXT,
            id: 'lbl_transaction_date',
            label: 'Data de transação',
        });
        formData.addField({
            type: ServerWidget.FieldType.TEXT,
            id: 'lbl_customer',
            label: 'Customer',
        });
        formData.addField({
            type: ServerWidget.FieldType.CHECKBOX,
            id: 'cbx_select',
            label: 'Selecionar',
        });
        form.addField({
            type: ServerWidget.FieldType.TEXT,
            id: "lbl_description",
            label: "Descrição"
        });
        form.addButton({
            id: 'btn_send',
            label: 'Enviar',
            functionName: 'enviar'
        });
        var index = 0;
        search_1.default.create({
            type: "salesorder",
            columns: [
                'internalid',
                'entity',
                'trandate',
            ],
            filters: [
                ['customermain.custentity_ykp_acao_judicial', 'IS', 'T'],
                'AND',
                ['mainline', 'is', 'T']
            ]
        }).run().each(function (result) {
            formData.setSublistValue({
                id: 'lbl_internal_id',
                line: index,
                value: result.getText('internalid')
            });
            formData.setSublistValue({
                id: 'lbl_transaction_date',
                line: index,
                value: result.getText('trandate')
            });
            formData.setSublistValue({
                id: 'lbl_customer',
                line: index,
                value: result.getText('entity')
            });
            index++;
            return true;
        });
        ctx.response.writePage(form);
    };
});
