/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* Suitelet para criação dos parâmetros de modelo de requisição
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget", "N/record", "N/log", "N/search", "N/redirect"], function (require, exports, UI, record, log, search, redirect) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    record = __importStar(record);
    log = __importStar(log);
    search = __importStar(search);
    redirect = __importStar(redirect);
    var onRequest = function (ctx) {
        var parameters = ctx.request.parameters;
        log.default.debug('parameters', parameters);
        var modelos = JSON.parse(parameters.modelos);
        log.default.debug('modelos length', modelos.length);
        if(modelos.length > 0){
            for(var i = 0; i<modelos.length; i++){
                var modeloLookup = search.default.lookupFields({
                    type: 'customrecord_lrc_param_req_mod_projeto',
                    id: modelos[i],
                    columns:[
                        "custrecord_lrc_mod_proj_subsidiaria",
                        "custrecord_lrc_mod_proj_data_entrega",
                        "custrecord_lrc_mod_proj_solicitante",
                        "custrecord_lrc_mod_proj_data" ,
                        "custrecord_lrc_taf_proj_relacionada",
                        "custrecord_lrc_mod_proj"
                    ]
                })
                log.default.debug('modeloLookup', modeloLookup);
                var data = modeloLookup.custrecord_lrc_mod_proj_data;
                data = data.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                data = new Date(data);
                var entrega = modeloLookup.custrecord_lrc_mod_proj_data_entrega;
                entrega = entrega.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                entrega = new Date(entrega);
                var tarefaLookup = search.default.lookupFields({
                    type: 'projecttask',
                    id: modeloLookup.custrecord_lrc_taf_proj_relacionada[0].value,
                    columns: [
                        'custevent_rsc_etapa_projeto',
                        'custevent_rsc_tipo_tarefa'
                    ]
                });
                var requiRecord = record.default.create({
                    type: 'purchaserequisition'
                })
                requiRecord.setValue({
                    fieldId: 'entity',
                    value: modeloLookup.custrecord_lrc_mod_proj_solicitante[0].value
                })
                requiRecord.setValue({
                    fieldId: 'subsidiary',
                    value: modeloLookup.custrecord_lrc_mod_proj_subsidiaria[0].value
                })
                requiRecord.setValue({
                    fieldId: 'trandate',
                    value: data
                })
                requiRecord.setValue({
                    fieldId: 'duedate',
                    value: entrega
                })
                requiRecord.setValue({
                    fieldId: 'custbody_rsc_projeto_obra_gasto_compra',
                    value: modeloLookup.custrecord_lrc_mod_proj[0].value
                });
                requiRecord.setValue({
                    fieldId: 'class',
                    value: tarefaLookup.custevent_rsc_etapa_projeto[0].value
                });
                requiRecord.setValue({
                    fieldId: 'custbody_lrc_modelo',
                    value: modelos[i]
                });
                requiRecord.setValue({
                    fieldId: 'custbody_rsc_tipo_transacao_workflow',
                    value: 1
                });
                // requiRecord.setValue({
                //     fieldId: 'department',
                //     value: 71
                // });
                var searchLoc = search.default.create({
                    type: 'location',
                    filters:[
                        ['subsidiary', 'IS', modeloLookup.custrecord_lrc_mod_proj_subsidiaria[0].value]
                    ]
                }).run().getRange({
                    start: 0,
                    end: 1
                })
                // log_1.default.error('searchLoc[0].id',  searchLoc[0].id);
                requiRecord.setValue({
                    fieldId: 'location',
                    value: searchLoc[0].id
                })
                var l = 0;
                search.default.create({
                    type: 'customrecord_lrc_sublista_parametros',
                    filters: [
                        ['custrecord_lrc_parametros_sub', 'IS', modelos[i]]
                    ],
                    columns: [
                        'custrecord_lrc_itens',
                        'custrecord_lrc_quantidade',
                        'custrecord_lrc_unidades',
                        'custrecord_lrc_descricao2',
                        'custrecord_lrc_taxaesti',
                        'custrecord_lrc_valoresti'
                    ]
                }).run().each(function (item) {
                    requiRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'item',
                        value: item.getValue('custrecord_lrc_itens'),
                        line: l
                    });
                    // Log.error('item', item.getText('custrecord_lrc_itens'))
                    requiRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'class',
                        value: tarefaLookup.custevent_rsc_etapa_projeto[0].value,
                        line: l
                    });
                    requiRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'estimatedamount',
                        value: item.getValue('custrecord_lrc_valoresti'),
                        line: l
                    });
                    requiRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'customer',
                        value: modeloLookup.custrecord_lrc_mod_proj[0].value,
                        line: l
                    });
                    requiRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'projecttask',
                        value: modeloLookup.custrecord_lrc_taf_proj_relacionada[0].value,
                        line: l
                    });
                    requiRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'quantity',
                        value: item.getValue('custrecord_lrc_quantidade'),
                        line: l
                    });
                    requiRecord.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'description',
                        value: item.getValue('custrecord_lrc_descricao2'),
                        line: l
                    });
                    l++;
                    log.default.error('fimSublista', 'done');
                    return true;
                });
                try{
                    var idRequi = requiRecord.save({
                        ignoreMandatoryFields: true
                    });
                    var paramRecord = record.default.load({
                        type: 'customrecord_lrc_param_req_mod_projeto',
                        id: String(modelos[i])
                    });
                    paramRecord.setValue({
                        fieldId: 'custrecord_lrc_processado_modelo',
                        value: true
                    });
                    paramRecord.setValue({
                        fieldId: 'custrecord_rsc_data_limite_contratacao',
                        value: new Date()
                    });
                    log.default.debug('date', new Date());
                    paramRecord.save({
                        ignoreMandatoryFields: true
                    });
                    log.default.debug('id', idRequi);
                    redirect.toRecord({
                        type: 'job',
                        id: modeloLookup.custrecord_lrc_mod_proj[0].value,
                    })
                }catch(e){
                    log.default.debug('Error', e)
                }
                
            }
        }

        
    };
    exports.onRequest = onRequest;
    
});