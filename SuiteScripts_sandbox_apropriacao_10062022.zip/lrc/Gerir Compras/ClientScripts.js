/**
 * @NApiVersion 2.x
 * @NScriptType Clientscript
 *
 * clientscript_gerir_compras.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/url"], function (require, exports, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = void 0;
    url_1 = __importDefault(url_1);
    var fieldChanged = function (ctx) {
        var currRecord = ctx.currentRecord;
        if (ctx.fieldId == "custpage_lrc_pagina") {
            window.location.replace(url_1.default.resolveScript({
                scriptId: "customscript_lrc_tela_historico_preco",
                deploymentId: "customdeploy_lrc_tela_historico_preco",
                params: {
                    "page": currRecord.getValue("custpage_lrc_pagina"),
                    "items": getUrlParameter("items")
                }
            }));
        }
    };
    exports.fieldChanged = fieldChanged;
    var getUrlParameter = function getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1), sURLVariables = sPageURL.split('&'), sParameterName, i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return typeof sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
        return false;
    };
});
