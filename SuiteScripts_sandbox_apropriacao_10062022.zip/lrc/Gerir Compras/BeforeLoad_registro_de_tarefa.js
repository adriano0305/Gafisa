/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_processoDistrato.js
 *
 *
 */
 define(["require", "exports", "N/record", "N/ui/serverWidget"], function (require, exports, record, serverWidget, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    var beforeLoad = function (ctx) {
        var form = ctx.form;
        var recordTarefa = ctx.newRecord

        // Etapa 1: Criação de Campos Âncora 

        form.addField({ // Campo ancora, criado apenas para poder setar a sublista
            id: 'custpage_rsc_etapa',
            label: 'Etapa De Projeto',
            type: serverWidget.FieldType.TEXT
        }).updateDisplayType({
            displayType : serverWidget.FieldDisplayType.HIDDEN 
        });

        form.addField({ // Campo ancora, criado apenas para poder setar a sublista
            id: 'custpage_rsc_tarefa',
            label: 'Tarefa De Projeto',
            type: serverWidget.FieldType.TEXT
        }).updateDisplayType({
            displayType : serverWidget.FieldDisplayType.HIDDEN 
        });

        form.addField({ // Campo ancora, criado apenas para poder setar a sublista
            id: 'custpage_rsc_projecttask',
            label: 'Projecttask',
            type: serverWidget.FieldType.TEXT
        }).updateDisplayType({
            displayType : serverWidget.FieldDisplayType.HIDDEN 
        });

        // Fim da Etapa 1

        if (ctx.request && ctx.type === ctx.UserEventType.CREATE) {
            if (ctx.request.parameters.projetoObra && ctx.request.parameters.etapaProjeto && ctx.request.parameters.faseDeProjeto) {
                var parameters = ctx.request.parameters;
                var projetoObra = parameters.projetoObra;
                var etapaProjeto = parameters.etapaProjeto;
                var faseDeProjeto = parameters.faseDeProjeto;
                log.debug('parameters', parameters)
                 
                //Etapa 2: Configurando os campos 'Etapa Projeto' / 'Cliente: tarefa' / 'Tipo de Tarefa', ocultos no corpo do formulário

                var pushTarefa = record.load({ //Record.load -> para o registro de Tarefa (Campo Tipo de Tarefa)
                    type: 'projecttask',
                    id: faseDeProjeto
                });

                var pushTarefa_value = pushTarefa.getValue({
                    fieldId: 'custevent_rsc_tipo_tarefa'
                });
                
                recordTarefa.setValue({ // Projecttask - OK
                    fieldId: 'custpage_rsc_projecttask',
                    value: faseDeProjeto
                });
                recordTarefa.setValue({ // Etapa Projeto - OK
                    fieldId: "custpage_rsc_etapa",
                    value: etapaProjeto
                });
                recordTarefa.setValue({ // Cliente: Tarefa - OK
                    fieldId: "custbody_rsc_projeto_obra_gasto_compra",
                    value: projetoObra
                });

                recordTarefa.setValue({ // Tipo de Tarefa - OK
                    fieldId: "custpage_rsc_tarefa",
                    value: pushTarefa_value
                });
                var pushSubsidiary = record.load({ //Record.load -> para o registro de Projeto (Campo Subsidiaria)
                        type: 'job',
                        id: projetoObra
                });
                var subsidiary = pushSubsidiary.getValue({
                    fieldId: 'subsidiary'
                });
                recordTarefa.setValue({ // Subsidiária - OK
                    fieldId: "subsidiary",
                    value: subsidiary
                });
                    
                // Fim da Etapa 2

                    //Paramêtro QC
                    var lines = recordTarefa.getLineCount({
                        sublistId: 'item'
                    });
                    log.debug('LINES TESTE NOVOS',  lines)
    
                    // recordTarefa.setSublistValue({
                    //     sublistId: 'item',
                    //     fieldId: 'custcol_rsc_sublist_qc',
                    //     line: 0,
                    //     value: true
                    // });
                    // Final paramêtro QC
            }
        }
    };
    exports.beforeLoad = beforeLoad;
});
