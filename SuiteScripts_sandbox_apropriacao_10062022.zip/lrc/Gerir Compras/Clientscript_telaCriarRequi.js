/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript para definir as funções da criação de modelo de requisição das tarefas de modelo de projeto
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/currentRecord","N/url", "N/ui/dialog"], function (require, exports, record_1, currentRecord_1, url_1, dialog_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateInsert = exports.validateDelete = exports.validateLine = exports.cancelar = exports.criar = exports.pageInit = void 0;
    record_1 = __importDefault(record_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    dialog_1 = __importDefault(dialog_1);
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var criar = function () {
        var currentRecord = currentRecord_1.default.get();
        var qtLinhas = currentRecord.getLineCount({ sublistId: 'custpage_sublista' });
        var arrayReq = [];
        for (var i = 0; i < qtLinhas; i++) {
            var cheboxSelecionar_1 = currentRecord.getSublistValue({
                fieldId: 'custpage_transformar',
                sublistId: 'custpage_sublista',
                line: i
            });
            if (cheboxSelecionar_1 == true && currentRecord.getCurrentSublistIndex({ sublistId: 'custpage_sublista' })) {
                var modeloId = currentRecord.getSublistValue({
                    fieldId: 'custpage_id',
                    sublistId: 'custpage_sublista',
                    line: i
                });
                var paramRecord = record_1.default.load({
                    type: 'customrecord_lrc_param_req_mod_projeto',
                    id: String(modeloId)
                });
                paramRecord.setValue({
                    fieldId: 'custrecord_lrc_criar_requi',
                    value: true
                });
                paramRecord.save({
                    ignoreMandatoryFields: true
                });
                arrayReq.push(modeloId)
                // alert('Processo Finalizado! Sua requisição será criada em breve.');
                // window.close();
            }
        }
        var cheboxSelecionar = currentRecord.getCurrentSublistValue({
            fieldId: 'custpage_transformar',
            sublistId: 'custpage_sublista',
        });
        if (cheboxSelecionar == true) {
            var modeloId = currentRecord.getCurrentSublistValue({
                fieldId: 'custpage_id',
                sublistId: 'custpage_sublista',
            });
            var paramRecord = record_1.default.load({
                type: 'customrecord_lrc_param_req_mod_projeto',
                id: String(modeloId)
            });
            paramRecord.setValue({
                fieldId: 'custrecord_lrc_criar_requi',
                value: true
            });
            paramRecord.setValue({
                fieldId: 'custrecord_rsc_data_limite_contratacao',
                value: new Date()
            });
            paramRecord.save({
                ignoreMandatoryFields: true
            });
            // alert('Processo Finalizado! Sua requisição será criada em breve.');
            // window.close();
            arrayReq.push(modeloId);
        }
        var url = url_1.default.resolveScript({
            scriptId: 'customscript_rsc_criar_requi',
            deploymentId: 'customdeploy_rsc_criar_requi',
            params:{
                modelos: JSON.stringify(arrayReq)
            }
        })
        dialog_1.default.alert({
            title: 'Aviso!',
            message: 'Aguarde a criação das requisições'
        });
        window.location.replace(url)
    };
    exports.criar = criar;
    var cancelar = function () {
        window.close();
    };
    exports.cancelar = cancelar;
    var validateLine = function (ctx) {
        var sublistIndex = ctx.currentRecord.getCurrentSublistIndex({ sublistId: "custpage_sublista" });
        var sublistCount = ctx.currentRecord.getLineCount({ sublistId: "custpage_sublista" });
        if (ctx.sublistId = 'custpage_sublista') {
            if (sublistIndex == sublistCount) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos do botão criar modelo de requisição.");
                return false;
            }
        }
        return true;
    };
    exports.validateLine = validateLine;
    var validateDelete = function (ctx) {
        if (ctx.sublistId == "custpage_sublista") {
            alert("Você não pode adicionar nem remover linhas. Os critérios são definidos do botão criar modelo de requisição.");
            return false;
        }
        return true;
    };
    exports.validateDelete = validateDelete;
    var validateInsert = function (ctx) {
        if (ctx.sublistId == "custpage_sublista") {
            alert("Você não pode inserir linhas. Os critérios são definidos a partir do modelo");
            return false;
        }
        return true;
    };
    exports.validateInsert = validateInsert;
});
