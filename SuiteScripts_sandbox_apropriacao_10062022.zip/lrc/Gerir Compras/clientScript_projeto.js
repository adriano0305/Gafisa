/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript para definir as funções da criação de modelo de requisição das tarefas de modelo de projeto
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateInsert = exports.validateDelete = exports.validateLine = exports.pageInit = void 0;
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var validateLine = function (ctx) {
        var sublistIndex = ctx.currentRecord.getCurrentSublistIndex({ sublistId: "custpage_lrc_sublista_requisicao" });
        var sublistCount = ctx.currentRecord.getLineCount({ sublistId: "custpage_lrc_sublista_requisicao" });
        if (ctx.sublistId = 'custpage_lrc_sublista_requisicao') {
            if (sublistIndex == sublistCount) {
                alert("Você não pode adicionar nem remover linhas. Os critérios são definidos do botão criar modelo de requisição.");
                return false;
            }
        }
        return true;
    };
    exports.validateLine = validateLine;
    var validateDelete = function (ctx) {
        if (ctx.sublistId == "custpage_lrc_sublista_requisicao") {
            alert("Você não pode adicionar nem remover linhas. Os critérios são definidos do botão criar modelo de requisição.");
            return false;
        }
        return true;
    };
    exports.validateDelete = validateDelete;
    var validateInsert = function (ctx) {
        if (ctx.sublistId == "custpage_lrc_sublista_requisicao") {
            alert("Você não pode adicionar nem remover linhas. Os critérios são definidos do botão criar modelo de requisição.");
            return false;
        }
        return true;
    };
    exports.validateInsert = validateInsert;
});
