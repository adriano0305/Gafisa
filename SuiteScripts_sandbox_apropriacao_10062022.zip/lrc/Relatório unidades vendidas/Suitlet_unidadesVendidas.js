/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*@author Gustavo
*
*Suitlet_unidadesVendidas.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/log", "N/search"], function (require, exports, UI, log_1, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.procucarUnidades = exports.onRequest = void 0;
    UI = __importStar(UI);
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    var onRequest = function (ctx) {
        var form = UI.createForm({
            title: 'Unidades Vendidas'
        });
        var projetos_possiveis = form.addField({
            id: 'cuspage_lrc_selecao',
            label: 'Seleção de Projeto',
            type: UI.FieldType.SELECT
        });
        form.addField({
            id: 'cuspage_lrc_data_atual',
            label: 'Data do Relatório',
            type: UI.FieldType.DATE
        });
        form.addButton({
            id: 'custpage_lrc_botao',
            label: 'Montar Relatório',
            functionName: 'montarRelatorio'
        });
        var sublist = form.addSublist({
            id: 'custpage_lrc_sublist',
            label: 'Relatório de unidades vendidas',
            type: UI.SublistType.INLINEEDITOR
        });
        sublist.addField({
            id: 'custpage_lrc_subsidiaria',
            label: 'Empresa',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_emp_projeto',
            label: 'Divisão',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_ano',
            label: 'Ano',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_mes',
            label: 'Período',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_unidade',
            label: 'Unidade',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_data_doc',
            label: 'Data do Documento',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_fator_apropriacao',
            label: 'Fator de Apropriação',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_fator_participacao',
            label: 'Fator de Participação',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_a01',
            label: 'A01 - Venda Acumulada',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_a02',
            label: 'A02 - Venda do Mês',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_a03',
            label: 'A03 - Venda Acumulada da Correção Monetária',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_a04',
            label: 'A04 - Venda Dentro do Mês',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_a09',
            label: 'A09 - Recebimento Acumulado Valor Principal',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_a10',
            label: 'A10 - Recebimento Acumulado CM',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_a12',
            label: 'A12 - Valor de Recebimento do Principal no Mês',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_a13',
            label: 'A13 - Valor de Recebimento no mês CM',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_proj_financ',
            label: 'Projeto Financeiro',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_torre',
            label: 'Torre',
            type: UI.FieldType.TEXT
        });
        sublist.addField({
            id: 'custpage_lrc_unit',
            label: 'Unidade',
            type: UI.FieldType.TEXT
        });
        var search = search_1.default.create({
            type: 'job',
            columns: ['subsidiary'],
            filters: [
                ['entityid', 'IS', '63 Teste Apropriação']
            ]
        }).run().each(function (resultado) {
            var subsidiary = resultado.getText({
                name: 'subsidiary'
            });
            sublist.setSublistValue({
                id: 'custpage_lrc_subsidiaria',
                line: 0,
                value: subsidiary
            });
            return true;
        });
        log_1.default.error('search', search);
        sublist.setSublistValue({
            id: 'custpage_lrc_emp_projeto',
            line: 0,
            value: 'teste'
        });
        procucarUnidades();
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
    function procucarUnidades() {
        var id_projeto = "";
        var id_contrato;
        search_1.default.create({
            type: "job",
            filters: ["entityid", "IS", "52 B840 - JUNIX TESTE Bl Unidade"],
            columns: ["subsidiary"]
        }).run().each(function (result) {
            id_projeto = result.id;
            log_1.default.error('id', result.id);
            log_1.default.error('subsidiaria', result.getValue("subsidiary"));
            return true;
        });
        search_1.default.create({
            type: "customrecord_rsc_unidades_empreendimento",
            filters: ["custrecord_rsc_un_emp_projeto", "IS", id_projeto],
            columns: ["custrecord_rsc_un_emp_nr_contrato"]
        }).run().each(function (resultado) {
            id_contrato = resultado.getValue("custrecord_rsc_un_emp_nr_contrato");
            if (id_contrato)
                log_1.default.error("id do contrato encontrado na unidade", id_contrato);
            else
                log_1.default.error("id do contrato encontrado na unidade", "Essa unidade não foi vendida para ter um contrato");
            if (id_contrato) {
                var pesquisinha = search_1.default.lookupFields({
                    type: "invoice",
                    id: id_contrato,
                    columns: ["custbody_rsc_vlr_venda"]
                });
                log_1.default.error("pesquisinha", pesquisinha);
                var contador_1 = 0;
                search_1.default.create({
                    type: "customsale_rsc_financiamento",
                    filters: ["custbody_lrc_fatura_principal", "IS", id_contrato]
                }).run().each(function (resultado) {
                    contador_1++;
                    return true;
                });
                log_1.default.error("quantidade de financiamentos", contador_1);
            }
            return true;
        });
    }
    exports.procucarUnidades = procucarUnidades;
});
