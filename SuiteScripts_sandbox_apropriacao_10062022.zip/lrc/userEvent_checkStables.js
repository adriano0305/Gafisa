/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * userEvent_checkStables.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/currentRecord"], function (require, exports, search_1, currentRecord_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    search_1 = __importDefault(search_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    exports.beforeLoad = function (ctx) {
        var ctxType = ctx.type;
        if (ctxType == ctx.UserEventType.CREATE || ctxType == ctx.UserEventType.EDIT || ctxType == ctx.UserEventType.XEDIT) {
            var ctxForm = ctx.form;
            ctxForm.clientScriptModulePath = "./client_checkStables.js";
            ctxForm.addButton({
                id: 'custpage_btn_check_stables',
                label: 'Checar Duplicidade',
                functionName: 'checkStablesDuplicity'
            });
        }
    };
    exports.beforeSubmit = function (ctx) {
        var ctxType = ctx.type;
        if (ctxType == ctx.UserEventType.CREATE || ctxType == ctx.UserEventType.EDIT || ctxType == ctx.UserEventType.XEDIT) {
            var currentRecord = currentRecord_1.default.get();
            var horseId = currentRecord.getValue({
                fieldId: 'custrecord_rsc_cocheira_cavalo'
            });
            var horseAlreadyInStable_1 = false;
            search_1.default.create({
                type: 'customrecord_rsc_cocheiras',
                filters: [
                    ['custrecord_rsc_cocheira_cavalo', 'IS', horseId]
                ]
            }).run().each(function () {
                horseAlreadyInStable_1 = true;
                return true;
            });
            if (horseAlreadyInStable_1) {
                throw Error("O cavalo " + horseId + " j\u00E1 est\u00E1 em uma cocheira");
            }
        }
    };
});
