/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_regrasRegistro.js
 *
 * UserEvent aplicado no registro 'LRC @ Caminho Campo'
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    var beforeSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE) {
            var record = ctx.newRecord;
            var idSublista = record.getValue('custrecord_lrc_campo_idsublista');
            var linha = record.getValue('custrecord_lrc_campo_linha');
            if (idSublista && !linha) {
                throw new Error('Ao especificar uma sublista, é necessário preencher o campo "linha"!');
            }
            if (linha && !idSublista) {
                throw new Error('É necessário preencher o campo de sublista!');
            }
        }
        else if (ctx.type == ctx.UserEventType.EDIT) {
            var newRecord = ctx.newRecord;
            var idSublista = newRecord.getValue('custrecord_lrc_campo_idsublista');
            var linha = newRecord.getValue('custrecord_lrc_campo_linha');
            if (idSublista && !linha) {
                throw new Error('Ao especificar uma sublista, é necessário preencher o campo "linha"!');
            }
            if (linha && !idSublista) {
                throw new Error('É necessário preencher o campo de sublista!');
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
