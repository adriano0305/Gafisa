/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * RestletTranslateSymbols.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/search", "N/runtime", "N/log", "N/https", "N/url", "./SuiteletPreviewSegment"], function (require, exports, record_1, search_1, runtime_1, log_1, https_1, url_1, SuiteletPreviewSegment_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    runtime_1 = __importDefault(runtime_1);
    log_1 = __importDefault(log_1);
    https_1 = __importDefault(https_1);
    url_1 = __importDefault(url_1);
    var functionObj = {
        "customrecord_lrc_simbolo_formulario": translateSymbolForm,
        "customrecord_lrc_simbolo_campo": translateSymbolField,
        "customrecord_lrc_simbolo_sublista": translateSymbolSublist,
        "customrecord_lrc_simbolo_suitescript": translateSymbolSuiteScript
    };
    function extractSearchLookupValue(column, lookup) {
        var x = lookup[column];
        if (x && typeof x === 'object' && !Array.isArray(x)) { // Objeto
            return x.value;
        }
        else if (x && Array.isArray(x)) { // Array de objetos
            if (x.length == 1) {
                return x[0].value;
            }
            else if (x.length > 1) {
                return x.map(function (object) {
                    return object.value;
                });
            }
        }
        else if (x) {
            return x;
        }
        return null;
    }
    function getCampoValues(recordId, symbolId) {
        log_1.default.error("CAMPO-getCampoValues", "DONE");
        var campo = {};
        var idInicial = recordId;
        log_1.default.error("C_idInicial", idInicial);
        var simboloCampo = search_1.default.lookupFields({
            type: 'customrecord_lrc_simbolo_campo',
            id: symbolId,
            columns: [
                'internalid',
                'custrecord_lrc_simbolo_campo',
                'custrecord_lrc_campo',
                'custrecord_lrc_simbolo_campo_layout'
            ]
        });
        log_1.default.error("C_simboloCampo", simboloCampo);
        var campoJoin = extractSearchLookupValue("custrecord_lrc_campo", simboloCampo);
        log_1.default.error("C_campoJoin", campoJoin);
        campo["internalid"] = campoJoin;
        // const simboloCampo = Search.create({
        //     type: 'customrecord_lrc_simbolo_campo',
        //     filters: [
        //         ['custrecord_lrc_simbolo_campo_layout', 'IS', idInicial]
        //     ],
        //     columns: [
        //         'internalid',
        //         'custrecord_lrc_simbolo_campo',
        //         'custrecord_lrc_campo',
        //         'custrecord_lrc_simbolo_campo_layout'
        //     ]
        // }).run().getRange({
        //     start: 0,
        //     end: 1
        // });
        // let simbolo = simboloCampo[0].getValue('custrecord_lrc_simbolo_campo'); era p ser custrecord_lrc_campo
        // let campoJoin = simboloCampo[0].getValue('custrecord_lrc_campo');
        // let layout = simboloCampo[0].getValue('custrecord_lrc_simbolo_campo_layout');
        var campoRegistro = search_1.default.lookupFields({
            type: 'customrecord_lrc_regcampo',
            id: campoJoin,
            columns: [
                'custrecord_lrc_regcampo_caminho_campo',
                'custrecord_lrc_regcampo_idregistro_inici',
                'custrecord_lrc_regcampo_idinterno_regist',
                'custrecord_lrc_regcampo_texto_campo'
            ]
        });
        log_1.default.error("C_campoRegistro", campoRegistro);
        var firstHopId;
        var getPdfRecId = extractSearchLookupValue("custrecord_lrc_regcampo_idinterno_regist", campoRegistro);
        if (getPdfRecId) {
            firstHopId = recordId;
        }
        else {
            firstHopId = extractSearchLookupValue("custrecord_lrc_regcampo_idregistro_inici", campoRegistro);
        }
        log_1.default.error("C_firstHopId", firstHopId);
        campo["firstHopId"] = firstHopId;
        campo["getText"] = extractSearchLookupValue("custrecord_lrc_regcampo_texto_campo", campoRegistro);
        var caminhoCampojoin = extractSearchLookupValue("custrecord_lrc_regcampo_caminho_campo", campoRegistro);
        log_1.default.error("C_caminhoCampo", caminhoCampojoin);
        // const campo = Search.create({
        //     type: 'customrecord_lrc_regcampo',
        //     filters: [
        //         ['internalid', 'IS', campoJoin]
        //     ],
        //     columns: [
        //         'custrecord_lrc_regcampo_caminho_campo',
        //         'custrecord_lrc_regcampo_idregistro_inici',
        //         'custrecord_lrc_regcampo_idinterno_regist',
        //         'custrecord_lrc_regcampo_texto_campo'
        //     ]
        // }).run().getRange({
        //     start: 0,
        //     end: 1
        // });
        // let idRecursivo = campo[0].getValue('custrecord_lrc_regcampo_idregistro_inici'); firstHopId
        // let caminhoCampoJoin = campo[0].getValue('custrecord_lrc_regcampo_caminho_campo');
        // let idInterno = campo[0].getValue('custrecord_lrc_regcampo_idregistro_inici');
        // let capturarTexto = campo[0].getValue('custrecord_lrc_regcampo_texto_campo');
        // let idInternoCheckBox = campo[0].getValue('custrecord_lrc_regcampo_idinterno_regist');
        var caminhoCampo = search_1.default.lookupFields({
            type: 'customrecord_lrc_caminho',
            id: caminhoCampojoin,
            columns: [
                'custrecord_lrc_caminho_campo',
                'custrecord_lrc_campo_join',
                'custrecord_lrc_campo_idregistro',
                'custrecord_lrc_campo_idsublista',
                'custrecord_lrc_campo_linha'
            ]
        });
        // let caminhoCampo = Search.create({
        //     type: 'customrecord_lrc_caminho',
        //     filters: [
        //         ['internalid', 'IS', caminhoCampoJoin]
        //     ],
        //     columns: [
        //         'custrecord_lrc_caminho_campo',
        //         'custrecord_lrc_campo_join',
        //         'custrecord_lrc_campo_idregistro',
        //         'custrecord_lrc_campo_idsublista',
        //         'custrecord_lrc_campo_linha'
        //     ]
        // }).run().getRange({
        //     start: 0,
        //     end: 1
        // });
        // let join = caminhoCampo[0].getValue('custrecord_lrc_campo_join');
        // let idRegistro: any = caminhoCampo[0].getValue('custrecord_lrc_campo_idregistro');
        // let idCampo = caminhoCampo[0].getValue('custrecord_lrc_caminho_campo');
        campo["sublistId"] = extractSearchLookupValue("custrecord_lrc_campo_idsublista", caminhoCampo); // não sei se está correto
        var objPathHead = {
            "internalid": caminhoCampojoin,
            "recordType": extractSearchLookupValue("custrecord_lrc_campo_idregistro", caminhoCampo),
            "sublistId": extractSearchLookupValue("custrecord_lrc_campo_idsublista", caminhoCampo),
            "fieldId": extractSearchLookupValue("custrecord_lrc_caminho_campo", caminhoCampo),
            "line": extractSearchLookupValue("custrecord_lrc_campo_linha", caminhoCampo),
            "join": extractSearchLookupValue("custrecord_lrc_campo_join", caminhoCampo)
        };
        // var idDoCampoFinal;
        // let obj = {
        //     idInicial: idInicial,
        //     caminhoCampo: caminhoCampo,
        //     join: join,
        //     idRegistro: idRegistro,
        //     idCampo: idCampo,
        //     idDoCampoFinal: idDoCampoFinal,
        //     idInternoCheckBox: idInternoCheckBox,
        //     layout: layout,
        //     idInterno: idInterno,
        //     simbolo: simbolo,
        //     capturarTexto: capturarTexto,
        //     idRecursivo: idRecursivo
        // }
        campo["pathHead"] = objPathHead;
        return campo;
    }
    function getCampoTranslate(obj) {
        /*
            obj = {
                "internalid",
                "firstHopId",
                "pathHead": {
                    "internalid": ID interno da cabeca do caminho,
                    "recordType": Tipo do registro que a cabeça do caminho indica,
                    "sublistId": ID da sublista que a cabeça do caminho indica para fazer o join,
                    "fieldId": ID do campo para fazer o join,
                    "line": Linha da sublista para fazer o join,
                    "join"
                }
            }
        */
        log_1.default.error("C_getCampoTranslate", "DONE");
        // var procurandoRegistroFinal: any, idRegistroFinal;
        var hopId = obj.firstHopId;
        log_1.default.error("hopId", hopId);
        var pathHead = obj.pathHead;
        log_1.default.error("pathHead", pathHead);
        while (pathHead.join) {
            var recordType_1 = pathHead.recordType;
            var sublistId_1 = pathHead.sublistId;
            var fieldId_1 = pathHead.fieldId;
            var line_1 = pathHead.line;
            // if (obj.idInternoCheckBox) {
            //     const segmento = Search.create({
            //         type: 'customrecord_lrc_segmentos',
            //         filters: [
            //             ['custrecord_lrc_layout_pdf_seg', 'IS', obj.layout]
            //         ],
            //         columns: [
            //             'custrecord_lrc_id_registro_gerador_pdf'
            //         ]
            //     }).run().getRange({
            //         start: 0,
            //         end: 1
            //     });
            //     obj.idRecursivo = segmento[0].getValue('custrecord_lrc_id_registro_gerador_pdf');
            // }
            if (sublistId_1 && line_1) { // Join pela sublista, linha e campo
                log_1.default.error("if_recordType", recordType_1);
                log_1.default.error("if_hopId", hopId);
                var record_2 = record_1.default.load({
                    type: recordType_1,
                    id: hopId
                });
                log_1.default.error("if_sublistId", sublistId_1);
                log_1.default.error("if_line", line_1);
                log_1.default.error("if_fieldId", fieldId_1);
                hopId = record_2.getSublistValue({
                    sublistId: sublistId_1,
                    line: line_1,
                    fieldId: fieldId_1
                });
                log_1.default.error("C_newHopId", hopId);
            }
            else if (!sublistId_1 && !line_1) { // Join pelo campo
                var searchLookupFields = search_1.default.lookupFields({
                    type: recordType_1,
                    id: hopId,
                    columns: [
                        fieldId_1
                    ]
                });
                log_1.default.error("searchLookupFields", searchLookupFields);
                hopId = extractSearchLookupValue(fieldId_1, searchLookupFields);
                log_1.default.error("newHopId", hopId);
            }
            var pathLookupFields = search_1.default.lookupFields({
                type: 'customrecord_lrc_caminho',
                id: pathHead.join,
                columns: [
                    'custrecord_lrc_caminho_campo',
                    'custrecord_lrc_campo_join',
                    'custrecord_lrc_campo_idregistro',
                    'custrecord_lrc_campo_idsublista',
                    'custrecord_lrc_campo_linha'
                ]
            });
            log_1.default.error("C_pathLookupFields", pathLookupFields);
            pathHead = {
                "internalid": pathHead.join,
                "recordType": extractSearchLookupValue("custrecord_lrc_campo_idregistro", pathLookupFields),
                "sublistId": extractSearchLookupValue("custrecord_lrc_campo_idsublista", pathLookupFields),
                "fieldId": extractSearchLookupValue("custrecord_lrc_caminho_campo", pathLookupFields),
                "line": extractSearchLookupValue("custrecord_lrc_campo_linha", pathLookupFields),
                "join": extractSearchLookupValue("custrecord_lrc_campo_join", pathLookupFields)
            };
            log_1.default.error("C_newPathHead", pathHead);
            // procurandoRegistroFinal = Search.create({
            //     type: obj.idRegistro,
            //     filters: [
            //         ['internalid', 'IS', obj.idRecursivo]
            //     ],
            //     columns: [
            //         obj.idCampo
            //     ]
            // }).run().getRange({
            //     start: 0,
            //     end: 1
            // });
            // idRegistroFinal = procurandoRegistroFinal[0].getValue(obj.idCampo);
            // obj.caminhoCampo = Search.lookupFields({
            //     type: 'customrecord_lrc_caminho',
            //     id: obj.join,
            //     columns: [
            //         'custrecord_lrc_caminho_campo',
            //         'custrecord_lrc_campo_join',
            //         'custrecord_lrc_campo_idregistro',
            //         'custrecord_lrc_campo_idsublista',
            //         'custrecord_lrc_campo_linha'
            //     ]
            // });
            // obj.join = obj.caminhoCampo.custrecord_lrc_campo_join;
            // obj.idRegistro = obj.caminhoCampo.custrecord_lrc_campo_idregistro;
            // obj.idCampo = obj.caminhoCampo.custrecord_lrc_caminho_campo;
            // // obj.idDoCampoFinal = obj.idInternoCheckbox ? segmento : obj.idInterno;
            // if (obj.idInternoCheckBox) {
            //     const segmento = Search.create({
            //         type: 'customrecord_lrc_segmentos',
            //         filters: [
            //             ['custrecord_lrc_layout_pdf_seg', 'IS', obj.layout]
            //         ],
            //         columns: [
            //             'custrecord_lrc_id_registro_gerador_pdf'
            //         ]
            //     }).run().getRange({
            //         start: 0,
            //         end: 1
            //     });
            //     Log.error("CAMPO-segmento", segmento);
            //     obj.idRecursivo = segmento[0].getValue('custrecord_lrc_id_registro_gerador_pdf');
            // }
            // if (!obj.idCampo) {
            //     Log.error("NAO ENTRE", "Droga, entrou");
            //     obj.idRecursivo = idRegistroFinal;
            // }
            // Log.error("CAMPO-idregistroFInal", idRegistroFinal);
            // Log.error("CAMPO-idRegistro", obj.idRegistro);
            // Log.error("CAMPO-idRecursivo", obj.idRecursivo);
            // Log.error("CAMPO-obj.idCampoLookUP", obj.idCampo);
            // try {
            //     procurandoRegistroFinal = Search.lookupFields({
            //         type: obj.idRegistro,
            //         id: idRegistroFinal,
            //         columns: [
            //             obj.idCampo
            //         ]
            //     });
            // } catch (erro) {
            //     throw Error("Busca inválida! " + erro)
            // }
            // Log.error("CAMPO-procurandoRegistroFInal", procurandoRegistroFinal);
            // Log.error("CAMPO-Antesif_obj.idCampo", obj.idCampo);
            // if (!obj.idCampo) obj.idCampo = "";
            // // Array.isArray(procurandoRegistroFinal)
            // if ((typeof procurandoRegistroFinal === "object" || procurandoRegistroFinal instanceof Object) && procurandoRegistroFinal) {
            //     Log.error("CAMPO-isArray", "DONE");
            //     if (obj.capturarTexto) {
            //         obj.idCampo = procurandoRegistroFinal[obj.idCampo][0].text;
            //     } else {
            //         obj.idCampo = procurandoRegistroFinal[obj.idCampo][0].value;
            //     }
            // } else {
            //     Log.error("CAMPO-else_obj.Campo", obj.idCampo);
            //     Log.error("CAMPO-ElseProcurandoRegistroFinal", procurandoRegistroFinal);
            //     if (procurandoRegistroFinal) obj.idCampo = procurandoRegistroFinal;
            // }
            // Log.error("CAMPO-obj.idCampo", obj.idCampo);
        }
        var recordType = pathHead.recordType;
        log_1.default.error('recordType', recordType);
        log_1.default.error("hopId", hopId);
        var recordId = hopId;
        log_1.default.error("recordId", recordId);
        var sublistId = pathHead.sublistId;
        log_1.default.error("sublistId", sublistId);
        // obj.simbolo = obj.idCampo;
        // Log.error("CAMPO-obj.simbolo", obj.simbolo);
        // let finalObj = {
        //     'join': obj.join,
        //     'idRegistro': obj.idRegistro,
        //     'idCampo': obj.idCampo,
        //     'campo': obj.simbolo
        //     // 'registroCampoSublista': registroCampoSublista
        // }
        var sublistArr = [];
        var record = record_1.default.load({
            type: recordType,
            id: recordId,
            isDynamic: true
        });
        var fieldId = pathHead.fieldId;
        log_1.default.error("fieldId", fieldId);
        var line = pathHead.line;
        log_1.default.error("line", line);
        var object = {};
        log_1.default.error("sublist", sublistId);
        if (sublistId) {
            if (obj.getText) { // Pegar texto ao inves do valor
                log_1.default.error("Entrou no text SUBLIST", "done");
                object['teste'] = record.getSublistText({
                    sublistId: sublistId,
                    fieldId: fieldId,
                    line: line
                });
            }
            else { // Valor
                log_1.default.error("Entrou no value SUBLIST", "done");
                object['teste'] = record.getSublistValue({
                    sublistId: sublistId,
                    fieldId: fieldId,
                    line: line
                });
            }
        }
        else {
            if (obj.getText) { // Pegar texto ao inves do valor
                log_1.default.error("Entrou no text", "done");
                object['teste'] = record.getText({
                    fieldId: fieldId,
                    line: line
                });
            }
            else { // Valor
                log_1.default.error("Entrou no value", "done");
                object['teste'] = record.getValue({
                    fieldId: fieldId,
                    line: line
                });
            }
        }
        sublistArr.push(object);
        log_1.default.error("C_sublistArr", sublistArr);
        return object;
    }
    function getDadosSublista(recordId, symbolId) {
        var sublist = {};
        var idInicial = recordId;
        log_1.default.error("idInicial", idInicial);
        // Capturar LRC @ Sublista a partir do simbolo
        var simboloSublistaLookupFields = search_1.default.lookupFields({
            type: "customrecord_lrc_simbolo_sublista",
            id: symbolId,
            columns: [
                "custrecord_lrc_simbolo_sublista",
            ]
        });
        log_1.default.error("simboloSublistaLookupFields", simboloSublistaLookupFields);
        var sublistaJoin = extractSearchLookupValue("custrecord_lrc_simbolo_sublista", simboloSublistaLookupFields);
        log_1.default.error("sublistaJoin", sublistaJoin);
        sublist["internalid"] = sublistaJoin;
        // Capturar campos da sublista a partir do LRC @ Sublista
        var camposSublistaArr = [];
        var camposSublistaSearchObj = search_1.default.create({
            type: 'customrecord_lrc_campos_sublista',
            filters: [
                ['CUSTRECORD_LRC_PARENT_SUBLIST_SYMBOL', 'IS', symbolId]
            ],
            columns: [
                'custrecord_lrc_label',
                'custrecord_lrc_fieldid',
                'custrecord_lrc_get_field_text',
                'custrecord_lrc_parent_sublist_symbol'
            ]
        });
        camposSublistaSearchObj.run().each(function (res) {
            camposSublistaArr.push({
                "idDoCampoFinal": String(res.getValue('custrecord_lrc_fieldid')),
                "capturarTexto": Boolean(res.getValue('custrecord_lrc_get_field_text')),
                "sublistaLabel": String(res.getValue('custrecord_lrc_label'))
            });
            return true;
        });
        log_1.default.error("camposSublistaArr", camposSublistaArr);
        sublist["fields"] = camposSublistaArr;
        // Capturando informacoes relevantes de LRC @ Sublista
        var sublistaLookupFields = search_1.default.lookupFields({
            type: "customrecord_lrc_sublista",
            id: sublistaJoin,
            columns: [
                'custrecord_lrc_sublista_idreg_inicial',
                'custrecord_lrc_sublista_getpdfrecid',
                'custrecord_lrc_sublista_gettext',
                'custrecord_lrc_sublist_id',
                'custrecord_lrc_sublista_caminho',
            ]
        });
        log_1.default.error("sublistaLookupFields", sublistaLookupFields);
        var firstHopId;
        var getPdfRecId = extractSearchLookupValue("custrecord_lrc_sublista_getpdfrecid", sublistaLookupFields);
        if (getPdfRecId) { // O primeiro "pulo" será ocasionado pelo registro gerador de pdf (recordId)
            firstHopId = recordId;
        }
        else {
            firstHopId = extractSearchLookupValue('custrecord_lrc_sublista_idreg_inicial', sublistaLookupFields);
        }
        log_1.default.error("firstHopId", firstHopId);
        sublist["firstHopId"] = firstHopId;
        var sublistId = extractSearchLookupValue("custrecord_lrc_sublist_id", sublistaLookupFields);
        log_1.default.error("sublistId", sublistId);
        sublist["sublistId"] = sublistId;
        var caminhoSublistaJoin = extractSearchLookupValue("custrecord_lrc_sublista_caminho", sublistaLookupFields);
        log_1.default.error("caminhoSublistaJoin", caminhoSublistaJoin);
        // Caminho da sublista
        var pathLookupFields = search_1.default.lookupFields({
            type: 'customrecord_lrc_caminho_sublista',
            id: caminhoSublistaJoin,
            columns: [
                'custrecord_lrc_id_campo',
                'custrecord_lrc_join_csub',
                'custrecord_lrc_id_tipo_registro_csub',
                'custrecord_lrc_id_sublista_csbu',
                'custrecord_lrc_linha_csub'
            ]
        });
        log_1.default.error("pathLookupFields", pathLookupFields);
        var test = {
            "value": number,
            "text": string
        };
        test.value = 1;
        var objPathHead = {
            "internalid": caminhoSublistaJoin,
            "recordType": extractSearchLookupValue("custrecord_lrc_id_tipo_registro_csub", pathLookupFields),
            "sublistId": extractSearchLookupValue("custrecord_lrc_id_sublista_csbu", pathLookupFields),
            "fieldId": extractSearchLookupValue("custrecord_lrc_id_campo", pathLookupFields),
            "line": extractSearchLookupValue("custrecord_lrc_linha_csub", pathLookupFields),
            "join": extractSearchLookupValue("custrecord_lrc_join_csub", pathLookupFields),
        };
        log_1.default.error("objPathHead", objPathHead);
        sublist["pathHead"] = objPathHead;
        /*
            sublist = {
                "internalid": ID interno do registro LRC @ Sublista
                "sublistId": ID da sublista que quer capturar
                "firstHopId": ID que indica o primeiro "pulo" para a cabeça da estrutura recursiva. Pode ser igual ao ID do registro gerador de PDF ou um ID fixo especificado no campo "ID interno do registro inicial" de LRC @ Sublista
                "fields": [
                    {
                        "idDoCampoFinal": ID do campo,
                        "custrecord_lrc_get_field_text": Capturar texto do campo,
                        "sublistaLabel": LABEL para identificar o campo posteriormente
                    }
                ],
                "pathHead": {
                    "internalid": ID interno da cabeca do caminho,
                    "recordType": Tipo do registro que a cabeça do caminho indica,
                    "sublistId": ID da sublista que a cabeça do caminho indica para fazer o join,
                    "fieldId": ID do campo para fazer o join,
                    "line": Linha da sublista para fazer o join
                    "join"
                }
            }
        */
        return sublist;
    }
    function getSublistaTranslate(objSublist) {
        /*
            objSublist = {
                "internalid": ID interno do registro LRC @ Sublista
                "sublistId": ID da sublista que quer capturar
                "firstHopId": ID que indica o primeiro "pulo" para a cabeça da estrutura recursiva. Pode ser igual ao ID do registro gerador de PDF ou um ID fixo especificado no campo "ID interno do registro inicial" de LRC @ Sublista
                "fields": [
                    {
                        "idDoCampoFinal": ID do campo,
                        "custrecord_lrc_get_field_text": Capturar texto do campo,
                        "sublistaLabel": LABEL para identificar o campo posteriormente
                    }
                ],
                "pathHead": {
                    "internalid": ID interno da cabeca do caminho,
                    "recordType": Tipo do registro que a cabeça do caminho indica,
                    "sublistId": ID da sublista que a cabeça do caminho indica para fazer o join,
                    "fieldId": ID do campo para fazer o join,
                    "line": Linha da sublista para fazer o join,
                    "join"
                }
            }
        */
        if (objSublist.fields.length == 0)
            return [];
        var hopId = objSublist.firstHopId;
        log_1.default.error("hopId", hopId);
        var pathHead = objSublist.pathHead;
        log_1.default.error("pathHead", pathHead);
        while (pathHead.join) {
            var recordType_2 = pathHead.recordType;
            var sublistId_2 = pathHead.sublistId;
            var fieldId = pathHead.fieldId;
            var line = pathHead.line;
            if (sublistId_2 && line) { // Join pela sublista, linha e campo
                var record_3 = record_1.default.load({
                    type: recordType_2,
                    id: hopId
                });
                hopId = record_3.getSublistValue({
                    sublistId: sublistId_2,
                    line: line,
                    fieldId: fieldId
                });
                log_1.default.error("newHopId", hopId);
            }
            else if (!sublistId_2 && !line) { // Join pelo campo
                var searchLookupFields = search_1.default.lookupFields({
                    type: recordType_2,
                    id: hopId,
                    columns: [
                        fieldId
                    ]
                });
                log_1.default.error("searchLookupFields", searchLookupFields);
                hopId = extractSearchLookupValue(fieldId, searchLookupFields);
                log_1.default.error("newHopId", hopId);
            }
            var pathLookupFields = search_1.default.lookupFields({
                type: 'customrecord_lrc_caminho_sublista',
                id: pathHead.join,
                columns: [
                    'custrecord_lrc_id_campo',
                    'custrecord_lrc_join_csub',
                    'custrecord_lrc_id_tipo_registro_csub',
                    'custrecord_lrc_id_sublista_csbu',
                    'custrecord_lrc_linha_csub'
                ]
            });
            log_1.default.error("pathLookupFields", pathLookupFields);
            pathHead = {
                "internalid": pathHead.join,
                "recordType": extractSearchLookupValue("custrecord_lrc_id_tipo_registro_csub", pathLookupFields),
                "sublistId": extractSearchLookupValue("custrecord_lrc_id_sublista_csbu", pathLookupFields),
                "fieldId": extractSearchLookupValue("custrecord_lrc_id_campo", pathLookupFields),
                "line": extractSearchLookupValue("custrecord_lrc_linha_csub", pathLookupFields),
                "join": extractSearchLookupValue("custrecord_lrc_join_csub", pathLookupFields),
            };
            log_1.default.error("newPathHead", pathHead);
        }
        // Quando eu chego no fim da estrutura recursiva, o tipo do registro em "pathHead" indica em qual registro encontrar a sublista.
        // Em hopId estará disponível o id do registro em que será encontrada a sublista
        var recordType = pathHead.recordType;
        log_1.default.error('recordType', recordType);
        var recordId = hopId;
        log_1.default.error("recordId", recordId);
        var sublistId = objSublist.sublistId;
        log_1.default.error("sublistId", sublistId);
        // Encontrar a sublista no registro e montar a estrutura de retorno
        var sublistArr = [];
        var record = record_1.default.load({
            type: recordType,
            id: recordId,
            isDynamic: true
        });
        var lineCount = record.getLineCount({
            sublistId: sublistId
        });
        log_1.default.error("lineCount", lineCount);
        log_1.default.error("fields", objSublist.fields);
        var _loop_1 = function (line) {
            var obj = {};
            objSublist.fields.forEach(function (field) {
                var fieldId = field.idDoCampoFinal;
                var getText = field.capturarTexto;
                var sublistaLabel = field.sublistaLabel;
                if (getText) { // Pegar texto ao inves do valor
                    obj[sublistaLabel] = record.getSublistText({
                        sublistId: sublistId,
                        fieldId: fieldId,
                        line: line
                    });
                }
                else { // Valor
                    obj[sublistaLabel] = record.getSublistValue({
                        sublistId: sublistId,
                        fieldId: fieldId,
                        line: line
                    });
                }
            });
            sublistArr.push(obj);
        };
        for (var line = 0; line < lineCount; line++) {
            _loop_1(line);
        }
        log_1.default.error("sublistArr", sublistArr);
        return sublistArr;
    }
    function searchLookUpFieldsSublista(recordId, symbolId) {
        log_1.default.error("recordId", recordId);
        var objDadosSublista = getDadosSublista(recordId, symbolId);
        log_1.default.error("objDadosSublista", objDadosSublista);
        return getSublistaTranslate(objDadosSublista);
    }
    function searchLookUpFields(recordId, symbolId) {
        log_1.default.error("C_recordId", recordId);
        var objDadosCampo = getCampoValues(recordId, symbolId);
        log_1.default.error("C_objDadosCampo", objDadosCampo);
        return getCampoTranslate(objDadosCampo);
    }
    function translateSymbolForm(symbol, recordId) {
        var newSymbol = symbol;
        var formulario = search_1.default.lookupFields({
            type: 'customrecord_lrc_simbolo_formulario',
            id: symbol.id,
            columns: [
                'custrecord_lrc_simbolo_form_valor'
            ]
        });
        newSymbol = formulario.custrecord_lrc_simbolo_form_valor;
        return newSymbol;
    }
    function translateSymbolField(symbol, recordId) {
        return searchLookUpFields(recordId, symbol.id);
    }
    function translateSymbolSublist(symbol, recordId) {
        return searchLookUpFieldsSublista(recordId, symbol.id);
    }
    function translateSymbolSuiteScript(symbol, recordId, allSymbols) {
        // Encontrar o simbolo do tipo "LRC @ Simbolo SuiteScript"
        //tenho que passar o parametro(como se fosse segmento) e o allsymbols, removendo com a função removeNotUsedSymbols, para ficar com apenas os simbolos que estão nos parametros
        var simboloSuiteScriptLookup = search_1.default.lookupFields({
            type: 'customrecord_lrc_simbolo_suitescript',
            id: symbol.id,
            columns: [
                'custrecord_lrc_parametros',
                'custrecord_lrc_simbolo_script',
                'custrecord_lrc_simbolo_implementacao',
                'custrecord_lrc_script_simbolo'
            ]
        });
        log_1.default.error("simboloSuiteScriptLookup", simboloSuiteScriptLookup);
        var parametros = String(extractSearchLookupValue("custrecord_lrc_parametros", simboloSuiteScriptLookup));
        log_1.default.error("parametros", parametros);
        var newSymbols = [];
        var translatedParameters;
        if (parametros) {
            newSymbols = SuiteletPreviewSegment_1.removeNotUsedSymbols(allSymbols.filter(function (symbol) {
                return ['customrecord_lrc_simbolo_campo',
                    'customrecord_lrc_simbolo_formulario',
                    'customrecord_lrc_simbolo_sublista'].indexOf(symbol.type) >= 0;
            }), parametros);
            log_1.default.error("newSymbols", newSymbols);
            // traduzir chamando a função translateSymbol.
            var finalTranslatedSymbols_1 = [];
            log_1.default.error("newSymbolsAfterFilter", newSymbols);
            newSymbols.forEach(function (symbol) {
                finalTranslatedSymbols_1.push({
                    symbol: symbol.symbol,
                    value: translateSymbol(symbol, recordId, allSymbols)
                });
            });
            log_1.default.error("finalTranslatedSymbols", finalTranslatedSymbols_1);
            //depois, devo chamar a função translateSegment
            translatedParameters = SuiteletPreviewSegment_1.translateSegment(parametros, finalTranslatedSymbols_1);
        }
        var script = extractSearchLookupValue("custrecord_lrc_simbolo_script", simboloSuiteScriptLookup);
        log_1.default.error("script", script);
        var implementacao = extractSearchLookupValue("custrecord_lrc_simbolo_implementacao", simboloSuiteScriptLookup);
        log_1.default.error("implementacao", implementacao);
        // Chamar o metodo GET para esse script 
        var response = https_1.default.request({
            method: https_1.default.Method.GET,
            url: url_1.default.resolveScript({
                scriptId: script,
                deploymentId: implementacao,
                params: translatedParameters,
                returnExternalUrl: true
            })
        });
        log_1.default.error("response", response);
        if (response.code.toString().substring(0, 1) != "2") {
            throw Error(response.body);
        }
        return response.body;
    }
    function translateSymbol(symbol, recordId, allSymbols) {
        return functionObj[symbol.type](symbol, recordId, allSymbols);
    }
    var onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            log_1.default.error("functionObj", functionObj);
            var MIN_GOVERNANCE = 250; // utilizado para logica de calculo de governancia restante. É o minimo de governancia restante aceitado para esse script
            var scriptObj = runtime_1.default.getCurrentScript(); // utilizado para logica de calculo de governancia restante
            var parameters = ctx.request.parameters;
            log_1.default.error("parameters", parameters);
            var layoutId = parameters.layoutId;
            log_1.default.error("layoutId", layoutId);
            var recordId = parameters.recordId;
            log_1.default.error("recordId", recordId);
            var allSymbols = JSON.parse(parameters.allSymbols);
            log_1.default.error("allSymbols", parameters.allSymbols);
            var symbols = JSON.parse(parameters.symbols);
            log_1.default.error("symbols", symbols);
            var symbolsLength = symbols.length;
            log_1.default.error("symbolsLength", symbolsLength);
            var translatedSymbols = [];
            var index = 0;
            for (var i = 0; i < symbolsLength; i++) {
                translatedSymbols.push({
                    symbol: symbols[i].symbol,
                    value: translateSymbol(symbols[i], layoutId, allSymbols) // aqui era recordID
                });
                var remainingUsage = Number(scriptObj.getRemainingUsage());
                log_1.default.error("remainingUsage", remainingUsage);
                index++;
                if (remainingUsage < MIN_GOVERNANCE) { // Governancia do script excedida, pois é menor que a governância minima estipulada!
                    break;
                }
            }
            ctx.response.write({
                output: JSON.stringify({
                    "success": true,
                    "nextIndex": index,
                    "symbols": JSON.stringify(translatedSymbols)
                })
            });
        }
    };
    exports.onRequest = onRequest;
});
