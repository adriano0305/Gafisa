/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEvent_regrasRegistro_CaminhoSublista.ts
 *
 * Retornar valor de crédito do memorando de crédito.
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    log_1 = __importDefault(log_1);
    var beforeSubmit = function (ctx) {
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT) {
            log_1.default.error("Entrou", ctx.newRecord);
            var record = ctx.newRecord;
            var sublista = record.getValue({
                fieldId: 'custrecord_lrc_id_sublista_csbu'
            });
            var linha = record.getValue({
                fieldId: 'custrecord_lrc_linha_csub'
            });
            if (sublista && !linha) {
                throw new Error("É necessário preencher o campo de sublista!");
            }
            if (!sublista && linha) {
                throw new Error("Ao especificar uma sublista, é necessário preencher o campo \"linha\"!");
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
