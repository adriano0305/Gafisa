/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * Suitlet2CNAB.ts
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/ui/serverWidget", "N/log", "N/search", "N/file"], function (require, exports, UI, log_1, search_1, file_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Arquivos = exports.onRequest = void 0;
    UI = __importStar(UI);
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    file_1 = __importDefault(file_1);
    //import CurrentRecord from "N/currentRecord";
    var onRequest = function (ctx) {
        var form = UI.createForm({
            title: "APROVAÇÃO DE PAGAMENTOS"
        });
        Arquivos();
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
    function Arquivos() {
        //let form = CurrentRecord.get();
        var lista_id_file = [0];
        search_1.default.create({
            type: "customrecord_lrc_confirm_aprov_cnab",
            filters: ["id", "IS", "1"],
            columns: ["custrecord_lrc_lista_id_file"]
        }).run().each(function (result) {
            var str = String(result.getValue("custrecord_lrc_lista_id_file"));
            lista_id_file = str.split(",");
            log_1.default.error("teste", lista_id_file);
            return true;
        });
        for (var i = 0; i < lista_id_file.length; i++) {
            try {
                var myFile = file_1.default.load({ id: lista_id_file[i] });
                myFile.folder = 1192;
                var salvado = myFile.save();
                if (salvado)
                    log_1.default.error("sucesso", lista_id_file[i]);
                else
                    log_1.default.error("fracasso", lista_id_file[i]);
            }
            catch (error) {
                log_1.default.error("Descrição de erro", error);
            }
        }
    }
    exports.Arquivos = Arquivos;
});
