/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 *
 * Client_enviar.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/currentRecord", "N/record", "N/url", "N/format", "N/file"], function (require, exports, search_1, currentRecord_1, record_1, url_1, format_1, file_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.TrasformarStringEmData = exports.criarLote = exports.buscaCNABs = exports.PegarCnabsParaDetalhamento = exports.SearchInstallments = exports.fieldChanged = exports.pageInit = void 0;
    search_1 = __importDefault(search_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    record_1 = __importDefault(record_1);
    url_1 = __importDefault(url_1);
    format_1 = __importDefault(format_1);
    file_1 = __importDefault(file_1);
    var consultacompleta;
    var lista_de_ids_tran =[];
    var pageInit = function (ctx) {
        // var consulta = SearchInstallments();
        // build_line_subsidiary(consulta, consulta.length);
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        // try {
        //     var curRec = ctx.currentRecord;
        //     //console.log(ctx.fieldId);
        //     console.log(ctx.fieldId)
        //     console.log(ctx.line)
        //     console.log(ctx.sublistId)
        //     console.log(curRec.getLineCount({sublistId:'custpage_lrc_sublist'}))
        //     if (ctx.fieldId == "custpage_lrc_sublist_checkbox" && ctx.sublistId == "custpage_lrc_sublist"){
        //         var num_lines = curRec.getLineCount({sublistId:'custpage_lrc_sublist'})
        //         for(var line = 0; line < num_lines; line++){
        //             if (ctx.line == line) {
        //                 console.log('T');
        //                 curRec.selectLine({
        //                     line: line,
        //                     sublistId: "custpage_lrc_sublist"
        //                 });
        //                 curRec.setCurrentSublistValue({
        //                     fieldId: "custpage_lrc_sublist_checkbox",
        //                     sublistId: "custpage_lrc_sublist",
        //                     value: true,
        //                     ignoreFieldChange: true
        //                 });
        //                 if (line != num_lines - 1) {
        //                     curRec.commitLine({
        //                         sublistId: "custpage_lrc_sublist"
        //                     });
        //                 }
        //             }
        //             else {
        //                 console.log('F');
        //                 curRec.selectLine({
        //                     line: line,
        //                     sublistId: "custpage_lrc_sublist"
        //                 });
        //                 curRec.setCurrentSublistValue({
        //                     fieldId: "custpage_lrc_sublist_checkbox",
        //                     sublistId: "custpage_lrc_sublist",
        //                     value: false,
        //                     ignoreFieldChange: true
        //                 });
        //                 if (line != num_lines - 1) {
        //                     curRec.commitLine({
        //                         sublistId: "custpage_lrc_sublist",
        //                     });
        //                 }
        //             }
        //         }
            
                
        //     }
        //     /*  if (ctx.fieldId == "custpage_lrc_detalhes_checkbox") {
        //          buscaCNABs();
        //      } */
        // }
        // catch (error) {
        //     console.log('Erro fieldChanged' + error);
        // }
    };
    exports.fieldChanged = fieldChanged;
    function SearchInstallments(subsiadiary,dateI,dateF) {
        try {
            var consulta = [], //Consulta será o resultado final das search retornadas em uma lista de objetos    
            listaconsultaiguais_1 = [], //Consulta será o resultado final das search retornadas em uma lista de objetos    
            listacompleta_1 = [], //todos os resultados    
            anterior_1;
            var filters = [];
            if(dateF && dateI){
                filters.push( search_1.default.createFilter({name: 'duedate', operator: search_1.default.Operator.WITHIN, values: [dateI, dateF]}) );
            }
            if(subsiadiary){
                filters.push( search_1.default.createFilter({name: 'subsidiary', join: 'transaction', operator: search_1.default.Operator.IS, values: subsiadiary}) );
            }

			// filters.push( search_1.default.createFilter({name: 'type', join: 'transaction', operator: search_1.default.Operator.ANYOF, values: tranType}) );
			filters.push( search_1.default.createFilter({name: 'mainline', join: 'transaction', operator: search_1.default.Operator.IS, values: true}) );
			filters.push( search_1.default.createFilter({name: 'custrecord_rsc_cnab_inst_status_ls', operator: search_1.default.Operator.IS, values: 2}) );
            search_1.default.create({
                type: "installment",
                filters: filters,
                columns: [
                    "duedate",
                    "custrecord_rsc_cnab_inst_bank_ls",
                    "amount",
                    search_1.default.createColumn({ name: "entity", join: "transaction" }),
                    search_1.default.createColumn({ name: "subsidiary", join: "transaction", sort: search_1.default.Sort.ASC }),
                    search_1.default.createColumn({ name: "internalid", join: "transaction" }) //id do vendorbill
                ]
            }).run().each(function (result) {
                var subsidiariaRes = result.getValue({ name: "subsidiary", join: "transaction" });
                listacompleta_1.push({
                    'data_vencimento': String(result.getValue("duedate")),
                    'banco': result.getText("custrecord_rsc_cnab_inst_bank_ls"),
                    'valor_total': Number(result.getValue("amount")),
                    'fornecedor': result.getText({ name: "entity", join: "transaction" }),
                    'subsidiaria': subsidiariaRes,
                    'quantidade': 1,
                    'id_titulo': result.id,
                    'id_tran': result.getText({ name: "internalid", join: "transaction" })
                });
                if (anterior_1 != subsidiariaRes) {
                    listaconsultaiguais_1.push({
                        'data_vencimento': String(result.getValue("duedate")),
                        'banco': result.getText("custrecord_rsc_cnab_inst_bank_ls"),
                        'valor_total': Number(result.getValue("amount")),
                        'fornecedor': result.getText({ name: "entity", join: "transaction" }),
                        'subsidiaria': subsidiariaRes,
                        'quantidade': 1,
                        'id_titulo': result.id,
                        'id_tran': result.getText({ name: "internalid", join: "transaction" })
                    });
                    anterior_1 = subsidiariaRes;
                }
                else {
                    listaconsultaiguais_1[listaconsultaiguais_1.length - 1]['valor_total'] += Number(result.getValue("amount"));
                    listaconsultaiguais_1[listaconsultaiguais_1.length - 1]['quantidade']++;
                }
                return true;
            });
            if (listacompleta_1)
                currentRecord_1.default.get().setValue({ fieldId: "custpage_lrc_consulta", value: JSON.stringify(listacompleta_1) });
            // consultacompleta = listacompleta_1;
            var consultaRecord = record_1.default.create({
                type:'customrecord_rsc_consulta_lote',
            })
            consultaRecord.setValue({
                fieldId:'custrecord_rsc_consulta',
                value: JSON.stringify(listacompleta_1)
            })
            consultacompleta = consultaRecord.save({ignoreMandatoryFields: true})
            return listaconsultaiguais_1;
        }
        catch (error) {
            console.log('Erro SearchInstallments ' + error);
            return [];
        }
    }
    exports.SearchInstallments = SearchInstallments;
    function PegarCnabsParaDetalhamento(rec, sub) {
        try {
            var show_list_1 = [], consulta = rec;
            
            consulta.forEach(function (elemen) {
                if (elemen.subsidiaria == sub){
                    show_list_1.push(elemen["id_titulo"]);
                    lista_de_ids_tran.push(elemen["id_tran"])
                }
                
            });
            if (show_list_1)
                // rec.setValue({ fieldId: "custpage_lrc_consulta_selected", value: JSON.stringify(show_list_1) });
            // console.log('show_list');
            // console.log(show_list_1);
            // console.log(rec.getValue({ fieldId: "custpage_lrc_consulta_selected" }));
            return show_list_1;
        }
        catch (error) {
            // console.log('Erro PegarCnabsParaDetalhamento ' + error);
            return [];
        }
    }
    exports.PegarCnabsParaDetalhamento = PegarCnabsParaDetalhamento;
    function clearInstallments(currRecord){
        var linhas = currRecord.getLineCount({
            sublistId:'custpage_lrc_sublist'
        })
        for(var i = linhas; i > 0;i--){
            currRecord.selectLine({ sublistId: 'custpage_lrc_sublist', line: i-1 });
            // currRecord.setCurrentSublistValue({ sublistId: 'custpage_lrc_sublist', fieldId: 'delete', value: true, ignoreFieldChange: true });
            // currRecord.commitLine({ sublistId: 'custpage_lrc_sublist' });
            currRecord.removeLine({ sublistId: 'custpage_lrc_sublist', line: i-1, ignoreRecalc: true });
            console.log('i', i);
        }
    }
    function buscaCNABs() {
        var currRecord = currentRecord_1.default.get();
        var subsiadiary = currRecord.getValue('custpage_lrc_subsidiaria');
        var dateI = currRecord.getValue('custpage_lrc_idate');
        var dateF = currRecord.getValue('custpage_lrc_fdate');        
        clearInstallments(currRecord)
        if(dateI && dateF){
            dateI = format_1.default.format({ value: dateI, type: format_1.default.Type.DATE });
            dateF = format_1.default.format({ value: dateF, type: format_1.default.Type.DATE });
            var consulta = SearchInstallments(subsiadiary,dateI,dateF);
            build_line_subsidiary(consulta, consulta.length);
        }else if(!dateI && dateF){
            alert('Preencha a data inicio');
            
        }else if(dateI && !dateF){
            alert('Preencha a data final');
        }else{
            var consulta = SearchInstallments(subsiadiary,dateI,dateF);
            build_line_subsidiary(consulta, consulta.length);
        }
    }
    exports.buscaCNABs = buscaCNABs;
    function detalhes(){
        var curRec = currentRecord_1.default.get();
        var linhas = curRec.getLineCount({sublistId:'custpage_lrc_sublist'});
        var selecionados =0 
        for(var i = 0; i<linhas;i++){
            var check = curRec.getSublistValue({
                fieldId: 'custpage_lrc_sublist_checkbox', 
                sublistId: 'custpage_lrc_sublist', 
                line: i
            })
            if(check){
                selecionados++;
            }
        }
        if(selecionados == 1){
            for(var i = 0; i<linhas;i++){
                var check = curRec.getSublistValue({
                    fieldId: 'custpage_lrc_sublist_checkbox', 
                    sublistId: 'custpage_lrc_sublist', 
                    line: i
                })
                var sub = curRec.getSublistValue({
                    fieldId: 'custpage_lrc_sublist_subsidiaria', 
                    sublistId: 'custpage_lrc_sublist', 
                    line: i
                })
                if(check){
                    var url = url_1.default.resolveScript({
                        scriptId: 'customscript_rsc_detalhes_cnab',
                        deploymentId: 'customdeploy_rsc_detalhes_cnab',
                        params: {
                            details:consultacompleta,
                            line: i,
                            sub: sub
                        }
                    })
                    window.open(url, "_blank")
                }
            }
        }else{
            alert('Seleciona apenas 1 subsidiaria para ver detalhes.');
        }
        
        
    }
    exports.detalhes = detalhes;
    function criarLote() {
        try {
            var curRec = currentRecord_1.default.get();
            //Dados
            var aprov1 = curRec.getValue({ fieldId: "custpage_lrc_aprovador1" });
            var aprov2 = curRec.getValue({ fieldId: "custpage_lrc_aprovador2" });
            var dateI = curRec.getValue('custpage_lrc_idate');
            var dateF = curRec.getValue('custpage_lrc_fdate');
            var sub = curRec.getValue('custpage_lrc_subsidiaria')
            var nome_lote = curRec.getValue({ fieldId: "custpage_lrc_nome_lote_cnab" });
            var lista_de_ids_parcelas_1 = [];
            // var lista_de_ids_tran = [];
            var lista_de_subsidiarias = [];
            var lista_de_fornecedores = [];
            var lista_arquivos_1 = [];
            var lista_de_vencimentos = [];
            var lista_de_valores = [];
            var total_linhas_sublista = curRec.getLineCount({ sublistId: "custpage_lrc_sublist" });
            console.log(total_linhas_sublista);
            //let list_det = CurrentRecord.get().getValue({ fieldId: "custpage_lrc_consulta_selected", value: JSON.stringify(show_list) });
            // var det = curRec.getValue({ fieldId: "custpage_lrc_consulta_selected" });
            // console.log(det);
            // var list_det = JSON.parse(String(det));
            //console.log();
            //verifica quais linhas da sublista tem a checkbox selecionada (valor true)
            for (var i = 0; i < total_linhas_sublista; i++) {
                var is_selecionada = curRec.getSublistValue({ fieldId: 'custpage_lrc_sublist_checkbox', sublistId: 'custpage_lrc_sublist', line: i });
                console.log(is_selecionada);
                if (is_selecionada) {
                    // console.log(curRec.getSublistValue({ fieldId: 'custpage_lrc_detalhes_id', sublistId: 'custpage_lrc_detalhes', line: i }));
                    // console.log(list_det[i]);
                    var array = PegarCnabsParaDetalhamento(JSON.parse(curRec.getValue('custpage_lrc_consulta')),curRec.getSublistValue({fieldId: 'custpage_lrc_sublist_subsidiaria', sublistId: 'custpage_lrc_sublist', line: i}));
                    lista_de_subsidiarias.push(curRec.getSublistValue({ fieldId: 'custpage_lrc_sublist_subsidiaria', sublistId: 'custpage_lrc_sublist', line: i }));
                    for(var j = 0; j < array.length; j++){
                        lista_de_ids_parcelas_1.push(array[j])
                    }
                    
                    // lista_de_ids_tran.push(curRec.getSublistValue({ fieldId: 'custpage_lrc_tran_id', sublistId: 'custpage_lrc_detalhes', line: i }));
                }
            }
            console.log("Ids das parcelas:", lista_de_ids_parcelas_1);
            console.log("Ids das parcelas:", lista_de_ids_tran);
            var lista_controllers_1 = [];
            
            // for(var j = 0 ;j < lista_de_ids_parcelas_1.length; j++){
            //     var searchController = search_1.default.create({
            //         type: "customrecord_rsc_cnab_controller",
            //         filters: [["custrecord_rsc_cnab_cont_cnabtype_ls", "IS", "1"], "AND", ["custrecord_rsc_cnab_cont_installments_ds", "ANYOF", lista_de_ids_parcelas_1[j]], "AND", ['custrecord_rsc_cnab_cont_status_ls', 'noneof', '3']],
            //         columns: ["custrecord_rsc_cnab_cont_installments_ds", "custrecord_rsc_cnab_cont_file_ls"]
            //     }).run().getRange({
            //         start:0,
            //         end:1
            //     })
            //     if(searchController[0]){
            //         var controllerLookup = search_1.default.lookupFields({
            //             type:'customrecord_rsc_cnab_controller',
            //             id:searchController[0].id,
            //             columns:[
            //                 'custrecord_rsc_cnab_cont_file_ls'
            //             ]
            //         })
            //         if(controllerLookup.custrecord_rsc_cnab_cont_file_ls.length > 0){
            //             if(lista_arquivos_1.indexOf(controllerLookup.custrecord_rsc_cnab_cont_file_ls[0].value) == -1){
            //                 lista_arquivos_1.push(controllerLookup.custrecord_rsc_cnab_cont_file_ls[0].value);
            //                 console.log("entrou if")
            //             }
            //         }
            //     }
            // }
            // var filters = [];
            // filters.push( search_1.default.createFilter({name: 'custrecord_rsc_cnab_cont_cnabtype_ls', operator: search_1.default.Operator.IS, values: 1}) );
            // filters.push( search_1.default.createFilter({name: 'custrecord_rsc_cnab_cont_status_ls', operator: search_1.default.Operator.IS, values: 2}) );
            var filter = []
            for(var j = 0 ;j < lista_de_ids_parcelas_1.length; j++){
                filter.push(["custrecord_rsc_cnab_cont_installments_ds","contains",lista_de_ids_parcelas_1[j]])
                if(lista_de_ids_parcelas_1.length - 1 != j){
                    filter.push("OR")
                }
            }
            search_1.default.create({
                type: "customrecord_rsc_cnab_controller",
                filters: [["custrecord_rsc_cnab_cont_cnabtype_ls", "IS", "1"], "AND",filter, "AND", ['custrecord_rsc_cnab_cont_status_ls', 'noneof', '3']],
                columns: ["custrecord_rsc_cnab_cont_installments_ds", "custrecord_rsc_cnab_cont_file_ls"]
            }).run().each(function (result) { 
                var id_parcelas = String(result.getValue("custrecord_rsc_cnab_cont_installments_ds"));
                var id_arquivos = String(result.getValue("custrecord_rsc_cnab_cont_file_ls"));
                var parcelas = id_parcelas;
                console.log('id_parcelas');
                console.log(id_parcelas);
                console.log(id_arquivos);
                console.log(result.id);
                console.log(lista_arquivos_1.indexOf(id_arquivos));
                if(lista_arquivos_1.indexOf(id_arquivos) == -1){
                    lista_arquivos_1.push(id_arquivos);
                    console.log("entrou if")
                }
                //parcelas.forEach((element: any) => {
                if (lista_de_ids_parcelas_1.indexOf(parcelas) != -1 && lista_controllers_1.indexOf(result.id) == -1) {
                    lista_controllers_1.push(result.id);
                    lista_arquivos_1.push(id_arquivos);
                    //console.log("Id controller: ", result.id, "Array de parcelas: ", parcelas);
                    
                }
                console.log(lista_arquivos_1);
                return true;
            });
            console.log(lista_arquivos_1);
            console.log('lista_de_subsidiarias', lista_de_subsidiarias);
            //criando um registro que guarda as informações para os aprovadores
            var newrecord = record_1.default.create({
                type: "customrecord_lrc_confirm_aprov_cnab",
            });
            newrecord.setValue({ fieldId: "name", value: nome_lote ? nome_lote : "Sem nome" });
            newrecord.setValue({ fieldId: "custrecord_lrc_list_arq", value: JSON.stringify(lista_arquivos_1) });
            newrecord.setValue({ fieldId: "custrecord_lrc_list_parc", value: JSON.stringify(lista_de_ids_tran) });
            newrecord.setValue({ fieldId: "custrecord_lrc_confirm_approv_1", value: aprov1 ? aprov1 : "" });
            newrecord.setValue({ fieldId: "custrecord_lrc_confirm_approv_2", value: aprov2 ? aprov2 : "" });
            newrecord.setValue({ fieldId: "custrecord_lrc_cnab_id_titulo", value: JSON.stringify(lista_de_ids_parcelas_1) });
            newrecord.setValue({ fieldId: "custrecord_lrc_cnab_subsidiaria", value: JSON.stringify(lista_de_subsidiarias) });
            newrecord.setValue({ fieldId: "custrecord_lrc_cnab_fornecedores", value: lista_de_fornecedores });
            newrecord.setValue({ fieldId: "custrecord_lrc_cnab_vencimentos", value: lista_de_vencimentos });
            newrecord.setValue({ fieldId: "custrecord_lrc_cnab_valores", value: lista_de_valores });
            newrecord.setValue({ fieldId: "custrecord_rsc_date_inicial", value: dateI });
            newrecord.setValue({ fieldId: "custrecord_rsc_date_final", value: dateF });
            newrecord.setValue({ fieldId: "custrecord_rsc_subsidiaria_busca",  value: sub});
            //newrecord.setValue({ fieldId: "custrecord_lrc_cnab_pretacoes", value: lista_de_prestacoes });
            var id_newrecord = newrecord.save();
            console.log(id_newrecord);
            console.log("Lista de arquivos:", lista_arquivos_1);
            console.log("SALVADO");
            var myUrl = url_1.default.resolveRecord({
                recordType: 'customrecord_lrc_confirm_aprov_cnab',
                recordId: id_newrecord,
                isEditMode: false
            });
            console.log(myUrl);
            window.location.replace(myUrl);
            return;
        }
        catch (error) {
            console.log("Erro criarLote " + error);
        }
    }
    exports.criarLote = criarLote;
    function TrasformarStringEmData(data) {
        var dia = data.slice(0, 2);
        var mes = data.slice(3, 5);
        var ano = data.slice(6);
        var str = ano + '-' + mes + '-' + dia;
        var date = new Date(str);
        return date;
    }
    exports.TrasformarStringEmData = TrasformarStringEmData;
    function verDestalhes(){
        var curRec = currentRecord_1.default.get();
        var dataI = curRec.getValue("custrecord_rsc_date_inicial");
        var dataF = curRec.getValue("custrecord_rsc_date_final");
        // var linhas = curRec.getLineCount({
        //     sublistId:'custpage_lrc_sublist'
        // })
        var sub = curRec.getValue('custrecord_lrc_cnab_subsidiaria')
        // var sub = [];
        // for(var i = 0; i < linhas; i++){
        //     sub.push(curRec.getSublistValue({
        //         sublistId:'custpage_lrc_sublist',
        //         fieldId: 'custpage_lrc_sublist_subsidiaria_value',
        //         line: i
        //     }))
        // }
        // // var sub = curRec.getValue("custrecord_rsc_subsidiaria_busca");
        console.log(sub)
        
        var url = url_1.default.resolveScript({
            scriptId: 'customscript_rsc_detalhes_lote',
            deploymentId: 'customdeploy_rsc_detalhes_lote',
            params: {
                sub:sub,
                dataI: dataI,
                dataF: dataF
            }
        })
        window.open(url, "_blank")
    }
    exports.verDestalhes = verDestalhes
    function aprovar(){
        try {
            var record = currentRecord_1.default.get();
            var registro = record_1.default.load({
                type:'customrecord_lrc_confirm_aprov_cnab',
                id: record.id
            })
            var aprov1 = registro.getValue({ fieldId: "custrecord_lrc_confirm_approv_1" });
            var aprov2 = registro.getValue({ fieldId: "custrecord_lrc_confirm_approv_2" });
            var check = registro.getValue({ fieldId: "custrecord_lrc_env_arq" });
            if (aprov1 && aprov2) {

                var url = url_1.default.resolveScript({
                    scriptId: 'customscript_rsc_aprovar_lote_st',
                    deploymentId: 'customdeploy_rsc_aprovar_lote_st',
                    params:{
                        idLote: record.id
                    }
                })
                 window.location.replace(url)

            }else{
                alert('O lote deve ter dois aprovadores');
            }
            
            // console.log(registro);
            // var lista_id_file = JSON.parse(String(registro.getValue({ fieldId: "custrecord_lrc_list_arq" })));
            // var lista_id_install = JSON.parse(String(registro.getValue({ fieldId: "custrecord_lrc_list_parc" })));
            // console.log(aprov1);
            // console.log(aprov2);
            // console.log(check);
            // if (aprov1 && aprov2 && check == true) {
            //     console.log(lista_id_file)
            //     lista_id_file.forEach(function (element) {
            //         console.log(element);
            //         if(element){

            //             var myFile = file_1.default.load({ id: Number(element) });
            //             myFile.folder = 1160; //pasta de teste -> 1192
            //             var salvado = myFile.save();
            //             console.log("teste1", "mandou os arquivos");
            //             console.log("salvado", salvado);
            //             issalvado_1 = true;
            //         }
            //     });
            //     lista_id_install.forEach(function (element) {
            //         console.log("element", element);
            //         if(element){

            //             //let parcela = Record.submitFields({id:element,type:Record.Type.VENDOR_BILL,values:"3"}) 
            //             var parcela = record_1.default.load({ id: element, type: record_1.default.Type.VENDOR_BILL });
            //             parcela.setValue({ fieldId: "custrecord_rsc_cnab_inst_status_ls", value: "3" });
            //             parcela.save({ ignoreMandatoryFields: true });
            //             isparcela_1 = true;
            //             console.log("parcela.save()", parcela);
            //             console.log("afterSubmit", "parcela salva");
            //         }
            //     });
            //     if (issalvado_1 && isparcela_1) {
            //         // var appp = record_1.default.load({ id: registro.id, type: "customrecord_lrc_confirm_aprov_cnab" });
            //         registro.setValue({ fieldId: "custrecord_lote_aprovado", value: true });
            //         registro.save({ ignoreMandatoryFields: true });
            //         var url = url_1.default.resolveRecord({
            //             recordType:'customrecord_lrc_confirm_aprov_cnab',
            //             recordId: registro.id
            //         })
            //         window.location.replace(url)
            //         console.log("appp", registro);
            //     }
            // }
            // else {
            //     console.log("teste1", "nao mandou os arquivos");
            // }
        }
        catch (e) {
            console.log("Erro afterSubmit", e);
        }
    }
    exports.aprovar = aprovar
    function build_line(form, details, linhas) {
        try {
            /*  console.log("form build_line " + form);
             console.log("details build_line " + details);
     
             console.log("linhas build_line " + linhas); */
            for (var j = 0; j < linhas; j++) {
                /* console.log("details build_line ");
                console.log(details[j]); */
                var newLine = form.selectNewLine({ sublistId: "custpage_lrc_detalhes" });
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_subsidiaria", value: details[j]["subsidiaria"] });
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_id", value: Number(details[j]["id_titulo"]) });
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_tran_id", value: Number(details[j]["id_tran"]) });
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_fornecedor", value: details[j]["fornecedor"] });
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_vencimento", value: details[j]["vencimento"] });
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_detalhes", fieldId: "custpage_lrc_detalhes_valor", value: details[j]["valor_total"] });
                newLine.commitLine({ sublistId: "custpage_lrc_detalhes" });
            }
        }
        catch (error) {
            console.log("Erro build_line " + error);
        }
    }
    function build_line_subsidiary(details, linhas) {
        try {
            var rec = currentRecord_1.default.get();
            console.log(details);
            for (var i = 0; i < linhas; i++) {
                var newLine = rec.selectNewLine({ sublistId: "custpage_lrc_sublist" });
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_sublist", fieldId: "custpage_lrc_sublist_subsidiaria", value: details[i]["subsidiaria"] });
                if (details[i]["banco"] == "")
                    details[i]["banco"] = "Não Informado";
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_sublist", fieldId: "custpage_lrc_sublist_banco", value: details[i]["banco"] });
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_sublist", fieldId: "custpage_lrc_sublist_valor_total", value: currencyMask(Number(details[i]["valor_total"]).toFixed(2)) });
                newLine.setCurrentSublistValue({ sublistId: "custpage_lrc_sublist", fieldId: "custpage_lrc_sublist_quantidade", value: Number(details[i]["quantidade"]).toFixed() });
                
                // newLine.setCurrentSublistValue({sublistId: "custpage_lrc_sublist", fieldId: "custpage_link", value: url })
                newLine.commitLine({ sublistId: "custpage_lrc_sublist" });
            }
        }
        catch (error) {
            console.log("Erro build_line " + error);
        }
    }
    function currencyMask(x) {
        return x.toString().replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }
});
