/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * SuitletCNAB.ts
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget"], function (require, exports, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    //import Record from "N/record";
    //import CurrentRecord from "N/currentRecord";
    var onRequest = function (ctx) {
        var form = UI.createForm({
            title: "CRIAÇÃO DE LOTES CNAB"
        });
        form.clientScriptModulePath = "./DetalhesCNAB.js";
        //CABEÇALHO
        //let selection_field =
        //form.addField({ id: "custpage_lrc_sub_field", label: "Selecione a subsidiaria para detalhamento", type: UI.FieldType.SELECT}); //Selecao de subsidiaria
        form.addField({ id: "custpage_lrc_idate", label: "Data início", source: "IDate", type: UI.FieldType.DATE }); //Selecao de data inicial
        form.addField({ id: "custpage_lrc_fdate", label: "Data final", source: "FDate", type: UI.FieldType.DATE }); //Selecao de data final
        // form.addField({ id: "custpage_lrc_aprovador1", label: "Aprovador 1", type: UI.FieldType.SELECT, source: "employee" });
        // form.addField({ id: "custpage_lrc_aprovador2", label: "Aprovador 2", type: UI.FieldType.SELECT, source: "employee" });
        // form.addField({ id: "custpage_lrc_checkbox1", label: "Selecionar Todos (Detalhes CNAB)", type: UI.FieldType.CHECKBOX }); //Checkbox de selecionar todos
        form.addField({ id: "custpage_lrc_subsidiaria", label: "Subsidiaria", type: UI.FieldType.SELECT, source: "subsidiary" });
        form.addButton({ id: "custpage_lrc_buscacnabs", label: "BUSCAR LOTES", functionName: "buscaCNABs" }); //Botao Buscar CNAB
        form.addButton({ id: "custpage_lrc_aprovarcnabs", label: "CRIAR LOTE CNAB", functionName: "criarLote" });
        form.addField({ id: "custpage_lrc_nome_lote_cnab", label: "NOMEAR O LOTE", type: UI.FieldType.TEXT });
        form.addField({ id: "custpage_lrc_consulta", label: "Resultado consulta", type: UI.FieldType.TEXT }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN });
        form.addField({ id: "custpage_lrc_consulta_selected", label: "Resultado consulta selecionada", type: UI.FieldType.TEXT }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN });
        //SELEÇÃO A APROVAR
        var sublist = form.addSublist({ id: "custpage_lrc_sublist", label: "Prestações por subsidiarias", type: UI.SublistType.INLINEEDITOR });
        sublist.addField({ id: "custpage_lrc_sublist_checkbox", type: UI.FieldType.CHECKBOX, label: "Seleção de Subsidiarias" });
        sublist.addField({ id: "custpage_lrc_sublist_subsidiaria", type: UI.FieldType.SELECT, label: "Subsidiaria", source: 'subsidiary' });
        sublist.addField({ id: "custpage_lrc_sublist_banco", type: UI.FieldType.TEXT, label: "Banco" });
        sublist.addField({ id: "custpage_lrc_sublist_valor_total", type: UI.FieldType.TEXT, label: "Valor Total" });
        sublist.addField({ id: "custpage_lrc_sublist_quantidade", type: UI.FieldType.TEXT, label: "Numero de CNABs" });
        sublist.addButton({ id: "custpage_ver_detalhes", label: "Ver Detalhes", functionName: "detalhes" });
        // var link = sublist.addField({
        //     id: "custpage_link",
        //     type: UI.FieldType.URL,
        //     label: 'Link'
        // })
        // link.linkText = 'Visualizar';
        // link.updateDisplayType({displayType: UI.FieldDisplayType.INLINE})
        
        //DETALHES DOs CNABs
        // var detalhe = form.addSublist({ id: "custpage_lrc_detalhes", label: "Detalhes do CNAB", type: UI.SublistType.INLINEEDITOR });
        // detalhe.addField({ id: "custpage_lrc_detalhes_checkbox", type: UI.FieldType.CHECKBOX, label: "Seleção de CNABs" });
        // detalhe.addField({ id: "custpage_lrc_detalhes_subsidiaria", type: UI.FieldType.TEXT, label: "Subsidiaria Selecionada" });
        // detalhe.addField({ id: "custpage_lrc_detalhes_id", type: UI.FieldType.TEXT, label: "Id Título" });
        // detalhe.addField({ id: "custpage_lrc_tran_id", type: UI.FieldType.TEXT, label: "Id tran." });
        // detalhe.addField({ id: "custpage_lrc_detalhes_fornecedor", type: UI.FieldType.TEXT, label: "Fornecedor" });
        // detalhe.addField({ id: "custpage_lrc_detalhes_vencimento", type: UI.FieldType.TEXT, label: "Vencimento" });
        // detalhe.addField({ id: "custpage_lrc_detalhes_valor", type: UI.FieldType.TEXT, label: "Valor" });
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
});
