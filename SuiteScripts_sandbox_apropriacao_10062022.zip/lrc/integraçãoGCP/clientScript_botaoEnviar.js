/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *
 * avaliacaoDeFornecedor.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/log", "./lib/parser"], function (require, exports, currentRecord_1, log_1, parser_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.botaoEnviar = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    log_1 = __importDefault(log_1);
    parser_1 = __importDefault(parser_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var botaoEnviar = function () {
        var record = currentRecord_1.default.get();
        var valorCampoDocumento = record.getValue({
            fieldId: 'custpage_lrc_anexar_documento',
        });
        log_1.default.error('getValue', valorCampoDocumento);
        console.log('getValue' + valorCampoDocumento);
        log_1.default.error('getValue', parser_1.default.parseCSV(valorCampoDocumento, ";"));
        console.log('getValue' + parser_1.default.parseCSV(valorCampoDocumento, ";"));
    };
    exports.botaoEnviar = botaoEnviar;
});
