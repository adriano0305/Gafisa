/**
* @NAPIVersion 2.0
* @NScriptType Restlet
*
* Restlet_operacaoPlanejada.ts
*
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/search"], function (require, exports, Log, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.post = void 0;
    Log = __importStar(Log);
    search_1 = __importDefault(search_1);
    var post = function (ctx) {
        var dataInicio = ctx.dataInicio;
        var dataFinal = ctx.dataFinal;
        var arrayProcessaPu = [];
        var arrayProcessaLa = [];
        var arrayProcessaIn = [];
        var arrayProcessaSa = [];
        var arrayProcessaVe = [];
        var jsonObjPu = {};
        var jsonObjLa = {};
        var jsonObjIn = {};
        var jsonObjSa = {};
        var jsonObjVe = {};
        var filters = [
            ['trandate', search_1.default.Operator.ONORAFTER, dataInicio],
            "AND",
            ['trandate', search_1.default.Operator.ONORBEFORE, dataFinal],
            "AND",
            ['mainline', 'is', 'T']
        ];
        var columns = [
            'trandate',
            'tranid',
            'duedate',
            'account',
            'class',
            'currency',
            'total',
            'entity',
            'lastModifiedDate'
        ];
        function montarJson(result) {
            var obj = {};
            //  obj['integrationType'] = "" //result.getValue("")
            //  obj['scenario'] = "" //result.getValue("")
            //  obj['businessUnit'] = "" //result.getValue("")
            //  obj['originSystem'] = "" //result.getValue("")
            //  obj['externalcode'] = result.getValue("tranid")
            //  obj['dateOfIssue'] = result.getValue("trandate")
            //  obj['dueDate'] = result.getValue("duedate")
            //  obj['payday'] = result.getValue("trandate")
            //  obj['description'] = result.getValue("memo")
            //  obj['observation'] = "" //result.getValue("")
            //  obj['documentType'] = result.getValue("custbody4")
            //  obj['documentNumber'] = result.getValue("transactioNumber")
            //  obj['accountingAccountPlan'] = "" //result.getValue("")
            //  obj['costCenterPlan'] = "" //result.getValue("")
            //  obj['currentAccount'] = result.getValue("custbody_lrc_invoice_prev_pag")
            //  obj['paymentNumber'] = "" //result.getValue("")
            //  obj['eventType'] = "" //result.getValue("")
            //  obj['value'] = result.getValue("total")
            //  obj['valueBussiness'] = "" //result.getValue("")
            //  obj['conversionBusiness'] = result.getValue("total")
            //  obj['valueAccount'] = result.getValue("total")
            //  obj['conversionAccount'] = result.getValue("exchangerate")
            //  obj['fixedRateAccount'] = "" //result.getValue("")
            //  obj['beneficiaryOrigin'] = "" //result.getValue("")
            //  obj['beneficiaryType'] = result.getValue("arAcct")
            //  obj['motionWay'] = result.getValue("")
            obj['accountingAccount'] = result.getValue("account");
            obj['costCenter'] = result.getValue("class");
            obj['currency'] = result.getValue("currency");
            obj['fixedRateBusiness'] = result.getValue("currency");
            obj['beneficiary'] = result.getValue("entity");
            return obj;
        }
        try {
            var purchaseorderSearchObj = search_1.default.create({
                type: "purchaseorder",
                filters: filters,
                columns: columns
            });
            purchaseorderSearchObj.run().each(function (result) {
                jsonObjPu = montarJson(result);
                arrayProcessaPu.push(jsonObjPu);
                return true;
            });
        }
        catch (e) {
            Log.error("Error", e);
        }
        search_1.default.create({
            type: "journalentry",
            filters: filters,
            columns: columns
        }).run().each(function (result) {
            Log.error("lancamento", result.getValue("trandate"));
            jsonObjLa = montarJson(result);
            arrayProcessaLa.push(jsonObjLa);
            //ctx.response.write({output: stringLancamento})
            return true;
        });
        search_1.default.create({
            type: "invoice",
            filters: filters,
            columns: columns
        }).run().each(function (result) {
            jsonObjIn = montarJson(result);
            arrayProcessaIn.push(jsonObjIn);
            return true;
        });
        search_1.default.create({
            type: "salesorder",
            filters: filters,
            columns: columns
        }).run().each(function (result) {
            jsonObjSa = montarJson(result);
            arrayProcessaSa.push(jsonObjSa);
            return true;
        });
        search_1.default.create({
            type: "vendorbill",
            filters: filters,
            columns: columns
        }).run().each(function (result) {
            jsonObjVe = montarJson(result);
            arrayProcessaVe.push(jsonObjVe);
            return true;
        });
        var objFinal = {};
        objFinal = [arrayProcessaPu, arrayProcessaLa, arrayProcessaIn, arrayProcessaSa, arrayProcessaVe];
        return objFinal;
    };
    exports.post = post;
});
