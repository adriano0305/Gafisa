/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *
 * EFD – INTEGRAÇÃO JUNIX BAIXA AO PAGAMENTO
 * Suitelet
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/search", "N/log", "N/runtime"], function (require, exports, record_1, search_1, log_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    runtime_1 = __importDefault(runtime_1);
    var onRequest = function (ctx) {
        //verificando se o metodo usado é o POST
        if (ctx.request.method == "POST") {
            var requestBody = JSON.parse(ctx.request.body); //variavel para ter acesso a todo o body do JSON
            //variavel para criar um registro sobre os JSON não processados
            var cobrancaId_1, fornecedorId_1, nomeFornecedor = void 0;
            try {
                requestBody.forEach(function (element) {
                    log_1.default.error('element', element);
                    Object.keys(element).forEach(function (key) {
                        log_1.default.error('key', key);
                        return true;
                    });
                    //atributos fornecedor
                    var cedenteCPFCNPJ = search_1.default.create({
                        type: "vendor",
                        filters: [
                            ['custentity_enl_cnpjcpf', 'IS', element.CedenteCPFCPNJ]
                        ],
                        columns: ['custentity_enl_cnpjcpf']
                    }).run().getRange({
                        start: 0,
                        end: 1
                    });
                    if (JSON.stringify(element)) {
                        //caso seja encontrado um cpf ou cnpj 
                        if (cedenteCPFCNPJ[0]) { //ATUALIZAR FORNECEDOR
                            // Log.error('J' + element.SacadoCPFCPNJ);
                            //atributos subsidiaria
                            var subsidiary = search_1.default.create({
                                type: "subsidiary",
                                filters: [
                                    ['taxidnum', 'IS', element.SacadoCPFCPNJ]
                                ],
                                columns: ['taxidnum'] //taxidnum == ID IMPOSTO NO NETSUITE DA SUBSIDIARIA
                            }).run().getRange({
                                start: 0,
                                end: 1
                            });
                            // Log.error('SUB' + subsidiary[0].id);
                            var oldFornecedor = record_1.default.load({
                                type: 'vendor',
                                id: cedenteCPFCNPJ[0].id
                            });
                            oldFornecedor.getValue({
                                fieldId: 'custentity_enl_cnpjcpf', //CedenteCPFCPNJ
                                // value: element.CedenteCPFCPNJ
                            });
                            oldFornecedor.setValue({
                                fieldId: 'subsidiary',
                                value: subsidiary[0].id
                            });
                            if (cedenteCPFCNPJ.length >= 12) {
                                oldFornecedor.setValue({
                                    fieldId: 'isperson',
                                    value: 'F'
                                });
                                oldFornecedor.setValue({
                                    fieldId: 'companyname',
                                    value: element.CedenteNome
                                });
                            }
                            else {
                                //atributos fornecedor
                                oldFornecedor.setValue({
                                    fieldId: 'isperson',
                                    value: 'T'
                                });
                                var name_1 = getSplitNames(element.CedenteNome);
                                log_1.default.error("name: ", name_1);
                                oldFornecedor.setValue({
                                    fieldId: 'firstname',
                                    value: name_1.firstName
                                });
                                oldFornecedor.setValue({
                                    fieldId: 'lastname',
                                    value: name_1.lastName
                                });
                                oldFornecedor.setValue({
                                    fieldId: 'salution',
                                    value: element.CedenteNome
                                });
                            }
                            //atributos cobrança
                            oldFornecedor.setValue({
                                fieldId: 'custbody_id_empreendimento',
                                value: element.IdEmpreendimento
                            });
                            oldFornecedor.setValue({
                                fieldId: 'custbody_rsc_bloco',
                                value: element.IdBloco
                            });
                            oldFornecedor.setValue({
                                fieldId: 'custbody_lrc_codigo_unidade',
                                value: element.IdUnidade
                            });
                            oldFornecedor.setValue({
                                fieldId: 'custbody_rsc_id_despesa',
                                value: element.IdDespesa
                            });
                            oldFornecedor.setValue({
                                fieldId: 'custbody_type_expense',
                                value: element.TipoDespesa
                            });
                            oldFornecedor.setValue({
                                fieldId: 'duedate',
                                value: element.DataVencimento
                            });
                            oldFornecedor.setValue({
                                fieldId: 'custbody_valor_despesa',
                                value: element.ValorDespesa
                            });
                            oldFornecedor.setValue({
                                fieldId: 'custbody10',
                                value: element.StatusDespesa
                            });
                            oldFornecedor.setValue({
                                fieldId: 'custbody9',
                                value: element.StatusUnidade
                            });
                            // setValue({
                            //     fieldId: '',  
                            //     value: element.BoletoArquivo
                            //});
                            oldFornecedor.setValue({
                                fieldId: 'custbody11',
                                value: element.LinhaDigitalvel
                            });
                            try {
                                fornecedorId_1 = cedenteCPFCNPJ[0].id;
                                oldFornecedor.save({
                                    ignoreMandatoryFields: true
                                });
                                // ctx.response.write({ output: 'Sucesso em atualizar o fornecedor' });
                            }
                            catch (erro) {
                                log_1.default.error("Error", erro);
                                ctx.response.write({ output: 'Erro ao atualizar o fornecedor. ' });
                                return;
                            }
                        }
                        else { // CRIAR UM FORNECEDOR
                            var newFornecedor = record_1.default.create({
                                type: 'vendor' //id do registro para integração no netsuite
                            });
                            var subsidiary = search_1.default.create({
                                type: "subsidiary",
                                filters: [
                                    ['taxidnum', 'IS', element.SacadoCPFCPNJ]
                                ],
                                columns: ['taxidnum'] //taxidnum == ID IMPOSTO NO NETSUITE DA SUBSIDIARIA
                            }).run().getRange({
                                start: 0,
                                end: 1
                            });
                            //atributos fornecedor
                            if (cedenteCPFCNPJ.length >= 12) {
                                newFornecedor.setValue({
                                    fieldId: 'isperson',
                                    value: 'F'
                                });
                                newFornecedor.setValue({
                                    fieldId: 'companyname',
                                    value: element.CedenteNome
                                });
                            }
                            else {
                                //atributos fornecedor
                                newFornecedor.setValue({
                                    fieldId: 'isperson',
                                    value: 'T'
                                });
                                var name_2 = getSplitNames(element.CedenteNome);
                                log_1.default.error("name: ", name_2);
                                newFornecedor.setValue({
                                    fieldId: 'firstname',
                                    value: name_2.firstName
                                });
                                newFornecedor.setValue({
                                    fieldId: 'lastname',
                                    value: name_2.lastName
                                });
                                newFornecedor.setValue({
                                    fieldId: 'salution',
                                    value: element.CedenteNome
                                });
                            }
                            newFornecedor.setValue({
                                fieldId: 'subsidiary',
                                value: subsidiary[0].id
                            });
                            //atributos fornecedor
                            newFornecedor.setValue({
                                fieldId: 'custentity_lrc_campo_status_cadastro',
                                value: 1 //'Novo Fornecedor'
                            });
                            newFornecedor.setValue({
                                fieldId: 'custentity_enl_cnpjcpf',
                                value: element.CedenteCPFCPNJ
                            });
                            newFornecedor.setValue({
                                fieldId: 'custentity_agencia',
                                value: element.CedenteAgencia
                            });
                            newFornecedor.setValue({
                                fieldId: 'custentity_lrc_ced_conta',
                                value: element.CedenciaConta
                            });
                            newFornecedor.setValue({
                                fieldId: 'custentity_lrc_ced_digito_conta',
                                value: element.CedenciaDigitoConta
                            });
                            newFornecedor.setValue({
                                fieldId: 'custentity_lrc_ced_digito_conta',
                                value: element.CedenciaDigitoConta
                            });
                            try {
                                fornecedorId_1 = newFornecedor.save({
                                    ignoreMandatoryFields: true
                                });
                                // ctx.response.write({ output: 'Sucesso em criar um fornecedor' });
                            }
                            catch (erro) {
                                log_1.default.error("Error", erro);
                                ctx.response.write({ output: 'Erro ao criar/salvar um novo fornecedor. ', erro: erro });
                                return;
                            }
                        }
                        var record = record_1.default.create({
                            type: 'vendorbill' //id do registro para integração no netsuite
                        });
                        //atributos cobrança
                        record.setValue({
                            fieldId: 'entity',
                            value: fornecedorId_1
                        });
                        record.setValue({
                            fieldId: 'custbody_id_empreendimento',
                            value: element.IdEmpreendimento
                        });
                        record.setValue({
                            fieldId: 'custbody_rsc_bloco',
                            value: element.IdBloco
                        });
                        record.setValue({
                            fieldId: 'custbody_lrc_codigo_unidade',
                            value: element.IdUnidade
                        });
                        record.setValue({
                            fieldId: 'custbody_rsc_id_despesa',
                            value: element.IdDespesa
                        });
                        record.setValue({
                            fieldId: 'custbody_type_expense',
                            value: element.TipoDespesa
                        });
                        //tratativa de erro da data
                        var DataVencimento = element.DataVencimento.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
                        DataVencimento = new Date(element.DataVencimento);
                        record.setValue({
                            fieldId: 'duedate',
                            value: DataVencimento
                        });
                        record.setValue({
                            fieldId: 'custbody_valor_despesa',
                            value: element.ValorDespesa
                        });
                        record.setValue({
                            fieldId: 'custbody10',
                            value: element.StatusDespesa
                        });
                        record.setValue({
                            fieldId: 'custbody9',
                            value: element.StatusUnidade
                        });
                        // record.setValue({
                        //     fieldId: '',  
                        //     value: element.BoletoArquivo
                        // });
                        record.setValue({
                            fieldId: 'custbody11',
                            value: element.LinhaDigitalvel
                        });
                        var contaSublista = runtime_1.default.getCurrentScript().getParameter({
                            name: 'custscript_lrc_parqglobal_conta_sublista'
                        });
                        var line = record.getLineCount({
                            sublistId: 'expense'
                        });
                        record.setSublistValue({
                            line: line,
                            sublistId: 'expense',
                            fieldId: 'account',
                            value: contaSublista
                        });
                        record.setSublistValue({
                            line: line,
                            sublistId: 'expense',
                            fieldId: 'grossamt',
                            value: element.ValorDespesa
                        });
                        try {
                            cobrancaId_1 = record.save({
                                ignoreMandatoryFields: true
                            });
                            ctx.response.write({ output: 'Sucesso a salvar a cobrança' });
                        }
                        catch (erro) {
                            log_1.default.error("Error", erro);
                            ctx.response.write({ output: 'Erro ao salvar a cobrança. ' });
                            return;
                        }
                    }
                    else {
                        ctx.response.write({ output: 'Não foi possível ler o JSON' });
                    }
                });
            }
            catch (error) {
                log_1.default.error('Error', error);
                ctx.response.write({ output: 'Algum valor do campo é inválido ou está vazio!' });
            }
        }
        else {
            ctx.response.write({ output: 'Método usado não é POST!' });
        }
    };
    exports.onRequest = onRequest;
    //função que recebe o nome completo da pessoa e separa ele em primeiro e ultimo nome para o registro no netsuite
    function getSplitNames(name) {
        var splitName = name.split(' ');
        var firstName = '';
        var lastName = '';
        splitName.forEach(function (word, index) {
            if (index === 0) {
                firstName = word;
            }
            else {
                lastName += ' ' + word; //concatena todos os sobrenomes
            }
        });
        return {
            firstName: firstName,
            lastName: lastName
        };
    }
});
