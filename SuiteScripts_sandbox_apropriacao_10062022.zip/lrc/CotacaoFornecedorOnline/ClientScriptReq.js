/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScriptReq.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/url"], function (require, exports, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.openEnviarEmail = exports.pageInit = void 0;
    url_1 = __importDefault(url_1);
    exports.pageInit = function () {
    };
    exports.openEnviarEmail = function () {
        var url = url_1.default.resolveScript({
            scriptId: "customscript_lrc_enviar_email_st",
            deploymentId: "customdeploy_lrc_enviar_email_st",
            params: { reqId: getUrlParameter("id") },
            returnExternalUrl: false
        });
        window.open(url);
    };
    var getUrlParameter = function (sParam) {
        var sPageURL = window.location.search.substring(1), sURLVariables = sPageURL.split('&'), sParameterName, i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return typeof sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
        return false;
    };
});
