/**
 *@NApiVersion 2.x
*@NScriptType UserEventScript
*
* UserEventSublistMensagemReq.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/ui/serverWidget", "N/url"], function (require, exports, search_1, serverWidget_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    search_1 = __importDefault(search_1);
    serverWidget_1 = __importDefault(serverWidget_1);
    url_1 = __importDefault(url_1);
    var MAX_SUBLIST_SIZE = 300;
    exports.beforeLoad = function (ctx) {
        var form = ctx.form;
        if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.VIEW) {
            var recordId = ctx.newRecord.id;
            buildForm(form);
            buildSublist(recordId, form);
        }
    };
    var buildForm = function (form) {
        form.addTab({
            label: "Mensagens da Requisição",
            id: "custpage_lrc_mensagem_tab"
        });
    };
    var buildSublist = function (recordId, form) {
        var msgSublist = form.addSublist({
            tab: 'custpage_lrc_mensagem_tab',
            id: "custpage_lrc_mensagem_sublist",
            type: serverWidget_1.default.SublistType.LIST,
            label: "Mensagens da Requisição"
        });
        msgSublist.addField({
            label: "Registro de Mensagem",
            id: "custpage_lrc_mensagem_registro",
            type: serverWidget_1.default.FieldType.TEXT
        });
        msgSublist.addField({
            label: 'Destinatário',
            type: serverWidget_1.default.FieldType.TEXT,
            id: 'custpage_lrc_dest'
        });
        msgSublist.addField({
            label: 'Assunto',
            type: serverWidget_1.default.FieldType.TEXT,
            id: 'custpage_lrc_assunto'
        });
        msgSublist.addField({
            label: 'Data',
            type: serverWidget_1.default.FieldType.DATE,
            id: 'custpage_lrc_req_data'
        });
        // Popula Sublista
        var lineIndex = 0;
        search_1.default.create({
            type: 'customrecord_lrc_mensagens_requisicao',
            columns: [
                'custrecord_lrc_dest',
                'custrecord_lrc_assunto',
                'custrecord_lrc_mensagem',
                'custrecord_lrc_req_data'
            ],
            filters: [
                ['custrecord_lrc_requisicao', 'IS', recordId.toString()]
            ]
        }).run().each(function (result) {
            msgSublist.setSublistValue({
                id: 'custpage_lrc_dest',
                line: lineIndex,
                value: result.getValue('custrecord_lrc_dest').toString().substring(0, MAX_SUBLIST_SIZE)
            });
            msgSublist.setSublistValue({
                id: 'custpage_lrc_assunto',
                line: lineIndex,
                value: result.getValue('custrecord_lrc_assunto').toString().substring(0, MAX_SUBLIST_SIZE)
            });
            var url = url_1.default.resolveRecord({
                recordId: result.id,
                recordType: 'customrecord_lrc_mensagens_requisicao'
            });
            msgSublist.setSublistValue({
                id: 'custpage_lrc_mensagem_registro',
                line: lineIndex,
                value: "<a href=" + url + " style=\"color:blue\">Visualizar</a>"
            });
            msgSublist.setSublistValue({
                id: 'custpage_lrc_req_data',
                line: lineIndex,
                value: result.getValue('custrecord_lrc_req_data')
            });
            lineIndex += 1;
            return true;
        });
    };
});
