/**
 *@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteleVisualizarEmail.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search"], function (require, exports, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    search_1 = __importDefault(search_1);
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var mensagemId = ctx.request.parameters.mensagemId;
            var mensagemLookup = search_1.default.lookupFields({
                type: 'customrecord_lrc_mensagens_requisicao',
                columns: [
                    'custrecord_lrc_mensagem',
                    'custrecord_lrc_assunto'
                ],
                id: mensagemId
            });
            var content = String(mensagemLookup['custrecord_lrc_mensagem']);
            var subject = String(mensagemLookup['custrecord_lrc_assunto']);
            // Build html
            var html = "\n        <!DOCTYPE html>\n            <html>\n                <head>\n                    <title>\n                        Visualiza\u00E7\u00E3o de email\n                    </title>\n                    " + buildStyle() + "\n                </head>\n                <body>\n                    " + buildSubject(subject) + "\n                    <br>\n                    " + buildContent(content) + "\n                </body>\n            </html>\n        ";
            ctx.response.write({ output: html });
        }
    };
    var buildStyle = function () {
        var html = "<style type=\"text/css\">";
        html += "\n    div.content {\n        width: 1250px;\n        border: 1px solid black;\n        padding: 10px;\n        margin: 0px;\n      }\n    ";
        html += "</style>";
        return html;
    };
    var buildSubject = function (subject) {
        var html = "<div>";
        html += "<strong>Assunto: </strong>";
        html += subject;
        html += "</div>";
        return html;
    };
    var buildContent = function (content) {
        var html = "<div class=\"content\">";
        html += content;
        html += "</div>";
        return html;
    };
});
