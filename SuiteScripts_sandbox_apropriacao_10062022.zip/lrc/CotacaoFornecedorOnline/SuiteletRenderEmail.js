/**
 *@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteletRenderEmail.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/render", "N/encode"], function (require, exports, render_1, encode_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    render_1 = __importDefault(render_1);
    encode_1 = __importDefault(encode_1);
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "POST") {
            var requestBody = JSON.parse(ctx.request.body);
            ctx.response.write({
                output: JSON.stringify(renderEmail(requestBody.templateId, requestBody.transactionId)),
            });
        }
    };
    var renderEmail = function (templateId, transactionId) {
        var mergeResult = render_1.default.mergeEmail({
            templateId: templateId,
            transactionId: transactionId
        });
        var emailSubject = mergeResult.subject;
        var emailBody = mergeResult.body;
        var responseBody = {
            content: encode_1.default.convert({
                string: emailBody,
                inputEncoding: encode_1.default.Encoding.UTF_8,
                outputEncoding: encode_1.default.Encoding.BASE_64
            }),
            subject: encode_1.default.convert({
                string: emailSubject,
                inputEncoding: encode_1.default.Encoding.UTF_8,
                outputEncoding: encode_1.default.Encoding.BASE_64
            })
        };
        return responseBody;
    };
});
