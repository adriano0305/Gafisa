/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScriptVisualizarMensagem.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/url", "N/currentRecord"], function (require, exports, url_1, currentRecord_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.pageInit = exports.visualizarMensagem = void 0;
    url_1 = __importDefault(url_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    exports.visualizarMensagem = function () {
        var currRecord = currentRecord_1.default.get();
        var url = url_1.default.resolveScript({
            scriptId: "customscript_lrc_st_view_email",
            deploymentId: "customdeploy_lrc_st_view_email",
            params: { mensagemId: currRecord.id }
        });
        console.log(url);
        window.open(url);
    };
    exports.pageInit = function () {
    };
});
