/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScriptTelaEnviarEmail.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/https", "N/url", "N/currentRecord", "N/record", "N/runtime"], function (require, exports, https_1, url_1, currentRecord_1, record_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.preview = exports.cancelar = exports.saveRecord = exports.validateLine = exports.validateField = exports.fieldChanged = exports.pageInit = void 0;
    https_1 = __importDefault(https_1);
    url_1 = __importDefault(url_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    record_1 = __importDefault(record_1);
    runtime_1 = __importDefault(runtime_1);
    var decodeStr = function (str) {
        // Chama um Suitelet que decodifica a string de BASE64 para UTF8
        try {
            var url = url_1.default.resolveScript({
                scriptId: "customscript_lrc_decode_string",
                deploymentId: "customdeploy_lrc_decode_string",
                returnExternalUrl: true
            });
            var response = https_1.default.post({
                url: url,
                body: JSON.stringify({
                    input: str
                })
            });
            if (response.code.toString().substring(0, 1) == "2") {
                return response.body;
            }
            else {
                throw "Ocorreu um erro ao decodificar o email: " + response.body;
            }
        }
        catch (e) {
            throw "Ocorreu um erro ao decodificar o email: " + e;
        }
    };
    var renderTemplate = function (templateId, reqId) {
        try {
            // Envia uma requisição para um Suitelet que renderiza o email
            var requestBody = {
                transactionId: Number(reqId),
                templateId: Number(templateId)
            };
            console.log(requestBody);
            var url = url_1.default.resolveScript({
                scriptId: "customscript_lrc_render_email_st",
                deploymentId: "customdeploy_lrc_render_email_st",
                returnExternalUrl: true
            });
            console.log(url);
            var response = https_1.default.post({
                url: url,
                body: JSON.stringify(requestBody)
            });
            // Recupera o corpo da requisição
            if (response.code.toString().substring(0, 1) == "2") {
                try {
                    var responseBody = JSON.parse(response.body);
                    responseBody.content = decodeStr(responseBody.content);
                    responseBody.subject = decodeStr(responseBody.subject);
                    return responseBody;
                }
                catch (e) {
                    throw "" + e;
                }
            }
            else {
                throw "Ocorreu um erro ao renderizar o email: " + response.body;
            }
        }
        catch (e) {
            throw "Ocorreu um erro ao renderizar o email: " + e;
        }
    };
    var getUrlParameter = function (sParam) {
        var sPageURL = window.location.search.substring(1), sURLVariables = sPageURL.split('&'), sParameterName, i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return typeof sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
        return false;
    };
    var loadEmailToBodyFields = function (currRecord) {
        var templateId = currRecord.getValue("custpage_lrc_modelo_email");
        if (!templateId)
            return;
        var reqId = getUrlParameter("reqId");
        if (!reqId)
            return;
        try {
            var renderedEmail = renderTemplate(String(templateId), reqId);
            currRecord.setValue({
                fieldId: "custpage_lrc_assunto",
                value: renderedEmail.subject
            });
            currRecord.setValue({
                fieldId: "custpage_lrc_corpo",
                value: renderedEmail.content
            });
        }
        catch (e) {
            alert(e);
        }
    };
    var getRecipientCheckbox = function (checkboxFieldId, recipientFieldId, sublistId, recipient, currRecord) {
        var lineCount = currRecord.getLineCount({
            sublistId: sublistId
        });
        var currLineIndex = currRecord.getCurrentSublistIndex({
            sublistId: sublistId
        });
        for (var line = 0; line < lineCount; line++) {
            if (line != currLineIndex) {
                var lineRecipient = currRecord.getSublistValue({
                    sublistId: sublistId,
                    fieldId: recipientFieldId,
                    line: line
                });
                if (lineRecipient == recipient) {
                    var checkboxValue = currRecord.getSublistValue({
                        sublistId: sublistId,
                        fieldId: checkboxFieldId,
                        line: line
                    });
                    if (checkboxValue) {
                        return true;
                    }
                }
            }
        }
        return false;
    };
    exports.pageInit = function (ctx) {
        loadEmailToBodyFields(ctx.currentRecord);
    };
    exports.fieldChanged = function (ctx) {
        if (ctx.fieldId == "custpage_lrc_modelo_email" && !ctx.sublistId) {
            if (ctx.currentRecord.getValue("custpage_lrc_modelo_email")) {
                loadEmailToBodyFields(ctx.currentRecord);
            }
            else {
                ctx.currentRecord.setValue({
                    fieldId: "custpage_lrc_corpo",
                    value: ""
                });
                ctx.currentRecord.setValue({
                    fieldId: "custpage_lrc_assunto",
                    value: ""
                });
            }
        }
    };
    exports.validateField = function (ctx) {
        if (ctx.sublistId == "custpage_lrc_sublist_dest") {
            var currCheckboxValue = ctx.currentRecord.getCurrentSublistValue({
                sublistId: ctx.sublistId,
                fieldId: ctx.fieldId
            });
            if (!currCheckboxValue)
                return true;
            var checkboxToCheck = {
                "custpage_lrc_is_to": "PARA",
                "custpage_lrc_is_cc": "CC",
                "custpage_lrc_is_bcc": "BCC",
            };
            if (Object.keys(checkboxToCheck).indexOf(ctx.fieldId) >= 0) {
                var recipient = String(ctx.currentRecord.getCurrentSublistValue({
                    sublistId: ctx.sublistId,
                    fieldId: "custpage_lrc_dests"
                }));
                var recipientName = String(ctx.currentRecord.getCurrentSublistText({
                    sublistId: ctx.sublistId,
                    fieldId: "custpage_lrc_dests"
                }));
                var recipientCheckboxValue = getRecipientCheckbox(ctx.fieldId, "custpage_lrc_dests", ctx.sublistId, recipient, ctx.currentRecord);
                var label = checkboxToCheck[ctx.fieldId];
                if (recipientCheckboxValue) {
                    alert("O campo \"" + label + "\" s\u00F3 pode ser preenchido uma \u00FAnica vez para o destinat\u00E1rio " + recipientName);
                    return false;
                }
            }
        }
        return true;
    };
    var hasCheckbox = function (currRecord, sublistId) {
        var fieldsToCheck = [
            "custpage_lrc_is_to",
            "custpage_lrc_is_cc",
            "custpage_lrc_is_bcc",
        ];
        var hasCheckbox = false;
        fieldsToCheck.forEach(function (fieldId) {
            var fieldValue = currRecord.getCurrentSublistValue({
                fieldId: fieldId,
                sublistId: sublistId
            });
            if (fieldValue) {
                hasCheckbox = true;
                return true;
            }
            return false;
        });
        return hasCheckbox;
    };
    var isDestSublistValid = function (currRecord, sublistId) {
        var recipient = currRecord.getCurrentSublistValue({
            sublistId: sublistId,
            fieldId: "custpage_lrc_dests"
        });
        if (!recipient) {
            alert("O campo \"Destinat\u00E1rios Adicionais\" deve estar preenchido!");
            return false;
        }
        var recipientName = currRecord.getCurrentSublistText({
            sublistId: sublistId,
            fieldId: "custpage_lrc_dests"
        });
        var fieldsToCheck = {
            "custpage_lrc_is_to": "PARA",
            "custpage_lrc_is_cc": "CC",
            "custpage_lrc_is_bcc": "BCC",
        };
        var hasDupCheckbox = false;
        var lineCount = currRecord.getLineCount({
            sublistId: sublistId
        });
        var currLineIndex = currRecord.getCurrentSublistIndex({
            sublistId: sublistId
        });
        Object.keys(fieldsToCheck).forEach(function (fieldId) {
            if (hasDupCheckbox)
                return;
            var currFieldValue = currRecord.getCurrentSublistValue({
                fieldId: fieldId,
                sublistId: sublistId
            });
            if (!currFieldValue)
                return; // Se for false, nao tem problema
            for (var line = 0; line < lineCount; line++) {
                if (line != currLineIndex) {
                    var lineRecipient = currRecord.getSublistValue({
                        sublistId: sublistId,
                        fieldId: "custpage_lrc_dests",
                        line: line
                    });
                    var lineFieldValue = currRecord.getSublistValue({
                        sublistId: sublistId,
                        fieldId: fieldId,
                        line: line
                    });
                    if (lineFieldValue == currFieldValue && lineRecipient == recipient) {
                        hasDupCheckbox = true;
                        alert("O campo \"" + fieldsToCheck[fieldId] + "\" s\u00F3 pode ser preenchido uma \u00FAnica vez para o destinat\u00E1rio " + recipientName);
                        break;
                    }
                }
            }
            return false;
        });
        return !hasDupCheckbox;
    };
    exports.validateLine = function (ctx) {
        if (ctx.sublistId == "custpage_lrc_sublist_dest") {
            var flag = hasCheckbox(ctx.currentRecord, ctx.sublistId);
            if (!flag) {
                alert("Linha inv\u00E1lida: Os campos \"PARA\" ou \"CC\" ou \"BCC\" devem estar preenchidos");
                return false;
            }
            var isSublistValid = isDestSublistValid(ctx.currentRecord, ctx.sublistId);
            if (!isSublistValid)
                return false;
        }
        return true;
    };
    exports.saveRecord = function (ctx) {
        // Valida sublista de destinatários
        var lineCount = ctx.currentRecord.getLineCount({ sublistId: "custpage_lrc_sublist_dest" });
        if (lineCount <= 0) {
            alert("A sublista de destinatários não pode estar vazia!");
            return false;
        }
        // Valida campo "Modelo"
        var templateId = ctx.currentRecord.getValue("custpage_lrc_modelo_email");
        if (!templateId) {
            alert("O campo \"MODELO\" deve estar preenchido");
            return false;
        }
        return true;
    };
    exports.cancelar = function () {
        var currRecord = currentRecord_1.default.get();
        var reqId = currRecord.getValue("custpage_lrc_reqid");
        var url = url_1.default.resolveRecord({
            recordId: String(reqId),
            recordType: record_1.default.Type.PURCHASE_REQUISITION.toString(),
            isEditMode: true
        });
        window.location.replace(url);
    };
    exports.preview = function () {
        var currRecord = currentRecord_1.default.get();
        var reqId = Number(currRecord.getValue("custpage_lrc_reqid"));
        var templateId = Number(currRecord.getValue("custpage_lrc_modelo_email"));
        if (!templateId) {
            alert("O campo \"MODELO\" deve estar preenchido");
            return;
        }
        // Captura os contatos:
        var to = [];
        var cc = [];
        var bcc = [];
        var lineCount = currRecord.getLineCount({ sublistId: "custpage_lrc_sublist_dest" });
        var currLineIndex = currRecord.getCurrentSublistIndex({ sublistId: "custpage_lrc_sublist_dest" });
        // Captura o contato atual
        var currContact = {};
        currContact.email = String(currRecord.getCurrentSublistValue({
            sublistId: "custpage_lrc_sublist_dest",
            fieldId: "custpage_lrc_dests",
        }));
        currContact.name = String(currRecord.getCurrentSublistText({
            sublistId: "custpage_lrc_sublist_dest",
            fieldId: "custpage_lrc_dests",
        }));
        var isCurrToChecked = currRecord.getCurrentSublistValue({
            sublistId: "custpage_lrc_sublist_dest",
            fieldId: "custpage_lrc_is_to",
        });
        if (isCurrToChecked)
            to.push(currContact);
        var isCurrCcChecked = currRecord.getCurrentSublistValue({
            sublistId: "custpage_lrc_sublist_dest",
            fieldId: "custpage_lrc_is_cc",
        });
        if (isCurrCcChecked)
            cc.push(currContact);
        var isCurrBccChecked = currRecord.getCurrentSublistValue({
            sublistId: "custpage_lrc_sublist_dest",
            fieldId: "custpage_lrc_is_bcc",
        });
        if (isCurrBccChecked)
            bcc.push(currContact);
        // Captura demais contatos
        for (var line = 0; line < lineCount; line++) {
            if (line != currLineIndex) {
                var contact = {};
                contact.email = String(currRecord.getSublistValue({
                    sublistId: "custpage_lrc_sublist_dest",
                    fieldId: "custpage_lrc_dests",
                    line: line
                }));
                contact.name = String(currRecord.getSublistText({
                    sublistId: "custpage_lrc_sublist_dest",
                    fieldId: "custpage_lrc_dests",
                    line: line
                }));
                var isToChecked = currRecord.getSublistValue({
                    sublistId: "custpage_lrc_sublist_dest",
                    fieldId: "custpage_lrc_is_to",
                    line: line
                });
                if (isToChecked)
                    to.push(contact);
                var isCcChecked = currRecord.getSublistValue({
                    sublistId: "custpage_lrc_sublist_dest",
                    fieldId: "custpage_lrc_is_cc",
                    line: line
                });
                if (isCcChecked)
                    cc.push(contact);
                var isBccChecked = currRecord.getSublistValue({
                    sublistId: "custpage_lrc_sublist_dest",
                    fieldId: "custpage_lrc_is_bcc",
                    line: line
                });
                if (isBccChecked)
                    bcc.push(contact);
            }
        }
        var params = {
            transactionId: reqId,
            templateId: templateId,
            authorId: Number(runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_autor_email' })) || -5,
            to: to,
            cc: cc,
            bcc: bcc
        };
        console.log(params);
        var url = url_1.default.resolveScript({
            scriptId: "customscript_lrc_preview_email_st",
            deploymentId: "customdeploy_lrc_preview_email_st",
            params: { params: JSON.stringify(params) }
        });
        console.log(url);
        window.open(url);
    };
});
