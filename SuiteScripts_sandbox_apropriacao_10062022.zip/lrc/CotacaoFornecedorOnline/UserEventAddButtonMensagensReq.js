/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * UserEventAddButtonMensagensReq.js
 *
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeLoad = void 0;
    exports.beforeLoad = function (ctx) {
        var form = ctx.form;
        if (ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.VIEW) {
            form.clientScriptModulePath = "./ClientScriptVisualizarMensagem.js";
            form.addButton({
                label: "Visualizar Mensagem",
                functionName: "visualizarMensagem",
                id: "custpage_lrc_visualizar_mensagem"
            });
        }
    };
});
