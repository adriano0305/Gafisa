/**
 *@NApiVersion 2.x
*@NScriptType Suitelet
*
* SuiteletPreviewEnviarEmail.js
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/render", "N/record", "N/log"], function (require, exports, search_1, render_1, record_1, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    search_1 = __importDefault(search_1);
    render_1 = __importDefault(render_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    exports.onRequest = function (ctx) {
        if (ctx.request.method == "GET") {
            var params = JSON.parse(ctx.request.parameters.params);
            log_1.default.error("params", params);
            // Email info
            var email = renderEmail(params.templateId, params.transactionId);
            var content = email.content;
            var subject = email.subject;
            // Get author info
            var authorId = params.authorId;
            var employeeLookup = search_1.default.lookupFields({
                type: record_1.default.Type.EMPLOYEE.toString(),
                columns: [
                    "email",
                    "entityid"
                ],
                id: authorId
            });
            var authorEmail = String(employeeLookup["email"]);
            var authorName = String(employeeLookup["entityid"]);
            // Build html
            var html = "\n        <!DOCTYPE html>\n            <html>\n                <head>\n                    <title>\n                        Pr\u00E9-Visualiza\u00E7\u00E3o de e-mail\n                    </title>\n                    " + buildStyle() + "\n                </head>\n                <body>\n                    " + buildFrom(authorName, authorEmail) + "\n                    " + buildTo(params.to) + "\n                    " + buildCc(params.cc) + "\n                    " + buildBcc(params.bcc) + "\n                    " + buildSubject(subject) + "\n                    <br>\n                    " + buildContent(content) + "\n                </body>\n            </html>\n        ";
            ctx.response.write({ output: html });
        }
    };
    var buildStyle = function () {
        var html = "<style type=\"text/css\">";
        html += "\n    div.content {\n        width: 1250px;\n        border: 1px solid black;\n        padding: 10px;\n        margin: 0px;\n      }\n    ";
        html += "</style>";
        return html;
    };
    var buildFrom = function (authorName, authorEmail) {
        var html = "<div>";
        html += "<strong>De: </strong>";
        html += "\n        " + authorName + " &lt;" + authorEmail + "&gt;\n    ";
        html += "</div>";
        return html;
    };
    var buildTo = function (contacts) {
        var html = "<div>";
        html += "<strong>Para: </strong>";
        var contactStr = "";
        contacts.forEach(function (contact) {
            if (contact.name) {
                contactStr += contact.name + " (" + contact.email + "); ";
            }
            else {
                contactStr += contact.email + ";";
            }
        });
        html += contactStr;
        html += "</div>";
        return html;
    };
    var buildCc = function (contacts) {
        var html = "<div>";
        html += "<strong>CC: </strong>";
        var contactStr = "";
        contacts.forEach(function (contact) {
            if (contact.name) {
                contactStr += contact.name + " (" + contact.email + "); ";
            }
            else {
                contactStr += contact.email + ";";
            }
        });
        html += contactStr;
        html += "</div>";
        return html;
    };
    var buildBcc = function (contacts) {
        var html = "<div>";
        html += "<strong>BCC: </strong>";
        var contactStr = "";
        contacts.forEach(function (contact) {
            if (contact.name) {
                contactStr += contact.name + " (" + contact.email + "); ";
            }
            else {
                contactStr += contact.email + ";";
            }
        });
        html += contactStr;
        html += "</div>";
        return html;
    };
    var buildSubject = function (subject) {
        var html = "<div>";
        html += "<strong>Assunto: </strong>";
        html += subject;
        html += "</div>";
        return html;
    };
    var buildContent = function (content) {
        var html = "<div class=\"content\">";
        html += content;
        html += "</div>";
        return html;
    };
    var renderEmail = function (templateId, transactionId) {
        var mergeResult = render_1.default.mergeEmail({
            templateId: templateId,
            transactionId: transactionId
        });
        var emailSubject = mergeResult.subject;
        var emailBody = mergeResult.body;
        var responseBody = {
            content: emailBody,
            subject: emailSubject
        };
        return responseBody;
    };
});
