/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
* suitelet_gerir_compras.ts
* 
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "N/ui/serverWidget"], function (require, exports, UI) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    UI = __importStar(UI);
    var onRequest = function (ctx) {
        var form = UI.createForm({
            title: "Configuração Fatores Periódicos"
        });
        form.clientScriptModulePath = "./ClientScript_configuracao_fatores_periodicos.js";
        form.addField({
            id: 'custpage_lrc_unidade_correcao_pai',
            type: UI.FieldType.SELECT,
            source: 'customrecord_lrc_unidade_correcao',
            label: 'Unidade de Correção Pai',
        });
        var sublist = form.addSublist({
            id: 'custpage_lrc_unidade_de_correcao',
            label: 'Unidade de Correção',
            type: UI.SublistType.INLINEEDITOR
        });
        sublist.addField({
            id: 'custpage_lrc_tipo_de_correcao',
            type: UI.FieldType.SELECT,
            source: 'customlist_lrc_tipo_unidade_correcao',
            label: 'Tipo de Correção',
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        sublist.addField({
            id: 'custpage_lrc_fator_periodico',
            type: UI.FieldType.TEXT,
            label: 'Fator Periódico',
        }).updateDisplayType({
            displayType: UI.FieldDisplayType.DISABLED
        });
        sublist.addField({
            id: 'custpage_lrc_data_de_vigencia',
            type: UI.FieldType.DATE,
            label: 'Data de Vigência',
        });
        form.addButton({
            id: 'custpage_lrc_enviar',
            label: 'Enviar',
            functionName: 'craindoRegistroFatoresPeriodicos'
        });
        ctx.response.writePage(form);
    };
    exports.onRequest = onRequest;
});
