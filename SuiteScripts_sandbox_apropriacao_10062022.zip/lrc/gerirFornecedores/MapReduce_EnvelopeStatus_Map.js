/**
 *@NApiVersion 2.x
 *@NScriptType MapReduceScript
 *
 * EnvelopeStatus_Map.ts
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/https", "N/search", "N/log", "N/file", "N/record", "N/runtime"], function (require, exports, https_1, search_1, log_1, file_1, record_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    https_1 = __importDefault(https_1);
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    file_1 = __importDefault(file_1);
    record_1 = __importDefault(record_1);
    runtime_1 = __importDefault(runtime_1);
    var getInputData = function () {
        try {
            return search_1.default.create({
                type: "customrecord_lrc_documento_docusign",
                filters: [
                    ['custrecord_lrc_verificar_att', 'IS', 'T']
                ],
                columns: [
                    'custrecord_lrc_contrato_pdf',
                    'custrecord_lrc_envelope',
                    'custrecord_lrc_ordem',
                    'custrecord_lrc_documentid',
                    'internalid'
                ]
            });
        }
        catch (e) {
            log_1.default.error('error', e);
        }
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        try {
            log_1.default.error('entrou', "map");
            var req = JSON.parse(ctx.value);
            var docrecord = req.values;
            log_1.default.error('docrecord', docrecord);
            log_1.default.error('reqid', req.id);
            var docId = docrecord.id;
            var ordem = docrecord.custrecord_lrc_ordem;
            var documentId = docrecord.custrecord_lrc_documentid;
            var envelope_id = docrecord.custrecord_lrc_envelope;
            log_1.default.error('envelopeId', envelope_id.value);
            var base_uri = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_base_uri' });
            var account_id = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_account_id' });
            var access_token = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_access_token' });
            var envelopeRecord = record_1.default.load({
                type: 'customrecord_lrc_envelopedocusign',
                id: envelope_id.value,
                isDynamic: true,
            });
            log_1.default.error('envelopeRecord', envelopeRecord);
            var GUID = envelopeRecord.getValue('custrecord_lrc_camp_campo');
            var contratoPdf = docrecord.custrecord_lrc_contrato_pdf;
            log_1.default.error('contrato pdf', contratoPdf.value);
            //Conversão em BASE_64
            var Fileobj = file_1.default.load({
                id: contratoPdf.value
            });
            log_1.default.error("Fileobj", Fileobj);
            var stringFile = Fileobj.getContents();
            log_1.default.error("stringFile", stringFile);
            var base64EncodedString = stringFile;
            log_1.default.error("base64XML", base64EncodedString);
            var evelopeLocks = https_1.default.request({
                method: https_1.default.Method.POST,
                url: base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID + "/lock",
                body: JSON.stringify({
                    "lockType": "edit"
                }),
                headers: {
                    'Authorization': "Bearer" + " " + access_token,
                    'Content-Type': "application/json"
                }
            });
            log_1.default.error("evelopeLocks", evelopeLocks);
            log_1.default.error("lock create url", base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID + "/lock");
            var body = JSON.parse(evelopeLocks.body);
            var lockToken = body.lockToken;
            log_1.default.error("body", body);
            var changeEnvelope = https_1.default.request({
                method: https_1.default.Method.PUT,
                url: base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/" + GUID + "/documents",
                body: JSON.stringify({
                    "documents": [
                        {
                            "documentId": documentId,
                            "name": Fileobj.name,
                            "order": ordem,
                            "documentBase64": base64EncodedString
                        }
                    ]
                }),
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer" + " " + access_token,
                    "X-DocuSign-Edit": JSON.stringify({ "LockToken": lockToken })
                }
            });
            log_1.default.error("response", changeEnvelope);
            var bodyobj = JSON.parse(changeEnvelope.body);
            log_1.default.error('objetos', bodyobj);
            log_1.default.error('docId', docId);
            var recordDoc = record_1.default.load({
                id: req.id,
                type: 'customrecord_lrc_documento_docusign'
            });
            if (changeEnvelope.code.toString().substring(0, 1) == "2") {
                log_1.default.error('entrou no if', 'if');
                recordDoc.setValue({
                    fieldId: 'custrecord_lrc_verificar_att',
                    value: false
                });
                recordDoc.save({
                    ignoreMandatoryFields: true
                });
            }
            log_1.default.error('recordDoc', recordDoc);
        }
        catch (e) {
            log_1.default.error('try catch', e);
        }
    };
    exports.map = map;
});
