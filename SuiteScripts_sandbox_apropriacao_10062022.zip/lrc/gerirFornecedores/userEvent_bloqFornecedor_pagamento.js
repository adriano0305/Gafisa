/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* UserEvent_bloqueioFornecedor.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/ui/serverWidget"], function (require, exports, search_1, serverWidget_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = exports.beforeLoad = void 0;
    search_1 = __importDefault(search_1);
    serverWidget_1 = __importDefault(serverWidget_1);
    var beforeLoad = function (ctx) {
        var newRecord = ctx.newRecord;
        var faturaForm = ctx.form;
        if (ctx.type == ctx.UserEventType.EDIT) {
            var campoVendorId = faturaForm.addField({
                id: 'custpage_vendorid',
                type: serverWidget_1.default.FieldType.TEXT,
                label: 'Fornecedor Escondido',
            });
            campoVendorId.updateDisplayType({
                displayType: serverWidget_1.default.FieldDisplayType.HIDDEN
            });
            var vendorId = newRecord.getValue('entity');
            newRecord.setValue({
                fieldId: 'custpage_vendorid',
                value: vendorId,
                ignoreFieldChange: true,
                forceSyncSourcing: true
            });
        }
    };
    exports.beforeLoad = beforeLoad;
    var beforeSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        if (ctx.type == ctx.UserEventType.CREATE || ctx.type == ctx.UserEventType.EDIT) {
            var fornecedorRecord = newRecord.getValue('entity');
            var searchFornecedor = search_1.default.create({
                type: "vendor",
                filters: ['internalid', 'IS', fornecedorRecord],
                columns: ['custentity_lrc_status_suspensao']
            }).run().getRange({
                start: 0,
                end: 1
            });
            if (searchFornecedor[0].getValue('custentity_lrc_status_suspensao')) {
                var statusSuspensao = Number(searchFornecedor[0].getValue('custentity_lrc_status_suspensao'));
                if (statusSuspensao == 3 || statusSuspensao == 4 || statusSuspensao == 5 || statusSuspensao == 6) {
                    throw Error('Fornecedor Suspenso');
                }
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
