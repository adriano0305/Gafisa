/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *
 * EnvelopeShipping.ts
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/https", "N/log", "N/runtime"], function (require, exports, https_1, log_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    https_1 = __importDefault(https_1);
    log_1 = __importDefault(log_1);
    runtime_1 = __importDefault(runtime_1);
    //  import { getAcessToken } from "./Suitelet_getToken";
    var beforeSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        //  const url = "https://demo.docusign.net/restapi/v2/accounts/3bc5a78e-e82f-4c34-aafc-74b3be5256f8/envelopes/";
        var base_uri = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_base_uri' });
        var account_id = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_account_id' });
        var inputData = [];
        var content;
        var body = {
            "status": "created"
        };
        log_1.default.error("body", body);
        var access_token = runtime_1.default.getCurrentScript().getParameter({ name: "custscript_lrc_access_token" });
        //  const headers = {
        //      'Bearer': " " + access_token,
        //      'Content-Type': "application/json",
        //      "Accept": "application/json"
        //  };
        //  Log.error("headers", headers);
        var dootaxApiResponse = https_1.default.post({
            url: base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/",
            headers: {
                "Authorization": "Bearer " + access_token,
                "Content-Type": "application/json"
            },
            body: JSON.stringify(body)
        });
        log_1.default.error("dootaxApiResponse", dootaxApiResponse);
        log_1.default.error('access token', access_token);
        log_1.default.error('url', base_uri + "/restapi/v2/accounts/" + account_id + "/envelopes/");
        if (dootaxApiResponse.code.toString().substring(0, 1) == "2") {
            content = JSON.parse(dootaxApiResponse.body);
            log_1.default.error("content", content);
            var inputenvelopeId = (content['envelopeId']);
            newRecord.setValue({
                fieldId: 'custrecord_lrc_camp_campo',
                value: inputenvelopeId
            });
            newRecord.setValue({
                fieldId: 'custrecord_lrc_status_envelopeducusign',
                value: content.status
            });
        }
        else {
            throw Error(dootaxApiResponse.body);
            log_1.default.error('erro na request', dootaxApiResponse);
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
