/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* lrc_cancel_memo.ts
*
* Retornar valor de crédito do memorando de crédito.
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    log_1 = __importDefault(log_1);
    var beforeSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var oldRecord = ctx.oldRecord;
        if (ctx.type == ctx.UserEventType.CREATE) {
            var quantidadeItensSublist = newRecord.getLineCount({
                sublistId: 'item'
            });
            var total = 0;
            for (var i = 0; i < quantidadeItensSublist; i++) {
                var linha = newRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_rsc_total_linha_contrato',
                    line: i
                });
                if (linha) {
                    total += Number(linha);
                }
            }
            newRecord.setValue({
                fieldId: 'custbody_lrc_valor_contrato',
                value: total
            });
            var valorPedido = newRecord.getValue('custbody_lrc_valor_pedidos');
            var valorSubcontrato = newRecord.getValue('custbody_lrc_valor_empreitada');
            var saldoContrato = total - Number(valorPedido) - Number(valorSubcontrato);
            newRecord.setValue({
                fieldId: 'custbody_lrc_saldo_contrato',
                value: saldoContrato
            });
        }
        if (ctx.type == ctx.UserEventType.EDIT) {
            var quantidadeItensSublist = newRecord.getLineCount({
                sublistId: 'item'
            });
            var total = 0;
            for (var i = 0; i < quantidadeItensSublist; i++) {
                var linha = newRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_rsc_total_linha_contrato',
                    line: i
                });
                if (linha) {
                    total += Number(linha);
                }
            }
            newRecord.setValue({
                fieldId: 'custbody_lrc_valor_contrato',
                value: total
            });
            var oldValorTotalContrato = oldRecord.getValue('custbody_lrc_valor_contrato');
            log_1.default.error('oldValorTotalContrato', oldValorTotalContrato);
            log_1.default.error('total', total);
            if (oldValorTotalContrato != total) {
                log_1.default.error('aqui', 'teste');
                var valorPedido = newRecord.getValue('custbody_lrc_valor_pedidos');
                var valorSubcontrato = newRecord.getValue('custbody_lrc_valor_empreitada');
                var saldoContrato = total - Number(valorPedido) - Number(valorSubcontrato);
                log_1.default.error('saldo', saldoContrato);
                newRecord.setValue({
                    fieldId: 'custbody_lrc_saldo_contrato',
                    value: saldoContrato
                });
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
