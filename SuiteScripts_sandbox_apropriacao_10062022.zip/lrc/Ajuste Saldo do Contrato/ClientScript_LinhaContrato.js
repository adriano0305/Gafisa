/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* TestClientSublist.ts
*
*/
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = exports.pageInit = void 0;
    var pageInit = function (ctx) {
        var record = ctx.currentRecord;
        var quantidadeItensSublist = record.getLineCount({
            sublistId: 'item'
        });
        for (var i = 0; i < quantidadeItensSublist; i++) {
            var qtd = record.getSublistValue({
                sublistId: 'item',
                fieldId: 'custcol_rsc_qtd_contrato_compra',
                line: i
            });
            var taxa = record.getSublistValue({
                sublistId: 'item',
                fieldId: 'origrate',
                line: i
            });
            console.log("quantidade", qtd);
            if (qtd && taxa) {
                var total = qtd * taxa;
                console.log("quantidade", qtd);
                console.log("taxa", taxa);
                console.log("total", total);
                record.selectLine({
                    sublistId: 'item',
                    line: i
                });
                record.setCurrentSublistValue({
                    fieldId: 'custcol_rsc_total_linha_contrato',
                    value: total,
                    sublistId: 'item'
                });
            }
        }
        var lpu = record.getValue({
            fieldId: 'custbody_rsc_contrato_lpu'
        });
        if (lpu == true) {
            var quantidadeItensSublist_1 = record.getLineCount({
                sublistId: 'item'
            });
            for (var i = 0; i < quantidadeItensSublist_1; i++) {
                record.selectLine({
                    line: i,
                    sublistId: "item"
                });
                record.getSublistField({
                    sublistId: 'item',
                    fieldId: 'custcol_rsc_total_linha_contrato',
                    line: i
                }).isDisabled = true;
                record.getSublistField({
                    sublistId: 'item',
                    fieldId: 'custcol_rsc_qtd_contrato_compra',
                    line: i
                }).isDisabled = true;
            }
            record.getField({
                fieldId: "custbody_lrc_valor_contrato"
            }).isDisabled = true;
            record.getField({
                fieldId: "custbody_lrc_saldo_contrato"
            }).isDisabled = true;
            record.getField({
                fieldId: "custbody_rsc_contrato_lpu"
            }).isDisabled = true;
        }
    };
    exports.pageInit = pageInit;
    var fieldChanged = function (ctx) {
        var fieldId = ctx.fieldId;
        var record = ctx.currentRecord;
        if (fieldId == 'custcol_rsc_qtd_contrato_compra' || fieldId == 'rate') {
            var line = ctx.line;
            var index = record.getCurrentSublistIndex({
                sublistId: 'item',
            });
            if (line == index) {
                var qtd = record.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_rsc_qtd_contrato_compra'
                });
                var taxa = record.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate'
                });
                if (qtd && taxa) {
                    var total = Number(qtd) * Number(taxa);
                    console.log("quantidade", qtd);
                    console.log("taxa", taxa);
                    console.log("total", total);
                    record.setCurrentSublistValue({
                        fieldId: 'custcol_rsc_total_linha_contrato',
                        value: total,
                        sublistId: 'item'
                    });
                }
            }
            else {
                var qtd = record.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_rsc_qtd_contrato_compra',
                    line: line
                });
                var taxa = record.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: line
                });
                if (qtd && taxa) {
                    var total = Number(qtd) * Number(taxa);
                    console.log("quantidade", qtd);
                    console.log("taxa", taxa);
                    console.log("total", total);
                    record.setCurrentSublistValue({
                        fieldId: 'custcol_rsc_total_linha_contrato',
                        value: total,
                        sublistId: 'item'
                    });
                }
            }
        }
        if (fieldId == 'custbody_rsc_contrato_lpu') {
            var lpu = record.getValue({
                fieldId: 'custbody_rsc_contrato_lpu'
            });
            if (lpu == true) {
                var quantidadeItensSublist = record.getLineCount({
                    sublistId: 'item'
                });
                for (var i = 0; i < quantidadeItensSublist; i++) {
                    record.selectLine({
                        line: i,
                        sublistId: "item"
                    });
                    record.setCurrentSublistValue({
                        fieldId: 'custcol_rsc_total_linha_contrato',
                        value: 0,
                        sublistId: 'item',
                        ignoreFieldChange: true
                    });
                    record.setCurrentSublistValue({
                        fieldId: 'custcol_rsc_qtd_contrato_compra',
                        value: 0,
                        sublistId: 'item',
                        ignoreFieldChange: true
                    });
                    record.getSublistField({
                        sublistId: 'item',
                        fieldId: 'custcol_rsc_total_linha_contrato',
                        line: i
                    }).isDisabled = true;
                    record.getSublistField({
                        sublistId: 'item',
                        fieldId: 'custcol_rsc_qtd_contrato_compra',
                        line: i
                    }).isDisabled = true;
                }
                record.setValue({
                    fieldId: 'custbody_lrc_saldo_contrato',
                    value: 0,
                    ignoreFieldChange: true
                });
                record.setValue({
                    fieldId: 'custbody_lrc_valor_contrato',
                    value: 0,
                    ignoreFieldChange: true
                });
                record.getField({
                    fieldId: "custbody_lrc_valor_contrato"
                }).isDisabled = true;
                record.getField({
                    fieldId: "custbody_lrc_saldo_contrato"
                }).isDisabled = true;
                record.getField({
                    fieldId: "custbody_rsc_contrato_lpu"
                }).isDisabled = true;
            }
        }
    };
    exports.fieldChanged = fieldChanged;
    /*var lineInit = function (ctx) {
        if (ctx.sublistId == 'item'){
            log.debug({title: 'Chegou aqui', details: ctx})
            var record = ctx.currentRecord;
            var lpu = record.getValue({
                fieldId: 'custbody_rsc_contrato_lpu'
            });
            log.debug({title: 'Chegou aqui', details: lpu})
            if (lpu == true) {
                record.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_rsc_total_linha_contrato'
                }).isDisabled = true;
                log.debug({title: 'Chegou aqui', details: 'certo'})
                record.getCurrentSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_rsc_qtd_contrato_compra'
                }).isDisabled = true;
            }
        }


    };
    exports.lineInit = lineInit;*/
});
