/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* lrc_cancel_memo.ts
*
* Retornar valor de crédito do memorando de crédito.
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    log_1 = __importDefault(log_1);
    var beforeSubmit = function (ctx) {
        var record = ctx.newRecord;
        var oldRecord = ctx.oldRecord;
        var dataAtual = new Date();
        log_1.default.error('passou aqui', 'done');
        if(ctx.type == ctx.UserEventType.EDIT || ctx.type == ctx.UserEventType.XEDIT){
            if (record.type == 'subsidiary') {
                if (oldRecord != record) {
                    log_1.default.error('passou aqui2', 'done');
                    log_1.default.error('dataAtual', dataAtual);
                    record.setValue({
                        fieldId: 'custrecord_lrc_data_modifica',
                        value: dataAtual
                    });
                }
            }
            if (record.type == 'location') {
                if (oldRecord != record) {
                    record.setValue({
                        fieldId: 'custrecord_lrc_data_modifica_local',
                        value: dataAtual
                    });
                }
            }
            if (record.type == 'department') {
                if (oldRecord != record) {
                    record.setValue({
                        fieldId: 'custrecord_lrc_modifica_departamento',
                        value: dataAtual
                    });
                }
            }
            if (record.type == 'account') {
                if (oldRecord != record) {
                    record.setValue({
                        fieldId: 'custrecord_lrc_data_modifica_conta',
                        value: dataAtual
                    });
                }
            }
            if (record.type == 'classification') {
                if (oldRecord != record) {
                    record.setValue({
                        fieldId: 'custrecord_lrc_data_modifica_class',
                        value: dataAtual
                    });
                }
            }
            if (record.type == 'customer') {
                if (oldRecord != record) {
                    record.setValue({
                        fieldId: 'custentity_lrc_data_modifica_cliente',
                        value: dataAtual
                    });
                }
            }
            if (record.type == 'vendor') {
                if (oldRecord != record) {
                    log_1.default.error('modifica fornecedor', 'ok');
                    record.setValue({
                        fieldId: 'custentity_lrc_data_modifica_fornec',
                        value: dataAtual
                    });
                }
            }
        }
        
    };
    exports.beforeSubmit = beforeSubmit;
});
