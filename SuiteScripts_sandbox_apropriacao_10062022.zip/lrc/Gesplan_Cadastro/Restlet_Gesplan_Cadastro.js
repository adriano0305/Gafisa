/**
* @NAPIVersion 2.0
* @NScriptType Restlet
*/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/search"], function (require, exports, Log, search_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.post = exports.delete = void 0;
    Log = __importStar(Log);
    search_1 = __importDefault(search_1);
    function getTipoRegistro(valor_tipo) {
        Log.error("valor tipo", valor_tipo);
        var tipoRegistro = search_1.default.create({
            type: "customrecord_lrc_gesplan_tipo_cadastro",
            filters: [
                ["custrecord_lrc_tipo_registro2", "is", valor_tipo],
            ],
            // columns: [
            //     "custrecord_lrc_recordtype",
            //     "custrecord_lrc_tipo_registro",
            //     "custrecord_lrc_valor_tipo"
            // ]
        }).run().getRange({
            start: 0,
            end: 1
        });
        Log.error("tipo Registro", tipoRegistro);
        return tipoRegistro[0];
    }
    function getReturnJSON(tipo, record, cargaInicial) {
        Log.error("String", tipo);
        var retorno;
        switch (tipo) {
            case 'subsidiary': //Subsidiária
                retorno = {
                    name: record.getValue("legalname")
                };
                break;
            case 'location': //Localidade
                retorno = {
                    name: record.getValue("name")
                };
                break;
            case 'department': //Departamento
                retorno = {
                    name: record.getValue("name")
                };
                break;
            case 'account': //Contas contábeis
                retorno = {
                    name: record.getValue("name"),
                    externalCode: record.getValue("number"),
                    // chartOfAccounts: record.getValue("01"),
                    classification: record.getValue("type")
                };
                break;
            case 'classification': //Centro de Custo
                retorno = {
                    name: record.getValue("name")
                };
                break;
            case 'customrecord_enl_entity_bank_details': //Contas Bancárias
                if (!cargaInicial) {
                    var conta = search_1.default.create({
                        type: "customrecord_enl_entity_bank_details",
                        filters: [
                            ["internalid", "is", record.getValue('custrecord_lrc_conta_bacaria')],
                        ],
                        columns: [
                            "name",
                        ]
                    }).run().getRange({
                        start: 0,
                        end: 1
                    });
                    Log.error("tipo Registro", conta[0]);
                    retorno = {
                        name: conta[0].getValue("name")
                    };
                }
                else {
                    retorno = {
                        name: record.getValue("name")
                    };
                }
                break;
            case 'customer': //Clientes
                retorno = {
                    name: record.getValue("companyname"),
                    externalCode: record.getValue("entityid"),
                    federalCode: record.getValue("custentity_enl_cnpjcpf"),
                    beneficiaryTime: 1
                };
                break;
            case 'vendor': //Fornecedores
                retorno = {
                    name: record.getValue("companyname"),
                    externalCode: record.getValue("entityid"),
                    federalCode: record.getValue("custentity_enl_cnpjcpf")
                };
                break;
            default:
                retorno = { fail: 'Não foi passado um tipo de registro valido' };
        }
        return retorno;
    }
    var del = function (ctx) {
        var type = ctx.type;
        var id = ctx.id;
        return {
            success: true
        };
    };
    exports.delete = del;
    var post = function (ctx) {
        var cargaInicial = ctx.cargaInicial;
        var valor_tipo_registro = ctx.tipoRegistro;
        var tipoRegistro = getTipoRegistro(parseInt(valor_tipo_registro));
        var dataInicio = ctx.dataInicio;
        Log.error('dataInicio', dataInicio);
        var dataFinal = ctx.dataFinal;
        if (!cargaInicial) {
            if (tipoRegistro) {
                var gesplanTipo = search_1.default.lookupFields({
                    type: 'customrecord_lrc_gesplan_tipo_cadastro',
                    id: tipoRegistro.id,
                    columns: [
                        "custrecord_lrc_rcdtype",
                        "custrecord_lrc_tipo_registro2",
                        "custrecord_lrc_vlr_tipo",
                    ]
                });
                Log.error('gesplanTipo', gesplanTipo);
                var tipo_1 = gesplanTipo['custrecord_lrc_rcdtype'];
                var items = ctx.items;
                var columns = [];
                //preenchimento dos campos que devem ser pegos
                switch (tipo_1) {
                    case 'subsidiary': //Subsidiária
                        columns = ["name", "legalname"];
                        break;
                    case 'location': //Localidade
                        columns = ["name"];
                        break;
                    case 'department': //Departamento
                        columns = ["name"];
                        break;
                    case 'account': //Contas contábeis
                        columns = ['name', 'type', 'number'];
                        break;
                    case 'classification': //Centro de Custo
                        columns = ["name"];
                        break;
                    case 'customrecord_enl_entity_bank_details': //Contas Bancárias
                        columns = ["name"];
                        break;
                    case 'customer': //Clientes
                        columns = ["companyname", "entityid", "custentity_enl_cnpjcpf"];
                        break;
                    case 'vendor': //Fornecedores
                        columns = ["companyname", "entityid", "custentity_enl_cnpjcpf"];
                        break;
                    default:
                        return { fail: 'Não foi passado um tipo de registro valido' };
                }
                //subsidiaria, localidade, departamento, contas contaveis, cliente, fornecedor
                var filters = [];
                var pesquisa_registros_cadastro = void 0;
                if (tipo_1 == 'customrecord_enl_entity_bank_details') {
                    filters.push(["custrecord_lrc_lastmodifieddate", "onOrAfter", dataInicio]);
                    filters.push("AND");
                    filters.push(["custrecord_lrc_lastmodifieddate", "onOrBefore", dataFinal]);
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: 'customrecord_lrc_conta_data_modificacao',
                        filters: filters,
                        columns: ["custrecord_lrc_conta_bacaria"]
                    });
                }
                else if (tipo_1 == 'subsidiary') {
                    filters.push(["custrecord_lrc_data_modifica", "onOrAfter", dataInicio]);
                    filters.push("AND");
                    filters.push(["custrecord_lrc_data_modifica", "onOrBefore", dataFinal]);
                                    filters.push("AND");
                  filters.push("legalname", "isnotempty", "");
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_1,
                        filters: filters,
                        columns: columns
                    });
                }
                else if (tipo_1 == 'location') {
                    filters.push(["custrecord_lrc_data_modifica_local", "onOrAfter", dataInicio]);
                    filters.push("AND");
                    filters.push(["custrecord_lrc_data_modifica_local", "onOrBefore", dataFinal]);
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_1,
                        filters: filters,
                        columns: columns
                    });
                }
                else if (tipo_1 == 'department') {
                    filters.push(["custrecord_lrc_modifica_departamento", "onOrAfter", dataInicio]);
                    filters.push("AND");
                    filters.push(["custrecord_lrc_modifica_departamento", "onOrBefore", dataFinal]);
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_1,
                        filters: filters,
                        columns: columns
                    });
                }
                else if (tipo_1 == 'account') {
                    filters.push(["custrecord_lrc_data_modifica_conta", "onOrAfter", dataInicio]);
                    filters.push("AND");
                    filters.push(["custrecord_lrc_data_modifica_conta", "onOrBefore", dataFinal]);
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_1,
                        filters: filters,
                        columns: columns
                    });
                }
                else if (tipo_1 == 'classification') {
                    filters.push(["custrecord_lrc_data_modifica_class", "onOrAfter", dataInicio]);
                    filters.push("AND");
                    filters.push(["custrecord_lrc_data_modifica_class", "onOrBefore", dataFinal]);
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_1,
                        filters: filters,
                        columns: columns
                    });
                }
                else if (tipo_1 == 'customer') {
                    filters.push(["custentity_lrc_data_modifica_cliente", "onOrAfter", dataInicio]);
                    filters.push("AND");
                    filters.push(["custentity_lrc_data_modifica_cliente", "onOrBefore", dataFinal]);
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_1,
                        filters: filters,
                        columns: columns
                    });
                }
                else if (tipo_1 == 'vendor') {
                    filters.push(["custentity_lrc_data_modifica_fornec", "onOrAfter", dataInicio]);
                    filters.push("AND");
                    filters.push(["custentity_lrc_data_modifica_fornec", "onOrBefore", dataFinal]);
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_1,
                        filters: filters,
                        columns: columns
                    });
                }
                var retorno_1 = [];
                var pagedData = pesquisa_registros_cadastro.runPaged({ pageSize: 1000 });
                for (var i = 0; i < pagedData.pageRanges.length; i++) {
                    var currentPage = pagedData.fetch(i);
                    currentPage.data.forEach(function (result) {
                        var retorno_elemento = getReturnJSON(tipo_1, result, cargaInicial);
                        retorno_1.push(retorno_elemento);
                        return true;
                    });
                }
                if (retorno_1.length > 0) {
                    return retorno_1;
                }
                else {
                    return { Mensagem: 'Sem resultados no periodo passado' };
                }
            }
            else {
                return { fail: 'Não foi passado um tipo de registro valido' };
            }
        }
        else {
            if (tipoRegistro) {
                var gesplanTipo = search_1.default.lookupFields({
                    type: 'customrecord_lrc_gesplan_tipo_cadastro',
                    id: tipoRegistro.id,
                    columns: [
                        "custrecord_lrc_rcdtype",
                        "custrecord_lrc_tipo_registro2",
                        "custrecord_lrc_vlr_tipo",
                    ]
                });
                Log.error('gesplanTipo', gesplanTipo);
                var tipo_2 = gesplanTipo['custrecord_lrc_rcdtype'];
                var items = ctx.items;
                var columns = [];
                //preenchimento dos campos que devem ser pegos
                switch (tipo_2) {
                    case 'subsidiary': //Subsidiária
                        columns = ["name", "legalname"];
                        break;
                    case 'location': //Localidade
                        columns = ["name"];
                        break;
                    case 'department': //Departamento
                        columns = ["name"];
                        break;
                    case 'account': //Contas contábeis
                        columns = ['name', 'type', 'number'];
                        break;
                    case 'classification': //Centro de Custo
                        columns = ["name"];
                        break;
                    case 'customrecord_enl_entity_bank_details': //Contas Bancárias
                        columns = ["name"];
                        break;
                    case 'customer': //Clientes
                        columns = ["companyname", "entityid", "custentity_enl_cnpjcpf"];
                        break;
                    case 'vendor': //Fornecedores
                        columns = ["companyname", "entityid", "custentity_enl_cnpjcpf"];
                        break;
                    default:
                        return { fail: 'Não foi passado um tipo de registro valido' };
                }
                //subsidiaria, localidade, departamento, contas contaveis, cliente, fornecedor
                var filters = [];
                var pesquisa_registros_cadastro = void 0;
                if (tipo_2 == 'customrecord_enl_entity_bank_details') {
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_2,
                        columns: ["name"]
                    });
                }
                else if (tipo_2 == 'subsidiary') {
                               
                  filters.push("legalname", "isnotempty", "");
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_2,
                      filters: filters,
                        columns: columns
                    });
                }
                else if (tipo_2 == 'location') {
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_2,
                        columns: columns
                    });
                }
                else if (tipo_2 == 'department') {
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_2,
                        columns: columns
                    });
                }
                else if (tipo_2 == 'account') {
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_2,
                        columns: columns
                    });
                }
                else if (tipo_2 == 'classification') {
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_2,
                        columns: columns
                    });
                }
                else if (tipo_2 == 'customer') {
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_2,
                        columns: columns
                    });
                }
                else if (tipo_2 == 'vendor') {
                    //pesquisar registros
                    pesquisa_registros_cadastro = search_1.default.create({
                        type: tipo_2,
                        columns: columns
                    });
                }
                var retorno_2 = [];
                var pagedData = pesquisa_registros_cadastro.runPaged({ pageSize: 1000 });
                for (var i = 0; i < pagedData.pageRanges.length; i++) {
                    var currentPage = pagedData.fetch(i);
                    currentPage.data.forEach(function (result) {
                        var retorno_elemento = getReturnJSON(tipo_2, result, cargaInicial);
                        retorno_2.push(retorno_elemento);
                        return true;
                    });
                }
                if (retorno_2.length > 0) {
                    return retorno_2;
                }
                else {
                    return { Mensagem: 'Sem resultados no periodo passado' };
                }
            }
            else {
                return { fail: 'Não foi passado um tipo de registro valido' };
            }
        }
    };
    exports.post = post;
});
