/**
 *@NApiVersion 2.x
*@NScriptType ClientScript
*
* Client_botoesTelaItem.ts
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/currentRecord", "N/log", "N/record", "N/url"], function (require, exports, currentRecord_1, log_1, record_1, url_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Emitir = exports.pageInit = void 0;
    currentRecord_1 = __importDefault(currentRecord_1);
    log_1 = __importDefault(log_1);
    record_1 = __importDefault(record_1);
    url_1 = __importDefault(url_1);
    var pageInit = function () {
    };
    exports.pageInit = pageInit;
    var Emitir = function () {
        var currentRecord = currentRecord_1.default.get();
        log_1.default.error('record', currentRecord);
        var contParcelas = 0;
        var contQuitadas = 0;
        var recordInvoice = record_1.default.load({
            type: 'invoice',
            id: currentRecord.id
        });
        var projeto = recordInvoice.getText('custbody_rsc_projeto_obra_gasto_compra');
        var cliente = recordInvoice.getValue({ fieldId: "entity" });
        var moeda = recordInvoice.getText('currency');
        var valor = recordInvoice.getValue('total');
        log_1.default.error('cliente', cliente);
        var data = recordInvoice.getText("trandate");
        // Search.create ({
        //     type: 'customsale_rsc_financiamento',
        //     filters: [
        //         ['custbody_lrc_fatura_principal', 'IS', currentRecord.id],
        //     ],
        // }).run().each(result =>{
        //     contParcelas++
        //     return true
        // })
        // Search.create ({
        //     type: 'customsale_rsc_financiamento',
        //     filters: [
        //         ['custbody_lrc_fatura_principal', 'IS', currentRecord.id],
        //     ],
        // }).run().each(result =>{
        //     const InvoiceRecord = Record.load({
        //         type:'customsale_rsc_financiamento',
        //         id: result.id
        //     })
        //     const total = InvoiceRecord.getValue('total')
        //     let valorTotal = 0;
        //     const linhasLink = InvoiceRecord.getLineCount({sublistId:'links'})
        //     for(let i = 0; i<linhasLink;i++){
        //         if(InvoiceRecord.getSublistValue({sublistId:'links', fieldId:'type', line:i})== "Pagamento"){
        //             const ValorPagamento = InvoiceRecord.getSublistValue({
        //                 sublistId:'links',
        //                 fieldId:'total',
        //                 line:i
        //             })
        //             valorTotal += Number(ValorPagamento);
        //         }
        //     }
        //     if(valorTotal >= Number(total)){
        //         contQuitadas++;    
        //     }
        //     return true
        // })
        // if(contParcelas == contQuitadas){
        var url = url_1.default.resolveScript({
            deploymentId: 'customdeploy_lrc_emissao_termo',
            scriptId: 'customscript_lrc_emissao_termo',
            params: {
                obra: projeto,
                cliente: cliente,
                data: data,
                idFatura: currentRecord.id,
                moeda: moeda,
                valor: valor
            }
        });
        window.open(url, "_blank");
        // }
    };
    exports.Emitir = Emitir;
});
