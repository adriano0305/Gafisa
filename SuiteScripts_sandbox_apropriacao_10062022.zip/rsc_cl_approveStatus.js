/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
define(["N/record", "N/ui/dialog"], function(record, dialog) {

    function pageInit (ctx){
    }

    function  updateApproveStaus (ctx) {
        try{
            var recTask = record.load({
                type: 'task',
                id: ctx
            });
            // console.log('recTask', recTask);
    
            var idPurchaseOR = recTask.getValue({
                fieldId: 'transaction'
            });
            // console.log('idPurchaseOR', idPurchaseOR);
    
            var toRec = record.load({
                type: 'purchaseorder',
                id: idPurchaseOR
            }); 
            // console.log('idPurchaseOR', idPurchaseOR);  

            var approveField = toRec.getValue({
                fieldId: 'approvalstatus'
            });

            if(approveField != 2){
                toRec.setValue({
                    fieldId: 'approvalstatus',
                    value: 2,
                    // ignoreFieldChange: true
                });
        
                toRec.save({
                    ignoreMandatoryFields: true
                });

                recTask.setValue({
                    fieldId: 'status',
                    value: 'COMPLETE'
                })

                recTask.save({
                    ignoreMandatoryFields : true
                });

                dialog.alert({
                    title: 'Status de Aprovação',
                    message: 'Tarefa Concluida. Pedido de Compra Aprovado!'
                }).location.reload()
            } else {
                dialog.alert({
                    title: 'Status de Aprovação',
                    message: 'Este Pedido de Compra já Foi Aprovado!'
                });
            }    
            
            
        }
        catch (err) {
            dialog.alert({
                title: 'Erro Desconhecido',
                message: err
            });
        }
        
    }

    return {
        pageInit: pageInit,
        updateApproveStaus: updateApproveStaus
    }
});
