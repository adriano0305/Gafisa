/**
 *@NApiVersion 2.1
 *@NScriptType WorkflowActionScript
 */
define(['N/log'], function(log) {
function onAction(context) {
    log.audit('onAction', context);

    const novoRegistro = context.newRecord;
    log.audit('novoRegistro', novoRegistro);    
}

return {
    onAction: onAction
}
});
