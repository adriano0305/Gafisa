/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/log', 'N/runtime', 'N/url'], (log, runtime, url) => {
function beforeLoad(context) {
    log.audit('beforeLoad', context);

    const registroAtual = context.newRecord;

    const form = context.form;

    form.clientScriptFileId = 13369;

    form.addButton({
        id: 'custpage_rsc_reenviar_minuta_boleto',
        label: 'Reenviar Minuta/Boleto',
        functionName: 'reenviarMinutaBoleto'
    });

    form.addButton({
        id: 'custpage_rsc_imprimir_minuta_boleto',
        label: 'Imprimir Minuta/Boleto',
        functionName: 'imprimirMinutaBoleto'
    });
}

return {
    beforeLoad: beforeLoad
};

});