/**
 * @NApiVersion 2.0
 * @NModuleScope Public
 * @scriptName rsc-cnab-invoice
 */
define([ 'N/search', 'N/runtime' ],

    /**
     * @function
     * @param search
     * @param runtime
     * @return {object}
     */
    function( search, runtime )
    {
        var language = runtime.getCurrentUser().getPreference({ name: 'LANGUAGE' });

        var label = {
            button: ( language === 'pt_BR' ) ? 'CNAB - Atualizar Parcelas' : 'CNAB - Update Installments',
            alert: ( language === 'pt_BR' ) ? 'Alerta' : 'Alert',
            block: ( language === 'pt_BR' ) ? 'CNAB: Há parcelas enviadas ao banco, não é possível alterar a transação.' :
                'CNAB: There are installments sent to the bank, it is not possible to change the transaction.',
            ticket: ( language === 'pt_BR' ) ? 'CNAB - Boletos Bancários' : 'CNAB - Bank Ticket',
            success: ( language === 'pt_BR' ) ? 'O(s) boleto(s) foram gerados com sucesso e anexados na transação.' :
                'Bank ticket were successfully generated and attached to the transaction.',
            error: ( language === 'pt_BR' ) ? 'Falha na geração do(s) boleto(s).' : 'Bank ticket generation failed.'
        };

        /**
         * @function enable|disable fields
         * @param record
         * @param fields
         * @param action
         */
        function disableFields( record, fields, action )
        {
            var lines = record.getLineCount({ sublistId: 'installment' });
            if( lines > 0 )
            {
                record.selectLine({ sublistId: 'installment', line: 0 });
                for( var i = 0; i < fields.length; i++ )
                {
                    record.getSublistField({
                        sublistId: 'installment',
                        fieldId: fields[i],
                        line: 0
                    }).isDisabled = action;
                }
                record.cancelLine({ sublistId: 'installment' });
            }
        }

        /**
         * @function disable all custom fields in the installments
         * @return {string[]}
         */
        function fieldsDisable() {

            return [
                'custrecord_rsc_cnab_inst_discount_cu', 'custrecord_rsc_cnab_inst_interest_cu', 'custrecord_rsc_cnab_inst_specie_ls',
                'custrecord_rsc_cnab_inst_1instruction_ls', 'custrecord_rsc_cnab_inst_2instruction_ls'
            ];
        }

        return {
            label: label,
            disableFields: disableFields,
            fieldsDisable: fieldsDisable
        }
    }
);