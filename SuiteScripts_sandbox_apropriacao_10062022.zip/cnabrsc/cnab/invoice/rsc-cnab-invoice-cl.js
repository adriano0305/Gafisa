/**
 * @NScriptType ClientScript
 * @NApiVersion 2.0
 * @scriptName rsc-cnab-invoice-cl
 */
define([ 'N/ui/dialog', 'N/runtime', 'N/currentRecord', './rsc-cnab-invoice', '../lib/rsc-cnab-constant', 'N/https', 'N/url' ],

    /**
     *
     * @param dialog
     * @param runtime
     * @param currentRecord
     * @param lib
     * @param _c
     * @param https
     * @param _url
     * @return {{saveRecord: (function(*): boolean)}}
     */
    function( dialog, runtime, currentRecord, lib, _c, https, _url )
    {
        /**
         *
         * @param context
         * @return {boolean}
         */
        function pageInit( context )
        {
            var record = context.currentRecord;
            if( record.id )
            {
                var terms = record.getValue({ fieldId: 'terms' });
                if( terms ) {
                    lib.disableFields( record, lib.fieldsDisable(),false );
                } else {
                    lib.disableFields( record, lib.fieldsDisable(),true );
                }
            }
        }

        /**
         * @function
         * @param context
         * @return {boolean}
         */
        function saveRecord( context )
        {
            var record = context.currentRecord;
            if( record.id )
            {
                var lines = record.getLineCount({ sublistId: 'installment' });
                var bank         = record.getValue({ fieldId: 'custbody_rsc_cnab_bank_ls' });
                var bankAccount  = record.getValue({ fieldId: 'custbody_rsc_cnab_bankaccountloc_ls' });
                var specie       = record.getValue({ fieldId: 'custbody_rsc_cnab_specie_ls' });
                var instruction1 = record.getValue({ fieldId: 'custbody_rsc_cnab_1instruction_ls' });
                var instruction2 = record.getValue({ fieldId: 'custbody_rsc_cnab_2instruction_ls' });
                var interest     = record.getValue({ fieldId: 'custbody_rsc_cnab_interestvalue_cu' });
                var discount     = record.getValue({ fieldId: 'custbody_rsc_cnab_discountvalue_cu' });

                for( var i=0; i < lines; i++ )
                {
                    record.selectLine({ sublistId: 'installment', line: i });
                    var status = record.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'custrecord_rsc_cnab_inst_status_ls' });

                    if( status && Number(status) !== _c._status.available && Number(status) !== _c._status.rejected ) {
                        dialog.alert({ title: lib.label.alert, message: lib.label.block });
                        return false;
                    } else {
                        setLineValues( record, bank, bankAccount, specie, instruction1, instruction2, interest, discount );
                    }
                }
            } else {
                updateInstallments();
            }
            return true;
        }

        /**
         * @function
         */
        function updateInstallments()
        {
            var record = currentRecord.get();
            var lines = record.getLineCount({ sublistId: 'installment' });

            var bank         = record.getValue({ fieldId: 'custbody_rsc_cnab_bank_ls' });
            var bankAccount  = record.getValue({ fieldId: 'custbody_rsc_cnab_bankaccountloc_ls' });
            var specie       = record.getValue({ fieldId: 'custbody_rsc_cnab_specie_ls' });
            var instruction1 = record.getValue({ fieldId: 'custbody_rsc_cnab_1instruction_ls' });
            var instruction2 = record.getValue({ fieldId: 'custbody_rsc_cnab_2instruction_ls' });
            var interest     = record.getValue({ fieldId: 'custbody_rsc_cnab_interestvalue_cu' });
            var discount     = record.getValue({ fieldId: 'custbody_rsc_cnab_discountvalue_cu' });

            for( var i=0; i < lines; i++ )
            {
                record.selectLine({ sublistId: 'installment', line: i });
                setLineValues( record, bank, bankAccount, specie, instruction1, instruction2, interest, discount );
            }
        }

        /**
         *
         * @param record
         * @param bank
         * @param bankAccount
         * @param specie
         * @param instruction1
         * @param instruction2
         * @param interest
         * @param discount
         */
        function setLineValues( record, bank, bankAccount, specie, instruction1, instruction2, interest, discount )
        {
            record.setCurrentSublistValue({
                sublistId: 'installment',
                fieldId: 'custrecord_rsc_cnab_inst_status_ls',
                value: _c._status.available,
                ignoreFieldChange: true
            });
            record.setCurrentSublistValue({
                sublistId: 'installment',
                fieldId: 'custrecord_rsc_cnab_inst_bank_ls',
                value: bank,
                ignoreFieldChange: true
            });
            record.setCurrentSublistValue({
                sublistId: 'installment',
                fieldId: 'custrecord_rsc_cnab_inst_locationba_ls',
                value: bankAccount,
                ignoreFieldChange: true
            });
            record.setCurrentSublistValue({
                sublistId: 'installment',
                fieldId: 'custrecord_rsc_cnab_inst_specie_ls',
                value: specie,
                ignoreFieldChange: true
            });
            record.setCurrentSublistValue({
                sublistId: 'installment',
                fieldId: 'custrecord_rsc_cnab_inst_1instruction_ls',
                value: instruction1,
                ignoreFieldChange: true
            });
            record.setCurrentSublistValue({
                sublistId: 'installment',
                fieldId: 'custrecord_rsc_cnab_inst_2instruction_ls',
                value: instruction2,
                ignoreFieldChange: true
            });
            record.setCurrentSublistValue({
                sublistId: 'installment',
                fieldId: 'custrecord_rsc_cnab_inst_discount_cu',
                value: discount,
                ignoreFieldChange: true
            });
            record.setCurrentSublistValue({
                sublistId: 'installment',
                fieldId: 'custrecord_rsc_cnab_inst_interest_cu',
                value: interest,
                ignoreFieldChange: true
            });
            record.commitLine({ sublistId: 'installment' });
        }

        /**
         * @function
         * @param context
         */
        function fieldChanged( context )
        {
            var record = currentRecord.get();

            if( context.fieldId === 'terms' )
            {
                var terms = record.getValue({ fieldId: 'terms' });
                if( terms ) {
                    lib.disableFields( record, lib.fieldsDisable(),false );
                } else {
                    lib.disableFields( record, lib.fieldsDisable(),true );
                }
            }
        }

        /**
         * @function
         */
        function generateBankTicket()
        {
            var record = currentRecord.get();
            var url = _url.resolveScript({
                scriptId: 'customscript_rsc_cnab_bank_ticket_tra_st',
                deploymentId: 'customdeploy_rsc_cnab_bank_ticket_tra_st'
            });
            var output = https.post({
                url: url,
                body: { transactionType: 'invoice', transactionId: record.id, entityType: 'customer' }
            }).body;
            if( JSON.parse(output) ) {
                dialog.alert({ title: lib.label.alert, message: lib.label.success });
            } else {
                dialog.alert({ title: lib.label.alert, message: lib.label.error });
            }
        }

        return {
            saveRecord: saveRecord,
            pageInit: pageInit,
            updateInstallments: updateInstallments,
            fieldChanged: fieldChanged,
            generateBankTicket: generateBankTicket
        }
    });