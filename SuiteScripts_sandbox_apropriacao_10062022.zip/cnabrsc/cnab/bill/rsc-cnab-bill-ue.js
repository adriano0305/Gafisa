/**
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 * @scriptName rsc-cnab-bill-ue
 */
define([ 'N/log', 'N/runtime', './rsc-cnab-bill', '../lib/rsc-cnab-constant' ],

    /**
     * @function
     * @param log
     * @param runtime
     * @param lib
     * @param _c
     * @return {{beforeLoad: beforeLoad}}
     */
    function( log, runtime, lib, _c )
    {
        /**
         * @function
         * @param context
         */
        function beforeLoad( context )
        {
            try
            {
                if( context.UserEventType.VIEW !== context.type )
                {
                    context.form.clientScriptModulePath = './rsc-cnab-bill-cl.js';
                    context.form.addButton({
                        id: 'custpage_btn_update_installments',
                        label : lib.label.button,
                        functionName: 'updateInstallments()'
                    });
                }
                else if( context.UserEventType.VIEW === context.type )
                {
                    var record = context.newRecord;
                    var lines = record.getLineCount({sublistId: 'installment'});

                    for( var i = 0; i < lines; i++ )
                    {
                        var status = record.getSublistValue({sublistId: 'installment', fieldId: 'custrecord_rsc_cnab_inst_status_ls', line: i});

                        if( Number(status) === _c._status.confirmed )
                        {
                            context.form.clientScriptModulePath = './rsc-cnab-bill-cl.js';
                            context.form.addButton({
                                id: 'custpage_btn_generate_bank_ticket ',
                                label: lib.label.ticket,
                                functionName: 'generateBankTicket()'
                            });
                            break;
                        }
                    }
                }
            } catch (e) {
                log.error( 'beforeLoad', e );
            }
        }

        return {
            beforeLoad: beforeLoad
        };
    }
);