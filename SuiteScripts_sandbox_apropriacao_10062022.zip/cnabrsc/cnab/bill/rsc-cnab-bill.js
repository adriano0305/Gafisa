/**
 * @NApiVersion 2.0
 * @NModuleScope Public
 * @scriptName rsc-cnab-bill
 */
define([ 'N/search', 'N/runtime' ],

    /**
     * @function
     * @param search
     * @param runtime
     * @return {object}
     */
    function( search, runtime )
    {
        var language = runtime.getCurrentUser().getPreference({ name: 'LANGUAGE' });

        var label = {
            barcode: ( language === 'pt_BR' ) ? 'Código de Barras Inválido!' : 'Invalid Barcode!',
            button: ( language === 'pt_BR' ) ? 'CNAB - Atualizar Parcelas' : 'CNAB - Update Installments',
            alert: ( language === 'pt_BR' ) ? 'Alerta' : 'Alert',
            block: ( language === 'pt_BR' ) ? 'CNAB: Há parcelas enviadas ao banco, não é possível alterar a transação.' :
                'CNAB: There are installments sent to the bank, it is not possible to change the transaction.',
            ticket: ( language === 'pt_BR' ) ? 'CNAB - Boletos Bancários' : 'CNAB - Bank Ticket'
        };

        /**
         * @function
         * @param paymentMethodId
         * @return {string}
         */
        function getSegment( paymentMethodId )
        {
            return search.lookupFields({

                type: 'customrecord_rsc_cnab_paymentmethod',
                id: paymentMethodId,
                columns: 'custrecord_rsc_cnab_pm_segment_ls'

            })['custrecord_rsc_cnab_pm_segment_ls'][0].text;
        }

        /**
         * @function enable|disable fields
         * @param record
         * @param fields
         * @param action
         */
        function disableFields( record, fields, action )
        {
            var lines = record.getLineCount({ sublistId: 'installment' });
            if( lines > 0 )
            {
                record.selectLine({ sublistId: 'installment', line: 0 });
                for( var i = 0; i < fields.length; i++ )
                {
                    record.getSublistField({
                        sublistId: 'installment',
                        fieldId: fields[i],
                        line: 0
                    }).isDisabled = action;
                }
                record.cancelLine({ sublistId: 'installment' });
            }
        }

        /**
         * @function disable all custom fields in the installments
         * @return {string[]}
         */
        function fieldsDisable() {

            return [
                'custrecord_rsc_cnab_inst_barcode_ds','custrecord_rsc_cnab_inst_paymentcode_nu','custrecord_rsc_cnab_inst_monthyearcom_nu',
                'custrecord_rsc_cnab_inst_taxpayeriden_nu','custrecord_rsc_cnab_inst_othervalue_nu','custrecord_rsc_cnab_inst_monetaryupda_nu',
                'custrecord_rsc_cnab_inst_taxpayername_ds','custrecord_rsc_cnab_inst_revenuecode_nu','custrecord_rsc_cnab_inst_typecpfcnpj_nu',
                'custrecord_rsc_cnab_inst_taxpayer_nu','custrecord_rsc_cnab_inst_calcperiod_dt','custrecord_rsc_cnab_inst_interest_cu',
                'custrecord_rsc_cnab_inst_fine_cu','custrecord_rsc_cnab_inst_grossrevenue_cu','custrecord_rsc_cnab_inst_grossrevenue_pe',
                'custrecord_rsc_cnab_inst_stateregistr_nu','custrecord_rsc_cnab_inst_docnumber_nu','custrecord_rsc_cnab_inst_typecnpjcei_nu',
                'custrecord_rsc_cnab_inst_actdebtlabel_nu','custrecord_rsc_cnab_inst_year_nu','custrecord_rsc_cnab_inst_renavam9_nu',
                'custrecord_rsc_cnab_inst_state_ls','custrecord_rsc_cnab_inst_citycode_nu','custrecord_rsc_cnab_inst_platenumber_ds',
                'custrecord_rsc_cnab_inst_paymentoptio_ls','custrecord_rsc_cnab_inst_renavam12_nu','custrecord_rsc_cnab_inst_fgtsident_nu',
                'custrecord_rsc_cnab_inst_seal_nu','custrecord_rsc_cnab_inst_sealdv_nu'
            ];
        }

        /**
         * @function
         * @return {string[]}
         */
        function fieldsDisableSegment_J_O() {

            return [
                'custrecord_rsc_cnab_inst_paymentcode_nu','custrecord_rsc_cnab_inst_monthyearcom_nu', 'custrecord_rsc_cnab_inst_taxpayeriden_nu',
                'custrecord_rsc_cnab_inst_othervalue_nu','custrecord_rsc_cnab_inst_monetaryupda_nu', 'custrecord_rsc_cnab_inst_taxpayername_ds',
                'custrecord_rsc_cnab_inst_revenuecode_nu','custrecord_rsc_cnab_inst_typecpfcnpj_nu', 'custrecord_rsc_cnab_inst_taxpayer_nu',
                'custrecord_rsc_cnab_inst_calcperiod_dt','custrecord_rsc_cnab_inst_interest_cu', 'custrecord_rsc_cnab_inst_fine_cu',
                'custrecord_rsc_cnab_inst_grossrevenue_cu','custrecord_rsc_cnab_inst_grossrevenue_pe', 'custrecord_rsc_cnab_inst_stateregistr_nu',
                'custrecord_rsc_cnab_inst_docnumber_nu','custrecord_rsc_cnab_inst_typecnpjcei_nu', 'custrecord_rsc_cnab_inst_actdebtlabel_nu',
                'custrecord_rsc_cnab_inst_year_nu','custrecord_rsc_cnab_inst_renavam9_nu', 'custrecord_rsc_cnab_inst_state_ls',
                'custrecord_rsc_cnab_inst_citycode_nu','custrecord_rsc_cnab_inst_platenumber_ds', 'custrecord_rsc_cnab_inst_paymentoptio_ls',
                'custrecord_rsc_cnab_inst_renavam12_nu','custrecord_rsc_cnab_inst_fgtsident_nu', 'custrecord_rsc_cnab_inst_seal_nu',
                'custrecord_rsc_cnab_inst_sealdv_nu'
            ];
        }

        /**
         * @function enable fields GPS
         * @return {string[]}
         */
        function fieldsEnableSegment_N_01() {

            return [
                'custrecord_rsc_cnab_inst_paymentcode_nu','custrecord_rsc_cnab_inst_monthyearcom_nu', 'custrecord_rsc_cnab_inst_taxpayeriden_nu',
                'custrecord_rsc_cnab_inst_othervalue_nu','custrecord_rsc_cnab_inst_monetaryupda_nu', 'custrecord_rsc_cnab_inst_taxpayername_ds'
            ];
        }

        /**
         * @function disable fields GPS
         * @return {string[]}
         */
        function fieldsDisableSegment_N_01() {

            return [
                'custrecord_rsc_cnab_inst_revenuecode_nu','custrecord_rsc_cnab_inst_typecpfcnpj_nu', 'custrecord_rsc_cnab_inst_taxpayer_nu',
                'custrecord_rsc_cnab_inst_calcperiod_dt','custrecord_rsc_cnab_inst_interest_cu', 'custrecord_rsc_cnab_inst_fine_cu',
                'custrecord_rsc_cnab_inst_grossrevenue_cu','custrecord_rsc_cnab_inst_grossrevenue_pe', 'custrecord_rsc_cnab_inst_stateregistr_nu',
                'custrecord_rsc_cnab_inst_docnumber_nu','custrecord_rsc_cnab_inst_typecnpjcei_nu', 'custrecord_rsc_cnab_inst_actdebtlabel_nu',
                'custrecord_rsc_cnab_inst_year_nu','custrecord_rsc_cnab_inst_renavam9_nu', 'custrecord_rsc_cnab_inst_state_ls',
                'custrecord_rsc_cnab_inst_citycode_nu','custrecord_rsc_cnab_inst_platenumber_ds', 'custrecord_rsc_cnab_inst_paymentoptio_ls',
                'custrecord_rsc_cnab_inst_renavam12_nu','custrecord_rsc_cnab_inst_fgtsident_nu', 'custrecord_rsc_cnab_inst_seal_nu',
                'custrecord_rsc_cnab_inst_sealdv_nu'
            ];
        }

        /**
         * @function enable fields DARF Normal
         * @return {string[]}
         */
        function fieldsEnableSegment_N_02() {

            return [
                'custrecord_rsc_cnab_inst_revenuecode_nu','custrecord_rsc_cnab_inst_typecpfcnpj_nu','custrecord_rsc_cnab_inst_taxpayer_nu',
                'custrecord_rsc_cnab_inst_calcperiod_dt','custrecord_rsc_cnab_inst_interest_cu','custrecord_rsc_cnab_inst_fine_cu',
                'custrecord_rsc_cnab_inst_taxpayername_ds'
            ];
        }

        /**
         * @function disable fields DARF Normal
         * @return {string[]}
         */
        function fieldsDisableSegment_N_02() {

            return [
                'custrecord_rsc_cnab_inst_barcode_ds','custrecord_rsc_cnab_inst_paymentcode_nu','custrecord_rsc_cnab_inst_monthyearcom_nu',
                'custrecord_rsc_cnab_inst_taxpayeriden_nu','custrecord_rsc_cnab_inst_othervalue_nu','custrecord_rsc_cnab_inst_monetaryupda_nu',
                'custrecord_rsc_cnab_inst_grossrevenue_cu','custrecord_rsc_cnab_inst_grossrevenue_pe', 'custrecord_rsc_cnab_inst_stateregistr_nu',
                'custrecord_rsc_cnab_inst_docnumber_nu','custrecord_rsc_cnab_inst_typecnpjcei_nu', 'custrecord_rsc_cnab_inst_actdebtlabel_nu',
                'custrecord_rsc_cnab_inst_year_nu','custrecord_rsc_cnab_inst_renavam9_nu', 'custrecord_rsc_cnab_inst_state_ls',
                'custrecord_rsc_cnab_inst_citycode_nu','custrecord_rsc_cnab_inst_platenumber_ds', 'custrecord_rsc_cnab_inst_paymentoptio_ls',
                'custrecord_rsc_cnab_inst_renavam12_nu','custrecord_rsc_cnab_inst_fgtsident_nu', 'custrecord_rsc_cnab_inst_seal_nu',
                'custrecord_rsc_cnab_inst_sealdv_nu'
            ];
        }

        /**
         * @function enable fields DARF Simples
         * @return {string[]}
         */
        function fieldsEnableSegment_N_03() {

            return [
                'custrecord_rsc_cnab_inst_revenuecode_nu','custrecord_rsc_cnab_inst_typecpfcnpj_nu','custrecord_rsc_cnab_inst_taxpayer_nu',
                'custrecord_rsc_cnab_inst_calcperiod_dt','custrecord_rsc_cnab_inst_grossrevenue_cu','custrecord_rsc_cnab_inst_grossrevenue_pe',
                'custrecord_rsc_cnab_inst_interest_cu','custrecord_rsc_cnab_inst_fine_cu', 'custrecord_rsc_cnab_inst_taxpayername_ds'
            ];
        }

        /**
         * @function disable fields DARF Simples
         * @return {string[]}
         */
        function fieldsDisableSegment_N_03() {

            return [
                'custrecord_rsc_cnab_inst_barcode_ds','custrecord_rsc_cnab_inst_paymentcode_nu','custrecord_rsc_cnab_inst_monthyearcom_nu',
                'custrecord_rsc_cnab_inst_taxpayeriden_nu','custrecord_rsc_cnab_inst_othervalue_nu','custrecord_rsc_cnab_inst_monetaryupda_nu',
                'custrecord_rsc_cnab_inst_stateregistr_nu', 'custrecord_rsc_cnab_inst_docnumber_nu','custrecord_rsc_cnab_inst_typecnpjcei_nu',
                'custrecord_rsc_cnab_inst_actdebtlabel_nu', 'custrecord_rsc_cnab_inst_year_nu','custrecord_rsc_cnab_inst_renavam9_nu',
                'custrecord_rsc_cnab_inst_state_ls', 'custrecord_rsc_cnab_inst_citycode_nu','custrecord_rsc_cnab_inst_platenumber_ds',
                'custrecord_rsc_cnab_inst_paymentoptio_ls', 'custrecord_rsc_cnab_inst_renavam12_nu','custrecord_rsc_cnab_inst_fgtsident_nu',
                'custrecord_rsc_cnab_inst_seal_nu', 'custrecord_rsc_cnab_inst_sealdv_nu'
            ];
        }

        /**
         * @function enable fields DARJ
         * @return {string[]}
         */
        function fieldsEnableSegment_N_04() {

            return [
                'custrecord_rsc_cnab_inst_revenuecode_nu','custrecord_rsc_cnab_inst_typecpfcnpj_nu','custrecord_rsc_cnab_inst_taxpayer_nu',
                'custrecord_rsc_cnab_inst_stateregistr_nu','custrecord_rsc_cnab_inst_docnumber_nu','custrecord_rsc_cnab_inst_monetaryupda_nu',
                'custrecord_rsc_cnab_inst_interest_cu','custrecord_rsc_cnab_inst_fine_cu', 'custrecord_rsc_cnab_inst_taxpayername_ds'
            ];
        }

        /**
         * @function disable fields DARJ
         * @return {string[]}
         */
        function fieldsDisableSegment_N_04() {

            return [
                'custrecord_rsc_cnab_inst_barcode_ds','custrecord_rsc_cnab_inst_paymentcode_nu','custrecord_rsc_cnab_inst_monthyearcom_nu',
                'custrecord_rsc_cnab_inst_taxpayeriden_nu','custrecord_rsc_cnab_inst_othervalue_nu', 'custrecord_rsc_cnab_inst_typecnpjcei_nu',
                'custrecord_rsc_cnab_inst_actdebtlabel_nu', 'custrecord_rsc_cnab_inst_year_nu','custrecord_rsc_cnab_inst_renavam9_nu',
                'custrecord_rsc_cnab_inst_state_ls', 'custrecord_rsc_cnab_inst_citycode_nu','custrecord_rsc_cnab_inst_platenumber_ds',
                'custrecord_rsc_cnab_inst_paymentoptio_ls', 'custrecord_rsc_cnab_inst_renavam12_nu','custrecord_rsc_cnab_inst_fgtsident_nu',
                'custrecord_rsc_cnab_inst_seal_nu', 'custrecord_rsc_cnab_inst_sealdv_nu'
            ];
        }

        /**
         * @function enable fields GARE – SP ICMS
         * @return {string[]}
         */
        function fieldsEnableSegment_N_05() {

            return [
                'custrecord_rsc_cnab_inst_revenuecode_nu','custrecord_rsc_cnab_inst_typecnpjcei_nu','custrecord_rsc_cnab_inst_taxpayer_nu',
                'custrecord_rsc_cnab_inst_stateregistr_nu','custrecord_rsc_cnab_inst_actdebtlabel_nu','custrecord_rsc_cnab_inst_monthyearcom_nu',
                'custrecord_rsc_cnab_inst_interest_cu','custrecord_rsc_cnab_inst_fine_cu', 'custrecord_rsc_cnab_inst_taxpayername_ds'
            ];
        }

        /**
         * @function disable fields GARE – SP ICMS
         * @return {string[]}
         */
        function fieldsDisableSegment_N_05() {

            return [
                'custrecord_rsc_cnab_inst_barcode_ds','custrecord_rsc_cnab_inst_paymentcode_nu','custrecord_rsc_cnab_inst_taxpayeriden_nu',
                'custrecord_rsc_cnab_inst_othervalue_nu','custrecord_rsc_cnab_inst_monetaryupda_nu','custrecord_rsc_cnab_inst_typecpfcnpj_nu',
                'custrecord_rsc_cnab_inst_calcperiod_dt','custrecord_rsc_cnab_inst_grossrevenue_cu','custrecord_rsc_cnab_inst_grossrevenue_pe',
                'custrecord_rsc_cnab_inst_docnumber_nu','custrecord_rsc_cnab_inst_year_nu','custrecord_rsc_cnab_inst_renavam9_nu',
                'custrecord_rsc_cnab_inst_state_ls', 'custrecord_rsc_cnab_inst_citycode_nu','custrecord_rsc_cnab_inst_platenumber_ds',
                'custrecord_rsc_cnab_inst_paymentoptio_ls', 'custrecord_rsc_cnab_inst_renavam12_nu','custrecord_rsc_cnab_inst_fgtsident_nu',
                'custrecord_rsc_cnab_inst_seal_nu', 'custrecord_rsc_cnab_inst_sealdv_nu'
            ];
        }

        /**
         * @function enable fields IPVA - DPVAT
         * @return {string[]}
         */
        function fieldsEnableSegment_N_07_08() {

            return [
                'custrecord_rsc_cnab_inst_typecpfcnpj_nu','custrecord_rsc_cnab_inst_taxpayer_nu','custrecord_rsc_cnab_inst_year_nu',
                'custrecord_rsc_cnab_inst_renavam9_nu','custrecord_rsc_cnab_inst_state_ls','custrecord_rsc_cnab_inst_citycode_nu',
                'custrecord_rsc_cnab_inst_platenumber_ds','custrecord_rsc_cnab_inst_paymentoptio_ls', 'custrecord_rsc_cnab_inst_renavam12_nu',
                'custrecord_rsc_cnab_inst_taxpayername_ds'
            ];
        }

        /**
         * @function disable fields IPVA - DPVAT
         * @return {string[]}
         */
        function fieldsDisableSegment_N_07_08() {

            return [
                'custrecord_rsc_cnab_inst_barcode_ds','custrecord_rsc_cnab_inst_paymentcode_nu','custrecord_rsc_cnab_inst_monthyearcom_nu',
                'custrecord_rsc_cnab_inst_taxpayeriden_nu','custrecord_rsc_cnab_inst_othervalue_nu','custrecord_rsc_cnab_inst_monetaryupda_nu',
                'custrecord_rsc_cnab_inst_revenuecode_nu','custrecord_rsc_cnab_inst_calcperiod_dt','custrecord_rsc_cnab_inst_interest_cu',
                'custrecord_rsc_cnab_inst_fine_cu','custrecord_rsc_cnab_inst_grossrevenue_cu','custrecord_rsc_cnab_inst_grossrevenue_pe',
                'custrecord_rsc_cnab_inst_stateregistr_nu','custrecord_rsc_cnab_inst_docnumber_nu','custrecord_rsc_cnab_inst_typecnpjcei_nu',
                'custrecord_rsc_cnab_inst_actdebtlabel_nu','custrecord_rsc_cnab_inst_fgtsident_nu','custrecord_rsc_cnab_inst_seal_nu',
                'custrecord_rsc_cnab_inst_sealdv_nu'
            ];
        }

        /**
         * @function enable fields FGTS- GRF/GRRF/GRDE
         * @return {string[]}
         */
        function fieldsEnableSegment_N_11() {

            return [
                'custrecord_rsc_cnab_inst_revenuecode_nu','custrecord_rsc_cnab_inst_typecnpjcei_nu','custrecord_rsc_cnab_inst_taxpayer_nu',
                'custrecord_rsc_cnab_inst_barcode_ds','custrecord_rsc_cnab_inst_fgtsident_nu','custrecord_rsc_cnab_inst_seal_nu',
                'custrecord_rsc_cnab_inst_sealdv_nu','custrecord_rsc_cnab_inst_taxpayername_ds'
            ];
        }

        /**
         * @function disable fields FGTS- GRF/GRRF/GRDE
         * @return {string[]}
         */
        function fieldsDisableSegment_N_11() {

            return [
                'custrecord_rsc_cnab_inst_paymentcode_nu','custrecord_rsc_cnab_inst_monthyearcom_nu','custrecord_rsc_cnab_inst_taxpayeriden_nu',
                'custrecord_rsc_cnab_inst_othervalue_nu','custrecord_rsc_cnab_inst_monetaryupda_nu','custrecord_rsc_cnab_inst_typecpfcnpj_nu',
                'custrecord_rsc_cnab_inst_calcperiod_dt','custrecord_rsc_cnab_inst_interest_cu','custrecord_rsc_cnab_inst_fine_cu',
                'custrecord_rsc_cnab_inst_grossrevenue_cu','custrecord_rsc_cnab_inst_grossrevenue_pe','custrecord_rsc_cnab_inst_stateregistr_nu',
                'custrecord_rsc_cnab_inst_docnumber_nu','custrecord_rsc_cnab_inst_actdebtlabel_nu','custrecord_rsc_cnab_inst_year_nu',
                'custrecord_rsc_cnab_inst_renavam9_nu','custrecord_rsc_cnab_inst_state_ls','custrecord_rsc_cnab_inst_citycode_nu',
                'custrecord_rsc_cnab_inst_platenumber_ds','custrecord_rsc_cnab_inst_paymentoptio_ls','custrecord_rsc_cnab_inst_renavam12_nu'
            ];
        }

        /**
         * @function
         * @param record
         * @param segment
         */
        function manageFields( record, segment )
        {
            switch( segment )
            {
                case 'A':
                    disableFields( record, fieldsDisable(),true );
                    break;

                case 'J':
                    disableFields( record, ['custrecord_rsc_cnab_inst_barcode_ds'],false );
                    disableFields( record, fieldsDisableSegment_J_O(),true );
                    break;

                case 'O':
                    disableFields( record, ['custrecord_rsc_cnab_inst_barcode_ds'],false );
                    disableFields( record, fieldsDisableSegment_J_O(),true );
                    break;

                case 'N01':
                    disableFields( record, fieldsEnableSegment_N_01(),false );
                    disableFields( record, fieldsDisableSegment_N_01(),true );
                    break;

                case 'N02':
                    disableFields( record, fieldsEnableSegment_N_02(),false );
                    disableFields( record, fieldsDisableSegment_N_02(),true );
                    break;

                case 'N03':
                    disableFields( record, fieldsEnableSegment_N_03(),false );
                    disableFields( record, fieldsDisableSegment_N_03(),true );
                    break;

                case 'N04':
                    disableFields( record, fieldsEnableSegment_N_04(),false );
                    disableFields( record, fieldsDisableSegment_N_04(),true );
                    break;

                case 'N05':
                    disableFields( record, fieldsEnableSegment_N_05(),false );
                    disableFields( record, fieldsDisableSegment_N_05(),true );
                    break;

                case 'N07':
                    disableFields( record, fieldsEnableSegment_N_07_08(),false );
                    disableFields( record, fieldsDisableSegment_N_07_08(),true );
                    break;

                case 'N08':
                    disableFields( record, fieldsEnableSegment_N_07_08(),false );
                    disableFields( record, fieldsDisableSegment_N_07_08(),true );
                    break;

                case 'N11':
                    disableFields( record, fieldsEnableSegment_N_11(),false );
                    disableFields( record, fieldsDisableSegment_N_11(),true );
                    break;
            }
        }

        /**
         * @function
         * @param barcode
         * @return {boolean}
         */
        function validateBarcode( barcode )
        {
            barcode  = barcode.replace( /[^0-9]/g, '' );
            if( barcode.length === 47 || barcode.length === 44 )
            {
                if( barcode.length < 47 ) {
                    barcode = barcode + '00000000000'.substr( 0, (47 - barcode.length) );
                }
                barcode = barcode.substr(0,4) + barcode.substr(32,15) + barcode.substr(4,5) +
                    barcode.substr(10,10) + barcode.substr(21,10);

                var checkDigit = module11( barcode.substr(0,4) + barcode.substr(5,39) );
                if( checkDigit !== Number(barcode.substr(4,1)) ) {
                    return false;
                }
            } else {
                return false
            }
            return true;
        }

        /**
         * @function
         * @param number
         * @return {number}
         */
        function module11( number )
        {
            number = number.replace( /[^0-9]/g, '' );
            var sum  = 0;
            var weight  = 2;
            var base  = 9;
            var count = number.length - 1;

            for( var i=count; i >= 0; i-- )
            {
                sum = sum + ( number.substring(i,i+1) * weight );
                if( weight < base ) {
                    weight++;
                } else {
                    weight = 2;
                }
            }
            var digit = 11 - ( sum % 11 );
            if( digit > 9 ) digit = 0;
            if( digit === 0 ) digit = 1;
            return digit;
        }

        /**
         * @function
         * @param barcode
         * @return {boolean}
         */
        function validateDealershipBarcode( barcode )
        {
            barcode  = barcode.replace( /[^0-9]/g, '' );
            return barcode.length === 48;
        }

        return {
            label: label,
            getSegment: getSegment,
            validateBarcode: validateBarcode,
            validateDealershipBarcode: validateDealershipBarcode,
            disableFields: disableFields,
            fieldsDisable: fieldsDisable,
            manageFields: manageFields
        }
    }
);