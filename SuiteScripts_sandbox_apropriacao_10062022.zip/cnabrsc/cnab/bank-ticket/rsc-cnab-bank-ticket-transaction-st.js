/**
 * @NScriptType Suitelet
 * @NApiVersion 2.0
 * @scriptName rsc-cnab-bank-ticket-transaction-st
 */
define
(
    [ 'N/ui/serverWidget', 'N/runtime', 'N/record', 'N/file', 'N/url', 'N/task', '../lib/rsc-cnab-constant', './rsc-cnab-bank-ticket' ],

    /**
     * @function
     * @param ui
     * @param runtime
     * @param _record
     * @param file
     * @param url
     * @param task
     * @param _c
     * @param lib
     * @return {{onRequest: onRequest}}
     */
    function( ui, runtime, _record, file, url, task, _c, lib )
    {
        /**
         * @function
         * @param context
         */
        function onRequest( context )
        {
            try
            {
                const param = context.request.parameters;
                const response = lib.generate( param.transactionType, param.transactionId, param.entityType );
                context.response.write({ output: JSON.stringify(response.generated) });

            } catch(e) {
                log.error( 'onRequest', e );
            }
        }

        return {
            onRequest: onRequest
        };
    }
);