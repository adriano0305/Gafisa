/**
 * @NScriptType Suitelet
 * @NApiVersion 2.0
 * @scriptName rsc-cnab-bank-ticket-st
 */
define
(
    [ 'N/ui/serverWidget', 'N/runtime', 'N/record', 'N/file', 'N/url', 'N/task', '../lib/rsc-cnab-constant', './rsc-cnab-bank-ticket' ],

    /**
     * @function
     * @param ui
     * @param runtime
     * @param _record
     * @param file
     * @param url
     * @param task
     * @param _c
     * @param lib
     * @return {{onRequest: onRequest}}
     */
    function( ui, runtime, _record, file, url, task, _c, lib )
    {
        /**
         * @function
         * @param context
         */
        function onRequest( context )
        {
            try
            {
                const param = context.request.parameters;

                var form = ui.createForm({ title : lib.label().title });
                var sublist = lib.createSublist( form );

                var transaction = _record.load({ type: param.transactionType, id: param.transactionId, isDynamic: true });
                var tranId = transaction.getValue({ fieldId: 'tranid' });
                var entity = transaction.getText({ fieldId: 'entity' });
                var lines = transaction.getLineCount({ sublistId: 'installment' });

                for( var i=0; i < lines; i++ )
                {
                    transaction.selectLine({ sublistId: 'installment', line: i });
                    var id = transaction.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'nkey' });
                    var iNum = transaction.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'installmentnumber' });
                    var dueDate = transaction.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'duedate' });
                    var amount = transaction.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'amount' });

                    log.audit( 'onRequest', 'iNum: '+iNum );

                    lib.addList( sublist, id, tranId, entity, iNum, dueDate, amount, i );
                }

                context.response.writePage( form );

                // const response = lib.generate( param.transactionType, param.transactionId, param.entityType );
                // context.response.write({ output: fileId.toString() });

            } catch(e) {
                log.error( 'onRequest', e );
            }
        }

        return {
            onRequest: onRequest
        };
    }
);