/**
 * @NApiVersion 2.0
 * @NModuleScope Public
 * @scriptName rsc-cnab-bank-ticket
 */
define([ 'N/record', 'N/search', 'N/render', 'N/file', 'N/url', 'N/runtime', '../lib/rsc-cnab-constant', '../lib/rsc-cnab-underscore',
        './rsc-cnab-bank-ticket-api.js', 'N/runtime', 'N/ui/serverWidget'],

    /**
     * @function
     * @param _record
     * @param _search
     * @param _render
     * @param _file
     * @param _url
     * @param _runtime
     * @param _c
     * @param _u
     * @param api
     * @param runtime
     * @return {object}
     */
    function( _record, _search, _render, _file, _url, _runtime, _c, _u, api, runtime, ui)
    {
        /**
         * @function
         * @param bankAccountId
         * @param entityId
         * @param entityType
         */
        function getData( bankAccountId, entityId, entityType )
        {
            var ba = _record.load({ type: 'customrecord_rsc_cnab_bankaccount', id: bankAccountId, isDynamic: true });
            var locationId = ba.getValue({ fieldId: 'custrecord_rsc_cnab_ba_location_ls' });
            var bankId = ba.getValue({ fieldId: 'custrecord_rsc_cnab_ba_bank_ls' });
            var portfolioId = ba.getValue({ fieldId: 'custrecord_rsc_cnab_ba_portfolio_ls' });
            var setup = getSetup();

            return {
                bankAccount: getBankAccount( ba ),
                portfolio: getPortfolio( portfolioId ),
                entity: getEntity( entityType, entityId, setup ),
                location: getLocation( locationId, setup ),
                bank: getBank( bankId )
            };
        }

        /**
         * @function
         * @return {{number: string, city: string, addressType: string, district: string, cpf: string, cnpj: string, complement: string}}
         */
        function getSetup()
        {
            var result = _search.create({
                type: 'customrecord_rsc_cnab_fieldssetup',
                columns: ['custrecord_acs_cnab_fs_city_ds', 'custrecord_acs_cnab_fs_district_ds', 'custrecord_acs_cnab_fs_addresstype_ds',
                    'custrecord_acs_cnab_fs_number_ds', 'custrecord_acs_cnab_fs_complement_ds', 'custrecord_acs_cnab_fs_entitycnpj_ds',
                    'custrecord_acs_cnab_fs_entitycpf_ds', 'custrecord_acs_cnab_fs_legalname_ds', 'custrecord_acs_cnab_fs_locationcnpj_ds'],
                filters: []
            });
            var setup = result.run().getRange({ start: 0, end: 1 });
            return {
                city: setup[0].getValue({ name: 'custrecord_acs_cnab_fs_city_ds' }),
                district: setup[0].getValue({ name: 'custrecord_acs_cnab_fs_district_ds' }),
                addressType: setup[0].getValue({ name: 'custrecord_acs_cnab_fs_addresstype_ds' }),
                number: setup[0].getValue({ name: 'custrecord_acs_cnab_fs_number_ds' }),
                complement: setup[0].getValue({ name: 'custrecord_acs_cnab_fs_complement_ds' }),
                cnpj: setup[0].getValue({ name: 'custrecord_acs_cnab_fs_entitycnpj_ds' }),
                cpf: setup[0].getValue({ name: 'custrecord_acs_cnab_fs_entitycpf_ds' }),
                locationCnpj: setup[0].getValue({ name: 'custrecord_acs_cnab_fs_locationcnpj_ds' }),
                legalName: setup[0].getValue({ name: 'custrecord_acs_cnab_fs_legalname_ds' })
            }
        }

        /**
         * @function
         * @param bankAccount
         * @return {{number: string, agreement: string, agency: string, name: *, dvNumber: string}}
         */
        function getBankAccount( bankAccount )
        {
            return {
                name: bankAccount.getText({ fieldId: 'custrecord_rsc_cnab_ba_location_ls' }),
                agency: bankAccount.getValue({ fieldId: 'custrecord_rsc_cnab_ba_agencynumber_ls' }),
                dvAgency:bankAccount.getValue({fieldId: 'custrecord_rsc_cnab_ba_dvagencynumber_ds'}),
                number: bankAccount.getValue({ fieldId: 'custrecord_rsc_cnab_ba_number_ds' }),
                digitNumber: bankAccount.getValue({ fieldId: 'custrecord_rsc_cnab_ba_dvnumber_ds' }),
                agreement: bankAccount.getValue({ fieldId: 'custrecord_rsc_cnab_ba_agreement_ds' })
            }
        }

        /**
         * @function
         * @param bankId
         * @return {{template: string, code: string, name: string}}
         */
        function getBank( bankId )
        {
            var bank = _record.load({ type: 'customrecord_rsc_cnab_bank', id: bankId, isDynamic: true });
            var logoId = bank.getValue({ fieldId: 'custrecord_rsc_cnab_bank_logo_im' });
            return {
                name: bank.getValue({ fieldId: 'name' }),
                code: bank.getValue({ fieldId: 'custrecord_rsc_cnab_bank_code_ds' }),
                logo: getUrl( logoId ),
                billingFolder: bank.getValue({ fieldId: 'custrecord_rsc_cnab_bank_btickefolder_nu' }),
                template: bank.getValue({ fieldId: 'custrecord_rsc_cnab_bank_template_ds' })
            }
        }

        /**
         * @function
         * @param portfolioId
         * @return {{number: string, code: string}}
         */
        function getPortfolio( portfolioId )
        {
            var portfolio = _record.load({ type: 'customrecord_rsc_cnab_portfolio', id: portfolioId, isDynamic: true });
            return {
                number: portfolio.getValue({ fieldId: 'custrecord_rsc_cnab_portfolio_number_nu' }),
                code: portfolio.getValue({ fieldId: 'custrecord_rsc_cnab_portfolio_code_ds' })
            }
        }

        /**
         * @function
         * @param entityType
         * @param entityId
         * @param setup
         */
        function getEntity( entityType, entityId, setup )
        {
            var entity = _record.load({ type: entityType, id: entityId, isDynamic: true });
            var lines = entity.getLineCount({ sublistId: 'addressbook' });
            var obj = {};
            obj.name = entity.getValue({ fieldId: 'entityid' });
            //Pega o Nome da Razão Social
            obj.RazaoSocial = entity.getValue({fieldId:'custentity_enl_legalname'});
            // Fimm
            obj.cnpjCpf = entity.getValue({ fieldId: setup.cnpj }) || entity.getValue({ fieldId: setup.cpf });

            for( var i=0; i < lines; i++ )
            {
                entity.selectLine({ sublistId: 'addressbook', line: i });
                if( entity.getCurrentSublistValue({ sublistId: 'addressbook', fieldId: 'defaultbilling' }) )
                {
                    var addressBook = entity.getCurrentSublistSubrecord({ sublistId: 'addressbook', fieldId: 'addressbookaddress' });
                    getSubRecordAddress( addressBook, obj, setup );
                    break;
                }
            }
            return obj;
        }

        /**
         * @function
         * @param locationId
         * @param setup
         */
        function getLocation( locationId, setup )
        {
            var obj = {};
            var location = _record.load({ type: 'location', id: locationId, isDynamic: true });
            obj.cnpj = ( setup.locationCnpj ) ? location.getValue({ fieldId: setup.locationCnpj }) : '';
            obj.name = ( setup.legalName ) ? location.getValue({ fieldId: setup.legalName }) : '';
            var mainAddress = location.getSubrecord({ fieldId: 'mainaddress' });
            getSubRecordAddress( mainAddress, obj, setup );
            return obj;
        }

        /**
         * @function
         * @param obj
         * @param address
         * @param setup
         */
        function getSubRecordAddress( address, obj, setup )
        {
            var country = address.getValue({ fieldId: 'country' });
            var zip = address.getValue({ fieldId: 'zip' });
            var state = address.getValue({ fieldId: 'state' });
            var city = ( setup.city ) ? address.getText({ fieldId: setup.city }) : '';
            var district = ( setup.district ) ? address.getValue({ fieldId: setup.district }) : '';
            var street = address.getValue({ fieldId: 'addr1' });
            var addressType = ( setup.addressType ) ? address.getText({ fieldId: setup.addressType }) : '';
            var number = ( setup.number ) ? address.getValue({ fieldId: setup.number }) : '';
            var complement = ( setup.complement ) ? address.getValue({ fieldId: setup.complement }) : '';

            if( city ) {
                if( city.indexOf('-') > -1 ) {
                    city = city.substr(0, city.indexOf('-')).trim();
                }
            } else {
                city = '';
            }

            obj.country = ( country ) ? country : '';
            obj.zip = ( zip ) ? (zip.indexOf('-') > -1) ? zip : zip.substr(0,5)+'-'+zip.substr(5,3) : '';
            obj.state = ( state ) ? state : '';
            obj.city = city;
            obj.district = ( district ) ? district : district;
            obj.addressType = ( addressType ) ? addressType + ' ' : '';
            obj.street = ( street ) ? street : '';
            obj.number = ( number ) ? number : '';
            obj.complement = ( complement ) ? complement : '';
            obj.address1 =  obj.addressType + obj.street + ' ' + obj.number;
            obj.address2 = obj.district + '  ' + obj.zip + ' ' + obj.city + ' ' + obj.state
        }

        /**
         * @function
         * @param fileId
         * @return {string}
         */
        function getUrl( fileId )
        {
            var file = _file.load({ id: fileId });
            return file.url.replace( /\&/g, '&amp;' );
        }

        /**
         * @function
         * @param specieId
         * @return {{code: *}}
         */
        function getSpecieFields( specieId )
        {
            var fields = _search.lookupFields
            ({
                type: 'customrecord_rsc_cnab_species',
                id: specieId,
                columns: [ 'custrecord_rsc_cnab_species_btcode_ds' ]
            });
            return {
                code: fields[ 'custrecord_rsc_cnab_species_btcode_ds' ]
            }
        }

        /**
         * @function
         * @param data
         */
        function generateBankTicket( data, NF )
        {
            if(data.bank.code == '237'){
                //const numbers = data.bankAccount.agency + '' + data.bankAccount.number + '' + api.padding(data.portfolio.code, 2) + '' + api.padding(data.installment.ourNumber,11);
                data.digitOurNumber = generateOurNumberDigit(data.installment.ourNumber ,data.portfolio.code );
            }else{
                const number = data.bankAccount.agency + '' + data.bankAccount.number + '' + data.portfolio.number + '' + api.padding(data.installment.ourNumber,8);
                data.digitOurNumber = api.modulo10( number );
            }
            //const number = data.bankAccount.agency + '' + data.bankAccount.number + '' + api.padding(data.portfolio.number, 2) + '' + api.padding(data.installment.ourNumber,11);
            //log.error({title:"number1",details:number});
            //data.digitOurNumber = api.modulo11( number );
            //log.error({title:"digito11",details:api.modulo11( number )});
            if(data.bank.code == '237'){
                data.barcode = api.buildBarcodeBra( data );
                data.line = api.buildLineBra( data.barcode ); 
            }else if(data.bank.code == '001'){
                data.barcode = api.buildBarcodeBB( data );
                data.line = api.buildLine( data.barcode );
            //ajustar code banco Santander 
            }else if(data.bank.code == '033'){
                data.barcode = api.buildBarcodeSantander( data );
                data.line = api.buildLine( data.barcode );  
            }else{
                data.barcode = api.buildBarcode( data ); 
                data.line = api.buildLine( data.barcode );
            }
            //data.barcode = api.buildBarcode( data );
            log.error({title:"barcode",details:data.barcode});
            //data.line = api.buildLine( data.barcode );
            log.error({title:"line",details:data.line});
            data.processingDate = api.formatDate( new Date() );
          	if(data.bank.code == '237'){
              data.paymentPlace = 'Pagável preferencialmente na Rede Bradesco ou Bradesco Expresso';
            }else if(data.bank.code == '001'){
                data.paymentPlace = 'Pagável em qualquer banco';
            }else if(data.bank.code =='033'){
                data.paymentPlace = 'Pagável em qualquer banco ou correspondente não bancário mesmo após o vencimento';
            }else{
              data.paymentPlace = 'Pagável em qualquer banco ou correspondente não bancário mesmo após o vencimento'
            }
          	//data.paymentPlace = 'Pagável preferencialmente na Rede Bradesco ou Bradesco Expresso';
            //data.paymentPlace = 'ATÉ O VENCIMENTO PAGÁVEL EM QUALQUER BANCO';
            data.bank.digitCode = api.modulo11( data.bank.code );
            log.error({title:"digitCode",details: api.modulo11( data.bank.code )});
            data.installment.dueDate = api.formatDate( data.installment.dueDate );
            // <CNAB DUX - 23/01/20  INCLUINDO NUMERO DA PARCELA NO BOLETO>
            //data.ParcNumber = api.padding(data.installment.id, 2 );
            // </CNAB DUX>
            //data.documentNumber = api.padding( NF, 9 );
            data.documentNumber = api.padding( data.installment.id, 9 );
            data.dvAgencyBra = data.bankAccount.dvAgency;
            data.CarteiraBra = data.portfolio.code.substring(1, 3);
            data.agreement = data.bankAccount.agreement;
            //log.error({title:"CarteiraBra",details:data.portfolio.code.substring(1, 3)});
            if(data.bank.code =='237'){
                data.installment.ourNumber = api.padding( data.installment.ourNumber, 11);
            }else if(data.bank.code =='033'){
                data.installment.ourNumber = api.padding( data.installment.ourNumber, 13);
            }else if(data.bank.code =='001'){
                    data.installment.ourNumber = api.padding( data.installment.ourNumber, 10);
            }else{
                data.installment.ourNumber = api.padding( data.installment.ourNumber, 8);
            }
            log.error({title:"ourNumber",details:data.installment.ourNumber});
            //data.installment.ourNumber = api.padding( data.installment.ourNumber, 11);
            data.installment.amount = api.formatCurrency( data.installment.amount, 2, null, '.', ',' );
            data.barcode = api.barcodeBinary( data.barcode );
			//log.debug({title:"barcodeBinary",details:api.barcodeBinary( data.barcode )});
            var toMerge = _u.template( data.bank.template );
            var merged = toMerge({ data: data });
            var file = _render.xmlToPdf({ xmlString: merged });
            file.folder = data.bank.billingFolder;
            file.isOnline = true;
            file.name = 'boleto_'+data.entity.cnpjCpf+'_'+data.installment.dueDate.replace(/[\/]/gi, '-');
            return file.save();
        }

        /**
     *
     * @param transactionType
     * @param transactionId
     * @param entityType
     */
    function generate( transactionType, transactionId, entityType )
    {
        var transaction = _record.load({ type: transactionType, id: transactionId, isDynamic: true });
        var bankAccountId = transaction.getValue({ fieldId: 'custbody_rsc_cnab_bankaccountloc_ls' });
        var entityId = transaction.getValue({ fieldId: 'entity' });
        var NF = transaction.getValue({ fieldId: 'custbody_enl_fiscaldocnumber' });
        var lines = transaction.getLineCount({ sublistId: 'installment' });
        var data = getData( bankAccountId, entityId, entityType);
        var files = [];
        log.audit('lines',lines)
        for( var i=0; i < lines; i++ )
        {
            transaction.selectLine({ sublistId: 'installment', line: i });
            var status = transaction.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'custrecord_rsc_cnab_inst_status_ls' });
            log.audit('Status', Number(status) === _c._status.available )
            if( Number(status) === _c._status.available )
            {
                data.installment = getDataLine( transaction );
                var fileId = generateBankTicket( data, NF);
                transaction.setCurrentSublistValue({
                    sublistId: 'installment',
                    fieldId: 'custrecord_rsc_cnab_inst_ournumber_nu',
                    value: data.installment.ourNumber
                })

                transaction.commitLine({
                    sublistId: 'installment'
                })



                log.audit( 'onRequest', 'Bank ticket created: ' + fileId );
                files.push( fileId );

                _record.attach({
                    record: { type: 'file', id: fileId },
                    to: { type: transactionType, id: transactionId }
                });
            }


        }
        transaction.save()
        return ( files.length > 0 ) ? { generated: true } : { generated: false };
    }
    /**
         * Calcula o dígito de auto-conferência do Nosso Número | Específico para o banco Bradesco
         *
         * Para o cálculo do dígito, acrescentar o número da carteira à esquerda antes do Nosso Número, e aplicar o módulo 11, com base 7.
         * A diferença entre o divisor menos o resto será o dígito de auto-conferência.
         * Se o resto da divisão for “1”, desprezar a diferença entre o divisor menos o resto que será “10” e considerar o dígito como “P”.
         * Se o resto da divisão for “0”, desprezar o cálculo de subtração entre divisor e resto, e considerar o “0” como dígito.
         *
         * @param ourNumber
         * @param portfolio
         * @return {string|number}
         */
        function generateOurNumberDigit( ourNumber, portfolio )
        {
            var number = api.padding(Number(portfolio), 2 )+''+ api.padding( ourNumber, 11 );
            var base = 7;
            var sum = 0;
            var factor = 2;

            for( var i = number.length - 1; i >= 0; i-- )
            {
                var partial = parseInt( number[i] ) * factor;
                sum += partial;
                if( factor === base ) {
                    factor = 1;
                }
                factor++;
            }
            var digit = sum % 11;
            if( digit ===  1) {
                return 'P';
            } else if( digit === 0 ) {
                return 0;
            } else {
                return 11 - digit;
            }
        }

    /**
     * @param bankAccountId
      @param {} installments 
     * @return {string}
     */
    //<CNAB DUX - 08/01/20 - AJUSTAR DEPOIS>
    function generateOurNumber( bankAccountId, transaction ){
        try {
            const bankAccount = _record.load({ 
                type: 'customrecord_rsc_cnab_bankaccount', 
                id: bankAccountId,
                isDynamic: true
            })

            var ourNumber = parseInt(bankAccount.getValue({ 
                fieldId: 'custrecord_rsc_cnab_ba_ournumber_nu' 
            }))

            bankAccount.setValue({
                fieldId: 'custrecord_rsc_cnab_ba_ournumber_nu',
                value: ourNumber+1
            })
            //log.audit('Nosso_Numero1', ourNumber);
            bankAccount.save()
            //log.audit('Nosso_Numero2', ourNumber);
        } catch (error) {
            log.error('erro', error)
        }

        return ourNumber
    }
    //</CNAB DUX>

    /**
     *
     * @param transaction
     */
    function getDataLine( transaction )
    {
        var specieId = transaction.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'custrecord_rsc_cnab_inst_specie_ls' });
        var obj = {};
        // <CNAB DUX - 23/01/20  INCLUINDO NUMERO DA PARCELA NO BOLETO>
        obj.id = transaction.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'seqnum' });
        // </CNAB DUX>
        obj.dueDate = transaction.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'duedate' });
        obj.amount = transaction.getCurrentSublistValue({ sublistId: 'installment', fieldId: 'amount' });
        //<CNAB DUX - 08/01/20 - AJUSTAR DEPOIS>
        obj.ourNumber = generateOurNumber(transaction.getValue({fieldId: 'custbody_rsc_cnab_bankaccountloc_ls'}), transaction)
        //</CNAB DUX>
        obj.instruction1 = transaction.getCurrentSublistText({ sublistId: 'installment', fieldId: 'custrecord_rsc_cnab_inst_1instruction_ls' });
        obj.instruction2 = transaction.getCurrentSublistText({ sublistId: 'installment', fieldId: 'custrecord_rsc_cnab_inst_2instruction_ls' });
        obj.specie = getSpecieFields( specieId ).code;
        return obj;
    }

        /**
         *
         */
        function label()
        {
            const language = runtime.getCurrentUser().getPreference({name: 'LANGUAGE'});
            return {
                title: ( language === 'pt_BR' ) ? 'Geração de Boleto' : 'Generate Bank Ticket',
                bankData: ( language === 'pt_BR' ) ? 'Dados Bancários' : 'Bank Data',
                inst: ( language === 'pt_BR' ) ? 'Parcelas' : 'Installments',
                installments: ( language === 'pt_BR' ) ? 'Seleção de Parcelas' : 'Installments Selection',
                generation: ( language === 'pt_BR' ) ? 'Geração' : 'Generation',
                subsidiary: ( language === 'pt_BR' ) ? 'Subsidiária' : 'Subsidiary',
                bankAccount: ( language === 'pt_BR' ) ? 'Conta Corrente' : 'Bank Account',
                select: ( language === 'pt_BR' ) ? 'Selecionar' : 'Select',
                startDate: ( language === 'pt_BR' ) ? 'Data de Vencimento Incial' : 'Start Due Date',
                endDate: ( language === 'pt_BR' ) ? 'Data de Vencimento Final' : 'End Due Date',
                filters: ( language === 'pt_BR' ) ? 'Filtros' : 'Filters',
                location: ( language === 'pt_BR' ) ? 'Localidade' : 'Location',
                vendor: ( language === 'pt_BR' ) ? 'Fornecedor' : 'Vendor',
                customer: ( language === 'pt_BR' ) ? 'Cliente' : 'Customer',
                batchData: ( language === 'pt_BR' ) ? 'Dados da Remessa' : 'Batch Data',
                paymentDate: ( language === 'pt_BR' ) ? 'Data do Pagamento' : 'Payment Date',
                tranId: ( language === 'pt_BR' ) ? 'Transação' : 'Transaction',
                instNu: ( language === 'pt_BR' ) ? 'Número Parcela' : 'Installment Number',
                entity: ( language === 'pt_BR' ) ? 'Entidade' : 'Entity',
                dueDate: ( language === 'pt_BR' ) ? 'Data de Vencimento' : 'Due Date',
                amount: ( language === 'pt_BR' ) ? 'Valor' : 'Amount',
                search: ( language === 'pt_BR' ) ? 'Buscar' : 'Search',
                alert: ( language === 'pt_BR' ) ? 'Alerta' : 'Alert',
                interest: ( language === 'pt_BR' ) ? 'Juros' : 'Interest',
                fine: ( language === 'pt_BR' ) ? 'Multa' : 'Fine',
                rebate: ( language === 'pt_BR' ) ? 'Abatimento' : 'Rebate',
                discount: ( language === 'pt_BR' ) ? 'Desconto' : 'Discount',
                method: ( language === 'pt_BR' ) ? 'Forma de Pagamento' : 'Payment Method',
                selectAll: ( language === 'pt_BR' ) ? 'Selecionar Tudo' : 'Select All',
                unselectAll: ( language === 'pt_BR' ) ? 'Desmarcar Tudo' : 'Unselect All',
            };
        }

        /**
         *
         * @param form
         */
        function createSublist( form )
        {
            var sublist = form.addSublist({ id : 'installment', type : ui.SublistType.LIST, label: label().inst });
            sublist.addField({ id:'select', type:'checkbox', label:label().select });
            sublist.addField({ id:'id', type:'text', label:'Installment Id' }).updateDisplayType({ displayType : ui.FieldDisplayType.HIDDEN });
            sublist.addField({ id:'tranid', type:'text', label:label().tranId }).updateDisplayType({ displayType : ui.FieldDisplayType.DISABLED });
            sublist.addField({ id:'entitytext', type:'text', label:label().entity }).updateDisplayType({ displayType : ui.FieldDisplayType.DISABLED });
            sublist.addField({ id:'installment', type:'text', label:label().instNu }).updateDisplayType({ displayType : ui.FieldDisplayType.DISABLED });
            sublist.addField({ id:'duedate', type:'date', label:label().dueDate }).updateDisplayType({ displayType : ui.FieldDisplayType.DISABLED });
            sublist.addField({ id:'amount', type:'currency', label:label().amount }).updateDisplayType({ displayType : ui.FieldDisplayType.DISABLED });
            sublist.addButton({ id:'selectall', label:label().selectAll, functionName:'selectAll' });
            sublist.addButton({ id:'unselectall', label:label().unselectAll, functionName:'unselectAll' });
            return sublist;
        }

        /**
         *
         * @param sublist
         * @param id
         * @param tranId
         * @param entity
         * @param iNum
         * @param dueDate
         * @param amount
         * @param i
         */
        function addList( sublist, id, tranId, entity, iNum, dueDate, amount, i )
        {
            sublist.setSublistValue({ id: 'select', line: i, value: 'T' });
            sublist.setSublistValue({ id: 'id', line: i, value: id });
            sublist.setSublistValue({ id: 'tranid', line: i, value: tranId });
            sublist.setSublistValue({ id: 'entitytext', line: i, value: entity });
            // sublist.setSublistValue({ id: 'installment', line: i, value: iNum });
            sublist.setSublistValue({ id: 'duedate', line: i, value: dueDate });
            sublist.setSublistValue({ id: 'amount', line: i, value: amount });
        }

        return {
            generate: generate,
            label: label,
            createSublist: createSublist,
            addList: addList
        }
    }
);