/**
 * @NApiVersion 2.0
 * @NModuleScope Public
 * @scriptName rsc-cnab-bank-ticket-api
 */
define([  ],

    /**
     * @function
     * @return {object}
     */
    function(  )
    {
        /**
         * @function
         * @param number
         * @return {number}
         */
        function modulo10( number )
        {
            var total = 0;
            var factor = 2;
            for( var i = number.length - 1; i >= 0; i-- )
            {
                var temp = ( parseInt(number[i]) * factor ).toString();
                var sum = 0;
                for( var j = 0; j < temp.length; j++ ) {
                    sum += parseInt( temp[j] );
                }
                total += sum;
                factor = ( factor === 2 ) ? 1 : 2;
            }
            var rest = total % 10;
            return ( rest === 0 ) ? 0 : ( 10 - rest );
        }

        /**
         * @function
         * @param number
         * @param base
         * @param r
         * @return {number}
         */
        function modulo11( number, base, r )
        {
            if( !base ) base = 9;
            if( !r ) r = 0;
            var sum = 0;
            var factor = 2;

            for( var i = number.length - 1; i >= 0; i-- )
            {
                var partial = parseInt( number[i] ) * factor;
                sum += partial;
                if( factor === base ) {
                    factor = 1;
                }
                factor++;
            }
            if( r === 0 )
            {
                sum *= 10;
                var digit = sum % 11;
                return digit === 10 ? 0 : digit;
            }
            else if( r === 1 ) {
                return sum % 11;
            }
        }

        /**
         * @function fator de vencimento
         * @param date
         * @return {string}
         */
        function maturityFactor( date )
        {
            return padding( Math.floor((date.getTime() - new Date(1997, 9, 7).getTime())/(24 * 3600 * 1000)), 4 );
        }

        /**
         * @function
         * @param value
         * @param size
         * @return {string}
         */
        function padding( value, size )
        {
            var pad = '';
            for( var i = 0; i < size; i++ ) {
                pad += '0';
            }
            value = value.toString();
            return pad.substring( 0, pad.length - value.length ) + value;
        }

        /**
         *
         * @param date
         * @return {string}
         */
        function formatDate( date )
        {
            return padding( date.getDate(), 2 ) + '/' + padding( date.getMonth()+1, 2 ) + '/' + date.getFullYear();
        }

        /**
         * @function
         * @param value
         * @param n: length of decimal
         * @param x: length of whole part
         * @param s: sections delimiter
         * @param c: decimal delimiter
         */
        function formatCurrency( value, n, x, s, c )
        {
            var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')';
            var num = value.toFixed(Math.max(0, n));
            return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + s);
        }

        /**
         * @function
         * @param barcode
         * @return {string}
         */
        function barcodeBinary( barcode )
        {
            var binary = '0000';
            var digits = { 0: '00110', 1: '10001', 2: '01001', 3: '11000', 4: '00101', 5: '10100', 6: '01100', 7: '00011', 8: '10010', 9: '01010' };

            if( barcode.length % 2 !== 0 ) {
                barcode = '0' + barcode;
            }
            for( var i = 0; i < barcode.length; i += 2 )
            {
                var digit1 = digits[ parseInt(barcode[i]) ];
                var digit2 = digits[ parseInt(barcode[i + 1]) ];

                for( var y = 0; y < digit1.length; y++ ) {
                    binary += digit1[y] + digit2[y];
                }
            }
            binary += '1000';
            return binary;
        }
        //começo do codigo do banco do Brasil
        /**
         * @function Layout do Código de Barras
         * Posição - Tamanho - Picture   - Conteúdo
         * 01 a 03 - 03      - 9(03)     - Código do Banco na Câmara de Compensação = '001'
         * 04 a 04 - 01      - 9(01)     - Código da Moeda = '9'
         * 05 a 05 - 01      - 9(01)     - DAC  código de Barras
         * 06 a 09 - 04      - 9(04)     - Fator de Vencimento
         * 10 a 19 - 10      - 9(08)V(2) - Valor
         * 20 a 25 - 06      - 9(06)     - Zeros
         * 26 a 32 - 07      - 9(07)     - Número do Convênio fornecido pelo Banco (CCCCCCC)
         * 33 a 42 - 10      - 9(10)     - Complemento do Nosso-Número, sem DV (NNNNNNNNNN)
         * 43 a 44 - 02      - 9(02)     - Tipo de Carteira/Modalidade de Cobrança
         * @param data
         * @return {string}
         */
        function buildBarcodeBB( data )
        {
            var currency = '9';
            var factor = maturityFactor( data.installment.dueDate );
            var amount = formatCurrency( data.installment.amount, 2, null, '.', '' ).replace( /[,.]/gi, '' );
            amount = padding( amount, 10 );
            var ourNumber = padding( data.installment.ourNumber, 10);
            var Portfolio = data.portfolio.code
            var baDigit = modulo10(
                data.bankAccount.agency.toString() + data.bankAccount.number.toString() +
                 padding(data.portfolio.code,2) + padding(data.installment.ourNumber,10)
            );
            var dv = data.bankAccount.digitNumber == 'X' ? 0 : data.bankAccount.digitNumber;
            var digit = barcodeDigit(
                data.bank.code + currency + factor + amount + '000000' + data.bankAccount.agreement +  ourNumber + Portfolio
            );

            return data.bank.code + currency + digit + factor + amount + '000000' + data.bankAccount.agreement +  ourNumber + Portfolio
        }
        //fim do codigo do banco do Brasil
        
        //começo do codigo do banco Santander
        /**
         * @function Layout do Código de Barras
         * Posição - Tamanho - Picture   - Conteúdo
         * 01 a 03 - 03      - 9(03)     - Código do Banco na Câmara de Compensação = '001'
         * 04 a 04 - 01      - 9(01)     - Código da Moeda = '9'
         * 05 a 05 - 01      - 9(01)     - DAC  código de Barras
         * 06 a 09 - 04      - 9(04)     - Fator de Vencimento
         * 10 a 19 - 10      - 9(08)V(2) - Valor
         * 20 a 25 - 06      - 9(06)     - Zeros
         * 26 a 32 - 07      - 9(07)     - Número do Convênio fornecido pelo Banco (CCCCCCC)
         * 33 a 42 - 10      - 9(10)     - Complemento do Nosso-Número, sem DV (NNNNNNNNNN)
         * 43 a 44 - 02      - 9(02)     - Tipo de Carteira/Modalidade de Cobrança
         * @param data
         * @return {string}
         */
        
         //Criado Novo Banco Santander por Rafael Mossolin 07/07
        function buildBarcodeSantander( data )
        {
            var currency = '9';
            var factor = maturityFactor( data.installment.dueDate );
            var amount = formatCurrency( data.installment.amount, 2, null, '.', '' ).replace( /[,.]/gi, '' );
            amount = padding( amount, 10 );
            var ourNumber = padding( data.installment.ourNumber, 10);
            var Portfolio = data.portfolio.code
            var baDigit = modulo10(
                data.bankAccount.agency.toString() + data.bankAccount.number.toString() +
                 padding(data.portfolio.code,2) + padding(data.installment.ourNumber,10)
            );
            var dv = data.bankAccount.digitNumber == 'X' ? 0 : data.bankAccount.digitNumber;
            var digit = barcodeDigit(
                data.bank.code + currency + factor + amount + '000000' + data.bankAccount.agreement +  ourNumber + Portfolio
            );

            return data.bank.code + currency + digit + factor + amount + '000000' + data.bankAccount.agreement +  ourNumber + Portfolio
        }
        //fim do codigo do banco Santander

        //começo do codigo do banco Bradesco
        /**
         * @function Layout do Código de Barras
         * Posição - Tamanho - Picture   - Conteúdo
         * 01 a 03 - 03      - 9(03)     - Código do Banco na Câmara de Compensação = '033'
         * 04 a 04 - 01      - 9(01)     - Código da Moeda = '9'
         * 05 a 05 - 01      - 9(01)     - DAC  código de Barras
         * 06 a 09 - 04      - 9(04)     - Fator de Vencimento
         * 10 a 19 - 10      - 9(08)V(2) - Valor
         * 20 a 20   01      - 9(01)     - Fixo “9”
         * 21 a 27   07      - 9(07)     - Código do beneficiário padrão Santander
         * 28 a 40   13      - 9(13)     - Nosso Número com DV
         * 41 a 41   01      - 9(01)     - Fixo “0”
         * 42 a 44   03      - 9(03)     - Tipo de Modalidade Carteira: 101 - Cobrança Rápida COM Registro / 104 - Cobrança Eletrônica COM Registro
         * @param data
         * @return {string}
         */
        function buildBarcodeBra( data )
        {
            var currency = '9';
            var factor = maturityFactor( data.installment.dueDate );
            var amount = formatCurrency( data.installment.amount, 2, null, '.', '' ).replace( /[,.]/gi, '' );
            amount = padding( amount, 10 );
            var ourNumber = padding( data.installment.ourNumber, 11 );
            var Portfolio = data.portfolio.code.substring(1, 3);
            var baDigit = modulo10(
                data.bankAccount.agency.toString() + data.bankAccount.number.toString() +
                 padding(data.portfolio.code,2) + padding(data.installment.ourNumber,11)
                 //data.portfolio.number.toString() + padding(data.installment.ourNumber,11)
            );
            var dv = data.bankAccount.digitNumber == 'X' ? 0 : data.bankAccount.digitNumber;
            var digit = barcodeDigit(
                data.bank.code + currency + factor + amount + data.bankAccount.agency + Portfolio + ourNumber +  
                data.bankAccount.number + '0'
            );

            return data.bank.code + currency + digit + factor + amount + data.bankAccount.agency + Portfolio + ourNumber +  
            data.bankAccount.number + '0'
        }
        //fim do codigo do banco Bradesco 


        //começo do codigo do banco Itau
        /**
         * @function Layout do Código de Barras
         * Posição - Tamanho - Picture   - Conteúdo
         * 01 a 03 - 03      - 9(03)     - Código do Banco na Câmara de Compensação = '341'
         * 04 a 04 - 01      - 9(01)     - Código da Moeda = '9'
         * 05 a 05 - 01      - 9(01)     - DAC  código de Barras
         * 06 a 09 - 04      - 9(04)     - Fator de Vencimento
         * 10 a 19 - 10      - 9(08)V(2) - Valor
         * 20 a 22 - 03      - 9(03)     - Carteira
         * 23 a 30 - 08      - 9(08)     - Nosso Número
         * 31 a 31 - 01      - 9(01)     - DAC [Agência/Conta/Carteira/Nosso Número]
         * 32 a 35 - 04      - 9(04)     - N.º da Agência cedente
         * 36 a 40 - 05      - 9(05)     - N.º da Conta Corrente
         * 41 a 41 - 01      - 9(01)     - DAC [Agência/Conta Corrente] (Anexo 3)
         * 42 a 44 - 03      - 9(03)     - Zeros
         * @param data
         * @return {string}
         */
        function buildBarcode( data )
        {
            var currency = '9';
            var factor = maturityFactor( data.installment.dueDate );
            var amount = formatCurrency( data.installment.amount, 2, null, '.', '' ).replace( /[,.]/gi, '' );
            amount = padding( amount, 10 );
            var ourNumber = padding( data.installment.ourNumber, 8 );

            var baDigit = modulo10(
                data.bankAccount.agency.toString() + data.bankAccount.number.toString() +
                data.portfolio.number.toString() + padding(data.installment.ourNumber,8)
            );
            var dv = data.bankAccount.digitNumber == 'X' ? 0 : data.bankAccount.digitNumber;
            var digit = barcodeDigit(
                data.bank.code + currency + factor + amount + data.portfolio.number + ourNumber + baDigit + data.bankAccount.agency +
                data.bankAccount.number + dv + '000'
            );

            return data.bank.code + currency + digit + factor + amount + data.portfolio.number + ourNumber + baDigit + data.bankAccount.agency +
                data.bankAccount.number + dv + '000';
        }
        //fim do codigo do banco Itau 

        /**
         * @function
         * @param value
         * @return {number}
         */
        function barcodeDigit( value )
        {
            const rest = modulo11( value, 9, 1 );
            return ( rest === 0 || rest === 1 || rest === 10 || rest === 11 ) ? 1 : 11 - rest;
        }
        /**
         * @function Representação Numérica do Código de Barras
         * ----- Campo 1 (AAABC.CCDDX) -----
         * AAA = Código do Banco na Câmara de Compensação ( Itaú=341)
         * B   = Código da moeda = "9"
         * CCC = Código da  carteira de cobrança
         * DD  = Dois primeiros dígitos do Nosso Número
         * X   = DAC que amarra o campo 1
         * ----- Campo 2 (DDDDD.DEFFFY) -----
         * DDDDDD = Restante do Nosso Número
         * E      = DAC do campo [ Agência/Conta/Carteira/ Nosso Número ]
         * FFF    = Três primeiros números que identificam a Agência
         * Y      = DAC que amarra o campo 2
         * ----- Campo 3 (FGGGG.GGHHHZ) -----
         * F      = Restante do número que identifica a agência
         * GGGGGG = Número da conta corrente +  DAC
         * HHH    = Zeros ( Não utilizado )
         * Z      = DAC que amarra o campo 3
         * ----- Campo 4 (K) -----
         * K = DAC do Código de Barras (Anexo 2 )
         * ----- Campo 5 (UUUUVVVVVVVVVV) -----
         * UUUU       = Fator de vencimento
         * VVVVVVVVVV = Valor do Título
         * @param barcode
         * @return {string}
         */
        function buildLineBra( barcode )
        {
            var fields = [];

            // Campo 1 (AAABC.CCDDX)
            var field1 = barcode.substring(0, 3) +  barcode.substring(3, 4) + barcode.substring(19, 22) + barcode.substring(22, 24);
            //log.error({title:"field1",details:barcode.substring(0, 3) +  barcode.substring(3, 4) + barcode.substring(32, 35) + barcode.substring(18, 20)});
            field1 = field1 + modulo10( field1 );
            field1 = field1.substring(0, 5) + '.' + field1.substring(5, field1.length);
            //log.error({title:"field_1", details: field1.substring(0, 5) + '.' + field1.substring(5, field1.length)});
            fields.push( field1 );

            // Campo 2 (DDDDD.DEFFFY)
            var field2 = barcode.substring(24, 34);
            //log.error({title:"field2", details: barcode.substring(20, 31)});
            field2 = field2 + modulo10( field2 );
            //log.error({title:"field_2M10", details: field2 + modulo10( field2)});
            field2 = field2.substring(0, 5) + '.' + field2.substring(5, field2.length);
            //log.error({title:"field_2", details: field2.substring(0, 5) + '.' + field2.substring(5, field2.length)});
            fields.push( field2 );

            // Campo 3 (FGGGG.GGHHHZ)
            var field3 = barcode.substring(34, 44) 
            //log.error({title:"field3", details: barcode.substring(36, 46)});
            field3 = field3 + modulo10( field3 );
            //log.debug({title:"field3M10", details: field3 + modulo10( field3 )});
            field3 = field3.substring(0, 5) + '.' + field3.substring(5, field3.length);
            //log.error({title:"field_3", details: field3.substring(0, 5) + '.' + field3.substring(5, field3.length)});
            fields.push( field3 );

            // Campo 4 (K)
            fields.push( barcode.substring(4, 5) );
            //log.debug({title:"campo4", details: fields.push( barcode.substring(4, 5) )});

            // Campo 5 (UUUUVVVVVVVVVV)
            var field5 = barcode.substring(5, 9) + barcode.substring(9, 19);
            //log.error({title:"field5", details:  barcode.substring(5, 9) + barcode.substring(9, 19)});
            fields.push( field5 );
            //log.error({title:"fieldspush", details: fields.push( field5 )});
            //log.error({title:"fields", details: fields});
            return fields.join(' ');
        }

        /**
         * @function Representação Numérica do Código de Barras
         * ----- Campo 1 (AAABC.CCDDX) -----
         * AAA = Código do Banco na Câmara de Compensação ( Itaú=341)
         * B   = Código da moeda = "9"
         * CCC = Código da  carteira de cobrança
         * DD  = Dois primeiros dígitos do Nosso Número
         * X   = DAC que amarra o campo 1
         * ----- Campo 2 (DDDDD.DEFFFY) -----
         * DDDDDD = Restante do Nosso Número
         * E      = DAC do campo [ Agência/Conta/Carteira/ Nosso Número ]
         * FFF    = Três primeiros números que identificam a Agência
         * Y      = DAC que amarra o campo 2
         * ----- Campo 3 (FGGGG.GGHHHZ) -----
         * F      = Restante do número que identifica a agência
         * GGGGGG = Número da conta corrente +  DAC
         * HHH    = Zeros ( Não utilizado )
         * Z      = DAC que amarra o campo 3
         * ----- Campo 4 (K) -----
         * K = DAC do Código de Barras (Anexo 2 )
         * ----- Campo 5 (UUUUVVVVVVVVVV) -----
         * UUUU       = Fator de vencimento
         * VVVVVVVVVV = Valor do Título
         * @param barcode
         * @return {string}
         */
        function buildLine( barcode )
        {
            var fields = [];

            // Campo 1 (AAABC.CCDDX)
            var field1 = barcode.substring(0, 3) +  barcode.substring(3, 4) + barcode.substring(19, 22) + barcode.substring(22, 24);
            //log.error({title:"field1",details:barcode.substring(0, 3) +  barcode.substring(3, 4) + barcode.substring(19, 22) + barcode.substring(22, 24)});
            field1 = field1 + modulo10( field1 );
            field1 = field1.substring(0, 5) + '.' + field1.substring(5, field1.length);
            //log.error({title:"field_1", details: field1.substring(0, 5) + '.' + field1.substring(5, field1.length)});
            fields.push( field1 );

            // Campo 2 (DDDDD.DEFFFY)
            var field2 = barcode.substring(24, 34);
            //log.error({title:"field2", details: barcode.substring(24, 34)});
            field2 = field2 + modulo10( field2 );
            field2 = field2.substring(0, 5) + '.' + field2.substring(5, field2.length);
            //log.error({title:"field_2", details: field2.substring(0, 5) + '.' + field2.substring(5, field2.length)});
            fields.push( field2 );

            // Campo 3 (FGGGG.GGHHHZ)
            var field3 = barcode.substring(34, 44);
            //log.error({title:"field3", details: barcode.substring(34, 44)});
            field3 = field3 + modulo10( field3 );
            field3 = field3.substring(0, 5) + '.' + field3.substring(5, field3.length);
            //log.error({title:"field_3", details: field3.substring(0, 5) + '.' + field3.substring(5, field3.length)});
            fields.push( field3 );

            // Campo 4 (K)
            fields.push( barcode.substring(4, 5) );
            //log.error({title:"campo4", details: fields.push( barcode.substring(4, 5) )});

            // Campo 5 (UUUUVVVVVVVVVV)
            var field5 = barcode.substring(5, 9) + barcode.substring(9, 19);
            //log.error({title:"field5", details:  barcode.substring(5, 9) + barcode.substring(9, 19)});
            fields.push( field5 );

            return fields.join(' ');
        }

        return {
            modulo10: modulo10,
            modulo11: modulo11,
            buildBarcodeBB:buildBarcodeBB,
            buildBarcodeSantander:buildBarcodeSantander,
            buildBarcodeBra: buildBarcodeBra,
            buildBarcode: buildBarcode,
            buildLineBra: buildLineBra,
            buildLine: buildLine,
            padding: padding,
            formatDate: formatDate,
            formatCurrency: formatCurrency,
            barcodeBinary: barcodeBinary
        }
    }
);