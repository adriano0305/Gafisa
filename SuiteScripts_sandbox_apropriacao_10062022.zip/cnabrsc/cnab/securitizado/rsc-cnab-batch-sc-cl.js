/**
 * @NScriptType ClientScript
 * @NApiVersion 2.0
 * @scriptName rsc-cnab-batch-cl
 */
define([ 'N/ui/dialog', 'N/runtime', 'N/currentRecord', './rsc-cnab-batch-sc' ],

    /**
     *
     * @param dialog
     * @param runtime
     * @param currentRecord
     * @param lib
     * @return {{saveRecord: (function(*): boolean)}}
     */
    function( dialog, runtime, currentRecord, lib )
    {
        /**
         * @function
         * @param context
         */
        function fieldChanged( context )
        {
            var record = currentRecord.get();
            if( context.fieldId === 'subsidiary' )
            {
                const subsidiaryId = record.getValue({ fieldId: 'subsidiary' });
                const bankAccountField = record.getField({ fieldId: 'custpage_bankaccount' });

                if( !lib.insertBankAccountOptions(subsidiaryId, bankAccountField) )
                {
                    lib.clearFieldOptions( bankAccountField );
                    lib.clearFieldOptions( record.getField({fieldId: 'custpage_layout'}) );
                }
            }
            else if( context.fieldId === 'custpage_bankaccount' )
            {
                const bankAccountId = record.getValue({ fieldId: 'custpage_bankaccount' });
                const layoutField = record.getField({ fieldId: 'custpage_layout' });
                lib.clearFieldOptions( layoutField );
                lib.insertLayoutOptions(bankAccountId, layoutField)
            }
            else if( context.fieldId === 'interest' || context.fieldId === 'fine' || context.fieldId === 'rebate' || context.fieldId === 'discount' )
            {
                lib.setAmount( record, context.line );
            }
        }

        /**
         * @function
         * @return {boolean}
         */
        function search()
        {
            var record = currentRecord.get();
            console.log('reocord: ', record)
            const startDate = record.getValue({ fieldId: 'startdate' });
            const endDate = record.getValue({ fieldId: 'enddate' });
			const status = record.getValue({ fieldId: 'status' });
            const job = record.getValue({ fieldId: 'job_security' });
            var obj = record.getSublist({
                sublistId: 'list'
            });
            console.log('Sublist: ', JSON.stringify(obj));
			if( startDate && endDate && status)
            {
                const numLines = record.getLineCount({ sublistId: 'list' });
                console.log('numline', numLines);
                // lib.clearInstallments( record, numLines );
                for( var i = numLines; i > 0; i-- )
                {
                    record.selectLine({ sublistId: 'list', line: i-1 });
                    // record.setCurrentSublistValue({ sublistId: 'list', fieldId: 'delete', value: true, ignoreFieldChange: true });
                    // record.commitLine({ sublistId: 'list' });
                    record.removeLine({ sublistId: 'list', line: i-1, ignoreRecalc: true });
                }
                const bankAccount = record.getValue({ fieldId: 'custpage_bankaccount' });
                const vendor = record.getValue({ fieldId: 'vendor' });
                const customer = record.getValue({ fieldId: 'customer' });
                const layout = record.getValue({ fieldId: 'custpage_layout' });
                lib.getInstallments( startDate, endDate, status,job, bankAccount, vendor, customer, layout, record );
            }
            else
            {
                dialog.alert({
                    title: lib.label().alert,
                    message: lib.label().filtersMandatory
                });
                return false;
            }
        }

        /**
         * @function
         */
        function lineInit()
        {
            const record = currentRecord.get();
            const id = record.getCurrentSublistValue({ sublistId: 'list', fieldId: 'id' });
            if( id ) {
                document.getElementById('list_addedit').disabled = false;
                document.getElementById('list_insert').disabled = true;
            }
        }

        /**
         * @function
         */
        function sublistChanged()
        {
            document.getElementById('list_addedit').disabled = true;
        }

        /**
         * @function
         * @return {boolean}
         */
        function validateDelete()
        {
            const record = currentRecord.get();
            const _delete = record.getCurrentSublistValue({ sublistId: 'list', fieldId: 'delete' });
            return _delete === 'true';
        }

        /**
         * @function
         * @return {boolean}
         */
        function validateInsert()
        {
            return false;
        }

        /**
         * @function
         */
        function selectAll()
        {
            const record = currentRecord.get();
            lib.markAll( record, true );
        }

        /**
         * @function
         */
        function unselectAll()
        {
            const record = currentRecord.get();
            lib.markAll( record, false );
        }

        return {
            fieldChanged: fieldChanged,
            search: search,
            lineInit: lineInit,
            sublistChanged: sublistChanged,
            validateDelete: validateDelete,
            validateInsert: validateInsert,
            selectAll: selectAll,
            unselectAll: unselectAll
        }
    });
