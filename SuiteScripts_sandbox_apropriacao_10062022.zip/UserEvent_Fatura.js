/**
*@NApiVersion 2.x
*@NScriptType UserEventScript
*
* UserEventScript_telaConfigParcelamento.ts
* 
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/log", "N/search", "N/runtime"], function (require, exports, record_1, log_1, search_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.afterSubmit = exports.beforeSubmit = void 0;
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    search_1 = __importDefault(search_1);
    runtime_1 = __importDefault(runtime_1);
    var beforeSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var oldRecord = ctx.oldRecord;
        log_1.default.error('estou rodando', 'done');
        if (ctx.type == ctx.UserEventType.CREATE) {
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == 3) {
                var item = runtime_1.default.getCurrentScript().getParameter({ name: 'custscript_lrc_correcaofatura' });
                newRecord.setSublistValue({
                    fieldId: 'item',
                    sublistId: 'item',
                    value: item,
                    line: 0
                });
                newRecord.setSublistValue({
                    fieldId: 'amount',
                    sublistId: 'item',
                    value: 0,
                    line: 0
                });
                log_1.default.error('item', item);
            }
        }
        else if (ctx.type == ctx.UserEventType.EDIT) {
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == 2) {
                if (newRecord.getValue('custbody_lrc_fatura_principal') != oldRecord.getValue('custbody_lrc_fatura_principal')) {
                    throw new Error('Não é permitida a alteração da fatura principal.');
                }
            }
        }
        else if (ctx.type == ctx.UserEventType.DELETE) {
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == 2) {
                if (newRecord.getValue('custbody_lrc_fatura_principal')) {
                    throw new Error('Não é permitido excluir da fatura, pois há uma fatura principal preenchida.');
                }
            }
        }
    };
    exports.beforeSubmit = beforeSubmit;
    var afterSubmit = function (ctx) {
        var newRecord = ctx.newRecord;
        var oldRecord = ctx.oldRecord;
        var faturaprincipal = newRecord.getValue('custbody_lrc_fatura_principal');
        if (ctx.type == ctx.UserEventType.CREATE) {
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == 2) {
                if (newRecord.getValue('custbody_lrc_parcela_cancelada') == true) {
                    var totalParcela = newRecord.getValue('total');
                    var searchPrincipal = search_1.default.create({
                        type: 'invoice',
                        filters: ['internalid', 'IS', faturaprincipal],
                        columns: ['total']
                    }).run().getRange({
                        start: 0,
                        end: 1
                    });
                    var recordFaturaPrincipal = record_1.default.load({
                        type: 'invoice',
                        id: searchPrincipal[0].id
                    });
                    var total = recordFaturaPrincipal.getValue('total');
                    recordFaturaPrincipal.setValue({
                        fieldId: 'total',
                        value: Number(total) - Number(totalParcela)
                    });
                    recordFaturaPrincipal.save({
                        ignoreMandatoryFields: true
                    });
                }
            }
            else if (newRecord.getValue('custbody_lrc_tipo_fatura') == 3) {
                var somaparcelas_1 = 0;
                var total = newRecord.getValue('total');
                var searchParcelas = search_1.default.create({
                    type: 'invoice',
                    filters: ['custbody_lrc_fatura_principal', 'IS', faturaprincipal],
                    columns: ['total']
                }).run().each(function (result) {
                    var totalLookup = search_1.default.lookupFields({
                        type: 'invoice',
                        id: result.id,
                        columns: ['total']
                    });
                    somaparcelas_1 += Number(totalLookup['total']);
                    return true;
                });
                newRecord.setValue({
                    fieldId: 'total',
                    value: Number(total) + somaparcelas_1
                });
                var qtLinhas = newRecord.getLineCount({
                    sublistId: 'custpage_lrc_item'
                });
                var valoritens = 0;
                for (var i = 0; i < qtLinhas; i++) {
                    var valoritem = newRecord.getSublistValue({
                        fieldId: 'amount',
                        sublistId: 'item',
                        line: i
                    });
                    valoritens += Number(valoritem);
                }
                newRecord.setSublistValue({
                    fieldId: 'amount',
                    sublistId: 'item',
                    line: 0,
                    value: valoritens
                });
                newRecord.save({
                    ignoreMandatoryFields: true
                });
            }
        }
        else if (ctx.type == ctx.UserEventType.EDIT) {
            if (newRecord.getValue('custbody_lrc_tipo_fatura') == 2) {
                if (newRecord.getValue('total') != oldRecord.getValue('total')) {
                    var searchPrincipal = search_1.default.create({
                        type: 'invoice',
                        filters: ['internalid', 'IS', faturaprincipal],
                        columns: ['total']
                    }).run().getRange({
                        start: 0,
                        end: 1
                    });
                    var recordFaturaPrincipal = record_1.default.load({
                        type: 'invoice',
                        id: searchPrincipal[0].id
                    });
                    var totalPrincipal = Number(recordFaturaPrincipal.getValue('total'));
                    var diferençaTotal = Number(newRecord.getValue('total')) - Number(oldRecord.getValue('total'));
                    recordFaturaPrincipal.setValue({
                        fieldId: 'total',
                        value: totalPrincipal + diferençaTotal
                    });
                    recordFaturaPrincipal.save({
                        ignoreMandatoryFields: true
                    });
                }
            }
        }
    };
    exports.afterSubmit = afterSubmit;
});
