/**
 /**
 * @NApiVersion 2.1
 * @NScriptType MassUpdateScript
 */
 define(['N/log', 'N/record'], (record) => {
const each = (params) => {
    log.audit('params', params);
}

return {each}
});