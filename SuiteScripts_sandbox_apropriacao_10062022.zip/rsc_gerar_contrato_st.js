/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */

const custPage = 'custpage_rsc_';

define(['N/log', 'N/record', 'N/ui/serverWidget', 'N/url'], function(log, record, serverWidget, url) {
function onRequest(context) {
     /* ******************* FIELD TYPES ****************** *
    * ■ CHECKBOX ■ CURRENCY ■ DATE ■ DATETIMETZ ■ EMAIL   *
    * ■ FILE ■ FLOAT ■ HELP ■ INLINEHTML ■ INTEGER        *
    * ■ IMAGE ■ LABEL ■ LONGTEXT ■ MULTISELECT ■ PASSPORT *
    * ■ PERCENT ■ PHONE ■ SELECT ■ RADIO ■ RICHTEXT       *
    * ■ TEXT ■ TEXTAREA ■ TIMEOFDAY ■ URL                 *
    * *************************************************** */ 

    /* ****************** SUBLIST TYPES ***************** *
    * ■ INLINEEDITOR ■ EDITOR ■ LIST ■ STATICLIST         *
    * *************************************************** */ 

    const request = context.request;
    const response = context.response;

    const form = serverWidget.createForm({
        title: 'Gerar Contrato'
    });

    form.clientScriptModulePath = "./reparcelamento_cnab/rsc_gerar_contrato_ct.js";

    const informacoesPrincipais = form.addFieldGroup({
        id: custPage+'informacoes_principais',
        label: 'Informações Principais'
    });    
        
    const classificacao = form.addFieldGroup({
        id: custPage+'classificacao',
        label: 'Classificação'
    });    

    const dadosContrato = form.addFieldGroup({
        id: custPage+'dados_contrato',
        label: 'Dados do Contrato'
    });

    const faturamento = form.addFieldGroup({
        id: custPage+'faturamento',
        label: 'Faturamento'
    });

    const contratoParcelas = form.addFieldGroup({
        id: custPage+'contrato_parcelas',
        label: 'Contrato e Parcelas'
    });

    var atencao, clienteTarefa, dataInicio, dataTermino, entregarAte, memo, subsidiaria, localidade, nomeProjeto, valorFinanciamento, quantidadeParcelas, valoresParcelas,
    numeroProposta, statusContrato, unidade, objetoFinanciamento;

    if (request.method == 'GET') {
        log.audit('context GET', context);

        atencao = form.addField({
            id: custPage+'atencao',
            type: serverWidget.FieldType.INLINEHTML,
            label: ' ',
        });

        atencao.defaultValue = 'Favor preencher todos os campos (inclusive memo, se houver). '+
        '<B>OBSERVAÇÕES:</B> '+
        '1. <B>Data Término:</B> deve ser maior que a <i>"Data Início"</i>; '+
        '2. <B>Entregar Até:</B> deve ser maior que a <i>"Data Término"</i> e a <i>"Data Início"</i>. <br><br>';

        atencao.updateLayoutType({
            layoutType: serverWidget.FieldLayoutType.OUTSIDEABOVE
        });

        // Informações Principais
        clienteTarefa = form.addField({
            id: custPage+'cliente_tarefa',
            type: serverWidget.FieldType.SELECT,
            label: 'Cliente : Tarefa',
            container: custPage+'informacoes_principais',
            source: 'customer'
        });

        clienteTarefa.isMandatory = true;

        dataInicio = form.addField({
            id: custPage+'data_inicio',
            type: serverWidget.FieldType.DATE,
            label: 'Data Início',
            container: custPage+'informacoes_principais'
        });

        dataInicio.isMandatory = true;

        dataTermino = form.addField({
            id: custPage+'data_termino',
            type: serverWidget.FieldType.DATE,
            label: 'Data Término',
            container: custPage+'informacoes_principais'
        });

        dataTermino.isMandatory = true;

        entregarAte = form.addField({
            id: custPage+'entregar_ate',
            type: serverWidget.FieldType.DATE,
            label: 'Entregar Até',
            container: custPage+'informacoes_principais'
        });

        entregarAte.isMandatory = true;

        memo = form.addField({
            id: custPage+'memo',
            type: serverWidget.FieldType.TEXT,
            label: 'Memo',
            container: custPage+'informacoes_principais'
        });

        // Classificação
        subsidiaria = form.addField({
            id: custPage+'subsidiaria',
            type: serverWidget.FieldType.SELECT,
            label: 'Subsidiária',
            container: custPage+'classificacao',
            source: 'subsidiary'
        });
        
        subsidiaria.isMandatory = true;

        localidade = form.addField({
            id: custPage+'localidade',
            type: serverWidget.FieldType.SELECT,
            label: 'Localidade',
            container: custPage+'classificacao',
            source: 'location'
        });

        localidade.isMandatory = true;

        nomeProjeto = form.addField({
            id: custPage+'nome_projeto',
            type: serverWidget.FieldType.SELECT,
            label: 'Nome do Projeto',
            container: custPage+'classificacao',
            source: 'job'
        });

        nomeProjeto.isMandatory = true; 

        // Dados do Contrato
        numeroProposta = form.addField({
            id: custPage+'numero_proposta',
            type: serverWidget.FieldType.TEXT,
            label: 'Número da Proposta',
            container: custPage+'dados_contrato'
        });

        numeroProposta.isMandatory = true;

        statusContrato = form.addField({
            id: custPage+'status_contrato',
            type: serverWidget.FieldType.SELECT,
            label: 'Status do Contrato',
            container: custPage+'dados_contrato',
            source: 'customlist_rsc_lista_status_contrato'
        });

        statusContrato.isMandatory = true;

        unidade = form.addField({
            id: custPage+'unidade',
            type: serverWidget.FieldType.SELECT,
            label: 'Unidade',
            container: custPage+'dados_contrato',
            source: 'customrecord_rsc_unidades_empreendimento'
        });

        unidade.isMandatory = true;

        // Faturamento
        valorFinanciamento = form.addField({
            id: custPage+'valor_financiamento',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Valor do Financiamento',
            container: custPage+'faturamento'
        });

        valorFinanciamento.isMandatory = true;

        quantidadeParcelas = form.addField({
            id: custPage+'quantidade_parcelas',
            type: serverWidget.FieldType.SELECT,
            label: 'Quantidade de Parcelas',
            container: custPage+'faturamento'
        });

        quantidadeParcelas.addSelectOption({
            value: '',
            text: ''
        });

        const quantasVezes = 360;
        var x = 0;
        var n = 0;

        while (n < quantasVezes) {
            x += 1;
            quantidadeParcelas.addSelectOption({
                value: x, 
                text: x+'x'
            });
            n++;
        }

        quantidadeParcelas.isMandatory = true;

        valoresParcelas = form.addField({
            id: custPage+'valores_parcelas',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Valores das Parcelas',
            container: custPage+'faturamento'
        });

        valoresParcelas.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });
        
        form.addSubmitButton({
            label: 'Gerar Contrato'
        });

        // form.addButton({
        //     id: custPage+'gerar_contrato',
        //     label: 'Gerar Contrato',
        //     functionName: 'gerarContrato'
        // });
    } else {
        log.audit('context POST', context);

        const parameters = request.parameters;
        log.audit('parameters', parameters);
        
        clienteTarefa = form.addField({
            id: custPage+'cliente_tarefa',
            type: serverWidget.FieldType.TEXT,
            label: 'Cliente : Tarefa',
            container: custPage+'informacoes_principais'
            // ,
            // source: 'customer'
        });

        clienteTarefa.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        // Informações Principais
        dataInicio = form.addField({
            id: custPage+'data_inicio',
            type: serverWidget.FieldType.DATE,
            label: 'Data Início',
            container: custPage+'informacoes_principais'
        });

        dataInicio.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        dataTermino = form.addField({
            id: custPage+'data_termino',
            type: serverWidget.FieldType.DATE,
            label: 'Data Término',
            container: custPage+'informacoes_principais'
        });

        dataTermino.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        entregarAte = form.addField({
            id: custPage+'entregar_ate',
            type: serverWidget.FieldType.DATE,
            label: 'Entregar Até',
            container: custPage+'informacoes_principais'
        });

        entregarAte.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        memo = form.addField({
            id: custPage+'memo',
            type: serverWidget.FieldType.TEXT,
            label: 'Memo',
            container: custPage+'informacoes_principais'
        });

        memo.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        clienteTarefa.defaultValue = parameters.inpt_custpage_rsc_cliente_tarefa;
        dataInicio.defaultValue = parameters.custpage_rsc_data_inicio;
        dataTermino.defaultValue = parameters.custpage_rsc_data_termino;
        entregarAte.defaultValue = parameters.custpage_rsc_entregar_ate;
        memo.defaultValue = parameters.custpage_rsc_memo;

        // Classificação
        subsidiaria = form.addField({
            id: custPage+'subsidiaria',
            type: serverWidget.FieldType.TEXT,
            label: 'Subsidiária',
            container: custPage+'classificacao'
            // ,
            // source: 'subsidiary'
        });

        subsidiaria.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        localidade = form.addField({
            id: custPage+'localidade',
            type: serverWidget.FieldType.TEXT,
            label: 'Localidade',
            container: custPage+'classificacao'
            // ,
            // source: 'location'
        });

        localidade.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        nomeProjeto = form.addField({
            id: custPage+'nome_projeto',
            type: serverWidget.FieldType.TEXT,
            label: 'Nome do Projeto',
            container: custPage+'classificacao'
            // ,
            // source: 'job'
        });

        nomeProjeto.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        subsidiaria.defaultValue = parameters.inpt_custpage_rsc_subsidiaria;
        localidade.defaultValue = parameters.inpt_custpage_rsc_localidade;
        nomeProjeto.defaultValue = parameters.inpt_custpage_rsc_nome_projeto;

        // Dados do Contrato
        numeroProposta = form.addField({
            id: custPage+'numero_proposta',
            type: serverWidget.FieldType.TEXT,
            label: 'Número da Proposta',
            container: custPage+'dados_contrato'
        });

        numeroProposta.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        statusContrato = form.addField({
            id: custPage+'status_contrato',
            type: serverWidget.FieldType.TEXT,
            label: 'Status do Contrato',
            container: custPage+'dados_contrato'
            // ,
            // source: 'customlist_rsc_lista_status_contrato'
        });

        statusContrato.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        unidade = form.addField({
            id: custPage+'unidade',
            type: serverWidget.FieldType.TEXT,
            label: 'Unidade',
            container: custPage+'dados_contrato'
            // ,
            // source: 'customrecord_rsc_unidades_empreendimento'
        });

        unidade.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        numeroProposta.defaultValue = parameters.custpage_rsc_numero_proposta;
        statusContrato.defaultValue = parameters.inpt_custpage_rsc_status_contrato;
        unidade.defaultValue = parameters.inpt_custpage_rsc_unidade;

        // Faturamento
        valorFinanciamento = form.addField({
            id: custPage+'valor_financiamento',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Valor do Financiamento',
            container: custPage+'faturamento'
        });

        valorFinanciamento.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        quantidadeParcelas = form.addField({
            id: custPage+'quantidade_parcelas',
            type: serverWidget.FieldType.TEXT,
            label: 'Quantidade de Parcelas',
            container: custPage+'faturamento'
        });

        quantidadeParcelas.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });

        valoresParcelas = form.addField({
            id: custPage+'valores_parcelas',
            type: serverWidget.FieldType.CURRENCY,
            label: 'Valores das Parcelas',
            container: custPage+'faturamento'
        });

        valoresParcelas.updateDisplayType({
            displayType: serverWidget.FieldDisplayType.INLINE
        });        
        
        valorFinanciamento.defaultValue = parameters.custpage_rsc_valor_financiamento;
        quantidadeParcelas.defaultValue = parameters.inpt_custpage_rsc_quantidade_parcelas;
        valoresParcelas.defaultValue = parameters.custpage_rsc_valores_parcelas;

        var criarContrato = gerarContrato(parameters);

        if (criarContrato.status == 'Sucesso') {
            gerarParcelas({
                idContrato: criarContrato.id,
                parameters: parameters
            });

            var idContrato = form.addField({
                id: custPage+'id_contrato',
                type: serverWidget.FieldType.INTEGER,
                label: 'ID Contrato',
                container: custPage+'contrato_parcelas'
            });

            idContrato.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            var link_id_contrato = form.addField({
                id: custPage+'link_contrato',
                type: serverWidget.FieldType.URL,
                label: 'Link Contrato',
                container: custPage+'contrato_parcelas'
            });

            link_id_contrato.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            }); 

            idContrato.defaultValue = criarContrato.id;

            link_id_contrato.linkText = 'Fatura Nº '+criarContrato.documento;

            link_id_contrato.defaultValue = criarContrato.url;

            form.addButton({
                id: custPage+'checar_status',
                label: 'Checar Status',
                functionName: 'checarStatus'
            });

            form.addButton({
                id: custPage+'voltar',
                label: 'Voltar',
                functionName: 'voltar'
            });
        } else {
            var erro = form.addField({
                id: custPage+'erro',
                type: serverWidget.FieldType.TEXTAREA,
                label: 'Erro',
                container: custPage+'contrato_parcelas'
            });

            erro.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            erro.defaultValue = criarContrato.msg;

            form.addButton({
                id: custPage+'voltar',
                label: 'Voltar'
            });
        }
    }

    response.writePage({
        pageObject: form
    });
}

function gerarParcelas(dados) {
    log.audit('gerarParcelas', dados);

    var campos = {
        entity: dados.parameters.custpage_rsc_cliente_tarefa,
        startdate: formatData(dados.parameters.custpage_rsc_data_inicio),
        enddate: formatData(dados.parameters.custpage_rsc_data_termino),
        duedate: dados.parameters.custpage_rsc_data_inicio,
        memo: 'ª Parcela',
        subsidiary: dados.parameters.custpage_rsc_subsidiaria,
        location: dados.parameters.custpage_rsc_localidade,
        custbody_lrc_fatura_principal: dados.idContrato,
        custbody_rsc_projeto_obra_gasto_compra: dados.parameters.custpage_rsc_nome_projeto,
        custbody_rsc_indice: 8, // Índice
        custbody_rsc_data_juros: dados.parameters.custpage_rsc_data_inicio, // Data Juros
        custbody_rsc_terms: 3,
        custbody_enl_operationtypeid: 2,
        custbody_enl_order_documenttype: 2,
        custbody_rsc_nr_proposta: dados.parameters.custpage_rsc_numero_proposta,
        custbody_rsc_status_contrato: dados.parameters.custpage_rsc_status_contrato,
        custbody_rsc_data_venda: today(),
        custbody_rsc_vlr_venda: dados.parameters.custpage_rsc_valor_financiamento,
        custbody_rsc_tran_unidade: dados.parameters.custpage_rsc_unidade,
        items: {
            item: 287,
            quantity: 1,
            rate: dados.parameters.custpage_rsc_valores_parcelas,
            amount: dados.parameters.custpage_rsc_valores_parcelas,
            quantidadeParcelas: dados.parameters.custpage_rsc_quantidade_parcelas,
            valoresParcelas: dados.parameters.custpage_rsc_valores_parcelas
        }        
    }

    var arrayParcelas = [];

    for (i=0; i<Number(dados.parameters.custpage_rsc_quantidade_parcelas); i++) {
        arrayParcelas.push(campos);
    }

    log.audit('arrayParcelas', arrayParcelas);

    arrayParcelas.forEach(function (parcela, indice) {
        log.audit('Parcela nº', indice+1);

        const num = indice+1;

        const novaParcela = record.create({
            type: 'customsale_rsc_financiamento',
            isDynamic: true
        });
    
        Object.keys(parcela).forEach(function(bodyField) {
            if (bodyField == 'memo') {
                novaParcela.setValue({
                    fieldId: bodyField, 
                    value: num + campos[bodyField]
                });
            } else if (bodyField == 'duedate' || bodyField == 'custbody_rsc_data_juros') {
                var splitParcela = campos[bodyField].split('/');
        
                var entregarAte = new Date(splitParcela[2], (splitParcela[1]-1)+indice, splitParcela[0]);

                novaParcela.setValue({
                    fieldId: bodyField, 
                    value: entregarAte
                });
            } else {
                novaParcela.setValue({
                    fieldId: bodyField, 
                    value: campos[bodyField]
                });
            }
        });
    
        novaParcela.selectNewLine({
            sublistId: 'item' 
        });
    
        Object.keys(parcela.items).forEach(function(sublistField) {
            novaParcela.setCurrentSublistValue({
                sublistId: 'item',
                fieldId: sublistField,
                value: campos.items[sublistField]
            });
        });
    
        novaParcela.commitLine({
            sublistId: 'item'
        });
    
        var novaParcelaId, erro;
        
        try {
            novaParcelaId = novaParcela.save();
            log.audit('novaParcelaId ('+indice+')', novaParcelaId);
        } catch(e) {
            log.error('Erro novaParcelaId ('+indice+')', e);
            erro = e;
        }
    });
}

function urlTransacao(dados) {
    return url.resolveRecord({
        recordType: dados.registro,
        recordId: dados.id
    });
}

function today() {
    const hoje = new Date();

    var dia = hoje.getDate() <= 9 ? '0' + hoje.getDate() : hoje.getDate();
    var mes = (hoje.getMonth()+1) <= 9 ? '0' + (hoje.getMonth()+1) : (hoje.getMonth()+1);
    var ano = hoje.getFullYear();
    var hora = hoje.getHours();
    var minutos = hoje.getMinutes();
    var segundos = hoje.getSeconds();

    return new Date(dia + '/' + mes + '/' + ano + ' ' + hora + ':' + minutos + ':' + segundos);
}

function formatData(data) {
    var partesData = data.split("/");

    var novaData = new Date(partesData[2], partesData[1] - 1, partesData[0]);

    return novaData;
}

function gerarContrato(dados) {
    log.audit('gerarContrato', dados);

    var campos = {
        entity: dados.custpage_rsc_cliente_tarefa,
        startdate: formatData(dados.custpage_rsc_data_inicio),
        approvalstatus: 2,
        enddate: formatData(dados.custpage_rsc_data_termino),
        duedate: formatData(dados.custpage_rsc_entregar_ate),
        memo: dados.custpage_rsc_memo,
        subsidiary: dados.custpage_rsc_subsidiaria,
        location: dados.custpage_rsc_localidade,
        custbody_enl_operationtypeid: 2,
        custbody_enl_order_documenttype: 2,
        custbody_rsc_projeto_obra_gasto_compra: dados.custpage_rsc_nome_projeto,
        custbody_rsc_nr_proposta: dados.custpage_rsc_numero_proposta,
        custbody_rsc_status_contrato: dados.custpage_rsc_status_contrato,
        custbody_rsc_data_venda: today(),
        custbody_rsc_vlr_venda: dados.custpage_rsc_valor_financiamento,
        custbody_rsc_tran_unidade: dados.custpage_rsc_unidade,
        items: {
            item: 287,
            quantity: 1,
            rate: dados.custpage_rsc_valor_financiamento,
            amount: dados.custpage_rsc_valor_financiamento,
            quantidadeParcelas: dados.custpage_rsc_quantidade_parcelas,
            valoresParcelas: dados.custpage_rsc_valores_parcelas
        }        
    }

    const fatura = record.create({
        type: 'invoice',
        isDynamic: true
    });

    Object.keys(campos).forEach(function(bodyField) {
        fatura.setValue({
            fieldId: bodyField, 
            value: campos[bodyField]
        });
    });

    fatura.selectNewLine({
        sublistId: 'item' 
    });

    Object.keys(campos.items).forEach(function(sublistField) {
        fatura.setCurrentSublistValue({
            sublistId: 'item',
            fieldId: sublistField,
            value: campos.items[sublistField]
        });
    });

    fatura.commitLine({
        sublistId: 'item'
    });

    var faturaId, erro;
    
    try {
        faturaId = fatura.save();
        log.audit('faturaId', faturaId);
    } catch(e) {
        log.error('Erro Fatura', e);
        erro = e;
    }

    return faturaId ? {
        status: 'Sucesso', 
        id: faturaId,
        documento: record.load({type: 'invoice', id: faturaId}).getValue('tranid'),
        url: urlTransacao({registro: 'invoice', id: faturaId})
    } : {
        status: 'Erro', 
        msg: erro.message
    };
}

return {
    onRequest: onRequest
}
});
