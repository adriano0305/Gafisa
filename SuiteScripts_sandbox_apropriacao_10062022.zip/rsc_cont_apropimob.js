/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/ui/serverWidget', 'N/query', 'N/record'],
    
    (widget, query, record) => {
        function createList(assistant , records){

            // Create a sublist for the results.
            var resultsSublist = assistant.addSublist(
                {
                    id : 'results_sublist',
                    label : 'Calculo Apropriação',
                    type : widget.SublistType.INLINEEDITOR
                }
            );
            // Get the column names.
            var columnNames = Object.keys( records[0] );

            // Loop over the column names...
            for ( i = 0; i < columnNames.length; i++ ) {

                // Add the column to the sublist as a field.
                resultsSublist.addField(
                    {
                        id: 'custpage_results_sublist_col_' + i,
                        type: widget.FieldType.TEXT,
                        label: columnNames[i],
                    }
                );

            }
            // Add the records to the sublist...
            for ( r = 0; r < records.length; r++ ) {

                // Get the record.
                var record = records[r];

                // Loop over the columns...
                for ( c = 0; c < columnNames.length; c++ ) {

                    // Get the column name.
                    var column = columnNames[c];

                    // Get the column value.
                    var value = record[column];
                    if ( value != null ) {
                        value = value.toString();
                    }

                    // Add the column value.
                    resultsSublist.setSublistValue(
                        {
                            id : 'custpage_results_sublist_col_' + c,
                            line : r,
                            value : value
                        }
                    );

                }

            }
        }

        function writePeriodo(assistant){
            var periodo = assistant.addField({id: 'periodo', label: 'Selecione o periodo para execução', type: 'text'});
        }

        function getFatores(assistant){
            var queryResults = query.runSuiteQL({
                query: 'select substr(name,1,4) from subsidiary\n' +
                    'where 1 = custrecordtpemp'
            });
            var records = queryResults.asMappedResults();
            createList(assistant, records);
        }

        function getCalculo(assistant){
            var queryResults = query.runSuiteQL({
                query: 'select substr(name,1,4) from subsidiary\n' +
                    'where 1 = custrecordtpemp'
            });
            var records = queryResults.asMappedResults();
            createList(assistant, records);
        }
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
           var assistant = widget.createAssistant({title:"Apropriação Imobiliaria", hideNavBar: false});

           assistant.addStep({id:'periodo', label:'Selecione o periodo'});
           assistant.addStep({id:'fatores', label:'Conferencia dos fatores'});
           assistant.addStep({id:'calculo', label:'Conferir os calculos'});
           assistant.errorHtml = null;

           if (scriptContext.request.method == 'GET'){
               writePeriodo(assistant);
               assistant.currentStep = 'periodo';
               scriptContext.response.writePage(assistant);
           } else if (scriptContext.request.parameters.next === 'Finish'){
                   assistant.finishedHtml = "Enviaremos uma confirmação por email no final da execução";
                    scriptContext.response.writePage(assistant);
               } else if (scriptContext.request.parameters.cancel) {
                    //assistant.sendRedirect();
               } else if ( assistant.getNextStep().id === 'fatores' ){
                    if (assistant.getLastStep().id === 'calculo'){
                       writePeriodo(assistant);
                       assistant.currentStep = 'periodo';
                        scriptContext.response.writePage(assistant);
                    } else {
                        getFatores(assistant);
                       assistant.currentStep = assistant.getNextStep();
                        scriptContext.response.writePage(assistant);
                    }
           } else if (assistant.getNextStep().id === 'calculo'){
               getCalculo(assistant);
               assistant.currentStep = assistant.getNextStep();
               scriptContext.response.writePage(assistant);
           } else {
               writePeriodo(assistant);
               assistant.currentStep = assistant.getNextStep();
               scriptContext.response.writePage(assistant);
           }


        }

        return {onRequest}

    });
