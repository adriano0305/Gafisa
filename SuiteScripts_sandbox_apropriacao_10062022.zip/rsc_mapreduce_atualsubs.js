/**
 *@NApiVersion 2.x
 *@NScriptType MapReduceScript
 */
define(['N/query', 'N/record'], function(query, record) {

    function getInputData() {
        return query.runSuiteQL({
            query: "SELECT name, id, custrecord_rsc_pen_atual_fornecedores " +
            "FROM subsidiary " +
            "WHERE custrecord_rsc_pen_atual_fornecedores = 'T'"
        }).asMappedResults(); //seleciona nome, id e checkbox do registro subsidiária onde o checkbox está marcado
    }

    function reduce(reduceContext) {

        //Pegar dados
        var queryR = reduceContext.values //retorna array
        var queryResult = JSON.parse(queryR[0]) //retorna JSON
        var newSubId = queryResult.id //id das novas subsidiárias
        var subRecord = record.load({ //retorna os ids das novas subsidiárias
            type:'subsidiary',
            id:newSubId
        })
        var queryVendor = query.runSuiteQL({ //retorna id de todos os fornecedores para serem carregados no load
            query: "SELECT id " +
            "FROM vendor " +
            "WHERE custentity_rsc_pende_atua_subsdiarias = 'T'"
        }).asMappedResults();
      
        //carregar registro de fornecedor e criar array
        try{
            for (var i = 0; i < queryVendor.length; i++){ //para cada fornecedor checar se a subsidiária está na sublista
                var vendorId=queryVendor[i].id
                var vendorRecord=record.load({ //carrega todos os registros de fornecedores
                    type: 'vendor',
                    id: vendorId,
                });
                var lastLine = vendorRecord.getLineCount({sublistId: "submachine"}) //contar linhas na array submachine, retorna a quantidade de linhas e não o índice da array
                var currentSubArray = new Array()

                //colocar cada subsidiária em Fornecedores no array
                for(var j = 0; j < lastLine; j++){
                    var subId = vendorRecord.getSublistValue({ //id das subsidiarias que estão na sublista de fornecedores
                        sublistId: 'submachine',
                        fieldId: 'subsidiary',
                        line:j
                    });
                    
                    currentSubArray.push(Number(subId)) //coloca o sublistValue no array para checar se ele existe

                }

                //verificação da array e adição da subsidiária na lista, caso ela não esteja na sublista do fornecedor
                var index = currentSubArray.indexOf(newSubId) //índice na array
                
                if (index == -1){ //se o id não está no array, adiciona subsidiária  
                    vendorRecord.setSublistValue({
                        fieldId: 'subsidiary',
                        sublistId: 'submachine',
                        line:lastLine,
                        value:newSubId
                    })

                    vendorRecord.save({ignoreMandatoryFields: false})
                }

            }
        }catch (erro) {log.error("Erro", erro)}

        //desmarcar campo pendente atualização fornecedores na subsidiária que foi adicionada
        subRecord.setValue({
            fieldId: 'custrecord_rsc_pen_atual_fornecedores',
            value: false
        })
        subRecord.save({ignoreMandatoryFields: true})
    }


    return {
        getInputData: getInputData,
        reduce: reduce,
    }
});
