/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
define(['N/record'], function(record) {

   function fieldChanged(context) {
      var new_record = context.newRecord;

      // var field_name_categ = new_record.getValue({
      //    fieldId: 'name'
      // })

      // var field_class_categ = new_record.getValue({
      //    fieldId: 'custrecord_rsc_class_categ_item'
      // })

      var all_page = record.load({
         type: 'customrecord_rsc_rec_categ_item',
         // id: 2,
      })

      // var class_item_categ = all_page.getValue('custrecord_rsc_class_categ_item')
      log.debug('ALL PAGE', all_page)

      var field_name = new_record.getValue({
         fieldId: 'itemid'
      })

      var field_categ_item = new_record.getValue({
         fieldId: 'custitem_rsc_categ_item'
      })
      var field_class = new_record.getValue({
         fieldId: 'class'
      })


      // if (field_class !== class_item_categ) {
      //    log.debug('É DIFRENTE')
      // }

      log.debug('Nome: ', field_name)
      log.debug('Categoria item: ', field_categ_item)
      log.debug('Classe: ', field_class)  
      
   }


   return {
      fieldChanged: fieldChanged,
   }
});
