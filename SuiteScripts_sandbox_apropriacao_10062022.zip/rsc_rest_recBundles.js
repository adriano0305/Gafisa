/**
 *@NApiVersion 2.x
 *@NScriptType Restlet
 */
define([], function() {

    function _get(context) {
        return 'foda-se'
    } 

    function _post(context) {
       return context.nome
    }

    // function _put(context) {
        
    // }

    // function _delete(context) {
        
    // }

    return {
        get: _get,
        post: _post
        // put: _put,
        // delete: _delete
    }
});






