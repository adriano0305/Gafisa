/**
*@NApiVersion 2.x
*@NScriptType MapReduceScript
*
* MapReduce_fluxoEscritura.js
*
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/record", "N/log", "N/runtime"], function (require, exports, search_1, record_1, log_1, runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.monthDiff = exports.map = exports.getInputData = void 0;
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    log_1 = __importDefault(log_1);
    runtime_1 = __importDefault(runtime_1);
    var getInputData = function () {
        var scriptAtual = runtime_1.default.getCurrentScript();
        var parametro = JSON.parse(scriptAtual.getParameter({ name: 'custscript_rsc_info_projeto' }));
        log_1.default.error('parametro', parametro);
        return search_1.default.create({
            type: 'invoice',
            filters: [
                ['custbody_rsc_projeto_obra_gasto_compra', 'IS', parametro],
                'AND',
                ['mainline', 'IS', 'T'],
                "AND",
                ['internalid','IS', 85788],
                "AND",
                ["shipping", "is", "F"],
                "AND",
                ["taxline", "is", "F"],
                "AND",
                ["approvalstatus", "anyof", "2", "1"]
            ],
            columns: [
                'custbody_rsc_projeto_obra_gasto_compra',
            ]
        });
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        var req = JSON.parse(ctx.value);
        log_1.default.error('req', ctx);
        // Log.error("req.id",req.id) 
        var invoice = req.values;
        var empreendimentoLookup = search_1.default.lookupFields({
            type: 'job',
            id: invoice.custbody_rsc_projeto_obra_gasto_compra.value,
            columns: [
                'custentity_rsc_project_date_habite',
                'custentity_rsc_juros',
                'custentity_rsc_novo_inidice'
            ]
        });
        var searchIndice;
        var indice = false;
        if (empreendimentoLookup.custentity_rsc_novo_inidice[0].value) {
            searchIndice = search_1.default.lookupFields({
                type: 'customrecord_rsc_correction_unit',
                id: empreendimentoLookup.custentity_rsc_novo_inidice[0].value,
                columns: [
                    'custrecord_rsc_ucr_calc_base_item'
                ]
            });
            indice = true;
        }
        search_1.default.create({
            type: "customsale_rsc_financiamento",
            filters: [
                ['custbody_lrc_fatura_principal', 'IS', req.id],
                'AND',
                ['mainline', 'IS', 'T'],
                "AND",
                ["shipping", "is", "F"],
                "AND",
                ["taxline", "is", "F"],
                "AND",
                ["status", "anyof", "CuTrSale123:A"],
                "AND",
                ['internalid', 'ANYOF', [85793,85794]]
            ],
            columns: [
                'duedate',
                'total'
            ]
        }).run().each(function (result) {
            log_1.default.error('empreendimentoLookup.custentity_rsc_juros', empreendimentoLookup.custentity_rsc_juros);
            var dataHabite = String(empreendimentoLookup.custentity_rsc_project_date_habite);
            dataHabite = dataHabite.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            dataHabite = new Date(dataHabite);
            log_1.default.error('dataHabite', dataHabite);
            var dataParcela = String(result.getValue('duedate'));
            dataParcela = dataParcela.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            dataParcela = new Date(dataParcela);
            log_1.default.error('dataParcela', dataParcela);
            if (dataParcela.getTime() > dataHabite.getTime()) {
                var addLinha = true
                var linePrice = 0;
                log_1.default.error('result', result.id);
                // var parsedjurosAA = parseFloat(empreendimentoLookup.custentity_rsc_juros);
                // var base = (1 + (parsedjurosAA / 100));
                // var expoente = ((1 / 12));
                // log_1.default.error('base', base);
                // log_1.default.error('expoente', expoente);
                // var juros = (Math.pow(Number(base), Number(expoente)) - 1).toFixed(6);
                // log_1.default.error('juros', juros);
                // var mes = exports.monthDiff(dataParcela, dataHabite);
                // log_1.default.error('mes', mes);
                // var valorSublista = ((Number(result.getValue('total')) * Number(juros)) * mes).toFixed(2);
                // log_1.default.error('valorSublista', valorSublista);
                var searchPrice = search_1.default.lookupFields({
                    type: 'customrecord_rsc_correction_unit',
                    id: 5,
                    columns: [
                        'custrecord_rsc_ucr_calc_base_item'
                    ]
                });
                var recordFinanciamento = record_1.default.load({
                    type: 'customsale_rsc_financiamento',
                    id: result.id
                });
                var line = recordFinanciamento.getLineCount({
                    sublistId: 'item'
                });
                var INCC = false;
                var dataAtual = new Date('10/15/2021');
                for (var i = 0; i < line; i++) {
                    var itemLinha = recordFinanciamento.getSublistValue({
                        fieldId: 'item_display',
                        sublistId: 'item',
                        line: i
                    });
                    if (itemLinha == "INCC") {
                        dataAtual.setDate(dataAtual.getDate() - 1)
                        recordFinanciamento.setSublistValue({
                            fieldId: 'custcol_rsc_vigenciafim',
                            sublistId: 'item',
                            line: i,
                            value: dataAtual
                        });
                        INCC = true;
                    }
                    if(itemLinha == searchPrice.custrecord_rsc_ucr_calc_base_item[0].text){
                        log_1.default.error('entrou no if?', 'done');
                        addLinha = false;
                        linePrice = i;
                    }
                }
                log_1.default.error('linePrice', linePrice);
                if(addLinha){
                    linePrice = line;
                    recordFinanciamento.setSublistValue({
                        sublistId: 'item',
                        fieldId: 'item',
                        value: searchPrice.custrecord_rsc_ucr_calc_base_item[0].value,
                        line: linePrice
                    });
                }
                recordFinanciamento.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    value: 0,
                    line: linePrice
                });
                recordFinanciamento.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    value: 0,
                    line: linePrice
                });
                recordFinanciamento.setSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_rsc_datavigenciainicio',
                    line: line + 1,
                    value: new Date('10/15/2021')
                })
                if (INCC && indice) {
                    if(addLinha){
                        recordFinanciamento.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'item',
                            value: searchIndice.custrecord_rsc_ucr_calc_base_item[0].value,
                            line: line + 1
                        });
                        recordFinanciamento.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'amount',
                            value: 0,
                            line: line + 1
                        });
                        recordFinanciamento.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'rate',
                            value: 0,
                            line: line + 1
                        });
                        recordFinanciamento.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'custcol_rsc_datavigenciainicio',
                            line: line + 1,
                            value: new Date('10/15/2021')
                        });
                    }else{
                        recordFinanciamento.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'item',
                            value: searchIndice.custrecord_rsc_ucr_calc_base_item[0].value,
                            line: line
                        });
                        recordFinanciamento.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'amount',
                            value: 0,
                            line: line
                        });
                        recordFinanciamento.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'rate',
                            value: 0,
                            line: line
                        });
                        recordFinanciamento.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'custcol_rsc_datavigenciainicio',
                            line: line,
                            value: new Date('10/15/2021')
                        });
                    }
                }
                try{
                    recordFinanciamento.save({
                        ignoreMandatoryFields: true
                    });
                }catch(e){
                    log_1.default.error('Error', e);
                }
                
            }
            return true;
        });
        var recordJob = record_1.default.load({
            type: "job",
            id: invoice.custbody_rsc_projeto_obra_gasto_compra.value
        });
        recordJob.setValue({
            fieldId: 'custentity_rsc_liberado',
            value: true
        });
        recordJob.setValue({
            fieldId: 'custentity27',
            value: 'Concluido'
        });
        recordJob.save({
            ignoreMandatoryFields: true
        });
    };
    exports.map = map;
    var monthDiff = function (d1, d2) {
        var d1Y = d1.getFullYear();
        log_1.default.error('d1Y', d1Y);
        var d2Y = d2.getFullYear();
        log_1.default.error('d2Y', d2Y);
        var diffYears = (d1Y - d2Y) * 12;
        log_1.default.error('diffYears', diffYears);
        var d1M = d1.getMonth();
        log_1.default.error('d1M', d1M);
        var d2M = d2.getMonth();
        log_1.default.error('d2M', d2M);
        var diffMonths = d1M - d2M;
        log_1.default.error('diffMonths', diffMonths);
        diffYears + diffMonths;
        log_1.default.error('monthDiff', diffYears + diffMonths);
        return diffYears + diffMonths;
    };
    exports.monthDiff = monthDiff;
});