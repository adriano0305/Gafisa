/**
*@NApiVersion 2.x
*@NScriptType ClientScript
*
* ClientScript para definir as funções da criação de modelo de requisição das tarefas de modelo de projeto
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/currentRecord", "N/url", "N/ui/dialog"], function (require, exports, record_1, currentRecord_1, url_1, dialog_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.habite = exports.pageInit = void 0;
    record_1 = __importDefault(record_1);
    currentRecord_1 = __importDefault(currentRecord_1);
    url_1 = __importDefault(url_1);
    dialog_1 = __importDefault(dialog_1);
    var pageInit = function (ctx) {
    };
    exports.pageInit = pageInit;
    var habite = function () {
        var currRecord = currentRecord_1.default.get();
        var projetoRecord = record_1.default.load({
            id: currRecord.id,
            type: "job"
        });
        var dataHabite = projetoRecord.getValue('custentity_rsc_project_date_habite');
        if (dataHabite) {
            var url = url_1.default.resolveScript({
                scriptId: 'customscript_rsc_suitelet_btt_habite',
                deploymentId: 'customdeploy_rsc_suitelet_btt_habite',
                params: {
                    empreendimentoId: currRecord.id
                }
            });
            dialog_1.default.alert({
                title: 'Aviso!',
                message: 'O processo do Habite-se será realizado.'
            });
            window.location.replace(url);
        }
        else {
            dialog_1.default.alert({
                title: 'Aviso!',
                message: 'Data Habite-se deve ser preenchida.'
            });
        }
    };
    exports.habite = habite;
});
