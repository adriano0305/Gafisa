/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*
*
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/record", "N/redirect", "N/task"], function (require, exports, record_1, redirect_1, task_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    record_1 = __importDefault(record_1);
    redirect_1 = __importDefault(redirect_1);
    task_1 = __importDefault(task_1);
    var onRequest = function (ctx) {
        var parametros = ctx.request.parameters;
        var empreendimentoId = parametros.empreendimentoId;
        var taskReparcelamento = task_1.default.create({
            taskType: task_1.default.TaskType.MAP_REDUCE,
            scriptId: 'customscript_rsc_btt_habitemap',
            deploymentId: 'customdeploy_rsc_btt_map_habite',
            params: {
                custscript_rsc_info_projeto: empreendimentoId
            }
        });
        taskReparcelamento.submit();
        var recordJob = record_1.default.load({
            type: 'job',
            id: empreendimentoId
        });
        recordJob.setValue({
            fieldId: 'custentity27',
            value: 'Em andamento'
        });
        recordJob.save({
            ignoreMandatoryFields: true,
            enableSourcing: true
        });
        redirect_1.default.toRecord({
            type: 'job',
            id: empreendimentoId
        });
    };
    exports.onRequest = onRequest;
});
